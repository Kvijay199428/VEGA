package com.vegatrader.model.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "futures_instruments")
public class FuturesInstrument {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "instrument_key", unique = true)
    private String instrumentKey;
    private String exchangeToken;
    private String tradingSymbol;
    private String name;
    private String shortName;
    private String segment;
    private String exchange;

    @Column(name = "lot_size")
    private Integer lotSize;
    @Column(name = "tick_size")
    private Double tickSize;

    private String underlyingKey;
    private String underlyingSymbol;
    private String underlyingType;

    private LocalDate expiry;
    private String expiryStr;
    private Integer minimumLot;
    private Boolean weekly;

    private LocalDateTime lastSynced;

    // Getters/Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getInstrumentKey() {
        return instrumentKey;
    }

    public void setInstrumentKey(String k) {
        this.instrumentKey = k;
    }

    public String getTradingSymbol() {
        return tradingSymbol;
    }

    public void setTradingSymbol(String s) {
        this.tradingSymbol = s;
    }

    public void setExchangeToken(String exchangeToken) {
        this.exchangeToken = exchangeToken;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    public void setLotSize(Integer lotSize) {
        this.lotSize = lotSize;
    }

    public void setTickSize(Double tickSize) {
        this.tickSize = tickSize;
    }

    public void setUnderlyingKey(String underlyingKey) {
        this.underlyingKey = underlyingKey;
    }

    public void setUnderlyingSymbol(String underlyingSymbol) {
        this.underlyingSymbol = underlyingSymbol;
    }

    public void setUnderlyingType(String underlyingType) {
        this.underlyingType = underlyingType;
    }

    public void setExpiry(LocalDate expiry) {
        this.expiry = expiry;
    }

    public void setExpiryStr(String expiryStr) {
        this.expiryStr = expiryStr;
    }

    public void setMinimumLot(Integer minimumLot) {
        this.minimumLot = minimumLot;
    }

    public void setWeekly(Boolean weekly) {
        this.weekly = weekly;
    }

    public void setLastSynced(LocalDateTime lastSynced) {
        this.lastSynced = lastSynced;
    }
}
