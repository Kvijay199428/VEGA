package com.vegatrader.model.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "index_instruments")
public class IndexInstrument {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "instrument_key", unique = true)
    private String instrumentKey;
    private String exchangeToken;
    private String tradingSymbol;
    private String name;
    private String shortName;
    private String segment;
    private String exchange;

    private LocalDateTime lastSynced;

    // Getters/Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getInstrumentKey() {
        return instrumentKey;
    }

    public void setInstrumentKey(String k) {
        this.instrumentKey = k;
    }

    public String getTradingSymbol() {
        return tradingSymbol;
    }

    public void setTradingSymbol(String s) {
        this.tradingSymbol = s;
    }

    public void setExchangeToken(String exchangeToken) {
        this.exchangeToken = exchangeToken;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    public void setLastSynced(LocalDateTime lastSynced) {
        this.lastSynced = lastSynced;
    }
}
