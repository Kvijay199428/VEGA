package com.vegatrader.model.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Trading position entity.
 */
@Entity
@Table(name = "positions")
public class TradingPosition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "instrument_key")
    private String instrumentKey;

    @Column(name = "trading_symbol")
    private String tradingSymbol;

    @Column(name = "exchange")
    private String exchange;

    private String product;

    private Integer quantity;

    @Column(name = "buy_quantity")
    private Integer buyQuantity;

    @Column(name = "sell_quantity")
    private Integer sellQuantity;

    @Column(name = "buy_price")
    private Double buyPrice;

    @Column(name = "sell_price")
    private Double sellPrice;

    @Column(name = "average_price")
    private Double averagePrice;

    private Double ltp;

    @Column(name = "pnl")
    private Double pnl;

    @Column(name = "day_buy_quantity")
    private Integer dayBuyQuantity;

    @Column(name = "day_sell_quantity")
    private Integer daySellQuantity;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getInstrumentKey() {
        return instrumentKey;
    }

    public void setInstrumentKey(String instrumentKey) {
        this.instrumentKey = instrumentKey;
    }

    public String getTradingSymbol() {
        return tradingSymbol;
    }

    public void setTradingSymbol(String tradingSymbol) {
        this.tradingSymbol = tradingSymbol;
    }

    public String getExchange() {
        return exchange;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getBuyQuantity() {
        return buyQuantity;
    }

    public void setBuyQuantity(Integer buyQuantity) {
        this.buyQuantity = buyQuantity;
    }

    public Integer getSellQuantity() {
        return sellQuantity;
    }

    public void setSellQuantity(Integer sellQuantity) {
        this.sellQuantity = sellQuantity;
    }

    public Double getBuyPrice() {
        return buyPrice;
    }

    public void setBuyPrice(Double buyPrice) {
        this.buyPrice = buyPrice;
    }

    public Double getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(Double sellPrice) {
        this.sellPrice = sellPrice;
    }

    public Double getAveragePrice() {
        return averagePrice;
    }

    public void setAveragePrice(Double averagePrice) {
        this.averagePrice = averagePrice;
    }

    public Double getLtp() {
        return ltp;
    }

    public void setLtp(Double ltp) {
        this.ltp = ltp;
    }

    public Double getPnl() {
        return pnl;
    }

    public void setPnl(Double pnl) {
        this.pnl = pnl;
    }

    public Integer getDayBuyQuantity() {
        return dayBuyQuantity;
    }

    public void setDayBuyQuantity(Integer dayBuyQuantity) {
        this.dayBuyQuantity = dayBuyQuantity;
    }

    public Integer getDaySellQuantity() {
        return daySellQuantity;
    }

    public void setDaySellQuantity(Integer daySellQuantity) {
        this.daySellQuantity = daySellQuantity;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
}
