package com.vegatrader.model.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "equity_instruments")
public class EquityInstrument {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "instrument_key", unique = true)
    private String instrumentKey;
    private String exchangeToken;
    private String tradingSymbol;
    private String name;
    private String shortName;
    private String isin;
    private String segment;
    private String exchange;

    @Column(name = "lot_size")
    private Integer lotSize;
    @Column(name = "tick_size")
    private Double tickSize;
    private String securityType;

    private Boolean mtfEnabled;
    private Double mtfBracket;
    private Double intradayMargin;
    private Double intradayLeverage;

    private LocalDateTime lastSynced;

    // Getters/Setters (omitted for brevity, Lombok would be better but sticking to
    // standard Java)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getInstrumentKey() {
        return instrumentKey;
    }

    public void setInstrumentKey(String k) {
        this.instrumentKey = k;
    }

    public String getTradingSymbol() {
        return tradingSymbol;
    }

    public void setTradingSymbol(String s) {
        this.tradingSymbol = s;
    }

    public String getExchange() {
        return exchange;
    }

    public void setExchange(String e) {
        this.exchange = e;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String s) {
        this.segment = s;
    }

    // Default setters for reflection/parsing
    public void setExchangeToken(String exchangeToken) {
        this.exchangeToken = exchangeToken;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public void setIsin(String isin) {
        this.isin = isin;
    }

    public void setLotSize(Integer lotSize) {
        this.lotSize = lotSize;
    }

    public void setTickSize(Double tickSize) {
        this.tickSize = tickSize;
    }

    public void setSecurityType(String securityType) {
        this.securityType = securityType;
    }

    public void setMtfEnabled(Boolean mtfEnabled) {
        this.mtfEnabled = mtfEnabled;
    }

    public void setMtfBracket(Double mtfBracket) {
        this.mtfBracket = mtfBracket;
    }

    public void setIntradayMargin(Double intradayMargin) {
        this.intradayMargin = intradayMargin;
    }

    public void setIntradayLeverage(Double intradayLeverage) {
        this.intradayLeverage = intradayLeverage;
    }

    public void setLastSynced(LocalDateTime lastSynced) {
        this.lastSynced = lastSynced;
    }
}
