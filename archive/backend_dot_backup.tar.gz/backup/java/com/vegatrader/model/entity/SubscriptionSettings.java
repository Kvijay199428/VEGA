package com.vegatrader.model.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Subscription settings entity for user feed preferences.
 */
@Entity
@Table(name = "subscription_settings")
public class SubscriptionSettings {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "instrument_key", nullable = false)
    private String instrumentKey;

    @Column(name = "feed_level")
    private String feedLevel; // ltpc, full, quote

    @Column(name = "is_active")
    private boolean isActive = true;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getInstrumentKey() {
        return instrumentKey;
    }

    public void setInstrumentKey(String instrumentKey) {
        this.instrumentKey = instrumentKey;
    }

    public String getFeedLevel() {
        return feedLevel;
    }

    public void setFeedLevel(String feedLevel) {
        this.feedLevel = feedLevel;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
