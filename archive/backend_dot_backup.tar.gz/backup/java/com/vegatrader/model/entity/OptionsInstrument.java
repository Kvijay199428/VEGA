package com.vegatrader.model.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

/**
 * Options instrument entity.
 */
@Entity
@Table(name = "options_instruments")
public class OptionsInstrument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "instrument_key", unique = true)
    private String instrumentKey;

    @Column(name = "trading_symbol")
    private String tradingSymbol;

    @Column(name = "underlying_key")
    private String underlyingKey;

    @Column(name = "underlying_symbol")
    private String underlyingSymbol;

    @Column(name = "strike_price")
    private Double strikePrice;

    @Column(name = "expiry")
    private LocalDate expiry;

    @Column(name = "option_type")
    private String optionType; // CE or PE

    @Column(name = "lot_size")
    private Integer lotSize;

    @Column(name = "tick_size")
    private Double tickSize;

    @Column(name = "exchange")
    private String exchange;

    @Column(name = "segment")
    private String segment;

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getInstrumentKey() {
        return instrumentKey;
    }

    public void setInstrumentKey(String instrumentKey) {
        this.instrumentKey = instrumentKey;
    }

    public String getTradingSymbol() {
        return tradingSymbol;
    }

    public void setTradingSymbol(String tradingSymbol) {
        this.tradingSymbol = tradingSymbol;
    }

    public String getUnderlyingKey() {
        return underlyingKey;
    }

    public void setUnderlyingKey(String underlyingKey) {
        this.underlyingKey = underlyingKey;
    }

    public String getUnderlyingSymbol() {
        return underlyingSymbol;
    }

    public void setUnderlyingSymbol(String underlyingSymbol) {
        this.underlyingSymbol = underlyingSymbol;
    }

    public Double getStrikePrice() {
        return strikePrice;
    }

    public void setStrikePrice(Double strikePrice) {
        this.strikePrice = strikePrice;
    }

    public LocalDate getExpiry() {
        return expiry;
    }

    public void setExpiry(LocalDate expiry) {
        this.expiry = expiry;
    }

    public String getOptionType() {
        return optionType;
    }

    public void setOptionType(String optionType) {
        this.optionType = optionType;
    }

    public Integer getLotSize() {
        return lotSize;
    }

    public void setLotSize(Integer lotSize) {
        this.lotSize = lotSize;
    }

    public Double getTickSize() {
        return tickSize;
    }

    public void setTickSize(Double tickSize) {
        this.tickSize = tickSize;
    }

    public String getExchange() {
        return exchange;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }
}
