package com.vegatrader.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Authentication response DTO.
 */
public class AuthResponse {

    @JsonProperty("access_token")
    private String accessToken;

    @JsonProperty("token_type")
    private String tokenType;

    private String email;

    @JsonProperty("full_name")
    private String fullName;

    public AuthResponse() {
    }

    public AuthResponse(String accessToken, String tokenType, String email, String fullName) {
        this.accessToken = accessToken;
        this.tokenType = tokenType;
        this.email = email;
        this.fullName = fullName;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}
