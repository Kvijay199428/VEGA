package com.vegatrader.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Order request DTO.
 */
public class OrderRequest {

    @JsonProperty("instrument_token")
    private String instrumentToken;

    private Integer quantity;

    private String product; // D (Delivery), I (Intraday)

    @JsonProperty("order_type")
    private String orderType; // MARKET, LIMIT, SL, SL-M

    @JsonProperty("transaction_type")
    private String transactionType; // BUY, SELL

    private Double price;

    @JsonProperty("trigger_price")
    private Double triggerPrice;

    @JsonProperty("disclosed_quantity")
    private Integer disclosedQuantity;

    private String validity; // DAY, IOC

    @JsonProperty("is_amo")
    private Boolean isAmo;

    public OrderRequest() {
    }

    // Getters and setters
    public String getInstrumentToken() {
        return instrumentToken;
    }

    public void setInstrumentToken(String instrumentToken) {
        this.instrumentToken = instrumentToken;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getTriggerPrice() {
        return triggerPrice;
    }

    public void setTriggerPrice(Double triggerPrice) {
        this.triggerPrice = triggerPrice;
    }

    public Integer getDisclosedQuantity() {
        return disclosedQuantity;
    }

    public void setDisclosedQuantity(Integer disclosedQuantity) {
        this.disclosedQuantity = disclosedQuantity;
    }

    public String getValidity() {
        return validity;
    }

    public void setValidity(String validity) {
        this.validity = validity;
    }

    public Boolean getAmo() {
        return isAmo;
    }

    public void setAmo(Boolean amo) {
        isAmo = amo;
    }
}
