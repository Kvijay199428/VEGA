package com.vegatrader.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Strategy request/response DTO.
 */
public class StrategyDto {

    private Long id;
    private String name;
    private String description;

    @JsonProperty("strategy_type")
    private String strategyType;

    private String config;

    @JsonProperty("is_active")
    private boolean isActive;

    @JsonProperty("user_id")
    private Long userId;

    public StrategyDto() {
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStrategyType() {
        return strategyType;
    }

    public void setStrategyType(String strategyType) {
        this.strategyType = strategyType;
    }

    public String getConfig() {
        return config;
    }

    public void setConfig(String config) {
        this.config = config;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
