package com.vegatrader.service;

import com.vegatrader.model.entity.OptionsInstrument;
import com.vegatrader.repository.OptionsInstrumentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Instrument service for instrument data and search.
 */
@Service
public class InstrumentService {

    private static final Logger logger = LoggerFactory.getLogger(InstrumentService.class);

    private final OptionsInstrumentRepository optionsRepository;

    public InstrumentService(OptionsInstrumentRepository optionsRepository) {
        this.optionsRepository = optionsRepository;
    }

    /**
     * Get all unique underlyings for options.
     */
    public List<String> getOptionsUnderlyings(String exchange) {
        return optionsRepository.findDistinctUnderlyingKeysByExchange(exchange);
    }

    /**
     * Get expiries for an underlying.
     */
    public List<LocalDate> getExpiries(String underlyingKey) {
        return optionsRepository.findDistinctExpiriesByUnderlyingKey(underlyingKey);
    }

    /**
     * Get option chain from database.
     */
    public Map<String, Object> getOptionChain(String underlyingKey, LocalDate expiry) {
        List<OptionsInstrument> instruments = optionsRepository.findByUnderlyingKeyAndExpiry(underlyingKey, expiry);

        Map<Double, Map<String, OptionsInstrument>> strikeMap = new TreeMap<>();
        for (OptionsInstrument inst : instruments) {
            strikeMap.computeIfAbsent(inst.getStrikePrice(), k -> new HashMap<>())
                    .put(inst.getOptionType(), inst);
        }

        List<Map<String, Object>> chain = new ArrayList<>();
        for (Map.Entry<Double, Map<String, OptionsInstrument>> entry : strikeMap.entrySet()) {
            Map<String, Object> strike = new HashMap<>();
            strike.put("strike_price", entry.getKey());
            strike.put("call", entry.getValue().get("CE"));
            strike.put("put", entry.getValue().get("PE"));
            chain.add(strike);
        }

        Map<String, Object> result = new HashMap<>();
        result.put("underlying_key", underlyingKey);
        result.put("expiry", expiry);
        result.put("data", chain);
        result.put("count", chain.size());
        return result;
    }

    /**
     * Search instruments by trading symbol.
     */
    public List<OptionsInstrument> searchInstruments(String query, int limit) {
        // Simple search - in production, use full-text search
        return optionsRepository.findAll().stream()
                .filter(i -> i.getTradingSymbol() != null &&
                        i.getTradingSymbol().toLowerCase().contains(query.toLowerCase()))
                .limit(limit)
                .collect(Collectors.toList());
    }

    /**
     * Get instrument by key.
     */
    public Optional<OptionsInstrument> getInstrumentByKey(String instrumentKey) {
        return optionsRepository.findByInstrumentKey(instrumentKey);
    }
}
