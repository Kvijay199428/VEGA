package com.vegatrader.service;

import com.vegatrader.model.entity.UpstoxToken;
import com.vegatrader.repository.UpstoxTokenRepository;
import com.vegatrader.upstox.api.websocket.settings.SubscriptionTier;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Provider for Upstox access tokens from database.
 * 
 * <p>
 * Fetches tokens from upstox_tokens table and detects subscription tier.
 * 
 * @since 3.0.0
 */
@Component
public class UpstoxTokenProvider {

    private final UpstoxTokenRepository tokenRepository;

    public UpstoxTokenProvider(UpstoxTokenRepository tokenRepository) {
        this.tokenRepository = tokenRepository;
    }

    /**
     * Gets the primary access token.
     * 
     * @return access token string
     * @throws TokenNotFoundException if no valid token found
     */
    public String getAccessToken() {
        return tokenRepository.findByIsPrimaryTrue()
                .map(UpstoxToken::getAccessToken)
                .filter(token -> token != null && !token.isEmpty())
                .orElseThrow(() -> new TokenNotFoundException("No primary access token found"));
    }

    /**
     * Gets access token by API name.
     * 
     * @param apiName the API name
     * @return access token string
     * @throws TokenNotFoundException if token not found
     */
    public String getAccessToken(String apiName) {
        return tokenRepository.findByApiName(apiName)
                .map(UpstoxToken::getAccessToken)
                .filter(token -> token != null && !token.isEmpty())
                .orElseThrow(() -> new TokenNotFoundException("No token found for API: " + apiName));
    }

    /**
     * Gets access token by API index.
     * 
     * @param apiIndex the API index (0 = PRIMARY)
     * @return access token string
     * @throws TokenNotFoundException if token not found
     */
    public String getAccessToken(int apiIndex) {
        return tokenRepository.findByApiIndex(apiIndex)
                .map(UpstoxToken::getAccessToken)
                .filter(token -> token != null && !token.isEmpty())
                .orElseThrow(() -> new TokenNotFoundException("No token found for index: " + apiIndex));
    }

    /**
     * Gets the primary token entity.
     * 
     * @return UpstoxToken entity
     * @throws TokenNotFoundException if not found
     */
    public UpstoxToken getPrimaryToken() {
        return tokenRepository.findByIsPrimaryTrue()
                .orElseThrow(() -> new TokenNotFoundException("No primary token found"));
    }

    /**
     * Detects the subscription tier (Normal or Plus).
     * 
     * <p>
     * Detection logic:
     * <ul>
     * <li>Check token purpose for "PLUS" keyword</li>
     * <li>Check API name for "plus" indicator</li>
     * <li>Default to NORMAL if not detected</li>
     * </ul>
     * 
     * @return detected subscription tier
     */
    public SubscriptionTier detectTier() {
        Optional<UpstoxToken> primary = tokenRepository.findByIsPrimaryTrue();

        if (primary.isPresent()) {
            UpstoxToken token = primary.get();

            // Check purpose field
            String purpose = token.getPurpose();
            if (purpose != null && purpose.toUpperCase().contains("PLUS")) {
                return SubscriptionTier.PLUS;
            }

            // Check API name
            String apiName = token.getApiName();
            if (apiName != null && apiName.toLowerCase().contains("plus")) {
                return SubscriptionTier.PLUS;
            }
        }

        // Default to NORMAL
        return SubscriptionTier.NORMAL;
    }

    /**
     * Checks if a valid primary token exists.
     * 
     * @return true if valid token exists
     */
    public boolean hasValidToken() {
        return tokenRepository.findByIsPrimaryTrue()
                .map(UpstoxToken::getAccessToken)
                .map(token -> token != null && !token.isEmpty())
                .orElse(false);
    }

    /**
     * Gets the number of active tokens.
     * 
     * @return count of active tokens
     */
    public long getActiveTokenCount() {
        return tokenRepository.findByIsActive(1).size();
    }

    /**
     * Exception thrown when token is not found.
     */
    public static class TokenNotFoundException extends RuntimeException {
        public TokenNotFoundException(String message) {
            super(message);
        }
    }
}
