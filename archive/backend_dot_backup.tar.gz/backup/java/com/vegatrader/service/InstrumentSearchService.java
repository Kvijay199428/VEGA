package com.vegatrader.service;

import com.vegatrader.model.entity.OptionsInstrument;
import com.vegatrader.repository.OptionsInstrumentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Instrument search service with fuzzy matching.
 */
@Service
public class InstrumentSearchService {

    private static final Logger logger = LoggerFactory.getLogger(InstrumentSearchService.class);

    private final OptionsInstrumentRepository optionsRepository;

    public InstrumentSearchService(OptionsInstrumentRepository optionsRepository) {
        this.optionsRepository = optionsRepository;
    }

    /**
     * Search instruments by query.
     */
    public List<Map<String, Object>> search(String query, String exchange, String segment, int limit) {
        query = query.toLowerCase().trim();

        List<OptionsInstrument> allInstruments = optionsRepository.findAll();

        String finalQuery = query;
        return allInstruments.stream()
                .filter(i -> matchesQuery(i, finalQuery, exchange, segment))
                .limit(limit)
                .map(this::toSearchResult)
                .collect(Collectors.toList());
    }

    /**
     * Get popular/trending instruments.
     */
    public List<Map<String, Object>> getPopularInstruments(int limit) {
        // Return commonly traded instruments
        List<Map<String, Object>> popular = new ArrayList<>();

        String[] symbols = { "NIFTY", "BANKNIFTY", "RELIANCE", "TCS", "INFY", "HDFCBANK" };
        for (String symbol : symbols) {
            if (popular.size() >= limit)
                break;
            Map<String, Object> inst = new HashMap<>();
            inst.put("symbol", symbol);
            inst.put("name", symbol);
            inst.put("popular", true);
            popular.add(inst);
        }

        return popular;
    }

    /**
     * Autocomplete suggestions.
     */
    public List<String> autocomplete(String prefix, int limit) {
        prefix = prefix.toLowerCase();

        List<OptionsInstrument> allInstruments = optionsRepository.findAll();

        String finalPrefix = prefix;
        return allInstruments.stream()
                .map(OptionsInstrument::getTradingSymbol)
                .filter(s -> s != null && s.toLowerCase().startsWith(finalPrefix))
                .distinct()
                .limit(limit)
                .collect(Collectors.toList());
    }

    private boolean matchesQuery(OptionsInstrument instrument, String query, String exchange, String segment) {
        boolean matches = true;

        // Symbol match
        if (query.length() > 0) {
            String symbol = instrument.getTradingSymbol();
            String underlying = instrument.getUnderlyingSymbol();
            matches = (symbol != null && symbol.toLowerCase().contains(query)) ||
                    (underlying != null && underlying.toLowerCase().contains(query));
        }

        // Exchange filter
        if (exchange != null && !exchange.isEmpty()) {
            matches = matches && exchange.equalsIgnoreCase(instrument.getExchange());
        }

        // Segment filter
        if (segment != null && !segment.isEmpty()) {
            matches = matches && segment.equalsIgnoreCase(instrument.getSegment());
        }

        return matches;
    }

    private Map<String, Object> toSearchResult(OptionsInstrument instrument) {
        Map<String, Object> result = new HashMap<>();
        result.put("instrument_key", instrument.getInstrumentKey());
        result.put("trading_symbol", instrument.getTradingSymbol());
        result.put("underlying_symbol", instrument.getUnderlyingSymbol());
        result.put("exchange", instrument.getExchange());
        result.put("segment", instrument.getSegment());
        result.put("strike_price", instrument.getStrikePrice());
        result.put("expiry", instrument.getExpiry());
        result.put("option_type", instrument.getOptionType());
        result.put("underlying_key", instrument.getUnderlyingKey()); // Add this
        return result;
    }
}
