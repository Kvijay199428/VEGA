package com.vegatrader.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vegatrader.client.UpstoxClient;
import com.vegatrader.model.entity.UpstoxToken;
import com.vegatrader.repository.UpstoxTokenRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Sector service for sectoral indices data.
 */
@Service
public class SectorService {

    private static final Logger logger = LoggerFactory.getLogger(SectorService.class);

    private final UpstoxClient upstoxClient;
    private final UpstoxTokenRepository tokenRepository;

    // Sectoral indices instrument keys
    private static final Map<String, String> SECTOR_INDICES = Map.ofEntries(
            Map.entry("NIFTY_BANK", "NSE_INDEX|Nifty Bank"),
            Map.entry("NIFTY_IT", "NSE_INDEX|Nifty IT"),
            Map.entry("NIFTY_PHARMA", "NSE_INDEX|Nifty Pharma"),
            Map.entry("NIFTY_AUTO", "NSE_INDEX|Nifty Auto"),
            Map.entry("NIFTY_FMCG", "NSE_INDEX|Nifty FMCG"),
            Map.entry("NIFTY_METAL", "NSE_INDEX|Nifty Metal"),
            Map.entry("NIFTY_REALTY", "NSE_INDEX|Nifty Realty"),
            Map.entry("NIFTY_ENERGY", "NSE_INDEX|Nifty Energy"),
            Map.entry("NIFTY_INFRA", "NSE_INDEX|Nifty Infra"),
            Map.entry("NIFTY_PSU_BANK", "NSE_INDEX|Nifty PSU Bank"),
            Map.entry("NIFTY_MEDIA", "NSE_INDEX|Nifty Media"),
            Map.entry("NIFTY_PRIVATE_BANK", "NSE_INDEX|Nifty Private Bank"),
            Map.entry("NIFTY_FIN_SERVICE", "NSE_INDEX|Nifty Financial Services"));

    public SectorService(UpstoxClient upstoxClient, UpstoxTokenRepository tokenRepository) {
        this.upstoxClient = upstoxClient;
        this.tokenRepository = tokenRepository;
    }

    /**
     * Get all sector indices with current values.
     */
    @Cacheable(value = "sectorData", key = "'all'")
    public Map<String, Object> getAllSectors() {
        String token = getAccessToken();
        try {
            String keys = String.join(",", SECTOR_INDICES.values());
            JsonNode response = upstoxClient.get("/market-quote/ltp?instrument_key=" + keys, token);

            Map<String, Object> result = new HashMap<>();
            result.put("status", "success");
            result.put("data", response.path("data"));
            result.put("sectors", SECTOR_INDICES.keySet());
            return result;
        } catch (Exception e) {
            logger.error("Failed to fetch sector data: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch sector data", e);
        }
    }

    /**
     * Get specific sector data.
     */
    public Map<String, Object> getSector(String sectorName) {
        String instrumentKey = SECTOR_INDICES.get(sectorName.toUpperCase());
        if (instrumentKey == null) {
            throw new RuntimeException("Unknown sector: " + sectorName);
        }

        String token = getAccessToken();
        try {
            JsonNode response = upstoxClient.get("/market-quote/quotes?instrument_key=" + instrumentKey, token);

            Map<String, Object> result = new HashMap<>();
            result.put("status", "success");
            result.put("sector", sectorName);
            result.put("data", response.path("data"));
            return result;
        } catch (Exception e) {
            logger.error("Failed to fetch sector {}: {}", sectorName, e.getMessage());
            throw new RuntimeException("Failed to fetch sector data", e);
        }
    }

    /**
     * Get available sectors list.
     */
    public List<Map<String, String>> getAvailableSectors() {
        List<Map<String, String>> sectors = new ArrayList<>();
        for (Map.Entry<String, String> entry : SECTOR_INDICES.entrySet()) {
            Map<String, String> sector = new HashMap<>();
            sector.put("name", entry.getKey());
            sector.put("instrument_key", entry.getValue());
            sectors.add(sector);
        }
        return sectors;
    }

    private String getAccessToken() {
        return tokenRepository.findByIsPrimaryTrue()
                .map(UpstoxToken::getAccessToken)
                .orElseThrow(() -> new RuntimeException("No access token available"));
    }
}
