package com.vegatrader.service;

import com.vegatrader.model.entity.AiStrategy;
import com.vegatrader.repository.AiStrategyRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

/**
 * Trading strategies service.
 */
@Service
public class StrategyService {

    private static final Logger logger = LoggerFactory.getLogger(StrategyService.class);

    private final AiStrategyRepository strategyRepository;

    public StrategyService(AiStrategyRepository strategyRepository) {
        this.strategyRepository = strategyRepository;
    }

    /**
     * Get all strategies.
     */
    public List<AiStrategy> getAllStrategies() {
        return strategyRepository.findAll();
    }

    /**
     * Get strategy by ID.
     */
    public Optional<AiStrategy> getStrategy(Long id) {
        return strategyRepository.findById(id);
    }

    /**
     * Create new strategy.
     */
    public AiStrategy createStrategy(AiStrategy strategy) {
        strategy.setCreatedAt(LocalDateTime.now());
        strategy.setActive(true);
        AiStrategy saved = strategyRepository.save(strategy);
        logger.info("Strategy created: {}", saved.getName());
        return saved;
    }

    /**
     * Update strategy.
     */
    public AiStrategy updateStrategy(Long id, AiStrategy updates) {
        AiStrategy strategy = strategyRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Strategy not found: " + id));

        if (updates.getName() != null)
            strategy.setName(updates.getName());
        if (updates.getDescription() != null)
            strategy.setDescription(updates.getDescription());
        if (updates.getStrategyType() != null)
            strategy.setStrategyType(updates.getStrategyType());
        if (updates.getConfig() != null)
            strategy.setConfig(updates.getConfig());
        strategy.setUpdatedAt(LocalDateTime.now());

        AiStrategy saved = strategyRepository.save(strategy);
        logger.info("Strategy updated: {}", saved.getName());
        return saved;
    }

    /**
     * Delete strategy.
     */
    public void deleteStrategy(Long id) {
        strategyRepository.deleteById(id);
        logger.info("Strategy deleted: {}", id);
    }

    /**
     * Toggle strategy active status.
     */
    public AiStrategy toggleStrategy(Long id) {
        AiStrategy strategy = strategyRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Strategy not found: " + id));
        strategy.setActive(!strategy.isActive());
        strategy.setUpdatedAt(LocalDateTime.now());
        return strategyRepository.save(strategy);
    }

    /**
     * Get active strategies.
     */
    public List<AiStrategy> getActiveStrategies() {
        return strategyRepository.findByIsActiveTrue();
    }
}
