package com.vegatrader.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vegatrader.client.UpstoxClient;
import com.vegatrader.model.entity.UpstoxToken;
import com.vegatrader.repository.UpstoxTokenRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Portfolio service for holdings, positions, and P&L.
 */
@Service
public class PortfolioService {

    private static final Logger logger = LoggerFactory.getLogger(PortfolioService.class);

    private final UpstoxClient upstoxClient;
    private final UpstoxTokenRepository tokenRepository;

    public PortfolioService(UpstoxClient upstoxClient, UpstoxTokenRepository tokenRepository) {
        this.upstoxClient = upstoxClient;
        this.tokenRepository = tokenRepository;
    }

    /**
     * Get user's holdings.
     */
    public Map<String, Object> getHoldings() {
        String token = getAccessToken();
        try {
            JsonNode response = upstoxClient.get("/portfolio/long-term-holdings", token);
            return parseResponse(response, "holdings");
        } catch (Exception e) {
            logger.error("Failed to fetch holdings: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch holdings", e);
        }
    }

    /**
     * Get current positions.
     */
    public Map<String, Object> getPositions() {
        String token = getAccessToken();
        try {
            JsonNode response = upstoxClient.get("/portfolio/short-term-positions", token);
            return parseResponse(response, "positions");
        } catch (Exception e) {
            logger.error("Failed to fetch positions: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch positions", e);
        }
    }

    /**
     * Get profit and loss report.
     */
    public Map<String, Object> getProfitLoss(String segment, String financialYear) {
        String token = getAccessToken();
        try {
            String endpoint = String.format("/portfolio/profit-loss-report?segment=%s&financial_year=%s", segment,
                    financialYear);
            JsonNode response = upstoxClient.get(endpoint, token);
            return parseResponse(response, "pnl");
        } catch (Exception e) {
            logger.error("Failed to fetch P&L: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch P&L", e);
        }
    }

    /**
     * Get portfolio summary.
     */
    public Map<String, Object> getSummary() {
        Map<String, Object> summary = new HashMap<>();

        try {
            Map<String, Object> holdings = getHoldings();
            Map<String, Object> positions = getPositions();

            summary.put("holdings", holdings);
            summary.put("positions", positions);
            summary.put("timestamp", System.currentTimeMillis());
        } catch (Exception e) {
            logger.warn("Partial summary due to error: {}", e.getMessage());
        }

        return summary;
    }

    private String getAccessToken() {
        return tokenRepository.findByIsPrimaryTrue()
                .map(UpstoxToken::getAccessToken)
                .orElseThrow(() -> new RuntimeException("No access token available"));
    }

    private Map<String, Object> parseResponse(JsonNode response, String key) {
        Map<String, Object> result = new HashMap<>();
        result.put("status", response.path("status").asText());
        result.put(key, response.path("data"));
        return result;
    }
}
