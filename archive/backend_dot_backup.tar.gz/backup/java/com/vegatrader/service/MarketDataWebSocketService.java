package com.vegatrader.service;

import com.vegatrader.model.entity.UpstoxToken;
import com.vegatrader.repository.UpstoxTokenRepository;
import com.vegatrader.optionchain.proto.MarketDataFeedOptionChainV3;
import okhttp3.*;
import okio.ByteString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Market data WebSocket service for real-time quotes.
 */
@Service
public class MarketDataWebSocketService {

    private static final Logger logger = LoggerFactory.getLogger(MarketDataWebSocketService.class);

    private final UpstoxTokenRepository tokenRepository;
    private final OkHttpClient httpClient;

    private WebSocket webSocket;
    private final Set<String> subscriptions = ConcurrentHashMap.newKeySet();
    private final Map<String, Consumer<Map<String, Object>>> listeners = new ConcurrentHashMap<>();
    private boolean connected = false;

    public MarketDataWebSocketService(UpstoxTokenRepository tokenRepository) {
        this.tokenRepository = tokenRepository;
        this.httpClient = new OkHttpClient.Builder()
                .readTimeout(30, TimeUnit.SECONDS)
                .pingInterval(15, TimeUnit.SECONDS)
                .build();
    }

    @PostConstruct
    public void initialize() {
        logger.info("Market data WebSocket service initialized");
    }

    @PreDestroy
    public void shutdown() {
        disconnect();
    }

    /**
     * Connect to Upstox WebSocket.
     */
    public void connect() {
        if (connected) {
            logger.info("Already connected to market data WebSocket");
            return;
        }

        String token = getAccessToken();
        if (token == null) {
            logger.warn("No access token available for WebSocket connection");
            return;
        }

        try {
            String authorizedUrl = getAuthorizedUrl(token);
            if (authorizedUrl == null) {
                logger.error("Failed to get authorized WebSocket URL");
                return;
            }

            Request request = new Request.Builder()
                    .url(authorizedUrl)
                    .build();

            webSocket = httpClient.newWebSocket(request, new WebSocketListener() {
                @Override
                public void onOpen(WebSocket ws, Response response) {
                    connected = true;
                    logger.info("📊 Connected to Upstox market data WebSocket V3");
                    resubscribeAll();
                }

                @Override
                public void onMessage(WebSocket ws, String text) {
                    handleTextMessage(text);
                }

                @Override
                public void onMessage(WebSocket ws, ByteString bytes) {
                    handleBinaryMessage(bytes.toByteArray());
                }

                @Override
                public void onFailure(WebSocket ws, Throwable t, Response response) {
                    connected = false;
                    logger.error("WebSocket failure: {}", t.getMessage());
                    scheduleReconnect();
                }

                @Override
                public void onClosed(WebSocket ws, int code, String reason) {
                    connected = false;
                    logger.info("WebSocket closed: {} - {}", code, reason);
                }
            });
        } catch (Exception e) {
            logger.error("Error setting up WebSocket connection: {}", e.getMessage());
        }
    }

    private String getAuthorizedUrl(String token) throws Exception {
        String authUrl = "https://api.upstox.com/v3/feed/market-data-feed/authorize";
        Request request = new Request.Builder()
                .url(authUrl)
                .header("Authorization", "Bearer " + token)
                .header("Accept", "*/*")
                .build();

        // Use a separate client that doesn't follow redirects automatically
        OkHttpClient authClient = new OkHttpClient.Builder()
                .followRedirects(false)
                .build();

        try (Response response = authClient.newCall(request).execute()) {
            if (response.code() == 302) {
                return response.header("Location");
            } else if (response.isSuccessful()) {
                // Parse JSON response if not redirected
                com.fasterxml.jackson.databind.JsonNode node = new com.fasterxml.jackson.databind.ObjectMapper()
                        .readTree(response.body().string());
                if ("success".equals(node.path("status").asText())) {
                    return node.path("data").path("authorizedRedirectUri").asText();
                }
            }
            logger.error("Auth failed with status {}: {}", response.code(), response.body().string());
            return null;
        }
    }

    /**
     * Disconnect from WebSocket.
     */
    public void disconnect() {
        if (webSocket != null) {
            webSocket.close(1000, "Shutting down");
            connected = false;
        }
    }

    /**
     * Subscribe to instrument.
     */
    public void subscribe(String instrumentKey) {
        subscriptions.add(instrumentKey);
        if (connected && webSocket != null) {
            String message = String.format(
                    "{\"guid\":\"sub_%s\",\"method\":\"sub\",\"data\":{\"mode\":\"full\",\"instrumentKeys\":[\"%s\"]}}",
                    UUID.randomUUID().toString().substring(0, 8),
                    instrumentKey);
            webSocket.send(message);
            logger.debug("Subscribed to: {}", instrumentKey);
        } else {
            logger.info("Subscription added for {}, will connect/subscribe when WebSocket is ready", instrumentKey);
            connect();
        }
    }

    /**
     * Unsubscribe from instrument.
     */
    public void unsubscribe(String instrumentKey) {
        subscriptions.remove(instrumentKey);
        if (connected && webSocket != null) {
            String message = String.format(
                    "{\"guid\":\"unsub_%s\",\"method\":\"unsub\",\"data\":{\"instrumentKeys\":[\"%s\"]}}",
                    UUID.randomUUID().toString().substring(0, 8),
                    instrumentKey);
            webSocket.send(message);
            logger.debug("Unsubscribed from: {}", instrumentKey);
        }
    }

    /**
     * Add listener for market data updates.
     */
    public void addListener(String id, Consumer<Map<String, Object>> listener) {
        listeners.put(id, listener);
    }

    /**
     * Remove listener.
     */
    public void removeListener(String id) {
        listeners.remove(id);
    }

    /**
     * Check if connected.
     */
    public boolean isConnected() {
        return connected;
    }

    /**
     * Get current subscriptions.
     */
    public Set<String> getSubscriptions() {
        return new HashSet<>(subscriptions);
    }

    private void handleTextMessage(String text) {
        logger.debug("Received text message: {}", text);
        // Upstox might send JSON for sub/unsub confirmation
    }

    private void handleBinaryMessage(byte[] data) {
        try {
            MarketDataFeedOptionChainV3.FeedResponse response = MarketDataFeedOptionChainV3.FeedResponse
                    .parseFrom(data);

            // Distribute feed updates to listeners
            if (response.getFeedsCount() > 0) {
                Map<String, Object> update = new HashMap<>();
                update.put("type", "live_feed");
                update.put("feeds", response.getFeedsMap());
                update.put("timestamp", response.getCurrentTs());

                broadcastToListeners(update);
            }
        } catch (Exception e) {
            logger.error("Error parsing binary message: {}", e.getMessage());
        }
    }

    private void broadcastToListeners(Map<String, Object> data) {
        for (Consumer<Map<String, Object>> listener : listeners.values()) {
            try {
                listener.accept(data);
            } catch (Exception e) {
                logger.error("Listener error: {}", e.getMessage());
            }
        }
    }

    private void resubscribeAll() {
        for (String instrumentKey : subscriptions) {
            subscribe(instrumentKey);
        }
    }

    private void scheduleReconnect() {
        // Reconnect after delay
        new Thread(() -> {
            try {
                Thread.sleep(5000);
                if (!connected) {
                    connect();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }

    private String getAccessToken() {
        return tokenRepository.findByIsPrimaryTrue()
                .map(UpstoxToken::getAccessToken)
                .orElse(null);
    }

    @Scheduled(fixedRate = 60000)
    public void healthCheck() {
        if (!connected && !subscriptions.isEmpty()) {
            logger.info("Reconnecting to market data WebSocket...");
            connect();
        }
    }
}
