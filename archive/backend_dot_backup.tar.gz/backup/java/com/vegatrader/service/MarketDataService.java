package com.vegatrader.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vegatrader.client.UpstoxClient;
import com.vegatrader.model.entity.UpstoxToken;
import com.vegatrader.repository.UpstoxTokenRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Market data service for quotes and historical data.
 */
@Service
public class MarketDataService {

    private static final Logger logger = LoggerFactory.getLogger(MarketDataService.class);

    private final UpstoxClient upstoxClient;
    private final UpstoxTokenRepository tokenRepository;

    public MarketDataService(UpstoxClient upstoxClient, UpstoxTokenRepository tokenRepository) {
        this.upstoxClient = upstoxClient;
        this.tokenRepository = tokenRepository;
    }

    /**
     * Get LTP (Last Traded Price) for instruments.
     */
    public Map<String, Object> getLtp(List<String> instrumentKeys) {
        String token = getAccessToken();
        try {
            String keys = String.join(",", instrumentKeys);
            JsonNode response = upstoxClient.get("/market-quote/ltp?instrument_key=" + keys, token);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to fetch LTP: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch LTP", e);
        }
    }

    /**
     * Get full market quotes.
     */
    public Map<String, Object> getQuotes(List<String> instrumentKeys) {
        String token = getAccessToken();
        try {
            String keys = String.join(",", instrumentKeys);
            JsonNode response = upstoxClient.get("/market-quote/quotes?instrument_key=" + keys, token);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to fetch quotes: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch quotes", e);
        }
    }

    /**
     * Get OHLC data.
     */
    public Map<String, Object> getOhlc(List<String> instrumentKeys, String interval) {
        String token = getAccessToken();
        try {
            String keys = String.join(",", instrumentKeys);
            String endpoint = String.format("/market-quote/ohlc?instrument_key=%s&interval=%s", keys, interval);
            JsonNode response = upstoxClient.get(endpoint, token);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to fetch OHLC: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch OHLC", e);
        }
    }

    /**
     * Get historical candle data.
     */
    @Cacheable(value = "historicalData", key = "#instrumentKey + '-' + #interval + '-' + #toDate")
    public Map<String, Object> getHistoricalData(String instrumentKey, String interval, String toDate,
            String fromDate) {
        String token = getAccessToken();
        try {
            String endpoint = String.format("/historical-candle/%s/%s/%s/%s",
                    instrumentKey.replace("|", "%7C"), interval, toDate, fromDate);
            JsonNode response = upstoxClient.get(endpoint, token);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to fetch historical data: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch historical data", e);
        }
    }

    /**
     * Get intraday candle data.
     */
    public Map<String, Object> getIntradayData(String instrumentKey, String interval) {
        String token = getAccessToken();
        try {
            String endpoint = String.format("/historical-candle/intraday/%s/%s",
                    instrumentKey.replace("|", "%7C"), interval);
            JsonNode response = upstoxClient.get(endpoint, token);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to fetch intraday data: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch intraday data", e);
        }
    }

    /**
     * Get market status.
     */
    public Map<String, Object> getMarketStatus() {
        String token = getAccessToken();
        try {
            JsonNode response = upstoxClient.get("/market/status/NSE", token);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to fetch market status: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch market status", e);
        }
    }

    private String getAccessToken() {
        return tokenRepository.findByIsPrimaryTrue()
                .map(UpstoxToken::getAccessToken)
                .orElseThrow(() -> new RuntimeException("No access token available"));
    }

    private Map<String, Object> parseResponse(JsonNode response) {
        Map<String, Object> result = new HashMap<>();
        result.put("status", response.path("status").asText());
        result.put("data", response.path("data"));
        return result;
    }
}
