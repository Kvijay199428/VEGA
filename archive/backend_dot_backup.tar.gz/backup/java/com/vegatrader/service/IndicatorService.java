package com.vegatrader.service;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Technical indicators service.
 */
@Service
public class IndicatorService {

    private static final Logger logger = LoggerFactory.getLogger(IndicatorService.class);

    /**
     * Calculate Simple Moving Average (SMA).
     */
    public double calculateSMA(List<Double> prices, int period) {
        if (prices.size() < period) {
            return 0.0;
        }
        double sum = 0;
        for (int i = prices.size() - period; i < prices.size(); i++) {
            sum += prices.get(i);
        }
        return sum / period;
    }

    /**
     * Calculate Exponential Moving Average (EMA).
     */
    public double calculateEMA(List<Double> prices, int period) {
        if (prices.size() < period) {
            return 0.0;
        }
        double multiplier = 2.0 / (period + 1);
        double ema = prices.get(0);
        for (int i = 1; i < prices.size(); i++) {
            ema = (prices.get(i) * multiplier) + (ema * (1 - multiplier));
        }
        return ema;
    }

    /**
     * Calculate Relative Strength Index (RSI).
     */
    public double calculateRSI(List<Double> prices, int period) {
        if (prices.size() <= period) {
            return 50.0;
        }

        List<Double> gains = new ArrayList<>();
        List<Double> losses = new ArrayList<>();

        for (int i = 1; i < prices.size(); i++) {
            double change = prices.get(i) - prices.get(i - 1);
            gains.add(Math.max(0, change));
            losses.add(Math.max(0, -change));
        }

        double avgGain = gains.subList(gains.size() - period, gains.size()).stream()
                .mapToDouble(Double::doubleValue).average().orElse(0);
        double avgLoss = losses.subList(losses.size() - period, losses.size()).stream()
                .mapToDouble(Double::doubleValue).average().orElse(0);

        if (avgLoss == 0)
            return 100.0;
        double rs = avgGain / avgLoss;
        return 100 - (100 / (1 + rs));
    }

    /**
     * Calculate MACD (Moving Average Convergence Divergence).
     */
    public Map<String, Double> calculateMACD(List<Double> prices) {
        double ema12 = calculateEMA(prices, 12);
        double ema26 = calculateEMA(prices, 26);
        double macdLine = ema12 - ema26;

        // Signal line (9-period EMA of MACD)
        List<Double> macdValues = new ArrayList<>();
        for (int i = 26; i <= prices.size(); i++) {
            double e12 = calculateEMA(prices.subList(0, i), 12);
            double e26 = calculateEMA(prices.subList(0, i), 26);
            macdValues.add(e12 - e26);
        }
        double signalLine = calculateEMA(macdValues, 9);

        Map<String, Double> result = new HashMap<>();
        result.put("macd", macdLine);
        result.put("signal", signalLine);
        result.put("histogram", macdLine - signalLine);
        return result;
    }

    /**
     * Calculate Bollinger Bands.
     */
    public Map<String, Double> calculateBollingerBands(List<Double> prices, int period, double stdDevMultiplier) {
        double sma = calculateSMA(prices, period);

        DescriptiveStatistics stats = new DescriptiveStatistics();
        for (int i = prices.size() - period; i < prices.size(); i++) {
            stats.addValue(prices.get(i));
        }
        double stdDev = stats.getStandardDeviation();

        Map<String, Double> result = new HashMap<>();
        result.put("middle", sma);
        result.put("upper", sma + (stdDevMultiplier * stdDev));
        result.put("lower", sma - (stdDevMultiplier * stdDev));
        return result;
    }

    /**
     * Calculate ATR (Average True Range).
     */
    public double calculateATR(List<Double> highs, List<Double> lows, List<Double> closes, int period) {
        if (highs.size() < period + 1) {
            return 0.0;
        }

        List<Double> trueRanges = new ArrayList<>();
        for (int i = 1; i < highs.size(); i++) {
            double tr = Math.max(
                    highs.get(i) - lows.get(i),
                    Math.max(
                            Math.abs(highs.get(i) - closes.get(i - 1)),
                            Math.abs(lows.get(i) - closes.get(i - 1))));
            trueRanges.add(tr);
        }

        return trueRanges.subList(trueRanges.size() - period, trueRanges.size()).stream()
                .mapToDouble(Double::doubleValue).average().orElse(0);
    }

    /**
     * Calculate all indicators for a price series.
     */
    public Map<String, Object> calculateAllIndicators(List<Double> prices, List<Double> highs, List<Double> lows) {
        Map<String, Object> indicators = new HashMap<>();

        indicators.put("sma20", calculateSMA(prices, 20));
        indicators.put("sma50", calculateSMA(prices, 50));
        indicators.put("ema12", calculateEMA(prices, 12));
        indicators.put("ema26", calculateEMA(prices, 26));
        indicators.put("rsi14", calculateRSI(prices, 14));
        indicators.put("macd", calculateMACD(prices));
        indicators.put("bollingerBands", calculateBollingerBands(prices, 20, 2.0));

        if (highs != null && lows != null) {
            indicators.put("atr14", calculateATR(highs, lows, prices, 14));
        }

        return indicators;
    }
}
