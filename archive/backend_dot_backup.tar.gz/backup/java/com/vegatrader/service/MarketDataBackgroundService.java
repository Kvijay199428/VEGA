package com.vegatrader.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vegatrader.client.UpstoxClient;
import com.vegatrader.model.entity.UpstoxToken;
import com.vegatrader.repository.UpstoxTokenRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Background service for market data polling.
 */
@Service
public class MarketDataBackgroundService {

    private static final Logger logger = LoggerFactory.getLogger(MarketDataBackgroundService.class);

    private final UpstoxClient upstoxClient;
    private final UpstoxTokenRepository tokenRepository;

    // Cached market data
    private final Map<String, Map<String, Object>> cache = new ConcurrentHashMap<>();
    private final Set<String> watchlist = ConcurrentHashMap.newKeySet();

    public MarketDataBackgroundService(UpstoxClient upstoxClient, UpstoxTokenRepository tokenRepository) {
        this.upstoxClient = upstoxClient;
        this.tokenRepository = tokenRepository;
    }

    /**
     * Add instrument to watchlist for background polling.
     */
    public void addToWatchlist(String instrumentKey) {
        watchlist.add(instrumentKey);
        logger.debug("Added to watchlist: {}", instrumentKey);
    }

    /**
     * Remove instrument from watchlist.
     */
    public void removeFromWatchlist(String instrumentKey) {
        watchlist.remove(instrumentKey);
        cache.remove(instrumentKey);
        logger.debug("Removed from watchlist: {}", instrumentKey);
    }

    /**
     * Get cached data for instrument.
     */
    public Map<String, Object> getCachedData(String instrumentKey) {
        return cache.get(instrumentKey);
    }

    /**
     * Get all cached data.
     */
    public Map<String, Map<String, Object>> getAllCachedData() {
        return new HashMap<>(cache);
    }

    /**
     * Background polling task - runs every second.
     */
    @Scheduled(fixedRate = 1000)
    public void pollMarketData() {
        if (watchlist.isEmpty()) {
            return;
        }

        String token = getAccessToken();
        if (token == null) {
            return;
        }

        try {
            String keys = String.join(",", watchlist);
            JsonNode response = upstoxClient.get("/market-quote/ltp?instrument_key=" + keys, token);

            if ("success".equals(response.path("status").asText())) {
                JsonNode data = response.path("data");
                Iterator<String> fields = data.fieldNames();
                while (fields.hasNext()) {
                    String key = fields.next();
                    JsonNode quote = data.get(key);
                    Map<String, Object> quoteMap = new HashMap<>();
                    quoteMap.put("ltp", quote.path("last_price").asDouble());
                    quoteMap.put("timestamp", System.currentTimeMillis());
                    cache.put(key, quoteMap);
                }
            }
        } catch (Exception e) {
            logger.error("Error polling market data: {}", e.getMessage());
        }
    }

    /**
     * Get watchlist.
     */
    public Set<String> getWatchlist() {
        return new HashSet<>(watchlist);
    }

    /**
     * Clear watchlist.
     */
    public void clearWatchlist() {
        watchlist.clear();
        cache.clear();
    }

    private String getAccessToken() {
        return tokenRepository.findByIsPrimaryTrue()
                .map(UpstoxToken::getAccessToken)
                .orElse(null);
    }
}
