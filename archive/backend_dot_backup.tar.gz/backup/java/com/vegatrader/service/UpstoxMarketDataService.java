package com.vegatrader.service;

import com.vegatrader.upstox.api.websocket.*;
import com.vegatrader.upstox.api.websocket.cache.MarketDataCache;
import com.vegatrader.upstox.api.websocket.listener.*;
import com.vegatrader.upstox.api.websocket.logging.MarketDataStreamerV3Logger;
import com.vegatrader.upstox.api.websocket.settings.*;
import com.vegatrader.websocket.MarketDataWebSocketHandler;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Spring service wrapper for MarketDataStreamerV3.
 * 
 * <p>
 * Provides Spring integration with:
 * <ul>
 * <li>Database token integration</li>
 * <li>Auto-configuration from settings</li>
 * <li>Health check scheduling</li>
 * <li>Frontend WebSocket broadcasting</li>
 * </ul>
 * 
 * @since 3.0.0
 */
@Service
public class UpstoxMarketDataService {

    private final UpstoxTokenProvider tokenProvider;
    private final MarketDataWebSocketHandler clientHandler;
    private final MarketDataStreamerSettings settings;

    private MarketDataStreamerV3 streamer;
    private MarketDataStreamerV3Logger logger;
    private MarketDataCache cache;

    public UpstoxMarketDataService(
            UpstoxTokenProvider tokenProvider,
            MarketDataWebSocketHandler clientHandler) {
        this.tokenProvider = tokenProvider;
        this.clientHandler = clientHandler;

        // Detect tier and create settings
        SubscriptionTier tier = tokenProvider.detectTier();
        if (tier == SubscriptionTier.PLUS) {
            this.settings = MarketDataStreamerSettings.createPlusTier();
        } else {
            this.settings = MarketDataStreamerSettings.createNormalTier();
        }

        // Configure logging
        settings.setLogFilePath("logs/upstox-market-data.log");
        settings.setEnableLogging(true);
        settings.setLogMarketUpdates(false); // Can be verbose

        // Configure caching
        settings.setEnableCaching(true);
        settings.setCacheTTL(60);
        settings.setMaxCacheSize(10000);
    }

    @PostConstruct
    public void initialize() {
        logger.info("Initializing Upstox Market Data Service with tier: {}", settings.getTier());

        // Create streamer instance
        this.streamer = new MarketDataStreamerV3(tokenProvider, settings);
        this.logger = streamer.getLogger();
        this.cache = streamer.getCache();

        // Setup event listeners
        setupListeners();

        logger.info("Market Data Service initialized and ready");
    }

    @PreDestroy
    public void shutdown() {
        if (streamer != null) {
            logger.info("Shutting down Market Data Service");
            streamer.disconnect();
        }
    }

    /**
     * Setup event listeners for the streamer.
     */
    private void setupListeners() {
        // Connection opened
        streamer.setOnOpenListener(() -> {
            logger.logConnectionSuccess();
            // Could resubscribe to saved subscriptions here
        });

        // Connection closed
        streamer.setOnCloseListener((code, reason) -> {
            logger.logConnectionClosed(code, reason);
        });

        // Market updates - broadcast to frontend clients
        streamer.setOnMarketUpdateListener(update -> {
            if (update.isLiveFeed() || update.isInitialFeed()) {
                broadcastToFrontend(update);
            }
        });

        // Errors
        streamer.setOnErrorListener(error -> {
            logger.error("WebSocket error", error);
        });

        // Reconnection
        streamer.setOnReconnectingListener(attempt -> {
            logger.logReconnectAttempt(attempt, settings.getMaxReconnectAttempts());
        });

        // Reconnection stopped
        streamer.setOnAutoReconnectStoppedListener(message -> {
            logger.logReconnectStopped(message);
        });
    }

    /**
     * Broadcasts market updates to frontend clients.
     */
    private void broadcastToFrontend(MarketUpdateV3 update) {
        if (update.getFeeds() == null) {
            return;
        }

        update.getFeeds().forEach((instrumentKey, feedData) -> {
            try {
                Map<String, Object> broadcastData = convertFeedData(instrumentKey, feedData);
                clientHandler.broadcastMarketData(instrumentKey, broadcastData);
            } catch (Exception e) {
                logger.error("Error broadcasting to frontend", e);
            }
        });
    }

    /**
     * Converts FeedData to Map for frontend.
     */
    private Map<String, Object> convertFeedData(String instrumentKey,
            com.vegatrader.upstox.api.response.websocket.FeedData feedData) {
        Map<String, Object> map = new HashMap<>();
        map.put("instrument_key", instrumentKey);
        map.put("timestamp", System.currentTimeMillis());

        if (feedData.hasLtpc()) {
            Map<String, Object> ltpc = new HashMap<>();
            ltpc.put("ltp", feedData.getLtpc().getLtp());
            ltpc.put("ltt", feedData.getLtpc().getLtt());
            ltpc.put("ltq", feedData.getLtpc().getLtq());
            ltpc.put("cp", feedData.getLtpc().getCp());
            ltpc.put("change", feedData.getLtpc().getChange());
            ltpc.put("change_percent", feedData.getLtpc().getChangePercent());
            map.put("ltpc", ltpc);
        }

        if (feedData.hasOptionGreeks()) {
            Map<String, Object> greeks = new HashMap<>();
            greeks.put("delta", feedData.getOptionGreeks().getDelta());
            greeks.put("theta", feedData.getOptionGreeks().getTheta());
            greeks.put("gamma", feedData.getOptionGreeks().getGamma());
            greeks.put("vega", feedData.getOptionGreeks().getVega());
            greeks.put("iv", feedData.getOptionGreeks().getIv());
            map.put("option_greeks", greeks);
        }

        return map;
    }

    // Public API methods

    /**
     * Connects to the market data feed.
     */
    public void connect() {
        if (streamer != null) {
            streamer.connect();
        }
    }

    /**
     * Disconnects from the market data feed.
     */
    public void disconnect() {
        if (streamer != null) {
            streamer.disconnect();
        }
    }

    /**
     * Subscribes to instruments.
     * 
     * @param instrumentKeys the instrument keys
     * @param mode           the subscription mode
     */
    public void subscribe(Set<String> instrumentKeys, Mode mode) {
        if (streamer != null) {
            streamer.subscribe(instrumentKeys, mode);
        }
    }

    /**
     * Unsubscribes from instruments.
     * 
     * @param instrumentKeys the instrument keys
     */
    public void unsubscribe(Set<String> instrumentKeys) {
        if (streamer != null) {
            streamer.unsubscribe(instrumentKeys);
        }
    }

    /**
     * Changes subscription mode.
     * 
     * @param instrumentKeys the instrument keys
     * @param mode           the new mode
     */
    public void changeMode(Set<String> instrumentKeys, Mode mode) {
        if (streamer != null) {
            streamer.changeMode(instrumentKeys, mode);
        }
    }

    /**
     * Checks if connected.
     * 
     * @return true if connected
     */
    public boolean isConnected() {
        return streamer != null && streamer.isConnected();
    }

    /**
     * Gets current subscriptions.
     * 
     * @return set of subscribed instruments
     */
    public Set<String> getSubscriptions() {
        return streamer != null ? streamer.getSubscribedInstruments() : Set.of();
    }

    /**
     * Gets the subscription tier.
     * 
     * @return the tier
     */
    public SubscriptionTier getTier() {
        return settings.getTier();
    }

    /**
     * Gets the cache.
     * 
     * @return the cache instance
     */
    public MarketDataCache getCache() {
        return cache;
    }

    /**
     * Gets the logger.
     * 
     * @return the logger instance
     */
    public MarketDataStreamerV3Logger getLogger() {
        return logger;
    }

    /**
     * Health check - runs every minute.
     * Reconnects if disconnected and has subscriptions.
     */
    @Scheduled(fixedRate = 60000)
    public void healthCheck() {
        if (streamer != null && !streamer.isConnected() && !streamer.getSubscribedInstruments().isEmpty()) {
            logger.info("Health check: Reconnecting to market data feed");
            streamer.connect();
        }
    }

    /**
     * Log metrics every 5 minutes.
     */
    @Scheduled(fixedRate = 300000)
    public void logMetrics() {
        if (logger != null) {
            logger.logMetrics();
        }
    }
}
