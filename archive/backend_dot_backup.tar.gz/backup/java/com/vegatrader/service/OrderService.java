package com.vegatrader.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vegatrader.client.UpstoxClient;
import com.vegatrader.dto.OrderRequest;
import com.vegatrader.model.entity.UpstoxToken;
import com.vegatrader.repository.UpstoxTokenRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Order service for placing and managing orders.
 */
@Service
public class OrderService {

    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

    private final UpstoxClient upstoxClient;
    private final UpstoxTokenRepository tokenRepository;

    public OrderService(UpstoxClient upstoxClient, UpstoxTokenRepository tokenRepository) {
        this.upstoxClient = upstoxClient;
        this.tokenRepository = tokenRepository;
    }

    /**
     * Place a new order.
     */
    public Map<String, Object> placeOrder(OrderRequest request) {
        String token = getAccessToken();
        try {
            JsonNode response = upstoxClient.post("/order/place", token, request);
            logger.info("Order placed: {}", response.path("data").path("order_id").asText());
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to place order: {}", e.getMessage());
            throw new RuntimeException("Failed to place order", e);
        }
    }

    /**
     * Modify an existing order.
     */
    public Map<String, Object> modifyOrder(String orderId, OrderRequest request) {
        String token = getAccessToken();
        try {
            Map<String, Object> body = new HashMap<>();
            body.put("order_id", orderId);
            body.put("quantity", request.getQuantity());
            body.put("price", request.getPrice());
            body.put("trigger_price", request.getTriggerPrice());
            body.put("validity", request.getValidity());

            JsonNode response = upstoxClient.put("/order/modify", token, body);
            logger.info("Order modified: {}", orderId);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to modify order {}: {}", orderId, e.getMessage());
            throw new RuntimeException("Failed to modify order", e);
        }
    }

    /**
     * Cancel an order.
     */
    public Map<String, Object> cancelOrder(String orderId) {
        String token = getAccessToken();
        try {
            JsonNode response = upstoxClient.delete("/order/cancel?order_id=" + orderId, token);
            logger.info("Order cancelled: {}", orderId);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to cancel order {}: {}", orderId, e.getMessage());
            throw new RuntimeException("Failed to cancel order", e);
        }
    }

    /**
     * Get order book (all orders).
     */
    public Map<String, Object> getOrderBook() {
        String token = getAccessToken();
        try {
            JsonNode response = upstoxClient.get("/order/retrieve-all", token);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to fetch order book: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch order book", e);
        }
    }

    /**
     * Get order details.
     */
    public Map<String, Object> getOrderDetails(String orderId) {
        String token = getAccessToken();
        try {
            JsonNode response = upstoxClient.get("/order/details?order_id=" + orderId, token);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to fetch order {}: {}", orderId, e.getMessage());
            throw new RuntimeException("Failed to fetch order details", e);
        }
    }

    /**
     * Get trade book.
     */
    public Map<String, Object> getTradeBook() {
        String token = getAccessToken();
        try {
            JsonNode response = upstoxClient.get("/order/trades/get-trades-for-day", token);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to fetch trade book: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch trade book", e);
        }
    }

    private String getAccessToken() {
        return tokenRepository.findByIsPrimaryTrue()
                .map(UpstoxToken::getAccessToken)
                .orElseThrow(() -> new RuntimeException("No access token available"));
    }

    private Map<String, Object> parseResponse(JsonNode response) {
        Map<String, Object> result = new HashMap<>();
        result.put("status", response.path("status").asText());
        result.put("data", response.path("data"));
        return result;
    }
}
