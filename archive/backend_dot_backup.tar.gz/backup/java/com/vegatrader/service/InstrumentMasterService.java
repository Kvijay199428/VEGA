package com.vegatrader.service;

import com.vegatrader.model.entity.OptionsInstrument;
import com.vegatrader.repository.OptionsInstrumentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Instrument master service - consolidated from Python helpers.
 * Handles equity, futures, index, options instruments.
 */
@Service
public class InstrumentMasterService {

    private static final Logger logger = LoggerFactory.getLogger(InstrumentMasterService.class);

    private final OptionsInstrumentRepository optionsRepository;

    // Common index instrument keys
    // Keys must match exactly what is in the OptionsInstrument database
    // (underlying_key)
    private static final Map<String, String> INDEX_KEYS = Map.of(
            "NIFTY", "NSE_INDEX|Nifty 50",
            "BANKNIFTY", "NSE_INDEX|Nifty Bank",
            "FINNIFTY", "NSE_INDEX|Nifty Fin Service",
            "MIDCPNIFTY", "NSE_INDEX|NIFTY MID SELECT", // DB has UPPERCASE for this one
            "SENSEX", "BSE_INDEX|SENSEX");

    // Display names for dropdowns
    private static final Map<String, String> INDEX_NAMES = Map.of(
            "NIFTY", "NIFTY 50",
            "BANKNIFTY", "NIFTY BANK",
            "FINNIFTY", "NIFTY FIN SERVICE",
            "MIDCPNIFTY", "NIFTY MID SELECT",
            "SENSEX", "SENSEX");

    // Exchange mapping for each index
    private static final Map<String, String> INDEX_EXCHANGES = Map.of(
            "NIFTY", "NSE",
            "BANKNIFTY", "NSE",
            "FINNIFTY", "NSE",
            "MIDCPNIFTY", "NSE",
            "SENSEX", "BSE");

    public InstrumentMasterService(OptionsInstrumentRepository optionsRepository) {
        this.optionsRepository = optionsRepository;
    }

    /**
     * Get equity instruments (for live feed).
     */
    @Cacheable(value = "equityInstruments", key = "#exchange")
    public List<Map<String, Object>> getEquityInstruments(String exchange) {
        // Exchange in DB is "NSE", not "NSE_FO"
        List<String> underlyingKeys = optionsRepository.findDistinctUnderlyingKeysByExchange(exchange);
        System.out.println("DEBUG: Found " + underlyingKeys.size() + " underlying keys for exchange " + exchange);

        List<Map<String, Object>> instruments = new ArrayList<>();

        for (String key : underlyingKeys) {
            if (key != null && key.contains("|")) {
                // Parse key: NSE_EQ|RELIANCE -> RELIANCE
                String[] parts = key.split("\\|");
                if (parts.length > 1) {
                    String symbol = parts[1];
                    String eqKey = exchange + "_EQ|" + symbol; // Construct EQ key for frontend

                    Map<String, Object> inst = new HashMap<>();
                    inst.put("symbol", symbol);
                    inst.put("name", symbol);
                    inst.put("instrument_key", eqKey);
                    inst.put("exchange", exchange);
                    inst.put("segment", "EQ");
                    instruments.add(inst);
                }
            }
        }

        // Sort explicitly
        instruments.sort((a, b) -> ((String) a.get("symbol")).compareTo((String) b.get("symbol")));

        return instruments;
    }

    /**
     * Get index instruments.
     * 
     * @param exchange Optional exchange filter (NSE, BSE, etc.)
     */
    public List<Map<String, Object>> getIndexInstruments(String exchange) {
        return INDEX_KEYS.entrySet().stream()
                .filter(e -> {
                    // If exchange is specified, filter by it
                    if (exchange != null && !exchange.isEmpty()) {
                        String indexExchange = INDEX_EXCHANGES.get(e.getKey());
                        return exchange.equalsIgnoreCase(indexExchange);
                    }
                    return true; // No filter if exchange not specified
                })
                .map(e -> {
                    Map<String, Object> inst = new HashMap<>();
                    String symbol = e.getKey();
                    inst.put("symbol", symbol);
                    inst.put("instrument_key", e.getValue());
                    inst.put("name", INDEX_NAMES.getOrDefault(symbol, symbol));
                    inst.put("exchange", INDEX_EXCHANGES.getOrDefault(symbol, "NSE")); // Add exchange field
                    return inst;
                })
                .collect(Collectors.toList());
    }

    /**
     * Get futures instruments for an underlying.
     */
    public List<Map<String, Object>> getFuturesInstruments(String underlying) {
        // Return futures contracts based on underlying
        List<Map<String, Object>> futures = new ArrayList<>();

        // Current month, next month, far month
        String[] expiries = { "current", "next", "far" };
        for (String expiry : expiries) {
            Map<String, Object> fut = new HashMap<>();
            fut.put("underlying", underlying);
            fut.put("expiry_type", expiry);
            fut.put("instrument_type", "FUT");
            futures.add(fut);
        }

        return futures;
    }

    /**
     * Get MIS (Intraday) allowed instruments.
     */
    public List<String> getMisAllowedInstruments() {
        return List.of(
                "NSE_EQ", "NSE_FO", "BSE_EQ", "BSE_FO", "MCX_FO", "NSE_INDEX");
    }

    /**
     * Get MTF (Margin Trading Facility) allowed instruments.
     */
    public List<String> getMtfAllowedInstruments() {
        return List.of("NSE_EQ", "BSE_EQ");
    }

    /**
     * Validate instrument for trading.
     */
    public Map<String, Object> validateInstrument(String instrumentKey, String product, String orderType) {
        Map<String, Object> result = new HashMap<>();
        result.put("instrument_key", instrumentKey);
        result.put("valid", true);

        String segment = instrumentKey.split("\\|")[0];

        if ("I".equals(product)) { // Intraday
            if (!getMisAllowedInstruments().contains(segment)) {
                result.put("valid", false);
                result.put("reason", "MIS not allowed for this segment");
            }
        }

        if ("MTF".equals(product)) {
            if (!getMtfAllowedInstruments().contains(segment)) {
                result.put("valid", false);
                result.put("reason", "MTF not allowed for this segment");
            }
        }

        return result;
    }

    /**
     * Get instrument key by symbol.
     */
    public String getInstrumentKey(String symbol, String exchange, String segment) {
        if ("INDEX".equals(segment)) {
            return INDEX_KEYS.getOrDefault(symbol, exchange + "_INDEX|" + symbol);
        }
        return exchange + "_" + segment + "|" + symbol;
    }
}
