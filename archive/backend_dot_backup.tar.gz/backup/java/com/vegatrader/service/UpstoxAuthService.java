package com.vegatrader.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vegatrader.client.UpstoxClient;
import com.vegatrader.model.entity.UpstoxToken;
import com.vegatrader.repository.UpstoxTokenRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

/**
 * Upstox OAuth service for token management.
 */
@Service
public class UpstoxAuthService {

    private static final Logger logger = LoggerFactory.getLogger(UpstoxAuthService.class);

    @Value("${upstox.auth-url}")
    private String authUrl;

    @Value("${upstox.token-url}")
    private String tokenUrl;

    @Value("${upstox.redirect-uri}")
    private String redirectUri;

    private final UpstoxClient upstoxClient;
    private final UpstoxTokenRepository tokenRepository;

    public UpstoxAuthService(UpstoxClient upstoxClient, UpstoxTokenRepository tokenRepository) {
        this.upstoxClient = upstoxClient;
        this.tokenRepository = tokenRepository;
    }

    /**
     * Get authorization URL for OAuth flow.
     */
    public String getAuthorizationUrl(String apiName) {
        UpstoxToken config;

        // Handle PRIMARY as a special name - find primary or first available
        if ("PRIMARY".equalsIgnoreCase(apiName)) {
            config = tokenRepository.findByIsPrimaryTrue()
                    .orElseGet(() -> {
                        // No primary, get first available
                        var all = tokenRepository.findAll();
                        if (all.iterator().hasNext()) {
                            return all.iterator().next();
                        }
                        throw new RuntimeException("No API configurations found in database");
                    });
        } else {
            config = tokenRepository.findByApiName(apiName)
                    .orElseThrow(() -> new RuntimeException("API config not found: " + apiName));
        }

        return String.format("%s?response_type=code&client_id=%s&redirect_uri=%s&state=%s",
                authUrl, config.getClientId(), redirectUri, config.getApiName());
    }

    /**
     * Exchange authorization code for access token.
     */
    public Map<String, Object> exchangeToken(String code, String apiName) {
        UpstoxToken config = tokenRepository.findByApiName(apiName)
                .orElseThrow(() -> new RuntimeException("API config not found: " + apiName));

        try {
            JsonNode response = upstoxClient.exchangeToken(
                    code,
                    config.getClientId(),
                    config.getClientSecret(),
                    redirectUri);

            if (response.has("access_token")) {
                config.setAccessToken(response.path("access_token").asText());
                config.setRefreshToken(response.path("refresh_token").asText());
                config.setTokenType(response.path("token_type").asText("Bearer"));
                config.setExpiresIn(response.path("expires_in").asLong());
                config.setLastRefreshed(LocalDateTime.now());
                config.setIsActive(1);

                // Set generated_at and validity_at (Python compatible)
                String now = java.time.ZonedDateTime.now()
                        .format(java.time.format.DateTimeFormatter.ISO_INSTANT);
                config.setGeneratedAt(now);

                // Token valid until next day 3:30 AM IST (Upstox tokens expire daily)
                java.time.LocalDate tomorrow = java.time.LocalDate.now().plusDays(1);
                java.time.ZonedDateTime validityTime = tomorrow.atTime(3, 30)
                        .atZone(java.time.ZoneId.of("Asia/Kolkata"));
                config.setValidityAt(validityTime.format(java.time.format.DateTimeFormatter.ISO_INSTANT));

                tokenRepository.save(config);

                logger.info("Token exchanged successfully for: {} (valid until {})",
                        apiName, config.getValidityAt());

                Map<String, Object> result = new HashMap<>();
                result.put("status", "success");
                result.put("api_name", apiName);
                result.put("message", "Token stored successfully");
                result.put("generated_at", config.getGeneratedAt());
                result.put("validity_at", config.getValidityAt());
                return result;
            } else {
                throw new RuntimeException("No access token in response");
            }
        } catch (Exception e) {
            logger.error("Token exchange failed for {}: {}", apiName, e.getMessage());
            throw new RuntimeException("Token exchange failed", e);
        }
    }

    /**
     * Get all API configurations.
     */
    public List<Map<String, Object>> getApiConfigs() {
        List<Map<String, Object>> configs = new ArrayList<>();
        for (UpstoxToken token : tokenRepository.findAll()) {
            Map<String, Object> config = new HashMap<>();
            config.put("api_name", token.getApiName());
            config.put("has_token", token.getAccessToken() != null);
            config.put("is_primary", token.isPrimary());
            config.put("last_refreshed", token.getLastRefreshed());
            configs.add(config);
        }
        return configs;
    }

    /**
     * Get primary access token.
     */
    public String getPrimaryAccessToken() {
        return tokenRepository.findByIsPrimaryTrue()
                .map(UpstoxToken::getAccessToken)
                .orElseThrow(() -> new RuntimeException("No primary token available"));
    }

    /**
     * Set API as primary.
     */
    public void setPrimaryApi(String apiName) {
        // Clear existing primary
        tokenRepository.findByIsPrimaryTrue().ifPresent(token -> {
            token.setPrimary(false);
            tokenRepository.save(token);
        });

        // Set new primary
        UpstoxToken token = tokenRepository.findByApiName(apiName)
                .orElseThrow(() -> new RuntimeException("API not found: " + apiName));
        token.setPrimary(true);
        tokenRepository.save(token);

        logger.info("Primary API set to: {}", apiName);
    }

    /**
     * Get tokens status from database.
     */
    public Map<String, Object> getTokensStatus() {
        Map<String, Object> status = new java.util.HashMap<>();

        java.util.List<Map<String, Object>> tokens = new java.util.ArrayList<>();
        int validCount = 0;
        boolean hasPrimary = false;
        boolean primaryExpired = true;

        tokenRepository.findAll().forEach(token -> {
            Map<String, Object> tokenInfo = new java.util.HashMap<>();
            tokenInfo.put("api_name", token.getApiName());
            tokenInfo.put("api_index", token.getApiIndex());
            tokenInfo.put("purpose", token.getPurpose());
            tokenInfo.put("is_primary", token.isPrimary());
            tokenInfo.put("is_active", token.getIsActive());
            tokenInfo.put("has_access_token", token.getAccessToken() != null && !token.getAccessToken().isEmpty());
            tokenInfo.put("generated_at", token.getGeneratedAt());
            tokenInfo.put("validity_at", token.getValidityAt());
            tokenInfo.put("created_at", token.getCreatedAt());

            // Check if token is valid (not expired)
            boolean isValid = false;
            if (token.getAccessToken() != null && token.getValidityAt() != null) {
                try {
                    java.time.Instant validity = java.time.Instant.parse(token.getValidityAt());
                    isValid = java.time.Instant.now().isBefore(validity);
                } catch (Exception e) {
                    // Ignore parse errors
                }
            }
            tokenInfo.put("is_valid", isValid);
            tokens.add(tokenInfo);
        });

        // Calculate counts
        for (Map<String, Object> t : tokens) {
            if (Boolean.TRUE.equals(t.get("has_access_token")) && Boolean.TRUE.equals(t.get("is_valid"))) {
                validCount++;
            }
            if (Boolean.TRUE.equals(t.get("is_primary"))) {
                hasPrimary = true;
                primaryExpired = !Boolean.TRUE.equals(t.get("is_valid"));
            }
        }

        status.put("tokens", tokens);
        status.put("count", tokens.size());
        status.put("valid_count", validCount);
        status.put("has_primary", hasPrimary);
        status.put("primary_expired", primaryExpired);

        return status;
    }

    /**
     * Get list of login URLs for APIs that don't have valid tokens.
     */
    public List<Map<String, Object>> getPendingLoginUrls(int startIndex) {
        List<Map<String, Object>> pendingLogins = new ArrayList<>();

        for (UpstoxToken token : tokenRepository.findAll()) {
            // Skip if before start index
            if (token.getApiIndex() != null && token.getApiIndex() < startIndex) {
                continue;
            }

            // Check if token is missing or expired
            boolean needsToken = token.getAccessToken() == null || token.getAccessToken().isEmpty();
            if (!needsToken && token.getValidityAt() != null) {
                try {
                    java.time.Instant validity = java.time.Instant.parse(token.getValidityAt());
                    needsToken = java.time.Instant.now().isAfter(validity);
                } catch (Exception e) {
                    // If parse fails, assume token is invalid
                    needsToken = true;
                }
            }

            if (needsToken && token.getClientId() != null && !token.getClientId().isEmpty()) {
                Map<String, Object> loginInfo = new HashMap<>();
                loginInfo.put("api_index", token.getApiIndex());
                loginInfo.put("api_name", token.getApiName());
                loginInfo.put("purpose", token.getPurpose());
                loginInfo.put("login_url", getAuthorizationUrl(token.getApiName()));
                pendingLogins.add(loginInfo);
            }
        }

        // Sort by api_index
        pendingLogins.sort((a, b) -> {
            Integer indexA = (Integer) a.get("api_index");
            Integer indexB = (Integer) b.get("api_index");
            if (indexA == null)
                indexA = 999;
            if (indexB == null)
                indexB = 999;
            return indexA.compareTo(indexB);
        });

        logger.info("Found {} APIs needing login (starting from index {})", pendingLogins.size(), startIndex);
        return pendingLogins;
    }

    /**
     * Get authorization URL by API index.
     */
    public String getAuthorizationUrlByIndex(int apiIndex) {
        UpstoxToken config = tokenRepository.findByApiIndex(apiIndex)
                .orElseThrow(() -> new RuntimeException("API config not found for index: " + apiIndex));

        return String.format("%s?response_type=code&client_id=%s&redirect_uri=%s&state=%s",
                authUrl, config.getClientId(), redirectUri, config.getApiName());
    }

    /**
     * Get API name by index.
     */
    public String getApiNameByIndex(int apiIndex) {
        return tokenRepository.findByApiIndex(apiIndex)
                .map(UpstoxToken::getApiName)
                .orElse("UNKNOWN");
    }
}
