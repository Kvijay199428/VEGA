package com.vegatrader.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vegatrader.model.entity.*;
import com.vegatrader.repository.*;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.zip.GZIPInputStream;

@Service
public class InstrumentSyncService {

    private static final Logger logger = LoggerFactory.getLogger(InstrumentSyncService.class);
    private static final String UPSTOX_INSTRUMENTS_URL = "https://assets.upstox.com/market-quote/instruments/exchange/complete.json.gz";

    private final OkHttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final EquityInstrumentRepository equityRepo;
    private final IndexInstrumentRepository indexRepo;
    private final FuturesInstrumentRepository futuresRepo;
    private final OptionsInstrumentRepository optionsRepo;

    public InstrumentSyncService(
            OkHttpClient httpClient,
            ObjectMapper objectMapper,
            EquityInstrumentRepository equityRepo,
            IndexInstrumentRepository indexRepo,
            FuturesInstrumentRepository futuresRepo,
            OptionsInstrumentRepository optionsRepo) {
        this.httpClient = httpClient;
        this.objectMapper = objectMapper;
        this.equityRepo = equityRepo;
        this.indexRepo = indexRepo;
        this.futuresRepo = futuresRepo;
        this.optionsRepo = optionsRepo;
    }

    public Map<String, Object> syncInstruments() {
        logger.info("Starting instrument sync from Upstox...");
        LocalDateTime startTime = LocalDateTime.now();

        try {
            // 1. Download and Parse
            List<Map<String, Object>> instruments = downloadInstruments();
            logger.info("Downloaded {} instruments", instruments.size());

            // 2. Clear Tables
            clearTables();

            // 3. Classify and Save
            int eqCount = 0, idxCount = 0, futCount = 0, optCount = 0;

            // Buffers for batch saving
            List<EquityInstrument> equities = new ArrayList<>();
            List<IndexInstrument> indices = new ArrayList<>();
            List<FuturesInstrument> futures = new ArrayList<>();
            List<OptionsInstrument> options = new ArrayList<>();

            boolean loggedOneOption = false;

            for (Map<String, Object> inst : instruments) {
                String segment = (String) inst.getOrDefault("segment", "");
                String type = (String) inst.getOrDefault("instrument_type", "");

                if (isIndex(segment, type)) {
                    indices.add(mapToIndex(inst));
                } else if (isEquity(segment, type)) {
                    equities.add(mapToEquity(inst));
                } else if ("FUT".equals(type)) {
                    futures.add(mapToFutures(inst));
                } else if ("CE".equals(type) || "PE".equals(type)) {
                    if (!loggedOneOption && inst.get("underlying_key") == null && "NSE_FO".equals(segment)) {
                        System.out.println("DEBUG: Option with null underlying_key: " + inst);
                        loggedOneOption = true;
                    }
                    options.add(mapToOptions(inst));
                }

                // Batch save every 5000 items to avoid memory spike
                if (equities.size() >= 5000) {
                    eqCount += saveBatch(equityRepo, equities);
                    equities.clear();
                }
                if (indices.size() >= 5000) {
                    idxCount += saveBatch(indexRepo, indices);
                    indices.clear();
                }
                if (futures.size() >= 5000) {
                    futCount += saveBatch(futuresRepo, futures);
                    futures.clear();
                }
                if (options.size() >= 5000) {
                    optCount += saveBatch(optionsRepo, options);
                    options.clear();
                }
            }

            // Save remaining
            if (!equities.isEmpty())
                eqCount += saveBatch(equityRepo, equities);
            if (!indices.isEmpty())
                idxCount += saveBatch(indexRepo, indices);
            if (!futures.isEmpty())
                futCount += saveBatch(futuresRepo, futures);
            if (!options.isEmpty())
                optCount += saveBatch(optionsRepo, options);

            logger.info("Sync complete. EQ: {}, IDX: {}, FUT: {}, OPT: {}", eqCount, idxCount, futCount, optCount);

            Map<String, Object> result = new HashMap<>();
            result.put("status", "success");
            result.put("total_downloaded", instruments.size());
            result.put("saved_equity", eqCount);
            result.put("saved_index", idxCount);
            result.put("saved_futures", futCount);
            result.put("saved_options", optCount);
            result.put("duration_seconds", java.time.Duration.between(startTime, LocalDateTime.now()).getSeconds());

            return result;

        } catch (Exception e) {
            logger.error("Sync failed", e);
            throw new RuntimeException("Sync failed: " + e.getMessage());
        }
    }

    private List<Map<String, Object>> downloadInstruments() throws Exception {
        Request request = new Request.Builder().url(UPSTOX_INSTRUMENTS_URL).build();
        try (Response response = httpClient.newCall(request).execute()) {
            if (!response.isSuccessful())
                throw new RuntimeException("Download failed: " + response.code());
            if (response.body() == null)
                throw new RuntimeException("Empty body");

            try (InputStream is = new GZIPInputStream(response.body().byteStream())) {
                return objectMapper.readValue(is, new TypeReference<List<Map<String, Object>>>() {
                });
            }
        }
    }

    private void clearTables() {
        equityRepo.deleteAll();
        indexRepo.deleteAll();
        futuresRepo.deleteAll();
        optionsRepo.deleteAll();
    }

    // Helpers
    private boolean isIndex(String segment, String type) {
        return "INDEX".equals(type) || segment.contains("INDEX");
    }

    private boolean isEquity(String segment, String type) {
        return ("EQ".equals(type) || "SM".equals(type)) && (segment.contains("EQ"));
    }

    private <T> int saveBatch(org.springframework.data.jpa.repository.JpaRepository<T, Long> repo, List<T> items) {
        repo.saveAll(items);
        return items.size();
    }

    // Mappers
    private EquityInstrument mapToEquity(Map<String, Object> data) {
        EquityInstrument e = new EquityInstrument();
        e.setInstrumentKey((String) data.get("instrument_key"));
        e.setExchangeToken(String.valueOf(data.get("exchange_token")));
        e.setTradingSymbol((String) data.get("trading_symbol"));
        e.setName((String) data.get("name"));
        e.setShortName((String) data.get("short_name"));
        e.setIsin((String) data.get("isin"));
        e.setSegment((String) data.get("segment"));
        e.setExchange((String) data.get("exchange"));
        e.setLastSynced(LocalDateTime.now());
        // Typesafe extraction
        Number lot = (Number) data.get("lot_size");
        if (lot != null)
            e.setLotSize(lot.intValue());
        Number tick = (Number) data.get("tick_size");
        if (tick != null)
            e.setTickSize(tick.doubleValue());

        return e;
    }

    private IndexInstrument mapToIndex(Map<String, Object> data) {
        IndexInstrument i = new IndexInstrument();
        i.setInstrumentKey((String) data.get("instrument_key"));
        i.setExchangeToken(String.valueOf(data.get("exchange_token")));
        i.setTradingSymbol((String) data.get("trading_symbol"));
        i.setName((String) data.get("name"));
        i.setSegment((String) data.get("segment"));
        i.setExchange((String) data.get("exchange"));
        i.setLastSynced(LocalDateTime.now());
        return i;
    }

    private FuturesInstrument mapToFutures(Map<String, Object> data) {
        FuturesInstrument f = new FuturesInstrument();
        f.setInstrumentKey((String) data.get("instrument_key"));
        f.setExchangeToken(String.valueOf(data.get("exchange_token")));
        f.setTradingSymbol((String) data.get("trading_symbol"));
        f.setName((String) data.get("name"));
        f.setSegment((String) data.get("segment"));
        f.setExchange((String) data.get("exchange"));

        f.setUnderlyingKey((String) data.get("underlying_key"));
        f.setUnderlyingType((String) data.get("underlying_type"));

        Number lot = (Number) data.get("lot_size");
        if (lot != null)
            f.setLotSize(lot.intValue());
        Number tick = (Number) data.get("tick_size");
        if (tick != null)
            f.setTickSize(tick.doubleValue());

        parseExpiry(data, f::setExpiry, f::setExpiryStr);
        f.setLastSynced(LocalDateTime.now());
        return f;
    }

    private OptionsInstrument mapToOptions(Map<String, Object> data) {
        OptionsInstrument o = new OptionsInstrument();
        o.setInstrumentKey((String) data.get("instrument_key"));
        o.setTradingSymbol((String) data.get("trading_symbol"));

        String underlyingKey = (String) data.get("underlying_key");
        String underlyingSymbol = (String) data.get("underlying_symbol");
        String segment = (String) data.get("segment");
        String exchange = (String) data.get("exchange");

        // Fallback for null underlying_key, mostly for Equity Options
        if (underlyingKey == null && underlyingSymbol != null && "NSE_FO".equals(segment)) {
            // Construct inferred key
            underlyingKey = "NSE_EQ|" + underlyingSymbol;
            // Ideally we should check if it exists or use exchange, but NSE_EQ is standard
            // for stocks
        }

        o.setUnderlyingKey(underlyingKey);
        o.setUnderlyingSymbol(underlyingSymbol);
        o.setOptionType((String) data.getOrDefault("instrument_type", "CE"));
        o.setSegment(segment);
        o.setExchange(exchange);

        Number lot = (Number) data.get("lot_size");
        if (lot != null)
            o.setLotSize(lot.intValue());
        Number tick = (Number) data.get("tick_size");
        if (tick != null)
            o.setTickSize(tick.doubleValue());
        Number strike = (Number) data.get("strike_price");
        if (strike != null)
            o.setStrikePrice(strike.doubleValue());

        parseExpiry(data, o::setExpiry, null); // OptionsInstrument doesn't have setExpiryStr in provided code

        return o;
    }

    private void parseExpiry(Map<String, Object> data, java.util.function.Consumer<LocalDate> setDate,
            java.util.function.Consumer<String> setStr) {
        Object exp = data.get("expiry");
        if (exp != null) {
            String sym = (String) data.get("trading_symbol");
            if (sym != null && sym.contains("RELIANCE") && sym.contains("25")) { // Log for Reliance to debug format
                System.out.println("DEBUG EXPIRY RAW: " + exp + " (Type: " + exp.getClass().getName() + ") for " + sym);
            }
            try {
                if (exp instanceof Number) {
                    long ms = ((Number) exp).longValue();
                    LocalDate d = java.time.Instant.ofEpochMilli(ms).atZone(java.time.ZoneId.of("Asia/Kolkata"))
                            .toLocalDate();
                    setDate.accept(d);
                    if (setStr != null)
                        setStr.accept(String.valueOf(ms));
                } else if (exp instanceof String) {
                    // Try parsing "2023-12-31"
                    try {
                        String dateStr = (String) exp;
                        LocalDate d = LocalDate.parse(dateStr, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                        setDate.accept(d);
                    } catch (Exception e) {
                        try {
                            // Fallback, maybe generic ISO
                            LocalDate d = LocalDate.parse((String) exp);
                            setDate.accept(d);
                        } catch (Exception Ignored) {
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }
    }
}
