package com.vegatrader.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

/**
 * Trading signals service.
 */
@Service
public class SignalService {

    private static final Logger logger = LoggerFactory.getLogger(SignalService.class);

    private final IndicatorService indicatorService;

    public SignalService(IndicatorService indicatorService) {
        this.indicatorService = indicatorService;
    }

    /**
     * Generate trading signal based on indicators.
     */
    public Map<String, Object> generateSignal(String instrumentKey, List<Double> prices) {
        Map<String, Object> signal = new HashMap<>();
        signal.put("instrument_key", instrumentKey);
        signal.put("timestamp", LocalDateTime.now().toString());

        // Calculate indicators
        double rsi = indicatorService.calculateRSI(prices, 14);
        Map<String, Double> macd = indicatorService.calculateMACD(prices);
        double sma20 = indicatorService.calculateSMA(prices, 20);
        double sma50 = indicatorService.calculateSMA(prices, 50);
        double currentPrice = prices.get(prices.size() - 1);

        // Determine signal
        String action = "HOLD";
        int strength = 0;
        List<String> reasons = new ArrayList<>();

        // RSI signal
        if (rsi < 30) {
            strength += 2;
            reasons.add("RSI oversold (" + String.format("%.1f", rsi) + ")");
        } else if (rsi > 70) {
            strength -= 2;
            reasons.add("RSI overbought (" + String.format("%.1f", rsi) + ")");
        }

        // MACD signal
        if (macd.get("histogram") > 0) {
            strength += 1;
            reasons.add("MACD positive");
        } else {
            strength -= 1;
            reasons.add("MACD negative");
        }

        // Moving average crossover
        if (sma20 > sma50 && currentPrice > sma20) {
            strength += 2;
            reasons.add("Bullish MA crossover");
        } else if (sma20 < sma50 && currentPrice < sma20) {
            strength -= 2;
            reasons.add("Bearish MA crossover");
        }

        if (strength >= 3) {
            action = "STRONG_BUY";
        } else if (strength >= 1) {
            action = "BUY";
        } else if (strength <= -3) {
            action = "STRONG_SELL";
        } else if (strength <= -1) {
            action = "SELL";
        }

        signal.put("action", action);
        signal.put("strength", strength);
        signal.put("reasons", reasons);
        signal.put("indicators", Map.of(
                "rsi", rsi,
                "macd", macd,
                "sma20", sma20,
                "sma50", sma50,
                "currentPrice", currentPrice));

        return signal;
    }

    /**
     * Get active signals.
     */
    public List<Map<String, Object>> getActiveSignals() {
        // Return cached/stored signals in production
        return new ArrayList<>();
    }
}
