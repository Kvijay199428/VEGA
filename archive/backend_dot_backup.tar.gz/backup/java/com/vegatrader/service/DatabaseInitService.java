package com.vegatrader.service;

import com.vegatrader.model.entity.*;
import com.vegatrader.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.annotation.PostConstruct;

/**
 * Database initialization and migration service.
 * Equivalent to Python migrate_*.py scripts.
 */
@Service
public class DatabaseInitService {

    private static final Logger logger = LoggerFactory.getLogger(DatabaseInitService.class);

    private final UserRepository userRepository;
    private final UpstoxTokenRepository tokenRepository;
    private final AiStrategyRepository strategyRepository;

    public DatabaseInitService(
            UserRepository userRepository,
            UpstoxTokenRepository tokenRepository,
            AiStrategyRepository strategyRepository) {
        this.userRepository = userRepository;
        this.tokenRepository = tokenRepository;
        this.strategyRepository = strategyRepository;
    }

    @PostConstruct
    public void initialize() {
        logger.info("Initializing database...");
        // JPA auto-creates tables based on entities
        // Add any custom initialization here
        logger.info("Database initialized successfully");
    }

    /**
     * Create default admin user if not exists.
     */
    @Transactional
    public void ensureDefaultUser() {
        if (!userRepository.existsByEmail("admin@vegatrader.com")) {
            User admin = new User();
            admin.setEmail("admin@vegatrader.com");
            admin.setFullName("Admin");
            admin.setActive(true);
            admin.setSuperuser(true);
            userRepository.save(admin);
            logger.info("Created default admin user");
        }
    }

    /**
     * Run database migrations.
     */
    @Transactional
    public void runMigrations() {
        logger.info("Running database migrations...");
        // Add migration logic here if needed
        logger.info("Migrations completed");
    }

    /**
     * Get database stats.
     */
    public String getDatabaseStats() {
        long users = userRepository.count();
        long tokens = tokenRepository.count();
        long strategies = strategyRepository.count();

        return String.format("Users: %d, Tokens: %d, Strategies: %d", users, tokens, strategies);
    }
}
