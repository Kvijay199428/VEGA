package com.vegatrader.service;

import com.vegatrader.optionchain.proto.MarketDataFeedOptionChainV3;
import com.vegatrader.valuation.ValuationCalculator;
import com.vegatrader.valuation.model.OptionStrikeData;
import com.vegatrader.valuation.model.OptionStrikeData.OptionSideData;
import com.vegatrader.websocket.MarketDataWebSocketHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Service to manage live option chain updates and Greeks calculation.
 */
@Service
public class OptionChainLiveService {

    private static final Logger logger = LoggerFactory.getLogger(OptionChainLiveService.class);

    private final MarketDataWebSocketService webSocketService;
    private final MarketDataWebSocketHandler webSocketHandler;

    // key: channel (e.g. option_chain:NSE_INDEX|Nifty 50:2023-12-28), value: chain
    // data
    private final Map<String, List<OptionStrikeData>> activeChains = new ConcurrentHashMap<>();

    // key: instrument_key, value: Set of channels that include this instrument
    private final Map<String, Set<String>> instrumentToChannels = new ConcurrentHashMap<>();

    public OptionChainLiveService(MarketDataWebSocketService webSocketService,
            MarketDataWebSocketHandler webSocketHandler) {
        this.webSocketService = webSocketService;
        this.webSocketHandler = webSocketHandler;
    }

    @PostConstruct
    public void init() {
        webSocketService.addListener("OptionChainLiveService", this::handleMarketData);
    }

    /**
     * Register a new option chain for live updates.
     */
    public void registerChain(String underlyingKey, String expiry, List<OptionStrikeData> chain) {
        String channel = String.format("option_chain:%s:%s", underlyingKey, expiry);
        activeChains.put(channel, chain);

        // Map instruments to this channel for quick lookup
        for (OptionStrikeData row : chain) {
            if (row.getCall() != null) {
                mapInstrumentToChannel(row.getCall().getInstrumentKey(), channel);
                webSocketService.subscribe(row.getCall().getInstrumentKey());
            }
            if (row.getPut() != null) {
                mapInstrumentToChannel(row.getPut().getInstrumentKey(), channel);
                webSocketService.subscribe(row.getPut().getInstrumentKey());
            }
        }

        // Also subscribe to underlying spot price if possible
        webSocketService.subscribe(underlyingKey);
        mapInstrumentToChannel(underlyingKey, channel);

        logger.info("Registered live option chain: {}", channel);
    }

    private void mapInstrumentToChannel(String instrumentKey, String channel) {
        instrumentToChannels.computeIfAbsent(instrumentKey, k -> ConcurrentHashMap.newKeySet()).add(channel);
    }

    private void handleMarketData(Map<String, Object> data) {
        if (!"live_feed".equals(data.get("type")))
            return;

        @SuppressWarnings("unchecked")
        Map<String, MarketDataFeedOptionChainV3.Feed> feeds = (Map<String, MarketDataFeedOptionChainV3.Feed>) data
                .get("feeds");

        Set<String> channelsToUpdate = new HashSet<>();

        for (Map.Entry<String, MarketDataFeedOptionChainV3.Feed> entry : feeds.entrySet()) {
            String instKey = entry.getKey();
            MarketDataFeedOptionChainV3.Feed feed = entry.getValue();

            Set<String> channels = instrumentToChannels.get(instKey);
            if (channels != null) {
                for (String channel : channels) {
                    updateChainWithFeed(channel, instKey, feed);
                    channelsToUpdate.add(channel);
                }
            }
        }

        if (feeds != null && !feeds.isEmpty()) {
            logger.info("Received market data for {} instruments, updating {} channels", feeds.size(),
                    channelsToUpdate.size());
        }

        // Calculate Greeks and broadcast for affected channels
        for (String channel : channelsToUpdate) {
            List<OptionStrikeData> chain = activeChains.get(channel);
            if (chain != null) {
                // Perform valuation calculation
                ValuationCalculator.calculateOptionChainValuations(chain);

                // Broadcast to websocket clients
                Map<String, Object> message = new HashMap<>();
                message.put("type", "option_chain_update");
                message.put("channel", channel);
                message.put("data", Map.of(
                        "data", chain,
                        "updated_at", new java.util.Date().toString()));

                // We use the underlying key as the broadcast key for now
                String underlyingKey = channel.split(":")[1];
                webSocketHandler.broadcastMarketData(underlyingKey, message);
            }
        }
    }

    private void updateChainWithFeed(String channel, String instKey, MarketDataFeedOptionChainV3.Feed feed) {
        List<OptionStrikeData> chain = activeChains.get(channel);
        if (chain == null)
            return;

        double ltp = 0;
        double bid = 0;
        double ask = 0;
        int volume = 0;
        int oi = 0;
        double iv = 0;

        // Extract data from feed union
        if (feed.hasLtpc()) {
            ltp = feed.getLtpc().getLtp();
        } else if (feed.hasFullFeed()) {
            if (feed.getFullFeed().hasMarketFF()) {
                MarketDataFeedOptionChainV3.MarketFullFeed mff = feed.getFullFeed().getMarketFF();
                ltp = mff.getLtpc().getLtp();
                if (mff.hasMarketLevel() && mff.getMarketLevel().getBidAskQuoteCount() > 0) {
                    MarketDataFeedOptionChainV3.Quote q = mff.getMarketLevel().getBidAskQuote(0);
                    bid = q.getBidP();
                    ask = q.getAskP();
                }
                volume = (int) mff.getVtt();
                oi = (int) mff.getOi();
                iv = mff.getIv();
            } else if (feed.getFullFeed().hasIndexFF()) {
                ltp = feed.getFullFeed().getIndexFF().getLtpc().getLtp();
            }
        }

        // Update the chain rows
        for (OptionStrikeData row : chain) {
            // Check if it's the underlying instrument
            if (instKey.equals(row.getUnderlyingKey())) {
                row.setUnderlyingSpotPrice(ltp);
                continue;
            }

            if (row.getCall() != null && instKey.equals(row.getCall().getInstrumentKey())) {
                updateOptionSide(row.getCall(), ltp, bid, ask, volume, oi, iv);
            } else if (row.getPut() != null && instKey.equals(row.getPut().getInstrumentKey())) {
                updateOptionSide(row.getPut(), ltp, bid, ask, volume, oi, iv);
            }
        }
    }

    private void updateOptionSide(OptionSideData side, double ltp, double bid, double ask, int volume, int oi,
            double iv) {
        if (ltp > 0)
            side.setLtp(ltp);
        if (bid > 0)
            side.setBidPrice(bid);
        if (ask > 0)
            side.setAskPrice(ask);
        if (volume > 0)
            side.setVolume(volume);
        if (oi > 0)
            side.setOi(oi);
        if (iv > 0)
            side.setIv(iv);
    }
}
