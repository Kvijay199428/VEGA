package com.vegatrader.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Subscription settings service for managing user subscriptions.
 */
@Service
public class SubscriptionSettingsService {

    private static final Logger logger = LoggerFactory.getLogger(SubscriptionSettingsService.class);

    // User subscriptions: userId -> Set of instrument keys
    private final Map<Long, Set<String>> userSubscriptions = new ConcurrentHashMap<>();

    /**
     * Get user's subscriptions.
     */
    public Set<String> getSubscriptions(Long userId) {
        return userSubscriptions.getOrDefault(userId, new HashSet<>());
    }

    /**
     * Add subscription for user.
     */
    public void addSubscription(Long userId, String instrumentKey) {
        userSubscriptions.computeIfAbsent(userId, k -> ConcurrentHashMap.newKeySet())
                .add(instrumentKey);
        logger.info("Subscription added: user={}, instrument={}", userId, instrumentKey);
    }

    /**
     * Remove subscription for user.
     */
    public void removeSubscription(Long userId, String instrumentKey) {
        Set<String> subs = userSubscriptions.get(userId);
        if (subs != null) {
            subs.remove(instrumentKey);
        }
        logger.info("Subscription removed: user={}, instrument={}", userId, instrumentKey);
    }

    /**
     * Update user's subscriptions.
     */
    public void updateSubscriptions(Long userId, Set<String> instrumentKeys) {
        userSubscriptions.put(userId, new HashSet<>(instrumentKeys));
        logger.info("Subscriptions updated: user={}, count={}", userId, instrumentKeys.size());
    }

    /**
     * Clear all subscriptions for user.
     */
    public void clearSubscriptions(Long userId) {
        userSubscriptions.remove(userId);
        logger.info("Subscriptions cleared: user={}", userId);
    }

    /**
     * Get all active subscriptions across users.
     */
    public Set<String> getAllActiveSubscriptions() {
        Set<String> all = new HashSet<>();
        for (Set<String> subs : userSubscriptions.values()) {
            all.addAll(subs);
        }
        return all;
    }
}
