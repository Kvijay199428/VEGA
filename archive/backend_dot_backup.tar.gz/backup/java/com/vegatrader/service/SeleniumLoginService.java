package com.vegatrader.service;

import com.vegatrader.model.entity.UpstoxToken;
import com.vegatrader.repository.UpstoxTokenRepository;
import dev.samstevens.totp.code.CodeGenerator;
import dev.samstevens.totp.code.DefaultCodeGenerator;
import dev.samstevens.totp.time.SystemTimeProvider;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Selenium-based automated login service for Upstox.
 * Mimics the Python auth_flow.py automation.
 */
@Service
public class SeleniumLoginService {

    private static final Logger logger = LoggerFactory.getLogger(SeleniumLoginService.class);

    @Value("${upstox.auth-url}")
    private String authUrl;

    @Value("${upstox.redirect-uri}")
    private String redirectUri;
    private String lastError = "";

    private final UpstoxTokenRepository tokenRepository;
    private final UpstoxAuthService upstoxAuthService;

    // Login credentials from .env
    private String mobileNumber;
    private String pin;
    private String totpSecret;

    // Status tracking
    private final AtomicBoolean isRunning = new AtomicBoolean(false);
    private final AtomicInteger completedCount = new AtomicInteger(0);
    private final AtomicInteger totalCount = new AtomicInteger(0);
    private String currentStatus = "Idle";
    private String currentApiName = "";

    public SeleniumLoginService(UpstoxTokenRepository tokenRepository, UpstoxAuthService upstoxAuthService) {
        this.tokenRepository = tokenRepository;
        this.upstoxAuthService = upstoxAuthService;
        loadCredentials();
    }

    private void loadCredentials() {
        // Load from backend/.env file
        String[] paths = {
                "D:/projects/VEGA TRADER/backend/.env",
                "d:/projects/VEGA TRADER/backend/.env",
                "../../.env"
        };

        for (String path : paths) {
            File envFile = new File(path);
            if (envFile.exists()) {
                try (BufferedReader reader = new BufferedReader(new FileReader(envFile))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        line = line.trim();
                        if (line.isEmpty() || line.startsWith("#"))
                            continue;
                        int eq = line.indexOf('=');
                        if (eq > 0) {
                            String key = line.substring(0, eq).trim();
                            String value = line.substring(eq + 1).trim();
                            if (value.startsWith("\"") && value.endsWith("\"")) {
                                value = value.substring(1, value.length() - 1);
                            }
                            switch (key) {
                                case "UPSTOX_MOBILE_NUMBER" -> mobileNumber = value;
                                case "UPSTOX_PIN" -> pin = value;
                                case "UPSTOX_TOTP" -> totpSecret = value;
                            }
                        }
                    }
                    logger.info("Loaded login credentials from .env: mobile={}, pin={}, totp={}",
                            mobileNumber != null ? "present" : "missing",
                            pin != null ? "present" : "missing",
                            totpSecret != null ? "present" : "missing");
                    return;
                } catch (Exception e) {
                    logger.error("Error loading .env: {}", e.getMessage());
                }
            }
        }
        logger.warn("Could not load login credentials from .env");
    }

    /**
     * Get current automation status.
     */
    public Map<String, Object> getStatus() {
        Map<String, Object> status = new HashMap<>();
        status.put("is_running", isRunning.get());
        status.put("completed", completedCount.get());
        status.put("total", totalCount.get());
        status.put("current_status", currentStatus);
        status.put("current_api", currentApiName);
        status.put("last_error", lastError);
        return status;
    }

    /**
     * Start automated multi-login process.
     */
    @Async
    public void startMultiLogin(int startIndex) {
        if (isRunning.get()) {
            logger.warn("Multi-login already running");
            return;
        }

        if (mobileNumber == null || pin == null || totpSecret == null) {
            logger.error("Missing login credentials. Cannot start automation.");
            currentStatus = "Error: Missing credentials";
            return;
        }

        isRunning.set(true);
        completedCount.set(0);
        currentStatus = "Starting...";

        try {
            // Get all tokens that need login
            List<UpstoxToken> tokensNeedingLogin = new ArrayList<>();
            for (UpstoxToken token : tokenRepository.findAll()) {
                if (token.getClientId() != null && !token.getClientId().isEmpty()) {
                    boolean needsToken = token.getAccessToken() == null || token.getAccessToken().isEmpty();
                    if (!needsToken && token.getValidityAt() != null) {
                        try {
                            Instant validity = Instant.parse(token.getValidityAt());
                            needsToken = Instant.now().isAfter(validity);
                        } catch (Exception e) {
                            needsToken = true;
                        }
                    }
                    if (needsToken) {
                        tokensNeedingLogin.add(token);
                    }
                }
            }

            totalCount.set(tokensNeedingLogin.size());
            logger.info("Found {} APIs needing login", totalCount.get());

            if (tokensNeedingLogin.isEmpty()) {
                currentStatus = "All tokens already valid!";
                isRunning.set(false);
                return;
            }

            // Setup WebDriver
            WebDriverManager.chromedriver().setup();
            WebDriver driver = createDriver();

            try {
                for (UpstoxToken token : tokensNeedingLogin) {
                    currentApiName = token.getApiName();
                    currentStatus = "Logging in: " + currentApiName;
                    logger.info("Processing login for: {}", currentApiName);

                    boolean success = performLogin(driver, token);
                    if (success) {
                        completedCount.incrementAndGet();
                        currentStatus = "Completed: " + currentApiName + " (" + completedCount.get() + "/"
                                + totalCount.get() + ")";
                        logger.info("Login successful for: {}", currentApiName);
                    } else {
                        currentStatus = "Failed: " + currentApiName + " (" + lastError + ")";
                        logger.error("Login failed for: {}", currentApiName);
                    }

                    // Wait between logins to avoid rate limits
                    Thread.sleep(2000);
                }
            } finally {
                try {
                    driver.quit();
                } catch (Exception e) {
                    logger.warn("Error closing driver: {}", e.getMessage());
                }
            }

            currentStatus = "Completed: " + completedCount.get() + "/" + totalCount.get() + " tokens generated";
            logger.info("Multi-login completed: {}/{}", completedCount.get(), totalCount.get());

        } catch (Exception e) {
            logger.error("Multi-login error: {}", e.getMessage(), e);
            currentStatus = "Error: " + e.getMessage();
        } finally {
            isRunning.set(false);
        }
    }

    private WebDriver createDriver() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--disable-gpu");
        options.addArguments("--window-size=1200,800");
        // options.addArguments("--headless"); // Uncomment for headless mode

        return new ChromeDriver(options);
    }

    private boolean performLogin(WebDriver driver, UpstoxToken token) {
        try {
            String loginUrl = String.format("%s?response_type=code&client_id=%s&redirect_uri=%s&state=%s",
                    authUrl, token.getClientId(), redirectUri, token.getApiName());

            logger.info("Navigating to: {}", loginUrl);
            driver.get(loginUrl);

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
            Thread.sleep(2000);

            String currentUrl = driver.getCurrentUrl();
            String redirectDomain = redirectUri.split("://")[1].split("/")[0];

            // Check if already redirected (session remembered)
            if (currentUrl.contains(redirectDomain)) {
                logger.info("Already redirected - extracting auth code");
                return extractAndExchangeToken(driver, currentUrl, token);
            }

            // Check for PIN page (session remembered)
            WebElement pinInput = null;
            try {
                pinInput = wait.withTimeout(Duration.ofSeconds(5))
                        .until(ExpectedConditions.presenceOfElementLocated(By.id("pinCode")));
                logger.info("Found PIN page - session remembered");
            } catch (TimeoutException e) {
                logger.info("PIN page not found, looking for mobile input...");
            }

            if (pinInput == null) {
                // Fresh login - enter mobile number
                WebElement mobileInput = wait.until(
                        ExpectedConditions.presenceOfElementLocated(By.id("mobileNum")));
                mobileInput.clear();
                mobileInput.sendKeys(mobileNumber);
                logger.info("Entered mobile number");

                // Click Get OTP
                WebElement getOtpBtn = wait.until(
                        ExpectedConditions.elementToBeClickable(By.id("getOtp")));
                getOtpBtn.click();
                logger.info("Clicked Get OTP");

                Thread.sleep(3000);

                // Check for rate limit error
                try {
                    WebElement errorMsg = driver.findElement(By.className("error-msg"));
                    if (errorMsg.getText().contains("1017069")
                            || errorMsg.getText().toLowerCase().contains("exceeded")) {
                        logger.error("OTP rate limit exceeded!");
                        return false;
                    }
                } catch (org.openqa.selenium.NoSuchElementException ignored) {
                }

                // Generate and enter TOTP
                String totpCode = generateTotpCode();
                logger.info("Generated TOTP code: {}", totpCode);

                WebElement otpInput = wait.until(
                        ExpectedConditions.presenceOfElementLocated(By.id("otpNum")));
                otpInput.clear();
                otpInput.sendKeys(totpCode);
                logger.info("Entered TOTP code");

                // Click continue
                WebElement continueBtn = wait.until(
                        ExpectedConditions.elementToBeClickable(By.id("continueBtn")));
                continueBtn.click();
                logger.info("Clicked continue");

                Thread.sleep(3000);

                // Wait for PIN input
                pinInput = wait.until(
                        ExpectedConditions.presenceOfElementLocated(By.id("pinCode")));
            }

            // Enter PIN
            pinInput.clear();
            pinInput.sendKeys(pin);
            logger.info("Entered PIN");

            // Click PIN continue
            WebElement pinContinueBtn = wait.until(
                    ExpectedConditions.elementToBeClickable(By.id("pinContinueBtn")));
            pinContinueBtn.click();
            logger.info("Clicked PIN continue");

            // Wait for redirect
            wait.withTimeout(Duration.ofSeconds(60)).until(
                    d -> d.getCurrentUrl().contains(redirectDomain));

            String redirectedUrl = driver.getCurrentUrl();
            return extractAndExchangeToken(driver, redirectedUrl, token);

        } catch (Exception e) {
            lastError = e.getMessage();
            logger.error("Login error for {}: {}", token.getApiName(), e.getMessage());
            return false;
        }
    }

    private boolean extractAndExchangeToken(WebDriver driver, String url, UpstoxToken token) {
        try {
            // Try to get code from HTML element first (for ML: state)
            try {
                WebElement codeElement = driver.findElement(By.id("auth-code"));
                String code = codeElement.getText().replace("Code: ", "").trim();
                if (!code.isEmpty()) {
                    return exchangeCode(code, token);
                }
            } catch (org.openqa.selenium.NoSuchElementException ignored) {
            }

            // Extract from URL
            String[] parts = url.split("\\?");
            if (parts.length > 1) {
                String query = parts[1];
                for (String param : query.split("&")) {
                    String[] kv = param.split("=");
                    if (kv.length == 2 && kv[0].equals("code")) {
                        return exchangeCode(kv[1], token);
                    }
                }
            }

            logger.error("Could not extract auth code from URL");
            return false;

        } catch (Exception e) {
            logger.error("Token extraction error: {}", e.getMessage());
            return false;
        }
    }

    private boolean exchangeCode(String code, UpstoxToken token) {
        try {
            Map<String, Object> result = upstoxAuthService.exchangeToken(code, token.getApiName());
            return "success".equals(result.get("status"));
        } catch (Exception e) {
            logger.error("Token exchange failed: {}", e.getMessage());
            return false;
        }
    }

    private String generateTotpCode() {
        try {
            CodeGenerator codeGenerator = new DefaultCodeGenerator();
            SystemTimeProvider timeProvider = new SystemTimeProvider();
            long currentBucket = Math.floorDiv(timeProvider.getTime(), 30);
            return codeGenerator.generate(totpSecret, currentBucket);
        } catch (Exception e) {
            logger.error("TOTP generation error: {}", e.getMessage());
            return "";
        }
    }
}
