package com.vegatrader.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Webhook handling service.
 */
@Service
public class WebhookService {

    private static final Logger logger = LoggerFactory.getLogger(WebhookService.class);

    // In-memory webhook log
    private final List<Map<String, Object>> webhookLog = Collections.synchronizedList(new ArrayList<>());
    private final Map<String, List<WebhookHandler>> handlers = new ConcurrentHashMap<>();

    /**
     * Register a webhook handler.
     */
    public void registerHandler(String eventType, WebhookHandler handler) {
        handlers.computeIfAbsent(eventType, k -> new ArrayList<>()).add(handler);
        logger.info("Webhook handler registered for: {}", eventType);
    }

    /**
     * Process incoming webhook.
     */
    public Map<String, Object> processWebhook(String eventType, Map<String, Object> payload) {
        Map<String, Object> result = new HashMap<>();
        result.put("event_type", eventType);
        result.put("received_at", LocalDateTime.now().toString());
        result.put("status", "received");

        // Log webhook
        Map<String, Object> logEntry = new HashMap<>(payload);
        logEntry.put("event_type", eventType);
        logEntry.put("received_at", LocalDateTime.now().toString());
        webhookLog.add(logEntry);

        // Process handlers
        List<WebhookHandler> eventHandlers = handlers.get(eventType);
        if (eventHandlers != null) {
            for (WebhookHandler handler : eventHandlers) {
                try {
                    handler.handle(payload);
                } catch (Exception e) {
                    logger.error("Webhook handler failed: {}", e.getMessage());
                }
            }
            result.put("handlers_executed", eventHandlers.size());
        } else {
            result.put("handlers_executed", 0);
        }

        logger.info("Webhook processed: {}", eventType);
        return result;
    }

    /**
     * Handle order update webhook.
     */
    public Map<String, Object> handleOrderUpdate(Map<String, Object> payload) {
        logger.info("Order update webhook: {}", payload.get("order_id"));
        return processWebhook("order_update", payload);
    }

    /**
     * Handle position update webhook.
     */
    public Map<String, Object> handlePositionUpdate(Map<String, Object> payload) {
        logger.info("Position update webhook");
        return processWebhook("position_update", payload);
    }

    /**
     * Handle trade update webhook.
     */
    public Map<String, Object> handleTradeUpdate(Map<String, Object> payload) {
        logger.info("Trade update webhook: {}", payload.get("trade_id"));
        return processWebhook("trade_update", payload);
    }

    /**
     * Get webhook log.
     */
    public List<Map<String, Object>> getWebhookLog(int limit) {
        int start = Math.max(0, webhookLog.size() - limit);
        return new ArrayList<>(webhookLog.subList(start, webhookLog.size()));
    }

    /**
     * Webhook handler interface.
     */
    @FunctionalInterface
    public interface WebhookHandler {
        void handle(Map<String, Object> payload);
    }
}
