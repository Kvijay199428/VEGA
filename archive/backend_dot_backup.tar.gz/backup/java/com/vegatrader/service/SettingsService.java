package com.vegatrader.service;

import com.vegatrader.model.entity.User;
import com.vegatrader.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * User settings service.
 */
@Service
public class SettingsService {

    private static final Logger logger = LoggerFactory.getLogger(SettingsService.class);

    private final UserRepository userRepository;

    // In-memory settings storage (should be persisted in production)
    private final Map<Long, Map<String, Object>> userSettings = new HashMap<>();

    public SettingsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Get user settings.
     */
    public Map<String, Object> getSettings(String email) {
        User user = getUserByEmail(email);
        return userSettings.getOrDefault(user.getId(), getDefaultSettings());
    }

    /**
     * Update user settings.
     */
    public Map<String, Object> updateSettings(String email, Map<String, Object> settings) {
        User user = getUserByEmail(email);
        Map<String, Object> current = userSettings.getOrDefault(user.getId(), getDefaultSettings());
        current.putAll(settings);
        userSettings.put(user.getId(), current);
        logger.info("Settings updated for user: {}", email);
        return current;
    }

    /**
     * Get specific setting.
     */
    public Object getSetting(String email, String key) {
        Map<String, Object> settings = getSettings(email);
        return settings.get(key);
    }

    /**
     * Reset settings to default.
     */
    public Map<String, Object> resetSettings(String email) {
        User user = getUserByEmail(email);
        Map<String, Object> defaults = getDefaultSettings();
        userSettings.put(user.getId(), defaults);
        logger.info("Settings reset for user: {}", email);
        return defaults;
    }

    private User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found: " + email));
    }

    private Map<String, Object> getDefaultSettings() {
        Map<String, Object> defaults = new HashMap<>();
        defaults.put("theme", "dark");
        defaults.put("defaultExchange", "NSE");
        defaults.put("defaultProduct", "Intraday");
        defaults.put("defaultOrderType", "MARKET");
        defaults.put("showValuation", true);
        defaults.put("showGreeks", true);
        defaults.put("refreshInterval", 1000);
        defaults.put("notificationsEnabled", true);
        defaults.put("soundEnabled", true);
        return defaults;
    }
}
