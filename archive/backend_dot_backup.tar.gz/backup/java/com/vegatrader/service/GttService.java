package com.vegatrader.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.vegatrader.client.UpstoxClient;
import com.vegatrader.model.entity.UpstoxToken;
import com.vegatrader.repository.UpstoxTokenRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * GTT (Good Till Triggered) order service.
 */
@Service
public class GttService {

    private static final Logger logger = LoggerFactory.getLogger(GttService.class);

    private final UpstoxClient upstoxClient;
    private final UpstoxTokenRepository tokenRepository;

    public GttService(UpstoxClient upstoxClient, UpstoxTokenRepository tokenRepository) {
        this.upstoxClient = upstoxClient;
        this.tokenRepository = tokenRepository;
    }

    /**
     * Get all GTT orders.
     */
    public Map<String, Object> getGttOrders() {
        String token = getAccessToken();
        try {
            JsonNode response = upstoxClient.get("/gtt/orders", token);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to fetch GTT orders: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch GTT orders", e);
        }
    }

    /**
     * Place a GTT order.
     */
    public Map<String, Object> placeGttOrder(Map<String, Object> request) {
        String token = getAccessToken();
        try {
            JsonNode response = upstoxClient.post("/gtt/orders", token, request);
            logger.info("GTT order placed");
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to place GTT order: {}", e.getMessage());
            throw new RuntimeException("Failed to place GTT order", e);
        }
    }

    /**
     * Modify a GTT order.
     */
    public Map<String, Object> modifyGttOrder(String gttOrderId, Map<String, Object> request) {
        String token = getAccessToken();
        try {
            request.put("gtt_order_id", gttOrderId);
            JsonNode response = upstoxClient.put("/gtt/orders", token, request);
            logger.info("GTT order modified: {}", gttOrderId);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to modify GTT order: {}", e.getMessage());
            throw new RuntimeException("Failed to modify GTT order", e);
        }
    }

    /**
     * Cancel a GTT order.
     */
    public Map<String, Object> cancelGttOrder(String gttOrderId) {
        String token = getAccessToken();
        try {
            JsonNode response = upstoxClient.delete("/gtt/orders/" + gttOrderId, token);
            logger.info("GTT order cancelled: {}", gttOrderId);
            return parseResponse(response);
        } catch (Exception e) {
            logger.error("Failed to cancel GTT order: {}", e.getMessage());
            throw new RuntimeException("Failed to cancel GTT order", e);
        }
    }

    private String getAccessToken() {
        return tokenRepository.findByIsPrimaryTrue()
                .map(UpstoxToken::getAccessToken)
                .orElseThrow(() -> new RuntimeException("No access token available"));
    }

    private Map<String, Object> parseResponse(JsonNode response) {
        Map<String, Object> result = new HashMap<>();
        result.put("status", response.path("status").asText());
        result.put("data", response.path("data"));
        return result;
    }
}
