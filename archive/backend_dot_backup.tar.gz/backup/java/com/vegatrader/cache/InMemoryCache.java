package com.vegatrader.cache;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory cache implementation (Mock Redis).
 * Equivalent to Python MockRedis in database/connection.py
 * 
 * For production, replace with Redis using Spring Data Redis.
 */
@Component
public class InMemoryCache {

    private static final Logger logger = LoggerFactory.getLogger(InMemoryCache.class);

    private final Map<String, Object> data = new ConcurrentHashMap<>();
    private final Map<String, Map<String, Object>> hashData = new ConcurrentHashMap<>();

    /**
     * Get value by key.
     */
    public Object get(String key) {
        return data.get(key);
    }

    /**
     * Set value with key.
     */
    public void set(String key, Object value) {
        data.put(key, value);
    }

    /**
     * Set value with TTL (TTL ignored in mock).
     */
    public void set(String key, Object value, int ttlSeconds) {
        data.put(key, value);
        // TODO: Implement TTL expiry with scheduled task
    }

    /**
     * Delete key.
     */
    public void delete(String key) {
        data.remove(key);
    }

    /**
     * Check if key exists.
     */
    public boolean exists(String key) {
        return data.containsKey(key);
    }

    /**
     * Hash set.
     */
    public void hset(String name, String key, Object value) {
        hashData.computeIfAbsent(name, k -> new ConcurrentHashMap<>()).put(key, value);
    }

    /**
     * Hash set with mapping.
     */
    public void hset(String name, Map<String, Object> mapping) {
        hashData.computeIfAbsent(name, k -> new ConcurrentHashMap<>()).putAll(mapping);
    }

    /**
     * Hash get.
     */
    public Object hget(String name, String key) {
        Map<String, Object> hash = hashData.get(name);
        return hash != null ? hash.get(key) : null;
    }

    /**
     * Hash get all.
     */
    public Map<String, Object> hgetall(String name) {
        return hashData.getOrDefault(name, new ConcurrentHashMap<>());
    }

    /**
     * Hash delete.
     */
    public void hdel(String name, String... keys) {
        Map<String, Object> hash = hashData.get(name);
        if (hash != null) {
            for (String key : keys) {
                hash.remove(key);
            }
        }
    }

    /**
     * Publish message (mock - just logs).
     */
    public void publish(String channel, String message) {
        logger.debug("Mock publish to {}: {}", channel, message);
    }

    /**
     * Clear all data.
     */
    public void clear() {
        data.clear();
        hashData.clear();
    }

    /**
     * Get cache size.
     */
    public int size() {
        return data.size() + hashData.size();
    }
}
