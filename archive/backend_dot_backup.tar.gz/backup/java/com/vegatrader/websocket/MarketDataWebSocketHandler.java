package com.vegatrader.websocket;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Market data WebSocket handler for client connections.
 */
@Component
public class MarketDataWebSocketHandler extends TextWebSocketHandler {

    private static final Logger logger = LoggerFactory.getLogger(MarketDataWebSocketHandler.class);
    private final ObjectMapper objectMapper = new ObjectMapper();

    // Session management
    private final Map<String, WebSocketSession> sessions = new ConcurrentHashMap<>();
    private final Map<String, Set<String>> sessionSubscriptions = new ConcurrentHashMap<>();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        System.out.println("WebSocket Connected: " + session.getId());
        sessions.put(session.getId(), session);
        sessionSubscriptions.put(session.getId(), ConcurrentHashMap.newKeySet());
        logger.info("📊 WebSocket connected: {}", session.getId());
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) {
        try {
            System.out.println("WebSocket Msg from " + session.getId() + ": " + message.getPayload());
            JsonNode json = objectMapper.readTree(message.getPayload());
            String action = json.path("action").asText();
            // ... rest of method
            switch (action) {
                case "subscribe":
                    handleSubscribe(session, json);
                    break;
                case "unsubscribe":
                    handleUnsubscribe(session, json);
                    break;
                case "subscribe_option_chain":
                    handleOptionChainSubscribe(session, json);
                    break;
                case "unsubscribe_option_chain":
                    handleOptionChainUnsubscribe(session, json);
                    break;
                case "ping":
                    session.sendMessage(new TextMessage("{\"action\":\"pong\"}"));
                    break;
                default:
                    // Check if 'type' is used instead of 'action' (frontend uses 'type')
                    String type = json.path("type").asText();
                    if ("subscribe_option_chain".equals(type)) {
                        handleOptionChainSubscribe(session, json);
                    } else if ("unsubscribe_option_chain".equals(type)) {
                        handleOptionChainUnsubscribe(session, json);
                    } else {
                        logger.warn("Unknown action/type: {}/{}", action, type);
                    }
            }
        } catch (Exception e) {
            logger.error("Error handling message: {}", e.getMessage());
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        System.out.println("WebSocket Closed: " + session.getId() + ", Status: " + status);
        sessions.remove(session.getId());
        sessionSubscriptions.remove(session.getId());
        logger.info("WebSocket disconnected: {} - {}", session.getId(), status.getReason());
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) {
        logger.error("WebSocket error for {}: {}", session.getId(), exception.getMessage());
    }

    /**
     * Handle subscribe request.
     */
    private void handleSubscribe(WebSocketSession session, JsonNode json) throws Exception {
        JsonNode instruments = json.path("instruments");
        if (instruments.isArray()) {
            Set<String> subs = sessionSubscriptions.get(session.getId());
            for (JsonNode inst : instruments) {
                String key = inst.asText();
                subs.add(key);
                logger.debug("Subscribed {} to {}", session.getId(), key);
            }
            session.sendMessage(new TextMessage(
                    "{\"action\":\"subscribed\",\"count\":" + subs.size() + "}"));
        }
    }

    /**
     * Handle unsubscribe request.
     */
    private void handleUnsubscribe(WebSocketSession session, JsonNode json) throws Exception {
        JsonNode instruments = json.path("instruments");
        if (instruments.isArray()) {
            Set<String> subs = sessionSubscriptions.get(session.getId());
            for (JsonNode inst : instruments) {
                subs.remove(inst.asText());
            }
            session.sendMessage(new TextMessage(
                    "{\"action\":\"unsubscribed\",\"count\":" + subs.size() + "}"));
        }
    }

    private void handleOptionChainSubscribe(WebSocketSession session, JsonNode json) throws Exception {
        String instKey = json.path("instrument_key").asText();
        String expiry = json.path("expiry_date").asText();

        if (instKey.isEmpty() || expiry.isEmpty())
            return;

        Set<String> subs = sessionSubscriptions.get(session.getId());
        subs.add(instKey); // Add underlying to subscriptions

        session.sendMessage(new TextMessage(
                String.format("{\"type\":\"option_chain_subscription_ack\",\"channel\":\"option_chain:%s:%s\"}",
                        instKey, expiry)));

        logger.info("Client {} subscribed to option chain: {}:{}", session.getId(), instKey, expiry);
    }

    private void handleOptionChainUnsubscribe(WebSocketSession session, JsonNode json) throws Exception {
        String instKey = json.path("instrument_key").asText();
        String expiry = json.path("expiry_date").asText();

        session.sendMessage(new TextMessage(
                String.format("{\"type\":\"option_chain_unsubscribe_ack\",\"channel\":\"option_chain:%s:%s\"}",
                        instKey, expiry)));
    }

    /**
     * Broadcast market data to subscribed sessions.
     */
    public void broadcastMarketData(String instrumentKey, Map<String, Object> data) {
        try {
            String message = objectMapper.writeValueAsString(data);
            TextMessage textMessage = new TextMessage(message);

            for (Map.Entry<String, WebSocketSession> entry : sessions.entrySet()) {
                Set<String> subs = sessionSubscriptions.get(entry.getKey());
                if (subs != null && subs.contains(instrumentKey)) {
                    try {
                        if (entry.getValue().isOpen()) {
                            entry.getValue().sendMessage(textMessage);
                        }
                    } catch (Exception e) {
                        logger.error("Error sending to {}: {}", entry.getKey(), e.getMessage());
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Error broadcasting: {}", e.getMessage());
        }
    }

    /**
     * Get active session count.
     */
    public int getActiveSessionCount() {
        return sessions.size();
    }

    /**
     * Get total subscription count.
     */
    public int getTotalSubscriptionCount() {
        return sessionSubscriptions.values().stream()
                .mapToInt(Set::size)
                .sum();
    }
}
