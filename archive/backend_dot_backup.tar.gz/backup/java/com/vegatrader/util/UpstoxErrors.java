package com.vegatrader.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Upstox API error handling utilities.
 */
public class UpstoxErrors {

    private static final Logger logger = LoggerFactory.getLogger(UpstoxErrors.class);

    private static final Map<String, String> ERROR_MESSAGES = new HashMap<>();

    static {
        ERROR_MESSAGES.put("UDAPI10001", "Invalid request");
        ERROR_MESSAGES.put("UDAPI10002", "Invalid API key");
        ERROR_MESSAGES.put("UDAPI10003", "Invalid access token");
        ERROR_MESSAGES.put("UDAPI10004", "Access token expired");
        ERROR_MESSAGES.put("UDAPI10005", "Invalid instrument key");
        ERROR_MESSAGES.put("UDAPI10006", "Insufficient funds");
        ERROR_MESSAGES.put("UDAPI10007", "Order quantity exceeds limit");
        ERROR_MESSAGES.put("UDAPI10008", "Invalid order type");
        ERROR_MESSAGES.put("UDAPI10009", "Market closed");
        ERROR_MESSAGES.put("UDAPI10010", "Rate limit exceeded");
        ERROR_MESSAGES.put("UDAPI100050", "Invalid credentials");
        ERROR_MESSAGES.put("UDAPI100057", "Invalid state parameter");
        ERROR_MESSAGES.put("UDAPI100068", "Invalid redirect URI");
    }

    /**
     * Get friendly error message for error code.
     */
    public static String getMessage(String errorCode) {
        return ERROR_MESSAGES.getOrDefault(errorCode, "Unknown error: " + errorCode);
    }

    /**
     * Check if error is retryable.
     */
    public static boolean isRetryable(String errorCode) {
        return "UDAPI10010".equals(errorCode) || // Rate limit
                "UDAPI10009".equals(errorCode); // Market closed
    }

    /**
     * Check if token refresh is needed.
     */
    public static boolean needsTokenRefresh(String errorCode) {
        return "UDAPI10003".equals(errorCode) || // Invalid token
                "UDAPI10004".equals(errorCode); // Token expired
    }

    /**
     * Log error with context.
     */
    public static void logError(String errorCode, String context) {
        String message = getMessage(errorCode);
        logger.error("Upstox error [{}]: {} - Context: {}", errorCode, message, context);
    }
}
