package com.vegatrader.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;

/**
 * Market data decoder for WebSocket binary messages.
 */
public class MarketDataDecoder {

    private static final Logger logger = LoggerFactory.getLogger(MarketDataDecoder.class);
    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Decode binary market data to Map.
     */
    public static Map<String, Object> decode(byte[] data) {
        Map<String, Object> result = new HashMap<>();

        try {
            ByteBuffer buffer = ByteBuffer.wrap(data);

            // Simplified decoder - actual implementation depends on Upstox binary format
            result.put("raw_length", data.length);
            result.put("timestamp", System.currentTimeMillis());

        } catch (Exception e) {
            logger.error("Failed to decode market data: {}", e.getMessage());
        }

        return result;
    }

    /**
     * Decode JSON market data.
     */
    public static Map<String, Object> decodeJson(String json) {
        Map<String, Object> result = new HashMap<>();

        try {
            JsonNode node = objectMapper.readTree(json);

            if (node.has("ltp")) {
                result.put("ltp", node.path("ltp").asDouble());
            }
            if (node.has("instrument_key")) {
                result.put("instrument_key", node.path("instrument_key").asText());
            }
            if (node.has("timestamp")) {
                result.put("timestamp", node.path("timestamp").asText());
            }
            if (node.has("open")) {
                result.put("open", node.path("open").asDouble());
            }
            if (node.has("high")) {
                result.put("high", node.path("high").asDouble());
            }
            if (node.has("low")) {
                result.put("low", node.path("low").asDouble());
            }
            if (node.has("close")) {
                result.put("close", node.path("close").asDouble());
            }
            if (node.has("volume")) {
                result.put("volume", node.path("volume").asLong());
            }

        } catch (Exception e) {
            logger.error("Failed to decode JSON: {}", e.getMessage());
        }

        return result;
    }
}
