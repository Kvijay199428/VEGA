package com.vegatrader.controller;

import com.vegatrader.service.SettingsService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * User settings controller.
 */
@RestController
@RequestMapping("/v1/settings")
@CrossOrigin
public class SettingsController {

    private final SettingsService settingsService;

    public SettingsController(SettingsService settingsService) {
        this.settingsService = settingsService;
    }

    @GetMapping("")
    public ResponseEntity<Map<String, Object>> getSettings(Authentication auth) {
        return ResponseEntity.ok(settingsService.getSettings(auth.getName()));
    }

    @PutMapping("")
    public ResponseEntity<Map<String, Object>> updateSettings(
            Authentication auth,
            @RequestBody Map<String, Object> settings) {
        return ResponseEntity.ok(settingsService.updateSettings(auth.getName(), settings));
    }

    @GetMapping("/{key}")
    public ResponseEntity<Object> getSetting(Authentication auth, @PathVariable String key) {
        return ResponseEntity.ok(settingsService.getSetting(auth.getName(), key));
    }

    @PostMapping("/reset")
    public ResponseEntity<Map<String, Object>> resetSettings(Authentication auth) {
        return ResponseEntity.ok(settingsService.resetSettings(auth.getName()));
    }
}
