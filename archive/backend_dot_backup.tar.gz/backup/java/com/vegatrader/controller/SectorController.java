package com.vegatrader.controller;

import com.vegatrader.service.SectorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Sector controller for sectoral indices.
 */
@RestController
@RequestMapping("/v1/sectors")
@CrossOrigin
public class SectorController {

    private final SectorService sectorService;

    public SectorController(SectorService sectorService) {
        this.sectorService = sectorService;
    }

    @GetMapping("")
    public ResponseEntity<Map<String, Object>> getAllSectors() {
        return ResponseEntity.ok(sectorService.getAllSectors());
    }

    @GetMapping("/{sectorName}")
    public ResponseEntity<Map<String, Object>> getSector(@PathVariable String sectorName) {
        return ResponseEntity.ok(sectorService.getSector(sectorName));
    }

    @GetMapping("/list")
    public ResponseEntity<List<Map<String, String>>> getAvailableSectors() {
        return ResponseEntity.ok(sectorService.getAvailableSectors());
    }
}
