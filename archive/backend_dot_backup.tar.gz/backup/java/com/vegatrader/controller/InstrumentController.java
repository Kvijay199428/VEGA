package com.vegatrader.controller;

import com.vegatrader.model.entity.OptionsInstrument;
import com.vegatrader.service.InstrumentService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * Instruments controller.
 */
@RestController
@RequestMapping("/v1/instruments")
@CrossOrigin
public class InstrumentController {

    private final InstrumentService instrumentService;

    public InstrumentController(InstrumentService instrumentService) {
        this.instrumentService = instrumentService;
    }

    @GetMapping("/underlyings")
    public ResponseEntity<List<String>> getUnderlyings(
            @RequestParam(defaultValue = "NSE") String exchange) {
        return ResponseEntity.ok(instrumentService.getOptionsUnderlyings(exchange));
    }

    @GetMapping("/expiries")
    public ResponseEntity<List<LocalDate>> getExpiries(@RequestParam String underlyingKey) {
        return ResponseEntity.ok(instrumentService.getExpiries(underlyingKey));
    }

    @GetMapping("/chain")
    public ResponseEntity<Map<String, Object>> getOptionChain(
            @RequestParam String underlyingKey,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate expiry) {
        return ResponseEntity.ok(instrumentService.getOptionChain(underlyingKey, expiry));
    }

    @GetMapping("/search")
    public ResponseEntity<List<OptionsInstrument>> searchInstruments(
            @RequestParam String query,
            @RequestParam(defaultValue = "20") int limit) {
        return ResponseEntity.ok(instrumentService.searchInstruments(query, limit));
    }

    @GetMapping("/{instrumentKey}")
    public ResponseEntity<OptionsInstrument> getInstrument(@PathVariable String instrumentKey) {
        return instrumentService.getInstrumentByKey(instrumentKey)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
