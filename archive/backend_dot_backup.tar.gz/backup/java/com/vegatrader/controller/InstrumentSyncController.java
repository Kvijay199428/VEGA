package com.vegatrader.controller;

import com.vegatrader.service.InstrumentSyncService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/v1/instruments")
public class InstrumentSyncController {

    private final InstrumentSyncService syncService;

    public InstrumentSyncController(InstrumentSyncService syncService) {
        this.syncService = syncService;
    }

    @PostMapping("/sync")
    public ResponseEntity<Map<String, Object>> syncInstruments() {
        return ResponseEntity.ok(syncService.syncInstruments());
    }
}
