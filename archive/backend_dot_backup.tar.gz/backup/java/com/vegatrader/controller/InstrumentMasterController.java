package com.vegatrader.controller;

import com.vegatrader.service.InstrumentMasterService;
import com.vegatrader.service.InstrumentSearchService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Instrument master controller.
 */
@RestController
@RequestMapping({ "/v1/instruments/master", "/v1/market" })
@CrossOrigin
public class InstrumentMasterController {

    private final InstrumentMasterService masterService;
    private final InstrumentSearchService searchService;

    public InstrumentMasterController(InstrumentMasterService masterService, InstrumentSearchService searchService) {
        this.masterService = masterService;
        this.searchService = searchService;
    }

    @GetMapping({ "/equity", "/instruments" })
    public ResponseEntity<List<Map<String, Object>>> getEquityInstruments(
            @RequestParam(defaultValue = "NSE") String exchange) {
        return ResponseEntity.ok(masterService.getEquityInstruments(exchange));
    }

    @GetMapping("/index")
    public ResponseEntity<List<Map<String, Object>>> getIndexInstruments(
            @RequestParam(defaultValue = "NSE") String exchange) {
        return ResponseEntity.ok(masterService.getIndexInstruments(exchange));
    }

    @GetMapping("/futures")
    public ResponseEntity<List<Map<String, Object>>> getFuturesInstruments(@RequestParam String underlying) {
        return ResponseEntity.ok(masterService.getFuturesInstruments(underlying));
    }

    @GetMapping("/mis")
    public ResponseEntity<List<String>> getMisAllowed() {
        return ResponseEntity.ok(masterService.getMisAllowedInstruments());
    }

    @GetMapping("/mtf")
    public ResponseEntity<List<String>> getMtfAllowed() {
        return ResponseEntity.ok(masterService.getMtfAllowedInstruments());
    }

    @PostMapping("/validate")
    public ResponseEntity<Map<String, Object>> validateInstrument(@RequestBody Map<String, String> request) {
        return ResponseEntity.ok(masterService.validateInstrument(
                request.get("instrument_key"),
                request.get("product"),
                request.get("order_type")));
    }

    @GetMapping("/search")
    public ResponseEntity<List<Map<String, Object>>> search(
            @RequestParam String query,
            @RequestParam(required = false) String exchange,
            @RequestParam(required = false) String segment,
            @RequestParam(defaultValue = "20") int limit) {
        return ResponseEntity.ok(searchService.search(query, exchange, segment, limit));
    }

    @GetMapping("/popular")
    public ResponseEntity<List<Map<String, Object>>> getPopular(@RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(searchService.getPopularInstruments(limit));
    }

    @GetMapping("/autocomplete")
    public ResponseEntity<List<String>> autocomplete(
            @RequestParam String prefix,
            @RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(searchService.autocomplete(prefix, limit));
    }
}
