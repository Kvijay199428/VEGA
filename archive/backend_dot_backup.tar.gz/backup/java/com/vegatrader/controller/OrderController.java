package com.vegatrader.controller;

import com.vegatrader.dto.OrderRequest;
import com.vegatrader.service.OrderService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Order management controller.
 */
@RestController
@RequestMapping("/v1/orders")
@CrossOrigin
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping("")
    public ResponseEntity<Map<String, Object>> placeOrder(@RequestBody OrderRequest request) {
        return ResponseEntity.ok(orderService.placeOrder(request));
    }

    @PutMapping("/{orderId}")
    public ResponseEntity<Map<String, Object>> modifyOrder(
            @PathVariable String orderId,
            @RequestBody OrderRequest request) {
        return ResponseEntity.ok(orderService.modifyOrder(orderId, request));
    }

    @DeleteMapping("/{orderId}")
    public ResponseEntity<Map<String, Object>> cancelOrder(@PathVariable String orderId) {
        return ResponseEntity.ok(orderService.cancelOrder(orderId));
    }

    @GetMapping("")
    public ResponseEntity<Map<String, Object>> getOrderBook() {
        return ResponseEntity.ok(orderService.getOrderBook());
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<Map<String, Object>> getOrderDetails(@PathVariable String orderId) {
        return ResponseEntity.ok(orderService.getOrderDetails(orderId));
    }

    @GetMapping("/trades")
    public ResponseEntity<Map<String, Object>> getTradeBook() {
        return ResponseEntity.ok(orderService.getTradeBook());
    }
}
