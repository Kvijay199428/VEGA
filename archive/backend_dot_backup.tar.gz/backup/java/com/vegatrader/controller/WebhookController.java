package com.vegatrader.controller;

import com.vegatrader.service.WebhookService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Webhook controller.
 */
@RestController
@RequestMapping("/v1/webhooks")
@CrossOrigin
public class WebhookController {

    private final WebhookService webhookService;

    public WebhookController(WebhookService webhookService) {
        this.webhookService = webhookService;
    }

    @PostMapping("/order")
    public ResponseEntity<Map<String, Object>> handleOrderWebhook(@RequestBody Map<String, Object> payload) {
        return ResponseEntity.ok(webhookService.handleOrderUpdate(payload));
    }

    @PostMapping("/position")
    public ResponseEntity<Map<String, Object>> handlePositionWebhook(@RequestBody Map<String, Object> payload) {
        return ResponseEntity.ok(webhookService.handlePositionUpdate(payload));
    }

    @PostMapping("/trade")
    public ResponseEntity<Map<String, Object>> handleTradeWebhook(@RequestBody Map<String, Object> payload) {
        return ResponseEntity.ok(webhookService.handleTradeUpdate(payload));
    }

    @GetMapping("/log")
    public ResponseEntity<List<Map<String, Object>>> getWebhookLog(
            @RequestParam(defaultValue = "100") int limit) {
        return ResponseEntity.ok(webhookService.getWebhookLog(limit));
    }
}
