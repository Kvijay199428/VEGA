package com.vegatrader.controller;

import com.vegatrader.service.UpstoxMarketDataService;
import com.vegatrader.upstox.api.instrument.filter.InstrumentFilterCriteria;
import com.vegatrader.upstox.api.instrument.service.InstrumentEnrollmentService;
import com.vegatrader.upstox.api.response.instrument.InstrumentResponse;
import com.vegatrader.upstox.api.websocket.Mode;
import com.vegatrader.upstox.api.websocket.cache.MarketDataCache;
import com.vegatrader.upstox.api.websocket.logging.MarketDataStreamerV3Logger;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * REST controller for MarketDataStreamerV3 testing and instrument enrollment.
 * 
 * <p>
 * Dedicated to port 28021 for MarketDataStreamerV3 operations.
 * 
 * @since 3.0.0
 */
@RestController
@RequestMapping("/api/v1/market-data-streamer")
public class MarketDataStreamerController {

    private final UpstoxMarketDataService marketDataService;
    private final InstrumentEnrollmentService enrollmentService;

    public MarketDataStreamerController(
            UpstoxMarketDataService marketDataService,
            InstrumentEnrollmentService enrollmentService) {
        this.marketDataService = marketDataService;
        this.enrollmentService = enrollmentService;
    }

    /**
     * Health check endpoint.
     */
    @GetMapping("/health")
    public Map<String, Object> health() {
        Map<String, Object> health = new HashMap<>();
        health.put("status", "UP");
        health.put("service", "MarketDataStreamerV3");
        health.put("port", 28021);
        health.put("connected", marketDataService.isConnected());
        health.put("tier", marketDataService.getTier());
        health.put("subscriptions", marketDataService.getSubscriptions().size());
        return health;
    }

    /**
     * Connect to WebSocket.
     */
    @PostMapping("/connect")
    public Map<String, Object> connect() {
        marketDataService.connect();
        return Map.of("status", "connecting", "message", "WebSocket connection initiated");
    }

    /**
     * Disconnect from WebSocket.
     */
    @PostMapping("/disconnect")
    public Map<String, Object> disconnect() {
        marketDataService.disconnect();
        return Map.of("status", "disconnected", "message", "WebSocket disconnected");
    }

    /**
     * Subscribe to instruments using filter criteria.
     */
    @PostMapping("/subscribe")
    public Map<String, Object> subscribe(@RequestBody SubscribeRequest request) {
        try {
            // Enroll instruments based on criteria
            List<String> instrumentKeys = enrollmentService.enrollInstruments(request.getCriteria());

            if (instrumentKeys.isEmpty()) {
                return Map.of("status", "error", "message", "No instruments found matching criteria");
            }

            // Subscribe
            Set<String> keys = new HashSet<>(instrumentKeys);
            Mode mode = Mode.valueOf(request.getMode().toUpperCase());
            marketDataService.subscribe(keys, mode);

            return Map.of(
                    "status", "subscribed",
                    "count", instrumentKeys.size(),
                    "mode", mode.toString(),
                    "instruments", instrumentKeys.subList(0, Math.min(10, instrumentKeys.size())) // First 10
            );
        } catch (Exception e) {
            return Map.of("status", "error", "message", e.getMessage());
        }
    }

    /**
     * Quick subscribe by segment and type.
     */
    @PostMapping("/subscribe/quick")
    public Map<String, Object> quickSubscribe(
            @RequestParam String segment,
            @RequestParam String instrumentType,
            @RequestParam(defaultValue = "FULL") String mode,
            @RequestParam(required = false) String pattern,
            @RequestParam(defaultValue = "10") int limit) {

        try {
            InstrumentFilterCriteria.Builder builder = InstrumentFilterCriteria.builder()
                    .segment(segment)
                    .instrumentType(instrumentType)
                    .limit(limit);

            if (pattern != null) {
                builder.tradingSymbolPattern(pattern);
            }

            List<String> instrumentKeys = enrollmentService.enrollInstruments(builder.build());

            if (instrumentKeys.isEmpty()) {
                return Map.of("status", "error", "message", "No instruments found");
            }

            Set<String> keys = new HashSet<>(instrumentKeys);
            Mode subscriptionMode = Mode.valueOf(mode.toUpperCase());
            marketDataService.subscribe(keys, subscriptionMode);

            return Map.of(
                    "status", "subscribed",
                    "count", instrumentKeys.size(),
                    "mode", subscriptionMode.toString(),
                    "instruments", instrumentKeys);
        } catch (Exception e) {
            return Map.of("status", "error", "message", e.getMessage());
        }
    }

    /**
     * Subscribe to Reliance Equity (example).
     */
    @PostMapping("/subscribe/reliance")
    public Map<String, Object> subscribeReliance() {
        List<String> keys = enrollmentService.enrollRelianceEquity();
        if (!keys.isEmpty()) {
            marketDataService.subscribe(new HashSet<>(keys), Mode.FULL);
            return Map.of("status", "subscribed", "instruments", keys);
        }
        return Map.of("status", "error", "message", "Reliance not found");
    }

    /**
     * Subscribe to Nifty 50.
     */
    @PostMapping("/subscribe/nifty50")
    public Map<String, Object> subscribeNifty50() {
        List<String> keys = enrollmentService.enrollNifty50();
        if (!keys.isEmpty()) {
            marketDataService.subscribe(new HashSet<>(keys), Mode.FULL);
            return Map.of("status", "subscribed", "instruments", keys);
        }
        return Map.of("status", "error", "message", "Nifty 50 not found");
    }

    /**
     * Get current subscriptions.
     */
    @GetMapping("/subscriptions")
    public Map<String, Object> getSubscriptions() {
        Set<String> subscriptions = marketDataService.getSubscriptions();
        return Map.of(
                "count", subscriptions.size(),
                "instruments", subscriptions);
    }

    /**
     * Unsubscribe from instruments.
     */
    @PostMapping("/unsubscribe")
    public Map<String, Object> unsubscribe(@RequestBody List<String> instrumentKeys) {
        marketDataService.unsubscribe(new HashSet<>(instrumentKeys));
        return Map.of("status", "unsubscribed", "count", instrumentKeys.size());
    }

    /**
     * Get cache statistics.
     */
    @GetMapping("/cache/stats")
    public Map<String, Object> getCacheStats() {
        MarketDataCache cache = marketDataService.getCache();
        return Map.of(
                "enabled", cache.isEnabled(),
                "size", cache.size(),
                "instrumentCacheStats", enrollmentService.getCacheStats());
    }

    /**
     * Get metrics.
     */
    @GetMapping("/metrics")
    public Map<String, Object> getMetrics() {
        MarketDataStreamerV3Logger logger = marketDataService.getLogger();
        return Map.of(
                "messagesReceived", logger.getMessagesReceived(),
                "messagesProcessed", logger.getMessagesProcessed(),
                "connectionAttempts", logger.getConnectionAttempts(),
                "successfulConnections", logger.getSuccessfulConnections(),
                "errors", logger.getErrors());
    }

    /**
     * Search instruments by criteria.
     */
    @PostMapping("/instruments/search")
    public Map<String, Object> searchInstruments(@RequestBody InstrumentFilterCriteria criteria) {
        List<String> instrumentKeys = enrollmentService.enrollInstruments(criteria);
        return Map.of(
                "count", instrumentKeys.size(),
                "instruments", instrumentKeys.subList(0, Math.min(20, instrumentKeys.size())));
    }

    /**
     * Get instrument details.
     */
    @GetMapping("/instruments/{instrumentKey}")
    public Object getInstrumentDetails(@PathVariable String instrumentKey) {
        InstrumentResponse instrument = enrollmentService.getInstrumentDetails(instrumentKey);
        if (instrument != null) {
            return instrument;
        }
        return Map.of("error", "Instrument not found");
    }

    /**
     * Clear instrument cache.
     */
    @PostMapping("/cache/clear")
    public Map<String, Object> clearCache() {
        enrollmentService.clearCache();
        return Map.of("status", "cleared", "message", "Instrument cache cleared");
    }

    /**
     * Request DTO for subscribe endpoint.
     */
    public static class SubscribeRequest {
        private InstrumentFilterCriteria criteria;
        private String mode = "FULL";

        public InstrumentFilterCriteria getCriteria() {
            return criteria;
        }

        public void setCriteria(InstrumentFilterCriteria criteria) {
            this.criteria = criteria;
        }

        public String getMode() {
            return mode;
        }

        public void setMode(String mode) {
            this.mode = mode;
        }
    }
}
