package com.vegatrader.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.vegatrader.client.UpstoxClient;
import com.vegatrader.model.entity.User;
import com.vegatrader.repository.UserRepository;
import com.vegatrader.repository.UpstoxTokenRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * User profile controller.
 */
@RestController
@RequestMapping("/v1/user")
@CrossOrigin
public class UserController {

    private final UserRepository userRepository;
    private final UpstoxTokenRepository tokenRepository;
    private final UpstoxClient upstoxClient;

    public UserController(UserRepository userRepository, UpstoxTokenRepository tokenRepository,
            UpstoxClient upstoxClient) {
        this.userRepository = userRepository;
        this.tokenRepository = tokenRepository;
        this.upstoxClient = upstoxClient;
    }

    @GetMapping("/profile")
    public ResponseEntity<Map<String, Object>> getProfile(Authentication auth) {
        Map<String, Object> profile = new HashMap<>();

        // Handle anonymous access (development mode)
        if (auth == null || auth.getName() == null) {
            profile.put("id", 1);
            profile.put("email", "dev@vegatrader.com");
            profile.put("full_name", "Development User");
            profile.put("is_active", true);
        } else {
            // Local user data
            userRepository.findByEmail(auth.getName()).ifPresent(user -> {
                profile.put("id", user.getId());
                profile.put("email", user.getEmail());
                profile.put("full_name", user.getFullName());
                profile.put("is_active", user.isActive());
            });
        }

        // Upstox profile
        try {
            String token = tokenRepository.findByIsPrimaryTrue()
                    .map(t -> t.getAccessToken())
                    .orElse(null);
            if (token != null) {
                JsonNode upstoxProfile = upstoxClient.get("/user/profile", token);
                JsonNode data = upstoxProfile.path("data");
                profile.put("upstox_profile", data);

                // Override with Upstox details if available
                if (data.has("user_name")) {
                    profile.put("full_name", data.get("user_name").asText());
                }
                if (data.has("email")) {
                    profile.put("email", data.get("email").asText());
                }
            }
        } catch (Exception e) {
            profile.put("upstox_error", e.getMessage());
        }

        return ResponseEntity.ok(profile);
    }

    @GetMapping("/account-info")
    public ResponseEntity<Map<String, Object>> getAccountInfo() {
        Map<String, Object> accountInfo = new HashMap<>();

        try {
            String token = tokenRepository.findByIsPrimaryTrue()
                    .map(t -> t.getAccessToken())
                    .orElseThrow(() -> new RuntimeException("No token"));

            JsonNode margin = upstoxClient.get("/user/get-funds-and-margin", token);
            accountInfo.put("funds", margin.path("data"));
            accountInfo.put("status", "success");
        } catch (Exception e) {
            accountInfo.put("status", "error");
            accountInfo.put("message", e.getMessage());
        }

        return ResponseEntity.ok(accountInfo);
    }

    @PutMapping("/profile")
    public ResponseEntity<User> updateProfile(Authentication auth, @RequestBody Map<String, String> updates) {
        // Handle anonymous access
        if (auth == null || auth.getName() == null) {
            return ResponseEntity.badRequest().build();
        }

        User user = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (updates.containsKey("full_name")) {
            user.setFullName(updates.get("full_name"));
        }

        userRepository.save(user);
        return ResponseEntity.ok(user);
    }
}
