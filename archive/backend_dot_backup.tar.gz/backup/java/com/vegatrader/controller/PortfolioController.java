package com.vegatrader.controller;

import com.vegatrader.service.PortfolioService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Portfolio controller for holdings and positions.
 */
@RestController
@RequestMapping("/v1/portfolio")
@CrossOrigin
public class PortfolioController {

    private final PortfolioService portfolioService;

    public PortfolioController(PortfolioService portfolioService) {
        this.portfolioService = portfolioService;
    }

    @GetMapping("/holdings")
    public ResponseEntity<Map<String, Object>> getHoldings() {
        return ResponseEntity.ok(portfolioService.getHoldings());
    }

    @GetMapping("/positions")
    public ResponseEntity<Map<String, Object>> getPositions() {
        return ResponseEntity.ok(portfolioService.getPositions());
    }

    @GetMapping("/pnl")
    public ResponseEntity<Map<String, Object>> getProfitLoss(
            @RequestParam(defaultValue = "EQ") String segment,
            @RequestParam(defaultValue = "2024-2025") String financialYear) {
        return ResponseEntity.ok(portfolioService.getProfitLoss(segment, financialYear));
    }

    @GetMapping("/summary")
    public ResponseEntity<Map<String, Object>> getSummary() {
        return ResponseEntity.ok(portfolioService.getSummary());
    }
}
