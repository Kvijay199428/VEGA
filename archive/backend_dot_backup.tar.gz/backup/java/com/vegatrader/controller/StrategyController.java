package com.vegatrader.controller;

import com.vegatrader.model.entity.AiStrategy;
import com.vegatrader.service.StrategyService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Trading strategies controller.
 */
@RestController
@RequestMapping("/v1/strategies")
@CrossOrigin
public class StrategyController {

    private final StrategyService strategyService;

    public StrategyController(StrategyService strategyService) {
        this.strategyService = strategyService;
    }

    @GetMapping("")
    public ResponseEntity<List<AiStrategy>> getAllStrategies() {
        return ResponseEntity.ok(strategyService.getAllStrategies());
    }

    @GetMapping("/active")
    public ResponseEntity<List<AiStrategy>> getActiveStrategies() {
        return ResponseEntity.ok(strategyService.getActiveStrategies());
    }

    @GetMapping("/{id}")
    public ResponseEntity<AiStrategy> getStrategy(@PathVariable Long id) {
        return strategyService.getStrategy(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("")
    public ResponseEntity<AiStrategy> createStrategy(@RequestBody AiStrategy strategy) {
        return ResponseEntity.ok(strategyService.createStrategy(strategy));
    }

    @PutMapping("/{id}")
    public ResponseEntity<AiStrategy> updateStrategy(
            @PathVariable Long id,
            @RequestBody AiStrategy strategy) {
        return ResponseEntity.ok(strategyService.updateStrategy(id, strategy));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStrategy(@PathVariable Long id) {
        strategyService.deleteStrategy(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/toggle")
    public ResponseEntity<AiStrategy> toggleStrategy(@PathVariable Long id) {
        return ResponseEntity.ok(strategyService.toggleStrategy(id));
    }
}
