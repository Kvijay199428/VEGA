package com.vegatrader.controller;

import com.vegatrader.service.IndicatorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Technical indicators controller.
 */
@RestController
@RequestMapping("/v1/indicators")
@CrossOrigin
public class IndicatorController {

    private final IndicatorService indicatorService;

    public IndicatorController(IndicatorService indicatorService) {
        this.indicatorService = indicatorService;
    }

    @PostMapping("/sma")
    public ResponseEntity<Map<String, Object>> calculateSMA(
            @RequestBody Map<String, Object> request) {
        @SuppressWarnings("unchecked")
        List<Double> prices = (List<Double>) request.get("prices");
        int period = (int) request.getOrDefault("period", 20);
        double sma = indicatorService.calculateSMA(prices, period);
        return ResponseEntity.ok(Map.of("sma", sma, "period", period));
    }

    @PostMapping("/ema")
    public ResponseEntity<Map<String, Object>> calculateEMA(
            @RequestBody Map<String, Object> request) {
        @SuppressWarnings("unchecked")
        List<Double> prices = (List<Double>) request.get("prices");
        int period = (int) request.getOrDefault("period", 12);
        double ema = indicatorService.calculateEMA(prices, period);
        return ResponseEntity.ok(Map.of("ema", ema, "period", period));
    }

    @PostMapping("/rsi")
    public ResponseEntity<Map<String, Object>> calculateRSI(
            @RequestBody Map<String, Object> request) {
        @SuppressWarnings("unchecked")
        List<Double> prices = (List<Double>) request.get("prices");
        int period = (int) request.getOrDefault("period", 14);
        double rsi = indicatorService.calculateRSI(prices, period);
        return ResponseEntity.ok(Map.of("rsi", rsi, "period", period));
    }

    @PostMapping("/macd")
    public ResponseEntity<Map<String, Double>> calculateMACD(
            @RequestBody Map<String, Object> request) {
        @SuppressWarnings("unchecked")
        List<Double> prices = (List<Double>) request.get("prices");
        return ResponseEntity.ok(indicatorService.calculateMACD(prices));
    }

    @PostMapping("/bollinger")
    public ResponseEntity<Map<String, Double>> calculateBollingerBands(
            @RequestBody Map<String, Object> request) {
        @SuppressWarnings("unchecked")
        List<Double> prices = (List<Double>) request.get("prices");
        int period = (int) request.getOrDefault("period", 20);
        double stdDev = (double) request.getOrDefault("stdDev", 2.0);
        return ResponseEntity.ok(indicatorService.calculateBollingerBands(prices, period, stdDev));
    }

    @PostMapping("/all")
    public ResponseEntity<Map<String, Object>> calculateAllIndicators(
            @RequestBody Map<String, Object> request) {
        @SuppressWarnings("unchecked")
        List<Double> prices = (List<Double>) request.get("prices");
        @SuppressWarnings("unchecked")
        List<Double> highs = (List<Double>) request.get("highs");
        @SuppressWarnings("unchecked")
        List<Double> lows = (List<Double>) request.get("lows");
        return ResponseEntity.ok(indicatorService.calculateAllIndicators(prices, highs, lows));
    }
}
