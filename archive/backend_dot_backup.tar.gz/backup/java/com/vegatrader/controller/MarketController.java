package com.vegatrader.controller;

import com.vegatrader.service.MarketDataService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Market data controller.
 */
@RestController
@RequestMapping("/v1/market")
@CrossOrigin
public class MarketController {

    private final MarketDataService marketDataService;

    public MarketController(MarketDataService marketDataService) {
        this.marketDataService = marketDataService;
    }

    @GetMapping("/ltp")
    public ResponseEntity<Map<String, Object>> getLtp(@RequestParam List<String> instrumentKeys) {
        return ResponseEntity.ok(marketDataService.getLtp(instrumentKeys));
    }

    @GetMapping("/quotes")
    public ResponseEntity<Map<String, Object>> getQuotes(@RequestParam List<String> instrumentKeys) {
        return ResponseEntity.ok(marketDataService.getQuotes(instrumentKeys));
    }

    @GetMapping("/ohlc")
    public ResponseEntity<Map<String, Object>> getOhlc(
            @RequestParam List<String> instrumentKeys,
            @RequestParam(defaultValue = "1d") String interval) {
        return ResponseEntity.ok(marketDataService.getOhlc(instrumentKeys, interval));
    }

    @GetMapping("/historical")
    public ResponseEntity<Map<String, Object>> getHistoricalData(
            @RequestParam String instrumentKey,
            @RequestParam(defaultValue = "day") String interval,
            @RequestParam String toDate,
            @RequestParam(required = false) String fromDate) {
        return ResponseEntity.ok(marketDataService.getHistoricalData(instrumentKey, interval, toDate, fromDate));
    }

    @GetMapping("/intraday")
    public ResponseEntity<Map<String, Object>> getIntradayData(
            @RequestParam String instrumentKey,
            @RequestParam(defaultValue = "1minute") String interval) {
        return ResponseEntity.ok(marketDataService.getIntradayData(instrumentKey, interval));
    }

    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getMarketStatus() {
        return ResponseEntity.ok(marketDataService.getMarketStatus());
    }
}
