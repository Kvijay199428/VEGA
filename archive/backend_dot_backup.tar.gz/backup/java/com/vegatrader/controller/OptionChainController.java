package com.vegatrader.controller;

import com.vegatrader.service.InstrumentMasterService;
import com.vegatrader.service.OptionChainLiveService;
import com.vegatrader.valuation.model.OptionStrikeData;
import com.vegatrader.valuation.model.OptionStrikeData.OptionSideData;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/v1/options")
@CrossOrigin
public class OptionChainController {

    private final InstrumentMasterService instrumentMasterService;

    private final com.vegatrader.repository.OptionsInstrumentRepository optionsRepo;
    private final OptionChainLiveService liveService;
    private final com.vegatrader.repository.UpstoxTokenRepository tokenRepository;
    private final com.vegatrader.client.UpstoxClient upstoxClient;

    public OptionChainController(InstrumentMasterService instrumentMasterService,
            com.vegatrader.repository.OptionsInstrumentRepository optionsRepo,
            OptionChainLiveService liveService,
            com.vegatrader.repository.UpstoxTokenRepository tokenRepository,
            com.vegatrader.client.UpstoxClient upstoxClient) {
        this.instrumentMasterService = instrumentMasterService;
        this.optionsRepo = optionsRepo;
        this.liveService = liveService;
        this.tokenRepository = tokenRepository;
        this.upstoxClient = upstoxClient;
    }

    @GetMapping("/underlyings")
    public ResponseEntity<Map<String, Object>> getUnderlyings(
            @RequestParam(defaultValue = "index") String segment,
            @RequestParam(defaultValue = "NSE") String exchange) {

        List<Map<String, Object>> data;
        if ("index".equalsIgnoreCase(segment)) {
            data = instrumentMasterService.getIndexInstruments(exchange);
        } else {
            // Default to equity for non-index requests
            data = instrumentMasterService.getEquityInstruments(exchange);
        }

        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("data", data);

        return ResponseEntity.ok(response);
    }

    @GetMapping("/expiries/{underlying}")
    public ResponseEntity<Map<String, Object>> getExpiries(@PathVariable String underlying) {
        System.out.println("Requested expiries for underlying: '" + underlying + "'");
        List<java.time.LocalDate> expiries = optionsRepo.findDistinctExpiriesByUnderlyingKey(underlying);
        System.out.println("Found " + expiries.size() + " unique expiries for " + underlying);

        // Frontend expects list of strings YYYY-MM-DD
        List<String> expiryStrings = expiries.stream()
                .filter(java.util.Objects::nonNull)
                .map(java.time.LocalDate::toString)
                .collect(java.util.stream.Collectors.toList());

        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("data", expiryStrings);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/debug/expiries-raw/{underlying}")
    public ResponseEntity<List<java.time.LocalDate>> getRawExpiries(@PathVariable String underlying) {
        return ResponseEntity.ok(optionsRepo.findDistinctExpiriesByUnderlyingKey(underlying));
    }

    @GetMapping("/chain")
    public ResponseEntity<Map<String, Object>> getOptionChain(
            @RequestParam("instrument_key") String instrumentKey,
            @RequestParam("expiry_date") String expiryDate) {

        java.time.LocalDate expiry = java.time.LocalDate.parse(expiryDate);
        List<com.vegatrader.model.entity.OptionsInstrument> instruments = optionsRepo
                .findByUnderlyingKeyAndExpiry(instrumentKey, expiry);

        // Group by strike price and use Valuation model
        Map<Double, OptionStrikeData> chainMap = new java.util.TreeMap<>();

        for (com.vegatrader.model.entity.OptionsInstrument inst : instruments) {
            double strike = inst.getStrikePrice();
            chainMap.putIfAbsent(strike, new OptionStrikeData());
            OptionStrikeData row = chainMap.get(strike);

            row.setStrikePrice(strike);
            row.setExpiry(expiryDate);
            row.setUnderlyingKey(instrumentKey);
            row.setUnderlyingSpotPrice(0.0);

            OptionSideData optData = new OptionSideData();
            optData.setInstrumentKey(inst.getInstrumentKey());
            optData.setLtp(0.0);
            optData.setBidPrice(0.0);
            optData.setAskPrice(0.0);
            optData.setVolume(0);
            optData.setOi(0);
            optData.setIv(0.0);

            String type = inst.getOptionType();
            if ("CE".equalsIgnoreCase(type)) {
                row.setCall(optData);
            } else {
                row.setPut(optData);
            }
        }

        List<OptionStrikeData> chainData = new ArrayList<>(chainMap.values());

        // Fetch live data from Upstox
        try {
            // Find token for OPTIONCHAIN1 or fallback to PRIMARY
            com.vegatrader.model.entity.UpstoxToken token = tokenRepository.findByApiName("OPTIONCHAIN1")
                    .or(() -> tokenRepository.findPrimaryToken())
                    .orElse(null);

            if (token != null && token.getAccessToken() != null) {
                String apiUrl = "/option/chain?instrument_key="
                        + java.net.URLEncoder.encode(instrumentKey, java.nio.charset.StandardCharsets.UTF_8)
                        + "&expiry_date=" + expiryDate;

                com.fasterxml.jackson.databind.JsonNode responseNode = upstoxClient.get(apiUrl, token.getAccessToken());

                if (responseNode != null && "success".equalsIgnoreCase(responseNode.path("status").asText())) {
                    com.fasterxml.jackson.databind.JsonNode dataArray = responseNode.path("data");

                    if (dataArray.isArray()) {
                        for (com.fasterxml.jackson.databind.JsonNode node : dataArray) {
                            double strike = node.path("strike_price").asDouble();
                            OptionStrikeData row = chainMap.get(strike);

                            if (row != null) {
                                // Update Call Data
                                if (node.has("call_options") && row.getCall() != null) {
                                    com.fasterxml.jackson.databind.JsonNode callNode = node.path("call_options");
                                    com.fasterxml.jackson.databind.JsonNode marketData = callNode.path("market_data");
                                    com.fasterxml.jackson.databind.JsonNode greeks = callNode.path("option_greeks");

                                    row.getCall().setLtp(marketData.path("ltp").asDouble());
                                    row.getCall().setBidPrice(marketData.path("bid_price").asDouble());
                                    row.getCall().setBidQty(marketData.path("bid_qty").asInt());
                                    row.getCall().setAskPrice(marketData.path("ask_price").asDouble());
                                    row.getCall().setAskQty(marketData.path("ask_qty").asInt());
                                    row.getCall().setVolume(marketData.path("volume").asInt());
                                    row.getCall().setOi(marketData.path("oi").asInt());
                                    row.getCall().setPrevOi(marketData.path("prev_oi").asInt());

                                    // Map Greeks
                                    if (greeks != null && !greeks.isMissingNode()) {
                                        row.getCall().setDelta(greeks.path("delta").asDouble());
                                        row.getCall().setGamma(greeks.path("gamma").asDouble());
                                        row.getCall().setTheta(greeks.path("theta").asDouble());
                                        row.getCall().setVega(greeks.path("vega").asDouble());
                                        row.getCall().setIv(greeks.path("iv").asDouble());
                                        row.getCall().setPop(greeks.path("pop").asDouble());
                                    }
                                }

                                // Update Put Data
                                if (node.has("put_options") && row.getPut() != null) {
                                    com.fasterxml.jackson.databind.JsonNode putNode = node.path("put_options");
                                    com.fasterxml.jackson.databind.JsonNode marketData = putNode.path("market_data");
                                    com.fasterxml.jackson.databind.JsonNode greeks = putNode.path("option_greeks");

                                    row.getPut().setLtp(marketData.path("ltp").asDouble());
                                    row.getPut().setBidPrice(marketData.path("bid_price").asDouble());
                                    row.getPut().setBidQty(marketData.path("bid_qty").asInt());
                                    row.getPut().setAskPrice(marketData.path("ask_price").asDouble());
                                    row.getPut().setAskQty(marketData.path("ask_qty").asInt());
                                    row.getPut().setVolume(marketData.path("volume").asInt());
                                    row.getPut().setOi(marketData.path("oi").asInt());
                                    row.getPut().setPrevOi(marketData.path("prev_oi").asInt());

                                    // Map Greeks
                                    if (greeks != null && !greeks.isMissingNode()) {
                                        row.getPut().setDelta(greeks.path("delta").asDouble());
                                        row.getPut().setGamma(greeks.path("gamma").asDouble());
                                        row.getPut().setTheta(greeks.path("theta").asDouble());
                                        row.getPut().setVega(greeks.path("vega").asDouble());
                                        row.getPut().setIv(greeks.path("iv").asDouble());
                                        row.getPut().setPop(greeks.path("pop").asDouble());
                                    }
                                }

                                // Update Underlying Spot if available
                                if (node.has("underlying_spot_price")) {
                                    row.setUnderlyingSpotPrice(node.path("underlying_spot_price").asDouble());
                                }
                            }
                        }

                        // Calculate Valuation Status
                        com.vegatrader.valuation.ValuationCalculator.calculateOptionChainValuations(chainData);
                    }
                } else {
                    System.out.println("Upstox Option Chain API returned error or non-success status");
                }
            } else {
                System.out.println("No valid access token available for Option Chain API");
            }
        } catch (Exception e) {
            System.err.println("Error fetching live option chain data: " + e.getMessage());
            e.printStackTrace();
        }

        // Register for live updates
        liveService.registerChain(instrumentKey, expiryDate, chainData);

        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("data", chainData);
        response.put("updated_at", java.time.LocalDateTime.now().toString());

        return ResponseEntity.ok(response);
    }

    @GetMapping("/debug/keys")
    public ResponseEntity<List<String>> getDebugKeys(@RequestParam(defaultValue = "NSE_FO") String exchange) {
        List<String> keys = optionsRepo.findDistinctUnderlyingKeysByExchange(exchange);
        return ResponseEntity.ok(keys);
    }

    @GetMapping("/debug/sample")
    public ResponseEntity<List<com.vegatrader.model.entity.OptionsInstrument>> getDebugSample() {
        return ResponseEntity.ok(optionsRepo.findAll().stream().limit(5).collect(java.util.stream.Collectors.toList()));
    }

    @GetMapping("/debug/exchanges")
    public ResponseEntity<List<String>> getDebugExchanges() {
        return ResponseEntity.ok(optionsRepo.findAllExchanges());
    }

    @GetMapping("/debug/search")
    public ResponseEntity<List<com.vegatrader.model.entity.OptionsInstrument>> debugSearch(@RequestParam String query) {
        return ResponseEntity.ok(optionsRepo.findAll().stream()
                .filter(o -> o.getTradingSymbol() != null && o.getTradingSymbol().contains(query))
                .limit(10)
                .collect(java.util.stream.Collectors.toList()));
    }

    @GetMapping("/debug/null-keys")
    public ResponseEntity<List<com.vegatrader.model.entity.OptionsInstrument>> getNullKeys() {
        return ResponseEntity.ok(optionsRepo.findByUnderlyingKeyIsNull().stream().limit(20)
                .collect(java.util.stream.Collectors.toList()));
    }
}
