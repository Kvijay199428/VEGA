package com.vegatrader.controller;

import com.vegatrader.service.GttService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * GTT (Good Till Triggered) controller.
 */
@RestController
@RequestMapping("/v1/gtt")
@CrossOrigin
public class GttController {

    private final GttService gttService;

    public GttController(GttService gttService) {
        this.gttService = gttService;
    }

    @GetMapping("")
    public ResponseEntity<Map<String, Object>> getGttOrders() {
        return ResponseEntity.ok(gttService.getGttOrders());
    }

    @PostMapping("")
    public ResponseEntity<Map<String, Object>> placeGttOrder(@RequestBody Map<String, Object> request) {
        return ResponseEntity.ok(gttService.placeGttOrder(request));
    }

    @PutMapping("/{gttOrderId}")
    public ResponseEntity<Map<String, Object>> modifyGttOrder(
            @PathVariable String gttOrderId,
            @RequestBody Map<String, Object> request) {
        return ResponseEntity.ok(gttService.modifyGttOrder(gttOrderId, request));
    }

    @DeleteMapping("/{gttOrderId}")
    public ResponseEntity<Map<String, Object>> cancelGttOrder(@PathVariable String gttOrderId) {
        return ResponseEntity.ok(gttService.cancelGttOrder(gttOrderId));
    }
}
