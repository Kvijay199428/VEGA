package com.vegatrader.controller;

import com.vegatrader.service.SignalService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Trading signals controller.
 */
@RestController
@RequestMapping("/v1/signals")
@CrossOrigin
public class SignalController {

    private final SignalService signalService;

    public SignalController(SignalService signalService) {
        this.signalService = signalService;
    }

    @GetMapping("")
    public ResponseEntity<List<Map<String, Object>>> getActiveSignals() {
        return ResponseEntity.ok(signalService.getActiveSignals());
    }

    @PostMapping("/generate")
    public ResponseEntity<Map<String, Object>> generateSignal(@RequestBody Map<String, Object> request) {
        String instrumentKey = (String) request.get("instrument_key");
        @SuppressWarnings("unchecked")
        List<Double> prices = (List<Double>) request.get("prices");
        return ResponseEntity.ok(signalService.generateSignal(instrumentKey, prices));
    }
}
