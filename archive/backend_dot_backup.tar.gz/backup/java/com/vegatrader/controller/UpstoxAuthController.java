package com.vegatrader.controller;

import com.vegatrader.service.SeleniumLoginService;
import com.vegatrader.service.UpstoxAuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Upstox OAuth controller.
 */
@RestController
@RequestMapping("/v1/auth/upstox")
@CrossOrigin
public class UpstoxAuthController {

    private final UpstoxAuthService upstoxAuthService;
    private final SeleniumLoginService seleniumLoginService;

    public UpstoxAuthController(UpstoxAuthService upstoxAuthService, SeleniumLoginService seleniumLoginService) {
        this.upstoxAuthService = upstoxAuthService;
        this.seleniumLoginService = seleniumLoginService;
    }

    @GetMapping("/login-url")
    public ResponseEntity<Map<String, Object>> getLoginUrl(
            @RequestParam(required = false, defaultValue = "PRIMARY") String apiName) {
        try {
            String url = upstoxAuthService.getAuthorizationUrl(apiName);
            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("data", Map.of("login_url", url, "api_name", apiName));
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("status", "error");
            error.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @GetMapping("/token")
    public ResponseEntity<Map<String, Object>> getPrimaryToken() {
        try {
            String token = upstoxAuthService.getPrimaryAccessToken();
            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("access_token", token);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("status", "error");
            error.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @GetMapping("/callback")
    public ResponseEntity<?> handleCallback(
            @RequestParam String code,
            @RequestParam String state) {

        // Check if this is a multi-login request (state starts with "ML:")
        // If so, return HTML page with the code for Python script to extract
        if (state != null && state.startsWith("ML:")) {
            String html = String.format("""
                    <!DOCTYPE html>
                    <html>
                    <head><title>Authorization Code</title></head>
                    <body>
                        <h1>Authorization Successful</h1>
                        <p>State: %s</p>
                        <p id="auth-code">Code: %s</p>
                        <script>
                            // Store code for parent window/script to read
                            window.authCode = '%s';
                            window.authState = '%s';
                        </script>
                    </body>
                    </html>
                    """, state, code, code, state);
            return ResponseEntity.ok()
                    .header("Content-Type", "text/html")
                    .body(html);
        }

        // Normal flow - state is the API name, exchange token and notify frontend
        try {
            Map<String, Object> result = upstoxAuthService.exchangeToken(code, state);

            // Return HTML that posts message to parent window
            String token = result.get("status").equals("success") ? upstoxAuthService.getPrimaryAccessToken() : null;

            String html = String.format("""
                    <!DOCTYPE html>
                    <html>
                    <head><title>Login Complete</title></head>
                    <body>
                        <h1>%s</h1>
                        <p>You can close this window.</p>
                        <script>
                            if (window.opener) {
                                window.opener.postMessage({
                                    type: '%s',
                                    token: '%s',
                                    apiName: '%s'
                                }, '*');
                            }
                            setTimeout(() => window.close(), 2000);
                        </script>
                    </body>
                    </html>
                    """,
                    result.get("status").equals("success") ? "Login Successful!" : "Login Failed",
                    result.get("status").equals("success") ? "LOGIN_SUCCESS" : "LOGIN_ERROR",
                    token != null ? token : "",
                    state);
            return ResponseEntity.ok()
                    .header("Content-Type", "text/html")
                    .body(html);
        } catch (Exception e) {
            String html = String.format("""
                    <!DOCTYPE html>
                    <html>
                    <head><title>Login Failed</title></head>
                    <body>
                        <h1>Login Failed</h1>
                        <p>Error: %s</p>
                        <script>
                            if (window.opener) {
                                window.opener.postMessage({
                                    type: 'LOGIN_ERROR',
                                    error: '%s'
                                }, '*');
                            }
                            setTimeout(() => window.close(), 5000);
                        </script>
                    </body>
                    </html>
                    """, e.getMessage(), e.getMessage());
            return ResponseEntity.ok()
                    .header("Content-Type", "text/html")
                    .body(html);
        }
    }

    @GetMapping("/configs")
    public ResponseEntity<List<Map<String, Object>>> getApiConfigs() {
        return ResponseEntity.ok(upstoxAuthService.getApiConfigs());
    }

    @PostMapping("/set-primary")
    public ResponseEntity<Map<String, String>> setPrimaryApi(@RequestParam String apiName) {
        upstoxAuthService.setPrimaryApi(apiName);
        return ResponseEntity.ok(Map.of("status", "success", "primary", apiName));
    }

    @GetMapping("/tokens/db-status")
    public ResponseEntity<Map<String, Object>> getTokensDbStatus() {
        Map<String, Object> status = upstoxAuthService.getTokensStatus();
        // Wrap in the format frontend expects
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("data", status);
        return ResponseEntity.ok(response);
    }

    /**
     * Multi-login endpoint - returns list of login URLs for APIs that need tokens.
     * Frontend opens these sequentially as popups.
     */
    @PostMapping("/launch-remaining-login")
    public ResponseEntity<Map<String, Object>> launchRemainingLogin(
            @RequestBody(required = false) Map<String, Object> request) {
        try {
            int startIndex = 0;
            if (request != null && request.containsKey("start_index")) {
                startIndex = ((Number) request.get("start_index")).intValue();
            }

            List<Map<String, Object>> pendingLogins = upstoxAuthService.getPendingLoginUrls(startIndex);

            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("message", "Multi-login URLs generated");
            response.put("pending_count", pendingLogins.size());
            response.put("pending_logins", pendingLogins);

            // If there are pending logins, return the first one for immediate use
            if (!pendingLogins.isEmpty()) {
                response.put("first_login_url", pendingLogins.get(0).get("login_url"));
                response.put("first_api_name", pendingLogins.get(0).get("api_name"));
            }

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("status", "error");
            error.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * Get login URL for a specific API by index.
     */
    @GetMapping("/login-url/{apiIndex}")
    public ResponseEntity<Map<String, Object>> getLoginUrlByIndex(@PathVariable int apiIndex) {
        try {
            String url = upstoxAuthService.getAuthorizationUrlByIndex(apiIndex);
            String apiName = upstoxAuthService.getApiNameByIndex(apiIndex);

            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("data", Map.of("login_url", url, "api_name", apiName, "api_index", apiIndex));
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("status", "error");
            error.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * Start automated multi-login using Selenium.
     * This triggers the SeleniumLoginService to open a Chrome browser
     * and automatically log in to all APIs that need tokens.
     */
    @PostMapping("/start-automation")
    public ResponseEntity<Map<String, Object>> startAutomation(
            @RequestBody(required = false) Map<String, Object> request) {
        try {
            int startIndex = 0;
            if (request != null && request.containsKey("start_index")) {
                startIndex = ((Number) request.get("start_index")).intValue();
            }

            // Check if already running
            Map<String, Object> currentStatus = seleniumLoginService.getStatus();
            if (Boolean.TRUE.equals(currentStatus.get("is_running"))) {
                Map<String, Object> response = new HashMap<>();
                response.put("status", "already_running");
                response.put("message", "Automation is already in progress");
                response.put("current_status", currentStatus);
                return ResponseEntity.ok(response);
            }

            // Start automation in background
            seleniumLoginService.startMultiLogin(startIndex);

            Map<String, Object> response = new HashMap<>();
            response.put("status", "started");
            response.put("message",
                    "Automated multi-login started. A Chrome browser will open to complete authentication.");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("status", "error");
            error.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * Get current automation status.
     * Frontend polls this endpoint to track progress.
     */
    @GetMapping("/automation-status")
    public ResponseEntity<Map<String, Object>> getAutomationStatus() {
        try {
            Map<String, Object> status = seleniumLoginService.getStatus();
            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("data", status);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("status", "error");
            error.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
}
