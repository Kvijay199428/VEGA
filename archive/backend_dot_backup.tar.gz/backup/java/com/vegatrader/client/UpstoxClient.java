package com.vegatrader.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * Upstox API client for making HTTP requests.
 */
@Component
public class UpstoxClient {

    private static final Logger logger = LoggerFactory.getLogger(UpstoxClient.class);
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    @Value("${upstox.base-url}")
    private String baseUrl;

    private final OkHttpClient httpClient;
    private final ObjectMapper objectMapper;

    public UpstoxClient() {
        this.httpClient = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();
        this.objectMapper = new ObjectMapper();
    }

    /**
     * Make GET request to Upstox API.
     */
    public JsonNode get(String endpoint, String accessToken) throws IOException {
        String url = baseUrl + endpoint;

        Request request = new Request.Builder()
                .url(url)
                .header("Authorization", "Bearer " + accessToken)
                .header("Accept", "application/json")
                .build();

        return executeRequest(request);
    }

    /**
     * Make POST request to Upstox API.
     */
    public JsonNode post(String endpoint, String accessToken, Object body) throws IOException {
        String url = baseUrl + endpoint;
        String json = objectMapper.writeValueAsString(body);

        Request request = new Request.Builder()
                .url(url)
                .header("Authorization", "Bearer " + accessToken)
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .post(RequestBody.create(json, JSON))
                .build();

        return executeRequest(request);
    }

    /**
     * Make PUT request to Upstox API.
     */
    public JsonNode put(String endpoint, String accessToken, Object body) throws IOException {
        String url = baseUrl + endpoint;
        String json = objectMapper.writeValueAsString(body);

        Request request = new Request.Builder()
                .url(url)
                .header("Authorization", "Bearer " + accessToken)
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .put(RequestBody.create(json, JSON))
                .build();

        return executeRequest(request);
    }

    /**
     * Make DELETE request to Upstox API.
     */
    public JsonNode delete(String endpoint, String accessToken) throws IOException {
        String url = baseUrl + endpoint;

        Request request = new Request.Builder()
                .url(url)
                .header("Authorization", "Bearer " + accessToken)
                .header("Accept", "application/json")
                .delete()
                .build();

        return executeRequest(request);
    }

    private JsonNode executeRequest(Request request) throws IOException {
        try (Response response = httpClient.newCall(request).execute()) {
            String body = response.body() != null ? response.body().string() : "";

            if (!response.isSuccessful()) {
                logger.error("Upstox API error: {} {}", response.code(), body);
                throw new IOException("Upstox API error: " + response.code());
            }

            return objectMapper.readTree(body);
        }
    }

    /**
     * Exchange authorization code for access token.
     */
    public JsonNode exchangeToken(String code, String clientId, String clientSecret, String redirectUri)
            throws IOException {
        FormBody formBody = new FormBody.Builder()
                .add("code", code)
                .add("client_id", clientId)
                .add("client_secret", clientSecret)
                .add("redirect_uri", redirectUri)
                .add("grant_type", "authorization_code")
                .build();

        Request request = new Request.Builder()
                .url(baseUrl + "/login/authorization/token")
                .header("Accept", "application/json")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .post(formBody)
                .build();

        return executeRequest(request);
    }
}
