package com.vegatrader.repository;

import com.vegatrader.model.entity.UpstoxToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Upstox token repository for database operations.
 * Matches Python upstox_auth.sql queries.
 */
@Repository
public interface UpstoxTokenRepository extends JpaRepository<UpstoxToken, Long> {

    Optional<UpstoxToken> findByApiName(String apiName);

    Optional<UpstoxToken> findByIsPrimaryTrue();

    List<UpstoxToken> findByAccessTokenIsNotNull();

    boolean existsByApiName(String apiName);

    // Python-compatible queries
    Optional<UpstoxToken> findByUserIdAndApiIndex(Integer userId, Integer apiIndex);

    Optional<UpstoxToken> findByApiIndex(Integer apiIndex);

    Optional<UpstoxToken> findByPurpose(String purpose);

    List<UpstoxToken> findByIsActive(Integer isActive);

    List<UpstoxToken> findByUserIdAndIsActive(Integer userId, Integer isActive);

    // Find PRIMARY token (api_index=0)
    default Optional<UpstoxToken> findPrimaryToken() {
        return findByApiIndex(0);
    }
}
