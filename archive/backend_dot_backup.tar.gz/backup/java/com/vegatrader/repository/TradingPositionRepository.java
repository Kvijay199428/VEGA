package com.vegatrader.repository;

import com.vegatrader.model.entity.TradingPosition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Trading position repository.
 */
@Repository
public interface TradingPositionRepository extends JpaRepository<TradingPosition, Long> {

    List<TradingPosition> findByUserId(Long userId);

    Optional<TradingPosition> findByUserIdAndInstrumentKey(Long userId, String instrumentKey);

    List<TradingPosition> findByProduct(String product);
}
