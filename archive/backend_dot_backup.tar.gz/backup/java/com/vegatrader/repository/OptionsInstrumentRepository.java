package com.vegatrader.repository;

import com.vegatrader.model.entity.OptionsInstrument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Options instrument repository.
 */
@Repository
public interface OptionsInstrumentRepository extends JpaRepository<OptionsInstrument, Long> {

    Optional<OptionsInstrument> findByInstrumentKey(String instrumentKey);

    List<OptionsInstrument> findByUnderlyingKey(String underlyingKey);

    List<OptionsInstrument> findByUnderlyingKeyAndExpiry(String underlyingKey, LocalDate expiry);

    @Query("SELECT DISTINCT o.expiry FROM OptionsInstrument o WHERE o.underlyingKey = :underlyingKey ORDER BY o.expiry")
    List<LocalDate> findDistinctExpiriesByUnderlyingKey(@Param("underlyingKey") String underlyingKey);

    @Query("SELECT DISTINCT o.underlyingKey FROM OptionsInstrument o WHERE o.exchange = :exchange")
    List<String> findDistinctUnderlyingKeysByExchange(@Param("exchange") String exchange);

    @Query("SELECT DISTINCT o.exchange FROM OptionsInstrument o")
    List<String> findAllExchanges();

    List<OptionsInstrument> findByUnderlyingKeyIsNull();

    List<OptionsInstrument> findByUnderlyingKeyAndStrikePrice(String underlyingKey, Double strikePrice);
}
