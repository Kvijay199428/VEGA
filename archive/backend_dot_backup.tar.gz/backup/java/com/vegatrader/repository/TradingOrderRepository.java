package com.vegatrader.repository;

import com.vegatrader.model.entity.TradingOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Trading order repository.
 */
@Repository
public interface TradingOrderRepository extends JpaRepository<TradingOrder, Long> {

    Optional<TradingOrder> findByOrderId(String orderId);

    List<TradingOrder> findByUserId(Long userId);

    List<TradingOrder> findByUserIdAndStatus(Long userId, String status);

    List<TradingOrder> findByInstrumentKey(String instrumentKey);
}
