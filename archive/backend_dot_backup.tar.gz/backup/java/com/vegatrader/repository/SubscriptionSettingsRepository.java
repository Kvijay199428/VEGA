package com.vegatrader.repository;

import com.vegatrader.model.entity.SubscriptionSettings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Subscription settings repository.
 */
@Repository
public interface SubscriptionSettingsRepository extends JpaRepository<SubscriptionSettings, Long> {

    List<SubscriptionSettings> findByUserId(Long userId);

    List<SubscriptionSettings> findByUserIdAndIsActiveTrue(Long userId);

    void deleteByUserIdAndInstrumentKey(Long userId, String instrumentKey);
}
