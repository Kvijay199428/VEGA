package com.vegatrader.repository;

import com.vegatrader.model.entity.FuturesInstrument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FuturesInstrumentRepository extends JpaRepository<FuturesInstrument, Long> {
}
