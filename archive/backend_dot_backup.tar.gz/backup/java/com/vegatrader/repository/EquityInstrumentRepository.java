package com.vegatrader.repository;

import com.vegatrader.model.entity.EquityInstrument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EquityInstrumentRepository extends JpaRepository<EquityInstrument, Long> {
    void deleteByInstrumentKey(String instrumentKey); // For individual delete if needed
}
