package com.vegatrader.repository;

import com.vegatrader.model.entity.AiStrategy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * AI Strategy repository.
 */
@Repository
public interface AiStrategyRepository extends JpaRepository<AiStrategy, Long> {

    List<AiStrategy> findByIsActiveTrue();

    List<AiStrategy> findByUserId(Long userId);

    List<AiStrategy> findByStrategyType(String strategyType);
}
