package com.vegatrader.repository;

import com.vegatrader.model.entity.IndexInstrument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IndexInstrumentRepository extends JpaRepository<IndexInstrument, Long> {
}
