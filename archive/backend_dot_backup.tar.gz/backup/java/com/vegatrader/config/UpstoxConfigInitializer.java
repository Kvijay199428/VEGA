package com.vegatrader.config;

import com.vegatrader.model.entity.UpstoxToken;
import com.vegatrader.repository.UpstoxTokenRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

/**
 * Initializes Upstox API configurations from .env file on startup.
 * Matches Python config_validator.py structure and upstox_auth.sql schema.
 */
@Component
@Order(1)
public class UpstoxConfigInitializer implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(UpstoxConfigInitializer.class);

    private final UpstoxTokenRepository tokenRepository;

    // API configs: {env_index, api_name, purpose}
    // Matches Python upstox_auth.sql and config_validator.py
    private static final String[][] API_CONFIGS = {
            { "0", "PRIMARY", "PRIMARY" },
            { "1", "WEBSOCKET1", "WEBSOCKET1" },
            { "2", "WEBSOCKET2", "WEBSOCKET2" },
            { "3", "WEBSOCKET3", "WEBSOCKET3" },
            { "4", "OPTIONCHAIN1", "OPTIONCHAIN1" },
            { "5", "OPTIONCHAIN2", "OPTIONCHAIN2" }
    };

    public UpstoxConfigInitializer(UpstoxTokenRepository tokenRepository) {
        this.tokenRepository = tokenRepository;
    }

    @Override
    public void run(String... args) {
        logger.info("=== Upstox Config Initializer Starting ===");

        // Check if configs already exist
        long existingCount = tokenRepository.count();
        if (existingCount > 0) {
            logger.info("Found {} existing Upstox API configurations - skipping init", existingCount);
            return;
        }

        // Load .env file
        Map<String, String> envVars = loadEnvFile();
        if (envVars.isEmpty()) {
            logger.error("Could not load any environment variables from .env file!");
            return;
        }

        logger.info("Loaded {} environment variables", envVars.size());

        // Load all API configurations
        int configsAdded = 0;
        for (String[] config : API_CONFIGS) {
            int envIndex = Integer.parseInt(config[0]);
            String apiName = config[1];
            String purpose = config[2];

            String clientId = envVars.get("UPSTOX_CLIENT_ID_" + envIndex);
            String clientSecret = envVars.get("UPSTOX_CLIENT_SECRET_" + envIndex);

            logger.info("Checking {}: CLIENT_ID_{}={}, CLIENT_SECRET_{}={}",
                    apiName, envIndex,
                    clientId != null ? "present" : "MISSING",
                    envIndex,
                    clientSecret != null ? "present" : "MISSING");

            if (clientId != null && !clientId.isEmpty() && clientSecret != null && !clientSecret.isEmpty()) {
                UpstoxToken token = new UpstoxToken();
                token.setUserId(1);
                token.setApiIndex(envIndex);
                token.setApiName(apiName);
                token.setClientId(clientId);
                token.setClientSecret(clientSecret);
                token.setPurpose(purpose);
                token.setPrimary(envIndex == 0); // First one is primary
                token.setIsActive(1);
                token.setTokenType("Bearer");

                tokenRepository.save(token);
                configsAdded++;
                logger.info("✅ Added API config: {} (index={}, purpose={}, primary={})",
                        apiName, envIndex, purpose, envIndex == 0);
            }
        }

        if (configsAdded > 0) {
            logger.info("=== Successfully initialized {} Upstox API configurations ===", configsAdded);
        } else {
            logger.error("❌ No valid Upstox API configurations found!");
            logger.error("Expected: UPSTOX_CLIENT_ID_0, UPSTOX_CLIENT_SECRET_0, etc.");
        }
    }

    private Map<String, String> loadEnvFile() {
        Map<String, String> envVars = new HashMap<>();

        String[] paths = {
                "D:/projects/VEGA TRADER/backend/.env",
                "d:/projects/VEGA TRADER/backend/.env",
                "../../.env",
                "../.env"
        };

        for (String path : paths) {
            File envFile = new File(path);
            if (envFile.exists() && envFile.isFile()) {
                logger.info("Found .env at: {}", envFile.getAbsolutePath());
                try (BufferedReader reader = new BufferedReader(new FileReader(envFile))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        line = line.trim();
                        if (line.isEmpty() || line.startsWith("#"))
                            continue;

                        int equalsIdx = line.indexOf('=');
                        if (equalsIdx > 0) {
                            String key = line.substring(0, equalsIdx).trim();
                            String value = line.substring(equalsIdx + 1).trim();
                            if ((value.startsWith("\"") && value.endsWith("\"")) ||
                                    (value.startsWith("'") && value.endsWith("'"))) {
                                value = value.substring(1, value.length() - 1);
                            }
                            envVars.put(key, value);
                        }
                    }
                    logger.info("Parsed {} variables from .env", envVars.size());
                    return envVars;
                } catch (Exception e) {
                    logger.error("Error reading .env: {}", e.getMessage());
                }
            }
        }

        logger.error("Could not find .env file");
        return envVars;
    }
}
