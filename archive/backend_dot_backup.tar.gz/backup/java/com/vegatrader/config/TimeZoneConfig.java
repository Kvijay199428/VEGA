package com.vegatrader.config;

import org.springframework.stereotype.Component;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.TimeZone;

/**
 * Centralized timezone configuration for the entire backend.
 * 
 * <p>
 * Features:
 * <ul>
 * <li>Default timezone: Asia/Kolkata (IST)</li>
 * <li>Thread-safe singleton</li>
 * <li>Utility methods for time conversion</li>
 * <li>Configurable via application settings</li>
 * </ul>
 * 
 * @since 1.0.0
 */
@Component
public class TimeZoneConfig {

    /** Default timezone for the application */
    public static final String DEFAULT_TIMEZONE = "Asia/Kolkata";

    /** Configured timezone ID */
    private final ZoneId zoneId;

    /** Java TimeZone for legacy APIs */
    private final TimeZone timeZone;

    /**
     * Creates timezone config with default Asia/Kolkata.
     */
    public TimeZoneConfig() {
        this(DEFAULT_TIMEZONE);
    }

    /**
     * Creates timezone config with specified timezone.
     * 
     * @param timezoneId the timezone ID (e.g., "Asia/Kolkata")
     */
    public TimeZoneConfig(String timezoneId) {
        this.zoneId = ZoneId.of(timezoneId != null ? timezoneId : DEFAULT_TIMEZONE);
        this.timeZone = TimeZone.getTimeZone(this.zoneId);

        // Set as JVM default
        TimeZone.setDefault(this.timeZone);
    }

    /**
     * Gets the configured ZoneId.
     * 
     * @return the ZoneId
     */
    public ZoneId getZoneId() {
        return zoneId;
    }

    /**
     * Gets the configured TimeZone.
     * 
     * @return the TimeZone
     */
    public TimeZone getTimeZone() {
        return timeZone;
    }

    /**
     * Gets current time in configured timezone.
     * 
     * @return current ZonedDateTime
     */
    public ZonedDateTime now() {
        return ZonedDateTime.now(zoneId);
    }

    /**
     * Gets current date in configured timezone.
     * 
     * @return current LocalDate
     */
    public LocalDate today() {
        return LocalDate.now(zoneId);
    }

    /**
     * Gets current time in configured timezone.
     * 
     * @return current LocalTime
     */
    public LocalTime currentTime() {
        return LocalTime.now(zoneId);
    }

    /**
     * Gets current LocalDateTime in configured timezone.
     * 
     * @return current LocalDateTime
     */
    public LocalDateTime nowLocal() {
        return LocalDateTime.now(zoneId);
    }

    /**
     * Converts epoch milliseconds to ZonedDateTime.
     * 
     * @param epochMilli epoch milliseconds
     * @return ZonedDateTime in configured timezone
     */
    public ZonedDateTime fromEpochMilli(long epochMilli) {
        return Instant.ofEpochMilli(epochMilli).atZone(zoneId);
    }

    /**
     * Converts epoch seconds to ZonedDateTime.
     * 
     * @param epochSecond epoch seconds
     * @return ZonedDateTime in configured timezone
     */
    public ZonedDateTime fromEpochSecond(long epochSecond) {
        return Instant.ofEpochSecond(epochSecond).atZone(zoneId);
    }

    /**
     * Converts LocalDateTime to epoch milliseconds.
     * 
     * @param localDateTime the local date time
     * @return epoch milliseconds
     */
    public long toEpochMilli(LocalDateTime localDateTime) {
        return localDateTime.atZone(zoneId).toInstant().toEpochMilli();
    }

    /**
     * Formats time with configured timezone.
     * 
     * @param dateTime the zoned date time
     * @param pattern  the pattern (e.g., "yyyy-MM-dd HH:mm:ss")
     * @return formatted string
     */
    public String format(ZonedDateTime dateTime, String pattern) {
        return dateTime.format(DateTimeFormatter.ofPattern(pattern));
    }

    /**
     * Formats current time with pattern.
     * 
     * @param pattern the pattern
     * @return formatted string
     */
    public String formatNow(String pattern) {
        return format(now(), pattern);
    }

    /**
     * Gets market open time for NSE (9:15 AM IST).
     * 
     * @return LocalTime for market open
     */
    public LocalTime getMarketOpenTime() {
        return LocalTime.of(9, 15);
    }

    /**
     * Gets market close time for NSE (3:30 PM IST).
     * 
     * @return LocalTime for market close
     */
    public LocalTime getMarketCloseTime() {
        return LocalTime.of(15, 30);
    }

    /**
     * Checks if current time is within market hours.
     * 
     * @return true if market is open
     */
    public boolean isMarketHours() {
        LocalTime now = currentTime();
        LocalDate today = today();

        // Check if weekend
        DayOfWeek dayOfWeek = today.getDayOfWeek();
        if (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY) {
            return false;
        }

        return !now.isBefore(getMarketOpenTime()) && !now.isAfter(getMarketCloseTime());
    }

    /**
     * Gets timezone display name.
     * 
     * @return display name (e.g., "India Standard Time")
     */
    public String getDisplayName() {
        return timeZone.getDisplayName();
    }

    /**
     * Gets timezone ID string.
     * 
     * @return timezone ID (e.g., "Asia/Kolkata")
     */
    public String getTimezoneId() {
        return zoneId.getId();
    }

    /**
     * Gets UTC offset in hours.
     * 
     * @return offset in hours (e.g., +5.5 for IST)
     */
    public double getUtcOffsetHours() {
        ZonedDateTime nowZoned = now();
        int offsetSeconds = nowZoned.getOffset().getTotalSeconds();
        return offsetSeconds / 3600.0;
    }

    @Override
    public String toString() {
        return String.format("TimeZoneConfig{id=%s, offset=UTC%+.1f}",
                getTimezoneId(), getUtcOffsetHours());
    }
}
