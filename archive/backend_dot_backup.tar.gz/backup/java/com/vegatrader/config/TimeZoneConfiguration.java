package com.vegatrader.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;

import jakarta.annotation.PostConstruct;
import java.util.TimeZone;

/**
 * Spring configuration for application-wide timezone settings.
 * 
 * <p>
 * Sets the JVM default timezone to Asia/Kolkata (IST) and provides
 * TimeZoneConfig bean for dependency injection.
 * 
 * @since 1.0.0
 */
@Configuration
public class TimeZoneConfiguration {

    @Value("${application.timezone:Asia/Kolkata}")
    private String configuredTimezone;

    /**
     * Initializes JVM default timezone at application startup.
     */
    @PostConstruct
    public void init() {
        TimeZone.setDefault(TimeZone.getTimeZone(configuredTimezone));
        System.out.println("Application timezone set to: " + configuredTimezone);
    }

    /**
     * Creates TimeZoneConfig bean.
     * 
     * @return TimeZoneConfig instance
     */
    @Bean
    public TimeZoneConfig timeZoneConfig() {
        return new TimeZoneConfig(configuredTimezone);
    }
}
