package com.vegatrader.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;
import java.io.File;

/**
 * Database configuration for SQLite.
 * Equivalent to Python database/connection.py
 */
@Configuration
public class DatabaseConfig {

    @Value("${spring.datasource.url:jdbc:sqlite:database/db/db/vegatrade.db}")
    private String databaseUrl;

    /**
     * Configure SQLite DataSource.
     */
    @Bean
    public DataSource dataSource() {
        // Ensure database directory exists
        ensureDatabaseDirectory();

        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.sqlite.JDBC");
        dataSource.setUrl(databaseUrl);
        return dataSource;
    }

    /**
     * Ensure database directory exists.
     */
    private void ensureDatabaseDirectory() {
        // Extract path from JDBC URL
        String path = databaseUrl.replace("jdbc:sqlite:", "");
        File dbFile = new File(path);
        File parentDir = dbFile.getParentFile();

        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs();
        }
    }

    /**
     * Get database file path.
     */
    public String getDatabasePath() {
        return databaseUrl.replace("jdbc:sqlite:", "");
    }
}
