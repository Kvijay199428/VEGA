package com.vegatrader.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Application configuration properties.
 */
@Configuration
@ConfigurationProperties(prefix = "app")
public class AppConfig {

    @Value("${spring.application.name:vega-trader}")
    private String applicationName;

    @Value("${server.port:8080}")
    private int serverPort;

    private String environment = "development";
    private boolean debugMode = false;

    // Market settings
    private String defaultExchange = "NSE";
    private int marketDataCacheTtl = 60;
    private int optionChainRefreshInterval = 3;

    // Getters and setters
    public String getApplicationName() {
        return applicationName;
    }

    public int getServerPort() {
        return serverPort;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public boolean isDebugMode() {
        return debugMode;
    }

    public void setDebugMode(boolean debugMode) {
        this.debugMode = debugMode;
    }

    public String getDefaultExchange() {
        return defaultExchange;
    }

    public void setDefaultExchange(String defaultExchange) {
        this.defaultExchange = defaultExchange;
    }

    public int getMarketDataCacheTtl() {
        return marketDataCacheTtl;
    }

    public void setMarketDataCacheTtl(int marketDataCacheTtl) {
        this.marketDataCacheTtl = marketDataCacheTtl;
    }

    public int getOptionChainRefreshInterval() {
        return optionChainRefreshInterval;
    }

    public void setOptionChainRefreshInterval(int optionChainRefreshInterval) {
        this.optionChainRefreshInterval = optionChainRefreshInterval;
    }
}
