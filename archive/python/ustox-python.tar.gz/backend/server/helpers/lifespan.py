"""
Application Lifespan Management
Handles startup and shutdown procedures for the FastAPI application
"""

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI

from .logging_config import setup_logging
from .instrument_sync import sync_instruments_background

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Application lifespan manager.
    
    Handles:
    - Startup: database initialization, service initialization, background tasks
    - Shutdown: graceful cleanup of all services
    """
    # Initialize logging first
    setup_logging()
    
    # Startup
    logger.info("🚀 Starting VEGA TRADER application...")
    
    try:
        # Initialize database tables
        from database.connection import engine, Base
        Base.metadata.create_all(bind=engine)
        logger.info("✅ Database tables initialized")
        
        # Initialize services
        from services.upstox_service import initialize_upstox_service, upstox_service
        from services.market_data_service import initialize_market_data_service, market_data_service
        from services.ai_service import ai_service
        
        await initialize_upstox_service()
        logger.info("✅ Upstox service initialized")
        
        await initialize_market_data_service()
        logger.info("✅ Market data service initialized")
        
        # Start background instrument sync
        asyncio.create_task(sync_instruments_background())
        
        # Start option chain background service (after a delay to ensure instruments are loaded)
        from optionchain_ws import option_chain_service
        async def start_option_chain_service():
            await asyncio.sleep(5)  # Wait for initial startup
            await option_chain_service.start()
        asyncio.create_task(start_option_chain_service())
        
        logger.info("✅ Application started successfully")
        
        yield
        
    finally:
        # Shutdown
        logger.info("🛑 Shutting down application...")
        
        # Stop option chain service first
        try:
            from optionchain_ws import option_chain_service
            await option_chain_service.stop()
            logger.info("✅ Option chain service stopped")
        except Exception as e:
            logger.warning(f"⚠️ Option chain service stop warning: {e}")
        
        # Import services for cleanup
        from services.upstox_service import upstox_service
        from services.market_data_service import market_data_service
        from services.ai_service import ai_service
        
        # Cleanup services gracefully
        await _safe_cleanup(upstox_service, "Upstox service")
        await _safe_cleanup(market_data_service, "Market data service")
        await _safe_cleanup(ai_service, "AI service")
        
        logger.info("✅ Application shutdown complete")


async def _safe_cleanup(service, name: str) -> None:
    """
    Safely cleanup a service, handling missing methods gracefully.
    
    Args:
        service: Service instance to cleanup
        name: Human-readable name for logging
    """
    try:
        if hasattr(service, 'cleanup') and callable(getattr(service, 'cleanup')):
            await service.cleanup()
            logger.info(f"✅ {name} cleanup completed")
        else:
            logger.debug(f"ℹ️ {name} has no cleanup method, skipping")
    except Exception as e:
        logger.warning(f"⚠️ {name} cleanup warning: {e}")
