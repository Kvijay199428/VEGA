"""
Centralized Logging Configuration for VEGA TRADER Backend
Provides file-based logging with rotation for all services
"""

import os
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime

# Determine log directory path
LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
os.makedirs(LOG_DIR, exist_ok=True)

# Log file paths
SERVER_LOG = os.path.join(LOG_DIR, "server.log")
WEBSOCKET_LOG = os.path.join(LOG_DIR, "websocket.log")
UPSTOX_LOG = os.path.join(LOG_DIR, "upstox.log")
DATABASE_LOG = os.path.join(LOG_DIR, "database.log")

# Log format
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# Max log file size (5 MB)
MAX_BYTES = 5 * 1024 * 1024
# Keep 3 backup files
BACKUP_COUNT = 3


def create_file_handler(log_path: str, level: int = logging.INFO) -> RotatingFileHandler:
    """Create a rotating file handler for a specific log file"""
    handler = RotatingFileHandler(
        log_path,
        maxBytes=MAX_BYTES,
        backupCount=BACKUP_COUNT,
        encoding='utf-8'
    )
    handler.setLevel(level)
    handler.setFormatter(logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT))
    return handler


def create_console_handler(level: int = logging.INFO) -> logging.StreamHandler:
    """Create a console handler with colored output"""
    handler = logging.StreamHandler()
    handler.setLevel(level)
    handler.setFormatter(logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT))
    return handler


def setup_logging(
    console_level: int = logging.INFO,
    file_level: int = logging.DEBUG,
    enable_console: bool = True
) -> None:
    """
    Configure logging for the entire application.
    
    Args:
        console_level: Logging level for console output
        file_level: Logging level for file output
        enable_console: Whether to enable console output
    """
    # Get root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    
    # Clear existing handlers
    root_logger.handlers.clear()
    
    # Add console handler if enabled
    if enable_console:
        root_logger.addHandler(create_console_handler(console_level))
    
    # Add main server log file handler
    root_logger.addHandler(create_file_handler(SERVER_LOG, file_level))
    
    # Configure specific loggers with their own file handlers
    loggers_config = {
        "websocket": WEBSOCKET_LOG,
        "middleware.websocket": WEBSOCKET_LOG,
        "server.websocket": WEBSOCKET_LOG,
        "upstox": UPSTOX_LOG,
        "upstox_auth": UPSTOX_LOG,
        "services.upstox_service": UPSTOX_LOG,
        "database": DATABASE_LOG,
        "sqlalchemy.engine": DATABASE_LOG,
    }
    
    for logger_name, log_path in loggers_config.items():
        logger = logging.getLogger(logger_name)
        logger.addHandler(create_file_handler(log_path, file_level))
        # Don't propagate to root to avoid duplicate logs
        if logger_name != "sqlalchemy.engine":
            logger.propagate = True
    
    # Reduce noise from third-party libraries
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("selenium").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance for a specific module.
    
    Args:
        name: Name of the module (typically __name__)
        
    Returns:
        Configured logger instance
    """
    return logging.getLogger(name)


# Initialize logging on import if running as main server
if __name__ == "__main__":
    setup_logging()
    logger = get_logger(__name__)
    logger.info("Logging system initialized")
    logger.debug("Debug message test")
    logger.warning("Warning message test")
    logger.error("Error message test")
