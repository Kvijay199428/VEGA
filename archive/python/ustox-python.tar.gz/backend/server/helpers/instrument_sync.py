"""
Instrument Sync Background Task
Handles daily synchronization of instruments from Upstox
"""

import asyncio
import logging
from datetime import datetime, time, timedelta
import pytz
from typing import Optional

logger = logging.getLogger(__name__)


async def sync_instruments_background() -> None:
    """
    Background task to sync instruments on startup.
    Only syncs once per day after 8 AM IST.
    """
    # Wait a bit for the app to fully start
    await asyncio.sleep(2)
    
    logger.info("🔄 Checking if instrument sync is needed...")
    
    try:
        from database.connection import SessionLocal
        from models.instrument_models import SyncMetadata
        from services.instrument_service import instrument_sync_service
        from sector.sector_sync import sector_sync_service
        
        db = SessionLocal()
        try:
            should_sync = _check_sync_needed(db)
            
            if should_sync:
                logger.info("🔄 Starting instrument sync...")
                result = instrument_sync_service.sync_instruments(db)
                logger.info(
                    f"✅ Sync complete: {result['total_saved']} instruments saved in {result['duration_seconds']:.1f}s"
                )
                logger.info(f"   📊 Breakdown: {result['saved_count']}")

                # Also sync sector CSVs
                logger.info("🔄 Starting sector CSV sync...")
                sector_result = sector_sync_service.sync_all_sectors()
                logger.info(
                    f"✅ Sector sync complete: {len(sector_result['successful'])}/{sector_result['total']} CSVs downloaded"
                )
        finally:
            db.close()
    except Exception as e:
        logger.error(f"❌ Instrument sync check failed: {e}")


def _check_sync_needed(db) -> bool:
    """
    Determine if instrument sync is needed based on last sync time.
    
    Rules:
    - Sync only after 8 AM IST
    - Sync only once per day
    - Skip if already synced today after 8 AM
    """
    from models.instrument_models import SyncMetadata
    
    # Check last sync time from metadata
    sync_meta = db.query(SyncMetadata).filter(
        SyncMetadata.table_name == 'equity_instruments'
    ).first()
    
    # Use IST timezone for consistent 8 AM comparison
    ist = pytz.timezone('Asia/Kolkata')
    now_ist = datetime.now(ist)
    today_8am_ist = ist.localize(datetime.combine(now_ist.date(), time(8, 0)))
    
    # Default: sync needed
    should_sync = True
    
    if sync_meta and sync_meta.last_sync:
        last_sync = sync_meta.last_sync
        
        # Convert last_sync to IST if it's naive (assumed UTC)
        if last_sync.tzinfo is None:
            last_sync_ist = pytz.utc.localize(last_sync).astimezone(ist)
        else:
            last_sync_ist = last_sync.astimezone(ist)
        
        # If we already synced today after 8 AM IST, skip
        if last_sync_ist >= today_8am_ist:
            logger.info(
                f"✅ Instruments already synced today at {last_sync_ist.strftime('%H:%M:%S')} IST. "
                f"Skipping sync. Next sync will be after 8 AM tomorrow."
            )
            should_sync = False
        # If current time is before 8 AM IST, check if we synced yesterday after 8 AM
        elif now_ist < today_8am_ist:
            yesterday_8am_ist = today_8am_ist - timedelta(days=1)
            if last_sync_ist >= yesterday_8am_ist:
                logger.info(
                    f"✅ Current time is before 8 AM IST. Last sync was at {last_sync_ist.strftime('%Y-%m-%d %H:%M:%S')} IST. "
                    f"Skipping sync. Will sync after 8 AM today."
                )
                should_sync = False
    
    if should_sync:
        # Additional check: Only sync if current time is after 8 AM IST
        if now_ist < today_8am_ist:
            logger.info(
                f"⏰ Current time is {now_ist.strftime('%H:%M:%S')} IST, before 8 AM. "
                f"Skipping sync until after 8 AM."
            )
            should_sync = False
    
    return should_sync
