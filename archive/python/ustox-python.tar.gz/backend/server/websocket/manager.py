"""
WebSocket Manager for Real-time Data Streaming
Handles WebSocket connections, subscriptions, and message broadcasting
"""

from fastapi import WebSocket
from typing import Dict, Set, List, Optional, Any
import json
import logging
import asyncio
from datetime import datetime

# Get dedicated websocket logger
logger = logging.getLogger("server.websocket")


class WebSocketManager:
    """
    Manages WebSocket connections for real-time data streaming.
    
    Features:
    - Connection tracking per user
    - Channel-based subscriptions (market data, orders, etc.)
    - Broadcast to all, channel, or specific user
    - Thread-safe operations with asyncio locks
    """

    def __init__(self):
        # Active connections: {websocket: user_info}
        self._active_connections: Dict[WebSocket, Dict] = {}
        
        # Subscriptions: {channel: set of websockets}
        self._subscriptions: Dict[str, Set[WebSocket]] = {}
        
        # User connections: {user_id: set of websockets}
        self._user_connections: Dict[int, Set[WebSocket]] = {}
        
        # Lock for thread-safe operations
        self._lock = asyncio.Lock()
        
        logger.info("WebSocket manager initialized")

    async def connect(self, websocket: WebSocket, user_info: Optional[Dict] = None):
        """
        Accept and register a new WebSocket connection.
        
        Args:
            websocket: WebSocket connection
            user_info: Optional user information
        """
        await websocket.accept()
        
        async with self._lock:
            self._active_connections[websocket] = user_info or {}
            
            # Track user connections
            if user_info and "id" in user_info:
                user_id = user_info["id"]
                if user_id not in self._user_connections:
                    self._user_connections[user_id] = set()
                self._user_connections[user_id].add(websocket)
        
        logger.info(f"✅ WebSocket connected. Active: {len(self._active_connections)}")

    async def disconnect(self, websocket: WebSocket):
        """
        Remove a WebSocket connection.
        
        Args:
            websocket: WebSocket connection to remove
        """
        async with self._lock:
            user_info = self._active_connections.pop(websocket, {})
            
            # Remove from user connections
            if user_info and "id" in user_info:
                user_id = user_info["id"]
                if user_id in self._user_connections:
                    self._user_connections[user_id].discard(websocket)
                    if not self._user_connections[user_id]:
                        del self._user_connections[user_id]
            
            # Remove from all subscriptions
            for channel in list(self._subscriptions.keys()):
                self._subscriptions[channel].discard(websocket)
                if not self._subscriptions[channel]:
                    del self._subscriptions[channel]
        
        logger.info(f"🔌 WebSocket disconnected. Active: {len(self._active_connections)}")

    async def subscribe(self, websocket: WebSocket, channel: str):
        """
        Subscribe a WebSocket to a channel.
        
        Args:
            websocket: WebSocket connection
            channel: Channel name to subscribe to
        """
        async with self._lock:
            if channel not in self._subscriptions:
                self._subscriptions[channel] = set()
            self._subscriptions[channel].add(websocket)
        
        logger.debug(f"📺 Subscribed to channel: {channel}")

    async def unsubscribe(self, websocket: WebSocket, channel: str):
        """
        Unsubscribe a WebSocket from a channel.
        
        Args:
            websocket: WebSocket connection
            channel: Channel name to unsubscribe from
        """
        async with self._lock:
            if channel in self._subscriptions:
                self._subscriptions[channel].discard(websocket)
                if not self._subscriptions[channel]:
                    del self._subscriptions[channel]
        
        logger.debug(f"🚫 Unsubscribed from channel: {channel}")

    async def send_personal_message(self, websocket: WebSocket, message: Any):
        """
        Send a message to a specific WebSocket.
        
        Args:
            websocket: Target WebSocket connection
            message: Message to send (dict or str)
        """
        try:
            if isinstance(message, dict):
                await websocket.send_json(message)
            else:
                await websocket.send_text(str(message))
        except Exception as e:
            logger.error(f"❌ Error sending message: {e}")

    async def send_to_user(self, user_id: int, message: Any):
        """
        Send a message to all WebSocket connections of a user.
        
        Args:
            user_id: Target user ID
            message: Message to send
        """
        if user_id in self._user_connections:
            for websocket in self._user_connections[user_id]:
                await self.send_personal_message(websocket, message)

    async def broadcast(self, message: Any, exclude: Optional[WebSocket] = None):
        """
        Broadcast a message to all connected WebSockets.
        
        Args:
            message: Message to broadcast
            exclude: Optional WebSocket to exclude from broadcast
        """
        for websocket in self._active_connections:
            if websocket != exclude:
                await self.send_personal_message(websocket, message)

    async def broadcast_to_channel(self, channel: str, message: Any):
        """
        Broadcast a message to all WebSockets subscribed to a channel.
        
        Args:
            channel: Target channel
            message: Message to broadcast
        """
        if channel in self._subscriptions:
            for websocket in self._subscriptions[channel]:
                await self.send_personal_message(websocket, message)

    async def handle_message(self, websocket: WebSocket, data: str):
        """
        Handle incoming WebSocket messages.
        
        Args:
            websocket: Source WebSocket connection
            data: Message data as string
        """
        try:
            message = json.loads(data)
            message_type = message.get("type")
            
            if message_type == "subscribe":
                channels = message.get("channels", [])
                for channel in channels:
                    await self.subscribe(websocket, channel)
                await self.send_personal_message(websocket, {
                    "type": "subscribed",
                    "channels": channels,
                    "timestamp": datetime.utcnow().isoformat()
                })
                
            elif message_type == "unsubscribe":
                channels = message.get("channels", [])
                for channel in channels:
                    await self.unsubscribe(websocket, channel)
                await self.send_personal_message(websocket, {
                    "type": "unsubscribed",
                    "channels": channels,
                    "timestamp": datetime.utcnow().isoformat()
                })
                
            elif message_type == "ping":
                await self.send_personal_message(websocket, {
                    "type": "pong",
                    "timestamp": datetime.utcnow().isoformat()
                })
                
            else:
                logger.debug(f"📨 Received message type: {message_type}")
                
        except json.JSONDecodeError:
            logger.warning(f"⚠️ Invalid JSON received: {data[:100]}...")
        except Exception as e:
            logger.error(f"❌ Error handling message: {e}")

    @property
    def connection_count(self) -> int:
        """Get the number of active connections."""
        return len(self._active_connections)

    @property
    def channel_stats(self) -> Dict[str, int]:
        """Get subscription counts per channel."""
        return {channel: len(subs) for channel, subs in self._subscriptions.items()}


# Global instance for backwards compatibility
websocket_manager = WebSocketManager()
