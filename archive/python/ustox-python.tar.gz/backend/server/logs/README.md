# Server Logs Directory
# This directory contains log files for the VEGA TRADER backend services
# 
# Log files:
# - server.log      - Main server logs
# - websocket.log   - WebSocket connection and message logs
# - upstox.log      - Upstox authentication and API logs
# - database.log    - Database query and connection logs
#
# Log rotation: 5MB max size, 3 backup files kept
