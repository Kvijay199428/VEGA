"""
VEGA TRADER Backend Server
Minimal server executor - entry point for the trading platform API
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
import logging
import uvicorn

# Import lifespan from helpers (relative import since we're in server package)
from .helpers import lifespan

# Import routers
from routers import (
    auth, user, market, orders, portfolio, strategies, 
    indicators, signals, settings, gtt, webhooks, instruments, options
)
from sector.sector_router import router as sector_router

# Import the SAME WebSocket manager used by optionchain_ws for broadcasting
from server.websocket.manager import websocket_manager
from middleware.auth import get_current_user

# Configure logging
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="VEGA TRADER API",
    description="Complete trading platform with AI strategies, real-time data, and order execution",
    version="1.0.0",
    lifespan=lifespan
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router)
app.include_router(user.router)
app.include_router(market.router)
app.include_router(orders.router)
app.include_router(portfolio.router)
app.include_router(strategies.router)
app.include_router(indicators.router)
app.include_router(signals.router)
app.include_router(settings.router)
app.include_router(gtt.router)
app.include_router(webhooks.router)
app.include_router(sector_router)  # Must be before instruments because of path overlap
app.include_router(instruments.router)
app.include_router(options.router)


# Root endpoint
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "status": "success",
        "message": "VEGA TRADER API is running",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health"
    }


# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "services": {
            "database": "connected",
            "redis": "connected",
            "upstox": "configured",
            "websocket": "active"
        },
        "timestamp": datetime.utcnow().isoformat()
    }


# WebSocket endpoint
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time data"""
    await websocket_manager.connect(websocket)
    try:
        while True:
            # Handle WebSocket messages
            data = await websocket.receive_text()
            await websocket_manager.handle_message(websocket, data)
    except WebSocketDisconnect:
        await websocket_manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        await websocket.close()


# Error handlers - must return Response objects, not dicts
@app.exception_handler(404)
async def not_found_handler(request, exc):
    return JSONResponse(
        status_code=404,
        content={
            "status": "error",
            "message": "Resource not found",
            "detail": str(exc.detail) if hasattr(exc, 'detail') else str(exc)
        }
    )


@app.exception_handler(500)
async def internal_error_handler(request, exc):
    logger.error(f"Internal server error: {exc}")
    return JSONResponse(
        status_code=500,
        content={
            "status": "error",
            "message": "Internal server error",
            "detail": "Something went wrong on our end"
        }
    )


if __name__ == "__main__":
    # Run the application
    uvicorn.run(
        "server:app",
        host="0.0.0.0",
        port=28020,
        reload=True,
        log_level="info"
    )
