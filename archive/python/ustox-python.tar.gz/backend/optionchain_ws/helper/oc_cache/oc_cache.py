"""
Option Chain Cache (oc_cache)
Thread-safe in-memory cache for option chain data
Stores option chain data for all instruments and expiries for instant retrieval
"""

from typing import Dict, Optional, List, Tuple, Any
from datetime import datetime, timedelta
import threading
import logging

logger = logging.getLogger(__name__)


class OptionChainCache:
    """
    Thread-safe in-memory cache for option chain data.
    
    Keys are tuples of (instrument_key, expiry_date)
    Values contain the option chain data and metadata
    """
    
    def __init__(self, ttl_seconds: int = 60):
        """
        Initialize the cache.
        
        Args:
            ttl_seconds: Time-to-live for cache entries in seconds
        """
        self._cache: Dict[Tuple[str, str], Dict[str, Any]] = {}
        self._lock = threading.RLock()
        self._ttl = timedelta(seconds=ttl_seconds)
        self._last_update: Dict[Tuple[str, str], datetime] = {}
        
    def set(self, instrument_key: str, expiry_date: str, data: List[Dict]) -> None:
        """
        Store option chain data in cache.
        
        Args:
            instrument_key: Underlying instrument key (e.g., "NSE_INDEX|Nifty 50")
            expiry_date: Expiry date in YYYY-MM-DD format
            data: Option chain data from Upstox API
        """
        key = (instrument_key, expiry_date)
        now = datetime.now()
        
        with self._lock:
            self._cache[key] = {
                "data": data,
                "instrument_key": instrument_key,
                "expiry_date": expiry_date,
                "updated_at": now.isoformat(),
                "count": len(data)
            }
            self._last_update[key] = now
            
        logger.debug(f"Cached option chain: {instrument_key} | {expiry_date} ({len(data)} strikes)")
    
    def get(self, instrument_key: str, expiry_date: str) -> Optional[Dict[str, Any]]:
        """
        Get option chain data from cache.
        
        Args:
            instrument_key: Underlying instrument key
            expiry_date: Expiry date in YYYY-MM-DD format
            
        Returns:
            Cached data dict or None if not found/expired
        """
        key = (instrument_key, expiry_date)
        
        with self._lock:
            if key not in self._cache:
                return None
                
            # Check TTL
            last_update = self._last_update.get(key)
            if last_update and datetime.now() - last_update > self._ttl:
                # Entry expired
                logger.debug(f"Cache expired: {instrument_key} | {expiry_date}")
                return None
                
            return self._cache[key].copy()
    
    def get_all_keys(self) -> List[Tuple[str, str]]:
        """
        Get all cached instrument/expiry combinations.
        
        Returns:
            List of (instrument_key, expiry_date) tuples
        """
        with self._lock:
            return list(self._cache.keys())
    
    def get_instruments(self) -> List[str]:
        """
        Get all unique instrument keys in cache.
        
        Returns:
            List of unique instrument keys
        """
        with self._lock:
            return list(set(key[0] for key in self._cache.keys()))
    
    def get_expiries_for_instrument(self, instrument_key: str) -> List[str]:
        """
        Get all cached expiries for an instrument.
        
        Args:
            instrument_key: Underlying instrument key
            
        Returns:
            List of expiry dates
        """
        with self._lock:
            return [key[1] for key in self._cache.keys() if key[0] == instrument_key]
    
    def is_fresh(self, instrument_key: str, expiry_date: str, max_age_seconds: int = 5) -> bool:
        """
        Check if cached data is fresh (updated within max_age_seconds).
        
        Args:
            instrument_key: Underlying instrument key
            expiry_date: Expiry date
            max_age_seconds: Maximum age to consider fresh
            
        Returns:
            True if data exists and is fresh
        """
        key = (instrument_key, expiry_date)
        
        with self._lock:
            last_update = self._last_update.get(key)
            if not last_update:
                return False
            return datetime.now() - last_update < timedelta(seconds=max_age_seconds)
    
    def clear(self) -> None:
        """Clear all cached data."""
        with self._lock:
            self._cache.clear()
            self._last_update.clear()
        logger.info("Option chain cache cleared")
    
    def stats(self) -> Dict[str, Any]:
        """
        Get cache statistics.
        
        Returns:
            Dict with cache stats
        """
        with self._lock:
            instruments = self.get_instruments()
            return {
                "total_entries": len(self._cache),
                "unique_instruments": len(instruments),
                "instruments": instruments,
                "memory_estimate_mb": len(str(self._cache)) / (1024 * 1024)
            }


# Global singleton instance
oc_cache = OptionChainCache(ttl_seconds=60)
