# Option Chain WebSocket Module Documentation

> Complete guide for the Option Chain WebSocket service, including architecture, file structure, and usage.

---

## 📂 Directory Structure

```
backend/optionchain_ws/
├── __init__.py                    # Package exports
├── optionchain_ws.py              # Main module - entry point
├── helper/
│   ├── __init__.py                # Helper package exports
│   ├── option_chain_background.py # Background fetcher service
│   └── oc_cache/
│       ├── __init__.py            # Cache package exports
│       └── oc_cache.py            # In-memory cache implementation
└── docs/
    └── optionchain_ws.md          # This documentation
```

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         Option Chain WebSocket System                    │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌─────────────────────┐     ┌─────────────────────┐                   │
│  │   Upstox API        │     │   WebSocket Clients │                   │
│  │   (Option Chain)    │     │   (Frontend)        │                   │
│  └─────────┬───────────┘     └──────────▲──────────┘                   │
│            │                            │                               │
│            │ HTTP GET                   │ WebSocket                     │
│            │ (every 3s per instrument)  │ (real-time broadcast)         │
│            ▼                            │                               │
│  ┌─────────────────────────────────────┴───────────────┐               │
│  │           OptionChainBackgroundService               │               │
│  │  (optionchain_ws/helper/option_chain_background.py) │               │
│  └─────────────────────┬───────────────────────────────┘               │
│                        │                                                │
│                        │ Store & Broadcast                              │
│                        ▼                                                │
│  ┌───────────────────────────────────┐   ┌─────────────────────────┐   │
│  │          oc_cache                  │   │  WebSocket Manager      │   │
│  │  (optionchain_ws/helper/oc_cache) │   │  (server/websocket/)    │   │
│  │                                   │   │                          │   │
│  │  • In-memory storage              │   │  • Client connections    │   │
│  │  • 60s TTL                        │   │  • Channel subscriptions │   │
│  │  • Thread-safe                    │   │  • Message broadcast     │   │
│  └───────────────────────────────────┘   └─────────────────────────┘   │
│                        ▲                                                │
│                        │ Get cached data                                │
│                        │                                                │
│  ┌─────────────────────┴───────────────────────────────┐               │
│  │              REST API Endpoint                       │               │
│  │           /api/v1/options/chain                      │               │
│  │           (routers/options.py)                       │               │
│  └───────────────────────────────────────────────────────┘               │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 📦 Module Components

### 1. Main Module (`optionchain_ws.py`)

Entry point for the option chain WebSocket service.

```python
from optionchain_ws import option_chain_service, oc_cache

# Start the background service
await option_chain_service.start()

# Get cached data
data = oc_cache.get("NSE_INDEX|Nifty 50", "2025-01-02")

# Check service status
status = option_chain_service.get_status()

# Stop the service
await option_chain_service.stop()
```

**Exports:**
| Name | Type | Description |
|------|------|-------------|
| `option_chain_service` | `OptionChainBackgroundService` | Global service instance |
| `oc_cache` | `OptionChainCache` | Global cache instance |
| `start_service()` | async function | Start the background service |
| `stop_service()` | async function | Stop the background service |
| `get_status()` | function | Get service status dict |
| `get_cache()` | function | Get cache instance |

---

### 2. Background Service (`helper/option_chain_background.py`)

Continuously fetches option chain data from Upstox API.

**Class: `OptionChainBackgroundService`**

| Method | Description |
|--------|-------------|
| `async start()` | Start the background fetch loop |
| `async stop()` | Stop the background service |
| `get_status()` | Returns dict with service status |

**Configuration:**
- **Fetch Interval**: 3 seconds (configurable via constructor)
- **API Token**: Uses `OPTIONCHAIN1` (api_index=4) or fallback to `PRIMARY`

**Fetch Cycle:**
1. Load all index underlyings from database
2. Get valid expiries (>= today)
3. Cycle through each instrument/expiry combination
4. Fetch from Upstox API → Transform → Calculate valuations → Cache → Broadcast

---

### 3. Cache Module (`helper/oc_cache/oc_cache.py`)

Thread-safe in-memory cache for option chain data.

**Class: `OptionChainCache`**

| Method | Description |
|--------|-------------|
| `set(instrument_key, expiry_date, data)` | Store option chain data |
| `get(instrument_key, expiry_date)` | Get cached data (returns None if expired) |
| `get_all_keys()` | Get all cached (instrument, expiry) tuples |
| `get_instruments()` | Get unique instrument keys |
| `get_expiries_for_instrument(key)` | Get expiries for an instrument |
| `is_fresh(key, expiry, max_age)` | Check if data is fresh |
| `clear()` | Clear all cached data |
| `stats()` | Get cache statistics |

**Configuration:**
- **TTL**: 60 seconds (configurable via constructor)
- **Thread Safety**: Uses `threading.RLock`

---

## 🔌 API Endpoints

### GET `/api/v1/options/chain`

Fetches option chain data (cache-first).

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `instrument_key` | string | Yes | Underlying key (e.g., `NSE_INDEX\|Nifty 50`) |
| `expiry_date` | string | Yes | Expiry date (YYYY-MM-DD) |
| `force_refresh` | boolean | No | Bypass cache and fetch fresh data |

**Response:**
```json
{
    "status": "success",
    "data": [...],
    "underlying": "NSE_INDEX|Nifty 50",
    "expiry": "2025-01-02",
    "count": 45,
    "cached": true,
    "updated_at": "2025-01-01T10:30:00"
}
```

---

### GET `/api/v1/options/background-status`

Get background service status.

**Response:**
```json
{
    "status": "success",
    "data": {
        "service": {
            "is_running": true,
            "fetch_interval_seconds": 3,
            "total_instruments": 45,
            "current_index": 12
        },
        "cache": {
            "total_entries": 45,
            "unique_instruments": 5,
            "instruments": ["NSE_INDEX|Nifty 50", ...],
            "memory_estimate_mb": 2.5
        }
    }
}
```

---

## 🌐 WebSocket Protocol

### Subscribe to Option Chain Updates

**Client → Server:**
```json
{
    "type": "subscribe_option_chain",
    "instrument_key": "NSE_INDEX|Nifty 50",
    "expiry_date": "2025-01-02"
}
```

**Server → Client (Acknowledgment):**
```json
{
    "type": "option_chain_subscription_ack",
    "channel": "option_chain:NSE_INDEX|Nifty 50:2025-01-02",
    "instrument_key": "NSE_INDEX|Nifty 50",
    "expiry_date": "2025-01-02",
    "status": "subscribed",
    "initial_data": {...},
    "timestamp": "2025-01-01T10:30:00Z"
}
```

**Server → Client (Updates):**
```json
{
    "type": "option_chain_update",
    "channel": "option_chain:NSE_INDEX|Nifty 50:2025-01-02",
    "data": {
        "status": "success",
        "data": [...],
        "underlying": "NSE_INDEX|Nifty 50",
        "expiry": "2025-01-02",
        "count": 45,
        "updated_at": "2025-01-01T10:30:03"
    }
}
```

### Unsubscribe

**Client → Server:**
```json
{
    "type": "unsubscribe_option_chain",
    "instrument_key": "NSE_INDEX|Nifty 50",
    "expiry_date": "2025-01-02"
}
```

---

## 🔗 Integration Points

### Application Startup (`main.py`)

```python
from optionchain_ws import option_chain_service

# In lifespan startup
async def start_option_chain_service():
    await asyncio.sleep(5)  # Wait for app initialization
    await option_chain_service.start()
asyncio.create_task(start_option_chain_service())

# In lifespan shutdown
await option_chain_service.stop()
```

### WebSocket Handlers (`server/websocket/handlers.py`)

```python
from optionchain_ws import oc_cache

# Get cached data for initial subscription response
cached = oc_cache.get(instrument_key, expiry_date)
```

### Options Router (`routers/options.py`)

```python
from optionchain_ws import oc_cache, option_chain_service

# Cache-first approach
cached = oc_cache.get(instrument_key, expiry_date)
if cached:
    return cached

# Get service status
status = option_chain_service.get_status()
```

---

## 📁 Backup Location

Original files backed up to:
```
backend/backup/optionchain/
├── services/
│   ├── option_chain_cache.py
│   └── option_chain_background.py
└── server/websocket/
    └── handlers.py
```

---

## 🧪 Testing

### Verify Imports
```bash
cd d:\projects\VEGA TRADER\backend
python -c "from optionchain_ws import option_chain_service, oc_cache; print('✅ Imports OK')"
```

### Check Service Status
```bash
curl http://localhost:28020/api/v1/options/background-status
```

### Test WebSocket
```javascript
const ws = new WebSocket('ws://localhost:28020/ws');
ws.onopen = () => {
    ws.send(JSON.stringify({
        type: 'subscribe_option_chain',
        instrument_key: 'NSE_INDEX|Nifty 50',
        expiry_date: '2025-01-02'
    }));
};
ws.onmessage = (e) => console.log(JSON.parse(e.data));
```

---

## ⚙️ Configuration

| Setting | Default | Location | Description |
|---------|---------|----------|-------------|
| Fetch Interval | 3s | `optionchain_ws.py` | Time between API calls |
| Cache TTL | 60s | `oc_cache.py` | Cache entry expiration |
| API Token | OPTIONCHAIN1 (index 4) | `option_chain_background.py` | Upstox API token |

---

*Last Updated: 2025-12-24*
