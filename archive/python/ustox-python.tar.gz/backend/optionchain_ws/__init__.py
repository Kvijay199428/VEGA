"""
Option Chain WebSocket Package (optionchain_ws)
Provides real-time option chain data via WebSocket

Structure:
    optionchain_ws/
    ├── __init__.py              # This file - package exports
    ├── optionchain_ws.py        # Main module with service instance
    ├── helper/
    │   ├── __init__.py          # Helper package exports
    │   ├── option_chain_background.py  # Background fetcher service
    │   └── oc_cache/
    │       ├── __init__.py      # Cache package exports
    │       └── oc_cache.py      # In-memory cache implementation
    └── docs/
        └── optionchain_ws.md    # Complete documentation
"""

# Re-export from main module for convenience
from optionchain_ws.optionchain_ws import (
    option_chain_service,
    oc_cache,
    OptionChainCache,
    OptionChainBackgroundService,
    start_service,
    stop_service,
    get_status,
    get_cache
)

__version__ = "1.0.0"

__all__ = [
    'option_chain_service',
    'oc_cache',
    'OptionChainCache',
    'OptionChainBackgroundService',
    'start_service',
    'stop_service',
    'get_status',
    'get_cache',
    '__version__'
]
