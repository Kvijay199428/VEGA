"""
Option Chain WebSocket Module (optionchain_ws)
Main entry point for the Option Chain WebSocket service

This module provides:
- Background service for continuous option chain data fetching
- In-memory caching for instant data retrieval
- WebSocket broadcasting for real-time updates

Usage:
    from optionchain_ws import option_chain_service, oc_cache
    
    # Start the background service
    await option_chain_service.start()
    
    # Get cached data
    data = oc_cache.get(instrument_key, expiry_date)
    
    # Stop the service
    await option_chain_service.stop()
"""

import logging
from typing import Dict, Any

# Import from helper modules
from optionchain_ws.helper.oc_cache import oc_cache, OptionChainCache
from optionchain_ws.helper.option_chain_background import OptionChainBackgroundService

logger = logging.getLogger(__name__)

# Create the global service instance
option_chain_service = OptionChainBackgroundService(fetch_interval=1)


async def start_service() -> None:
    """Start the option chain background service."""
    await option_chain_service.start()


async def stop_service() -> None:
    """Stop the option chain background service."""
    await option_chain_service.stop()


def get_status() -> Dict[str, Any]:
    """Get the current status of the option chain service."""
    return option_chain_service.get_status()


def get_cache() -> OptionChainCache:
    """Get the option chain cache instance."""
    return oc_cache


# Export for easy access
__all__ = [
    'option_chain_service',
    'oc_cache',
    'OptionChainCache',
    'OptionChainBackgroundService',
    'start_service',
    'stop_service',
    'get_status',
    'get_cache'
]
