"""
Strategy Schemas - Pydantic models for strategy requests and responses
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum


class StrategyType(str, Enum):
    MOMENTUM = "MOMENTUM"
    MEAN_REVERSION = "MEAN_REVERSION"
    BREAKOUT = "BREAKOUT"
    TREND_FOLLOWING = "TREND_FOLLOWING"
    SCALPING = "SCALPING"
    SWING = "SWING"
    CUSTOM = "CUSTOM"


class StrategyCategory(str, Enum):
    TECHNICAL = "TECHNICAL"
    FUNDAMENTAL = "FUNDAMENTAL"
    QUANTITATIVE = "QUANTITATIVE"
    AI = "AI"
    HYBRID = "HYBRID"


class StrategyStatus(str, Enum):
    DRAFT = "DRAFT"
    ACTIVE = "ACTIVE"
    PAUSED = "PAUSED"
    ARCHIVED = "ARCHIVED"


class RiskManagement(BaseModel):
    """Risk management parameters"""
    stop_loss: float = Field(2.0, ge=0.1, le=50, description="Stop loss percentage")
    take_profit: float = Field(5.0, ge=0.1, le=100, description="Take profit percentage")
    max_positions: int = Field(5, ge=1, le=50, description="Maximum open positions")
    max_position_size: Optional[float] = Field(None, ge=0, description="Maximum position size in value")
    trailing_stop: Optional[float] = Field(None, ge=0, le=50, description="Trailing stop percentage")


class StrategyRule(BaseModel):
    """Strategy trading rule"""
    name: str = Field(..., description="Rule name")
    condition: str = Field(..., description="Rule condition expression")
    action: str = Field(..., description="Action to take (BUY, SELL, HOLD)")


class StrategyCreate(BaseModel):
    """Request model for creating a strategy"""
    name: str = Field(..., min_length=1, max_length=255, description="Strategy name")
    description: Optional[str] = Field(None, description="Strategy description")
    strategy_type: StrategyType = Field(..., description="Type of strategy")
    category: StrategyCategory = Field(StrategyCategory.TECHNICAL, description="Strategy category")
    parameters: Optional[Dict[str, Any]] = Field(None, description="Strategy parameters")
    rules: Optional[List[StrategyRule]] = Field(None, description="Trading rules")
    instruments: Optional[List[str]] = Field(None, description="Target instruments")
    risk_management: Optional[RiskManagement] = Field(None, description="Risk management settings")

    class Config:
        use_enum_values = True


class StrategyUpdate(BaseModel):
    """Request model for updating a strategy"""
    name: Optional[str] = Field(None, min_length=1, max_length=255, description="Strategy name")
    description: Optional[str] = Field(None, description="Strategy description")
    parameters: Optional[Dict[str, Any]] = Field(None, description="Strategy parameters")
    rules: Optional[List[StrategyRule]] = Field(None, description="Trading rules")
    instruments: Optional[List[str]] = Field(None, description="Target instruments")
    risk_management: Optional[RiskManagement] = Field(None, description="Risk management settings")
    is_active: Optional[bool] = Field(None, description="Whether strategy is active")

    class Config:
        use_enum_values = True


class StrategyResponse(BaseModel):
    """Response model for strategy operations"""
    id: int
    name: str
    description: Optional[str] = None
    strategy_type: str
    category: str
    status: str
    is_active: bool
    parameters: Optional[Dict[str, Any]] = None
    rules: Optional[List[Dict[str, Any]]] = None
    instruments: Optional[List[str]] = None
    risk_management: Optional[Dict[str, Any]] = None
    backtest_results: Optional[Dict[str, Any]] = None
    created_at: str
    updated_at: str


class StrategyExecutionRequest(BaseModel):
    """Request model for executing a strategy"""
    strategy_id: int = Field(..., description="ID of strategy to execute")
    parameters: Optional[Dict[str, Any]] = Field(None, description="Execution parameters override")
    paper_trading: bool = Field(True, description="Run in paper trading mode")


class AIGenerationRequest(BaseModel):
    """Request model for AI strategy generation"""
    prompt: str = Field(..., min_length=10, max_length=2000, description="Description of desired strategy")
    model: Optional[str] = Field("gpt-3.5-turbo", description="LLM model to use")
    strategy_type: Optional[StrategyType] = Field(None, description="Preferred strategy type")
    risk_level: Optional[str] = Field("medium", description="Risk level: low, medium, high")

    class Config:
        use_enum_values = True


class BacktestRequest(BaseModel):
    """Request model for backtesting a strategy"""
    start_date: str = Field(..., description="Start date (YYYY-MM-DD)")
    end_date: str = Field(..., description="End date (YYYY-MM-DD)")
    initial_capital: float = Field(100000, ge=1000, description="Initial capital")
    commission: float = Field(0.01, ge=0, le=1, description="Commission percentage")


class BacktestResult(BaseModel):
    """Response model for backtest results"""
    start_date: str
    end_date: str
    initial_capital: float
    final_capital: float
    total_return: float
    annualized_return: float
    total_trades: int
    profitable_trades: int
    losing_trades: int
    win_rate: float
    max_drawdown: float
    sharpe_ratio: float
    sortino_ratio: Optional[float] = None
    volatility: float
    profit_factor: float
