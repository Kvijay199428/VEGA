"""
Order Schemas - Pydantic models for order requests and responses
"""

from pydantic import BaseModel, Field
from typing import Optional, List
from enum import Enum


class TransactionType(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    SL = "SL"
    SL_M = "SL-M"


class ProductType(str, Enum):
    CNC = "CNC"
    INTRADAY = "INTRADAY"
    MARGIN = "MARGIN"


class ValidityType(str, Enum):
    DAY = "DAY"
    IOC = "IOC"
    GTC = "GTC"


class OrderRequest(BaseModel):
    """Request model for placing an order"""
    instrument_token: str = Field(..., description="Upstox instrument token")
    transaction_type: TransactionType = Field(..., description="BUY or SELL")
    quantity: int = Field(..., ge=1, description="Order quantity")
    order_type: OrderType = Field(..., description="Order type")
    product: ProductType = Field(..., description="Product type")
    validity: ValidityType = Field(ValidityType.DAY, description="Order validity")
    price: Optional[float] = Field(None, ge=0, description="Price for limit orders")
    trigger_price: Optional[float] = Field(None, ge=0, description="Trigger price for stop orders")
    disclosed_quantity: Optional[int] = Field(None, ge=0, description="Disclosed quantity")
    tag: Optional[str] = Field(None, max_length=50, description="User tag for the order")
    is_amo: bool = Field(False, description="Is After Market Order")

    class Config:
        use_enum_values = True


class OrderUpdateRequest(BaseModel):
    """Request model for modifying an order"""
    quantity: Optional[int] = Field(None, ge=1, description="New quantity")
    price: Optional[float] = Field(None, ge=0, description="New price")
    trigger_price: Optional[float] = Field(None, ge=0, description="New trigger price")
    validity: Optional[ValidityType] = Field(None, description="New validity")
    disclosed_quantity: Optional[int] = Field(None, ge=0, description="New disclosed quantity")

    class Config:
        use_enum_values = True


class BatchOrderRequest(BaseModel):
    """Request model for placing multiple orders"""
    orders: List[OrderRequest] = Field(..., min_length=1, max_length=20, description="List of orders to place")


class OrderResponse(BaseModel):
    """Response model for order operations"""
    status: str
    order_id: Optional[str] = None
    message: Optional[str] = None
    data: Optional[dict] = None


class TradeResponse(BaseModel):
    """Response model for trade information"""
    trade_id: str
    order_id: str
    symbol: str
    exchange: str
    transaction_type: str
    quantity: int
    price: float
    trade_value: float
    brokerage: float
    trade_timestamp: str
