"""
Strategies Router - Handles AI trading strategies
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from typing import Dict, Any, List, Optional
from database.connection import get_db
from middleware.auth import get_current_user
from models.ai_strategy import Strategy, StrategyExecution, TechnicalIndicator
from services.ai_service import ai_service
from schemas.strategy import (
    StrategyCreate, StrategyUpdate, StrategyResponse,
    StrategyExecutionRequest, AIGenerationRequest
)

router = APIRouter(prefix="/api/v1/strategies", tags=["Strategies"])
security = HTTPBearer()

# ==========================================================================
# PREDEFINED STRATEGIES
# ==========================================================================

@router.get("/predefined")
async def get_predefined_strategies(
    strategy_type: Optional[str] = Query(None, description="Filter by strategy type"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get predefined strategies"""
    try:
        # Mock predefined strategies
        predefined_strategies = [
            {
                "id": "momentum_001",
                "name": "Momentum Strategy",
                "description": "Buys stocks showing upward momentum with volume confirmation",
                "type": "MOMENTUM",
                "category": "TECHNICAL",
                "difficulty": "INTERMEDIATE",
                "parameters": {
                    "lookback_period": 20,
                    "volume_threshold": 1.5,
                    "rsi_period": 14,
                    "rsi_threshold": 70
                },
                "rules": [
                    {
                        "name": "Entry",
                        "condition": "Price > SMA(20) AND Volume > 1.5 * AVG(20) AND RSI(14) < 70",
                        "action": "BUY"
                    },
                    {
                        "name": "Exit",
                        "condition": "RSI(14) > 70 OR Price < SMA(20) * 0.95",
                        "action": "SELL"
                    }
                ],
                "risk_management": {
                    "stop_loss": 2.0,
                    "take_profit": 5.0,
                    "max_positions": 5
                }
            },
            {
                "id": "mean_reversion_001",
                "name": "Mean Reversion Strategy",
                "description": "Buys oversold stocks and sells overbought stocks",
                "type": "MEAN_REVERSION",
                "category": "TECHNICAL",
                "difficulty": "ADVANCED",
                "parameters": {
                    "bb_period": 20,
                    "bb_std": 2,
                    "rsi_period": 14,
                    "rsi_oversold": 30,
                    "rsi_overbought": 70
                },
                "rules": [
                    {
                        "name": "Buy Signal",
                        "condition": "Price < BB_LOWER AND RSI(14) < 30",
                        "action": "BUY"
                    },
                    {
                        "name": "Sell Signal",
                        "condition": "Price > BB_UPPER OR RSI(14) > 70",
                        "action": "SELL"
                    }
                ],
                "risk_management": {
                    "stop_loss": 3.0,
                    "take_profit": 4.0,
                    "max_positions": 3
                }
            },
            {
                "id": "breakout_001",
                "name": "Breakout Strategy",
                "description": "Trades breakouts from consolidation patterns",
                "type": "BREAKOUT",
                "category": "TECHNICAL",
                "difficulty": "INTERMEDIATE",
                "parameters": {
                    "resistance_period": 50,
                    "volume_confirmation": True,
                    "atr_multiplier": 1.5
                },
                "rules": [
                    {
                        "name": "Breakout Entry",
                        "condition": "Price > Resistance(50) AND Volume > AVG(20) * 1.5",
                        "action": "BUY"
                    },
                    {
                        "name": "Breakdown Exit",
                        "condition": "Price < Support(20) OR ATR(14) * 1.5",
                        "action": "SELL"
                    }
                ],
                "risk_management": {
                    "stop_loss": 2.5,
                    "take_profit": 6.0,
                    "max_positions": 4
                }
            }
        ]
        
        # Filter by type if specified
        if strategy_type:
            predefined_strategies = [
                s for s in predefined_strategies 
                if s["type"].lower() == strategy_type.lower()
            ]
            
        return {
            "status": "success",
            "data": {
                "strategies": predefined_strategies,
                "total": len(predefined_strategies)
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get predefined strategies: {str(e)}"
        )

@router.get("/predefined/{strategy_id}")
async def get_predefined_strategy(
    strategy_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get specific predefined strategy"""
    try:
        # Get predefined strategies and find the requested one
        strategies = await get_predefined_strategies(db, current_user)
        
        for strategy in strategies["data"]["strategies"]:
            if strategy["id"] == strategy_id:
                return {
                    "status": "success",
                    "data": strategy
                }
                
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Predefined strategy not found"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get predefined strategy: {str(e)}"
        )

# ==========================================================================
# USER STRATEGIES
# ==========================================================================

@router.get("/user")
async def get_user_strategies(
    status: Optional[str] = Query(None, description="Filter by strategy status"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get user's strategies"""
    try:
        query = db.query(Strategy).filter(Strategy.user_id == current_user["id"])
        
        if status:
            query = query.filter(Strategy.status == status)
            
        strategies = query.order_by(Strategy.created_at.desc()).all()
        
        strategy_data = []
        for strategy in strategies:
            strategy_dict = {
                "id": strategy.id,
                "name": strategy.name,
                "description": strategy.description,
                "strategy_type": strategy.strategy_type,
                "category": strategy.category,
                "status": strategy.status,
                "is_active": strategy.is_active,
                "parameters": json.loads(strategy.parameters) if strategy.parameters else {},
                "rules": json.loads(strategy.rules) if strategy.rules else [],
                "instruments": json.loads(strategy.instruments) if strategy.instruments else [],
                "risk_management": json.loads(strategy.risk_management) if strategy.risk_management else {},
                "backtest_results": json.loads(strategy.backtest_results) if strategy.backtest_results else None,
                "created_at": strategy.created_at.isoformat(),
                "updated_at": strategy.updated_at.isoformat()
            }
            strategy_data.append(strategy_dict)
            
        return {
            "status": "success",
            "data": {
                "strategies": strategy_data,
                "total": len(strategies)
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get user strategies: {str(e)}"
        )

@router.post("/user")
async def create_strategy(
    strategy_data: StrategyCreate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Create a new strategy"""
    try:
        strategy = Strategy(
            user_id=current_user["id"],
            name=strategy_data.name,
            description=strategy_data.description,
            strategy_type=strategy_data.strategy_type,
            category=strategy_data.category,
            status="DRAFT",
            is_active=False,
            parameters=json.dumps(strategy_data.parameters) if strategy_data.parameters else {},
            rules=json.dumps(strategy_data.rules) if strategy_data.rules else [],
            instruments=json.dumps(strategy_data.instruments) if strategy_data.instruments else [],
            risk_management=json.dumps(strategy_data.risk_management) if strategy_data.risk_management else {},
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        db.add(strategy)
        db.commit()
        
        return {
            "status": "success",
            "data": {
                "id": strategy.id,
                "name": strategy.name,
                "message": "Strategy created successfully"
            }
        }
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create strategy: {str(e)}"
        )

@router.get("/user/{strategy_id}")
async def get_user_strategy(
    strategy_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get specific user strategy"""
    try:
        strategy = db.query(Strategy).filter(
            and_(Strategy.id == strategy_id, Strategy.user_id == current_user["id"])
        ).first()
        
        if not strategy:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Strategy not found"
            )
            
        return {
            "status": "success",
            "data": {
                "id": strategy.id,
                "name": strategy.name,
                "description": strategy.description,
                "strategy_type": strategy.strategy_type,
                "category": strategy.category,
                "status": strategy.status,
                "is_active": strategy.is_active,
                "parameters": json.loads(strategy.parameters) if strategy.parameters else {},
                "rules": json.loads(strategy.rules) if strategy.rules else [],
                "instruments": json.loads(strategy.instruments) if strategy.instruments else [],
                "risk_management": json.loads(strategy.risk_management) if strategy.risk_management else {},
                "backtest_results": json.loads(strategy.backtest_results) if strategy.backtest_results else None,
                "created_at": strategy.created_at.isoformat(),
                "updated_at": strategy.updated_at.isoformat()
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get strategy: {str(e)}"
        )

@router.put("/user/{strategy_id}")
async def update_strategy(
    strategy_id: int,
    strategy_update: StrategyUpdate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Update user strategy"""
    try:
        strategy = db.query(Strategy).filter(
            and_(Strategy.id == strategy_id, Strategy.user_id == current_user["id"])
        ).first()
        
        if not strategy:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Strategy not found"
            )
            
        # Update fields
        if strategy_update.name:
            strategy.name = strategy_update.name
        if strategy_update.description:
            strategy.description = strategy_update.description
        if strategy_update.parameters:
            strategy.parameters = json.dumps(strategy_update.parameters)
        if strategy_update.rules:
            strategy.rules = json.dumps(strategy_update.rules)
        if strategy_update.instruments:
            strategy.instruments = json.dumps(strategy_update.instruments)
        if strategy_update.risk_management:
            strategy.risk_management = json.dumps(strategy_update.risk_management)
            
        strategy.updated_at = datetime.utcnow()
        db.commit()
        
        return {
            "status": "success",
            "message": "Strategy updated successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update strategy: {str(e)}"
        )

@router.delete("/user/{strategy_id}")
async def delete_strategy(
    strategy_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Delete user strategy"""
    try:
        strategy = db.query(Strategy).filter(
            and_(Strategy.id == strategy_id, Strategy.user_id == current_user["id"])
        ).first()
        
        if not strategy:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Strategy not found"
            )
            
        # Check if strategy has active executions
        active_executions = db.query(StrategyExecution).filter(
            and_(
                StrategyExecution.strategy_id == strategy_id,
                StrategyExecution.status.in_(["RUNNING", "PENDING"])
            )
        ).count()
        
        if active_executions > 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot delete strategy with active executions"
            )
            
        db.delete(strategy)
        db.commit()
        
        return {
            "status": "success",
            "message": "Strategy deleted successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete strategy: {str(e)}"
        )

@router.post("/user/{strategy_id}/clone")
async def clone_strategy(
    strategy_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Clone predefined strategy to user's strategies"""
    try:
        # Get predefined strategy
        predefined_strategies = await get_predefined_strategies(db, current_user)
        
        strategy_data = None
        for strategy in predefined_strategies["data"]["strategies"]:
            if strategy["id"] == f"predefined_{strategy_id}":
                strategy_data = strategy
                break
                
        if not strategy_data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Predefined strategy not found"
            )
            
        # Create new strategy from predefined
        new_strategy = Strategy(
            user_id=current_user["id"],
            name=f"{strategy_data['name']} (Clone)",
            description=strategy_data['description'],
            strategy_type=strategy_data['type'],
            category=strategy_data['category'],
            status="DRAFT",
            is_active=False,
            parameters=json.dumps(strategy_data['parameters']),
            rules=json.dumps(strategy_data['rules']),
            instruments=json.dumps(strategy_data.get('instruments', [])),
            risk_management=json.dumps(strategy_data['risk_management']),
            source_strategy_id=strategy_id,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        db.add(new_strategy)
        db.commit()
        
        return {
            "status": "success",
            "data": {
                "strategy_id": new_strategy.id,
                "name": new_strategy.name,
                "message": "Strategy cloned successfully"
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to clone strategy: {str(e)}"
        )

# ==========================================================================
# AI STRATEGY GENERATION
# ==========================================================================

@router.post("/ai/generate")
async def generate_ai_strategy(
    generation_request: AIGenerationRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Generate strategy using AI"""
    try:
        result = await ai_service.generate_strategy(
            db, current_user["id"], generation_request.prompt, generation_request.model
        )
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate AI strategy: {str(e)}"
        )

@router.get("/ai/{user_id}")
async def get_ai_suggestions(
    user_id: int,
    limit: int = Query(10, ge=1, le=50, description="Number of suggestions to return"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get AI-generated trading suggestions"""
    try:
        # Verify user can access this data
        if current_user["id"] != user_id and not current_user.get("is_admin"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied"
            )
            
        # Generate market signals
        signals = await ai_service.generate_market_signals(db, user_id)
        
        # Return limited number of signals
        return {
            "status": "success",
            "data": {
                "suggestions": signals[:limit],
                "total_generated": len(signals)
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get AI suggestions: {str(e)}"
        )

# ==========================================================================
# STRATEGY EXECUTION
# ==========================================================================

@router.post("/execute")
async def execute_strategy(
    execution_request: StrategyExecutionRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Execute a trading strategy"""
    try:
        result = await ai_service.execute_strategy(
            db, execution_request.strategy_id, current_user["id"], execution_request.parameters
        )
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to execute strategy: {str(e)}"
        )

@router.get("/{strategy_id}/performance")
async def get_strategy_performance(
    strategy_id: int,
    period: str = Query("1M", description="Time period for performance", 
                       regex="^(1D|1W|1M|3M|6M|1Y|ALL)$"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get strategy performance metrics"""
    try:
        # Get strategy
        strategy = db.query(Strategy).filter(
            and_(Strategy.id == strategy_id, Strategy.user_id == current_user["id"])
        ).first()
        
        if not strategy:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Strategy not found"
            )
            
        # Get executions for the period
        query = db.query(StrategyExecution).filter(
            StrategyExecution.strategy_id == strategy_id
        )
        
        if period != "ALL":
            # Calculate date range
            end_date = datetime.utcnow()
            if period == "1D":
                start_date = end_date - timedelta(days=1)
            elif period == "1W":
                start_date = end_date - timedelta(weeks=1)
            elif period == "1M":
                start_date = end_date - timedelta(days=30)
            elif period == "3M":
                start_date = end_date - timedelta(days=90)
            elif period == "6M":
                start_date = end_date - timedelta(days=180)
            elif period == "1Y":
                start_date = end_date - timedelta(days=365)
                
            query = query.filter(StrategyExecution.started_at >= start_date)
            
        executions = query.order_by(StrategyExecution.started_at.desc()).all()
        
        # Calculate performance metrics
        total_executions = len(executions)
        successful_executions = len([e for e in executions if e.status == "COMPLETED"])
        failed_executions = len([e for e in executions if e.status == "FAILED"])
        
        # Calculate P&L from execution results
        total_pnl = 0
        total_trades = 0
        
        for execution in executions:
            if execution.results:
                results = json.loads(execution.results)
                total_trades += results.get("trades_executed", 0)
                # This would need to parse actual P&L from trades
                
        return {
            "status": "success",
            "data": {
                "strategy_id": strategy_id,
                "strategy_name": strategy.name,
                "period": period,
                "summary": {
                    "total_executions": total_executions,
                    "successful_executions": successful_executions,
                    "failed_executions": failed_executions,
                    "success_rate": (successful_executions / total_executions * 100) if total_executions > 0 else 0,
                    "total_trades": total_trades,
                    "total_pnl": total_pnl,
                    "average_pnl": total_pnl / total_executions if total_executions > 0 else 0
                },
                "executions": [
                    {
                        "id": e.id,
                        "status": e.status,
                        "started_at": e.started_at.isoformat(),
                        "completed_at": e.completed_at.isoformat() if e.completed_at else None,
                        "parameters": json.loads(e.parameters) if e.parameters else {},
                        "results": json.loads(e.results) if e.results else None
                    }
                    for e in executions
                ]
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get strategy performance: {str(e)}"
        )

# ==========================================================================
# BACKTESTING
# ==========================================================================

@router.post("/{strategy_id}/backtest")
async def backtest_strategy(
    strategy_id: int,
    start_date: str = Query(..., description="Backtest start date (YYYY-MM-DD)"),
    end_date: str = Query(..., description="Backtest end date (YYYY-MM-DD)"),
    initial_capital: float = Query(100000, ge=1000, description="Initial capital for backtest"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Run backtest for a strategy"""
    try:
        # Get strategy
        strategy = db.query(Strategy).filter(
            and_(Strategy.id == strategy_id, Strategy.user_id == current_user["id"])
        ).first()
        
        if not strategy:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Strategy not found"
            )
            
        # Parse dates
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        end_dt = datetime.strptime(end_date, "%Y-%m-%d")
        
        if start_dt >= end_dt:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Start date must be before end date"
            )
            
        # Run backtest (mock implementation)
        # In real implementation, this would:
        # 1. Get historical data for the period
        # 2. Apply strategy rules day by day
        # 3. Track portfolio performance
        # 4. Calculate metrics
        
        # Mock backtest results
        backtest_results = {
            "start_date": start_date,
            "end_date": end_date,
            "initial_capital": initial_capital,
            "final_capital": initial_capital * 1.15,  # 15% return
            "total_return": 15.0,
            "annualized_return": 18.2,
            "total_trades": 45,
            "profitable_trades": 28,
            "losing_trades": 17,
            "win_rate": 62.2,
            "max_drawdown": 8.5,
            "sharpe_ratio": 1.25,
            "sortino_ratio": 1.8,
            "volatility": 12.3,
            "max_consecutive_wins": 5,
            "max_consecutive_losses": 3,
            "average_trade_pnl": 250.5,
            "average_winning_trade": 450.2,
            "average_losing_trade": -180.3,
            "profit_factor": 2.1
        }
        
        # Store backtest results
        strategy.backtest_results = json.dumps(backtest_results)
        strategy.updated_at = datetime.utcnow()
        db.commit()
        
        return {
            "status": "success",
            "data": backtest_results
        }
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid date format: {str(e)}"
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to run backtest: {str(e)}"
        )