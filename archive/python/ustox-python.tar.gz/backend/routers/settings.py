"""
Settings Router - Handles user settings and preferences
"""

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from typing import Dict, Any, Optional
from datetime import datetime
from pydantic import BaseModel
from database.connection import get_db
from middleware.auth import get_current_user
from models.user import UserSettings
from services.subscription_settings_service import subscription_settings_service

router = APIRouter(prefix="/api/v1/settings", tags=["Settings"])
security = HTTPBearer()


# Pydantic model for subscription settings
class SubscriptionSettingsUpdate(BaseModel):
    equity_enabled: Optional[bool] = None
    index_enabled: Optional[bool] = None
    futures_enabled: Optional[bool] = None
    options_enabled: Optional[bool] = None
    mtf_enabled: Optional[bool] = None
    mis_enabled: Optional[bool] = None


@router.get("/general")
async def get_general_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get general settings"""
    try:
        settings = db.query(UserSettings).filter(
            UserSettings.user_id == current_user["id"]
        ).first()
        
        if not settings:
            settings = UserSettings(user_id=current_user["id"])
            db.add(settings)
            db.commit()
            
        return {
            "status": "success",
            "data": {
                "theme": settings.theme,
                "language": settings.language,
                "timezone": settings.timezone,
                "date_format": settings.date_format,
                "time_format": settings.time_format,
                "currency": settings.currency,
                "decimal_places": settings.decimal_places,
                "thousand_separator": settings.thousand_separator,
                "updated_at": settings.updated_at.isoformat()
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get general settings: {str(e)}"
        )

@router.put("/general")
async def update_general_settings(
    settings_data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Update general settings"""
    try:
        settings = db.query(UserSettings).filter(
            UserSettings.user_id == current_user["id"]
        ).first()
        
        if not settings:
            settings = UserSettings(user_id=current_user["id"])
            db.add(settings)
            
        # Update allowed fields
        allowed_fields = [
            "theme", "language", "timezone", "date_format", "time_format",
            "currency", "decimal_places", "thousand_separator"
        ]
        
        for field in allowed_fields:
            if field in settings_data:
                setattr(settings, field, settings_data[field])
                
        settings.updated_at = datetime.utcnow()
        db.commit()
        
        return {
            "status": "success",
            "message": "General settings updated successfully"
        }
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update general settings: {str(e)}"
        )

@router.get("/notifications")
async def get_notification_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get notification settings"""
    try:
        settings = db.query(UserSettings).filter(
            UserSettings.user_id == current_user["id"]
        ).first()
        
        if not settings:
            settings = UserSettings(user_id=current_user["id"])
            db.add(settings)
            db.commit()
            
        return {
            "status": "success",
            "data": {
                "email_notifications": settings.email_notifications,
                "sms_notifications": settings.sms_notifications,
                "push_notifications": settings.push_notifications,
                "trade_alerts": settings.trade_alerts,
                "price_alerts": settings.price_alerts,
                "strategy_alerts": settings.strategy_alerts,
                "market_updates": settings.market_updates,
                "system_updates": settings.system_updates,
                "marketing_communications": settings.marketing_communications,
                "notification_frequency": settings.notification_frequency,
                "quiet_hours_enabled": settings.quiet_hours_enabled,
                "quiet_hours_start": settings.quiet_hours_start,
                "quiet_hours_end": settings.quiet_hours_end
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get notification settings: {str(e)}"
        )

@router.put("/notifications")
async def update_notification_settings(
    settings_data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Update notification settings"""
    try:
        settings = db.query(UserSettings).filter(
            UserSettings.user_id == current_user["id"]
        ).first()
        
        if not settings:
            settings = UserSettings(user_id=current_user["id"])
            db.add(settings)
            
        # Update notification fields
        notification_fields = [
            "email_notifications", "sms_notifications", "push_notifications",
            "trade_alerts", "price_alerts", "strategy_alerts", "market_updates",
            "system_updates", "marketing_communications", "notification_frequency",
            "quiet_hours_enabled", "quiet_hours_start", "quiet_hours_end"
        ]
        
        for field in notification_fields:
            if field in settings_data:
                setattr(settings, field, settings_data[field])
                
        settings.updated_at = datetime.utcnow()
        db.commit()
        
        return {
            "status": "success",
            "message": "Notification settings updated successfully"
        }
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update notification settings: {str(e)}"
        )

@router.get("/derivatives-expiry")
async def get_derivatives_expiry_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get derivatives expiry settings"""
    try:
        settings = db.query(UserSettings).filter(
            UserSettings.user_id == current_user["id"]
        ).first()
        
        if not settings:
            settings = UserSettings(user_id=current_user["id"])
            db.add(settings)
            db.commit()
            
        return {
            "status": "success",
            "data": {
                "auto_square_off_enabled": settings.auto_square_off_enabled,
                "square_off_time": settings.square_off_time,
                "square_off_buffer_minutes": settings.square_off_buffer_minutes,
                "expiry_reminder_days": settings.expiry_reminder_days,
                "expiry_reminder_time": settings.expiry_reminder_time,
                "rollover_enabled": settings.rollover_enabled,
                "rollover_days_before": settings.rollover_days_before,
                "preferred_expiry": settings.preferred_expiry,
                "weekly_expiry_preference": settings.weekly_expiry_preference,
                "monthly_expiry_preference": settings.monthly_expiry_preference
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get derivatives expiry settings: {str(e)}"
        )

@router.put("/derivatives-expiry")
async def update_derivatives_expiry_settings(
    settings_data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Update derivatives expiry settings"""
    try:
        settings = db.query(UserSettings).filter(
            UserSettings.user_id == current_user["id"]
        ).first()
        
        if not settings:
            settings = UserSettings(user_id=current_user["id"])
            db.add(settings)
            
        # Update expiry fields
        expiry_fields = [
            "auto_square_off_enabled", "square_off_time", "square_off_buffer_minutes",
            "expiry_reminder_days", "expiry_reminder_time", "rollover_enabled",
            "rollover_days_before", "preferred_expiry", "weekly_expiry_preference",
            "monthly_expiry_preference"
        ]
        
        for field in expiry_fields:
            if field in settings_data:
                setattr(settings, field, settings_data[field])
                
        settings.updated_at = datetime.utcnow()
        db.commit()
        
        return {
            "status": "success",
            "message": "Derivatives expiry settings updated successfully"
        }
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update derivatives expiry settings: {str(e)}"
        )


# ==========================================================================
# SUBSCRIPTION SETTINGS (WebSocket instrument types)
# ==========================================================================

@router.get("/subscriptions")
async def get_subscription_settings(
    db: Session = Depends(get_db)
):
    """
    Get subscription settings for WebSocket instrument types.
    
    Returns which instrument types are enabled for live data subscription:
    - equity: NSE/BSE equities
    - index: Market indices (Nifty, Bank Nifty, etc.)
    - futures: F&O futures contracts
    - options: Call/Put options
    - mtf: MTF-enabled stocks
    - mis: Intraday-enabled stocks
    """
    try:
        settings = subscription_settings_service.get_settings(db)
        
        return {
            "status": "success",
            "data": settings.to_dict(),
            "enabled_types": subscription_settings_service.get_enabled_types(db)
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get subscription settings: {str(e)}"
        )


@router.put("/subscriptions")
async def update_subscription_settings(
    settings_data: SubscriptionSettingsUpdate,
    db: Session = Depends(get_db)
):
    """
    Update subscription settings for WebSocket instrument types.
    
    Toggle which instrument types to subscribe for live data:
    - equity_enabled: Enable/disable equity subscriptions
    - index_enabled: Enable/disable index subscriptions
    - futures_enabled: Enable/disable futures subscriptions
    - options_enabled: Enable/disable options subscriptions
    - mtf_enabled: Enable/disable MTF stock subscriptions
    - mis_enabled: Enable/disable MIS stock subscriptions
    """
    try:
        settings = subscription_settings_service.update_settings(
            db,
            equity_enabled=settings_data.equity_enabled,
            index_enabled=settings_data.index_enabled,
            futures_enabled=settings_data.futures_enabled,
            options_enabled=settings_data.options_enabled,
            mtf_enabled=settings_data.mtf_enabled,
            mis_enabled=settings_data.mis_enabled
        )
        
        return {
            "status": "success",
            "message": "Subscription settings updated successfully",
            "data": settings.to_dict(),
            "enabled_types": subscription_settings_service.get_enabled_types(db)
        }
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update subscription settings: {str(e)}"
        )


@router.post("/subscriptions/toggle/{instrument_type}")
async def toggle_instrument_type(
    instrument_type: str,
    enabled: bool = True,
    db: Session = Depends(get_db)
):
    """
    Toggle a specific instrument type on/off.
    
    Path: /settings/subscriptions/toggle/{instrument_type}?enabled=true/false
    
    Valid types: equity, index, futures, options, mtf, mis
    """
    valid_types = ['equity', 'index', 'futures', 'options', 'mtf', 'mis']
    
    if instrument_type not in valid_types:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid instrument type. Must be one of: {valid_types}"
        )
    
    try:
        settings = subscription_settings_service.toggle_type(db, instrument_type, enabled)
        
        return {
            "status": "success",
            "message": f"{instrument_type} {'enabled' if enabled else 'disabled'}",
            "data": settings.to_dict(),
            "enabled_types": subscription_settings_service.get_enabled_types(db)
        }
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to toggle {instrument_type}: {str(e)}"
        )