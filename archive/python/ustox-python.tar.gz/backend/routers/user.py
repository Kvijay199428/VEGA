"""
User Router - Handles user profile and account management
"""

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from typing import Dict, Any, Optional
from database.connection import get_db
from middleware.auth import get_current_user
from models.user import User, UserSettings, AuditLog
from models.upstox_token import UpstoxToken, API_CONFIG
from utils.auth import encrypt_token, decrypt_token
from services.upstox_service import upstox_service
import logging

# Configure logger
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/user", tags=["User"])
security = HTTPBearer()

# ==========================================================================
# USER PROFILE
# ==========================================================================

@router.get("/profile")
async def get_user_profile(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get current user's profile information from Upstox API"""
    try:
        # Check if user is authenticated via Upstox token
        upstox_token = current_user.get("upstox_token")
        profile_data = None
        
        # Helper to try fetching profile with a token
        async def try_fetch_profile(token):
            try:
                res = await upstox_service.get_user_profile(token)
                if res.get('status') == 'success':
                    return res.get('data', {})
            except Exception as e:
                logger.warning(f"Profile fetch failed with provided token: {e}")
            return None

        # 1. Try with session token
        if upstox_token:
            profile_data = await try_fetch_profile(upstox_token)
        
        # 2. If failed, try with PRIMARY token from DB
        if not profile_data:
            primary_token_record = db.query(UpstoxToken).filter(
                UpstoxToken.api_name == "PRIMARY",
                UpstoxToken.is_active == True
            ).first()
            
            if primary_token_record:
                logger.info("Falling back to PRIMARY token from DB for profile fetch")
                profile_data = await try_fetch_profile(primary_token_record.access_token)
        
        if profile_data:
            return {
                "status": "success",
                "data": {
                    "id": profile_data.get('user_id'),
                    "user_id": profile_data.get('user_id'),
                    "email": profile_data.get('email'),
                    "name": profile_data.get('user_name'),
                    "user_name": profile_data.get('user_name'),
                    "user_type": profile_data.get('user_type'),
                    "broker": profile_data.get('broker', 'UPSTOX'),
                    "exchanges": profile_data.get('exchanges', []),
                    "products": profile_data.get('products', []),
                    "order_types": profile_data.get('order_types', []),
                    "poa": profile_data.get('poa', False),
                    "ddpi": profile_data.get('ddpi', False),
                    "is_active": profile_data.get('is_active', True),
                    "upstox_linked": True,
                    "from_upstox": True
                }
            }
        
        # Fall back to database user for non-Upstox users or if API fails
        user_id = current_user.get("id")
        user = None
        
        if isinstance(user_id, int) or (isinstance(user_id, str) and user_id.isdigit()):
            user = db.query(User).filter(User.id == int(user_id)).first()
            
        if user:
            return {
                "status": "success",
                "data": {
                    "id": user.id,
                    "email": user.email,
                    "name": user.name,
                    "phone": user.phone,
                    "avatar_url": user.avatar_url,
                    "created_at": user.created_at.isoformat() if user.created_at else None,
                    "updated_at": user.updated_at.isoformat() if user.updated_at else None,
                    "is_active": user.is_active,
                    "is_verified": user.is_verified,
                    "upstox_linked": user.upstox_access_token is not None,
                    "preferences": {
                        "theme": user.theme,
                        "language": user.language,
                        "timezone": user.timezone
                    }
                }
            }
        
        # Return minimal profile for Upstox users if full profile fetch failed
        return {
            "status": "success",
            "data": {
                "id": current_user.get("id", current_user.get("user_id")),
                "email": current_user.get("email", ""),
                "name": current_user.get("user_name", current_user.get("name", "User")),
                "is_active": True,
                "upstox_linked": True,
                "note": "Partial profile data - upstream fetch failed"
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Profile endpoint error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get user profile: {str(e)}"
        )

@router.put("/profile")
async def update_user_profile(
    profile_data: dict,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Update user profile information"""
    try:
        user = db.query(User).filter(User.id == current_user["id"]).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
            
        # Update allowed fields
        allowed_fields = ["name", "phone", "avatar_url", "theme", "language", "timezone"]
        for field in allowed_fields:
            if field in profile_data:
                setattr(user, field, profile_data[field])
                
        user.updated_at = datetime.utcnow()
        db.commit()
        
        # Log the update
        audit_log = AuditLog(
            user_id=user.id,
            action="profile_update",
            details=f"Updated profile fields: {list(profile_data.keys())}",
            ip_address="",
            user_agent=""
        )
        db.add(audit_log)
        db.commit()
        
        return {
            "status": "success",
            "message": "Profile updated successfully",
            "data": {
                "id": user.id,
                "name": user.name,
                "email": user.email,
                "updated_at": user.updated_at.isoformat()
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update profile: {str(e)}"
        )

# ==========================================================================
# ACCOUNT INFORMATION
# ==========================================================================

@router.get("/account-info")
async def get_account_info(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get account information including funds and positions"""
    try:
        user_id = current_user.get("id")
        user = None
        
        # Try to find DB user if ID is integer
        if isinstance(user_id, int) or (isinstance(user_id, str) and user_id.isdigit()):
            user = db.query(User).filter(User.id == int(user_id)).first()
            
        account_info = {
            "account_status": "active",
            "account_type": "individual",
            "is_verified": True,
            "kyc_status": "verified",
            "upstox_linked": False
        }
        
        if user:
            account_info.update({
                "account_status": user.account_status,
                "account_type": user.account_type,
                "is_verified": user.is_verified,
                "kyc_status": user.kyc_status,
                "upstox_linked": user.upstox_access_token is not None
            })
        
        # Determine Upstox token
        # 1. Try from session
        upstox_token = current_user.get("upstox_token")
        
        # 2. Try from user record
        if not upstox_token and user and user.upstox_access_token:
            try:
                upstox_token = decrypt_token(user.upstox_access_token)
            except Exception:
                pass
        
        # 3. Try PRIMARY token from DB (final fallback)
        if not upstox_token:
             primary_token_record = db.query(UpstoxToken).filter(
                UpstoxToken.api_name == "PRIMARY",
                UpstoxToken.is_active == True
            ).first()
             if primary_token_record:
                 upstox_token = primary_token_record.access_token

        if upstox_token:
            account_info["upstox_linked"] = True
            try:
                funds_data = await upstox_service.get_funds(upstox_token)
                
                if funds_data.get('status') == 'success':
                    data = funds_data.get('data', {})
                    # Handle both structure formats (some APIs return data directly, some nested)
                    equity = data.get('equity', {})
                    commodity = data.get('commodity', {})
                    
                    # Calculate total balance if not present
                    total_balance = data.get('total_balance')
                    if total_balance is None:
                        # Sum available margins if total not explicitly provided
                        eq_avail = float(equity.get('available_margin', 0))
                        com_avail = float(commodity.get('available_margin', 0))
                        total_balance = eq_avail + com_avail
                        
                    account_info.update({
                        "equity": equity,
                        "commodity": commodity,
                        "total_balance": total_balance
                    })
                else:
                    logger.warning(f"Funds fetch returned non-success: {funds_data}")
            except Exception as e:
                logger.warning(f"Failed to get Upstox account info: {e}")
                
        return {
            "status": "success",
            "data": account_info
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get account info: {str(e)}"
        )

# ==========================================================================
# ACCOUNT SETTINGS
# ==========================================================================

@router.get("/account-settings")
async def get_account_settings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get user's account settings"""
    try:
        settings = db.query(UserSettings).filter(
            UserSettings.user_id == current_user["id"]
        ).first()
        
        if not settings:
            # Return default settings
            settings = UserSettings(user_id=current_user["id"])
            db.add(settings)
            db.commit()
            
        return {
            "status": "success",
            "data": {
                "notifications": {
                    "email": settings.email_notifications,
                    "sms": settings.sms_notifications,
                    "push": settings.push_notifications,
                    "trade_alerts": settings.trade_alerts,
                    "price_alerts": settings.price_alerts,
                    "strategy_alerts": settings.strategy_alerts
                },
                "trading": {
                    "default_product": settings.default_product,
                    "default_validity": settings.default_validity,
                    "auto_square_off": settings.auto_square_off,
                    "risk_management": settings.risk_management,
                    "max_loss_percent": settings.max_loss_percent
                },
                "privacy": {
                    "share_data": settings.share_data,
                    "analytics_tracking": settings.analytics_tracking,
                    "marketing_communications": settings.marketing_communications
                },
                "preferences": {
                    "theme": settings.theme,
                    "language": settings.language,
                    "timezone": settings.timezone,
                    "date_format": settings.date_format,
                    "time_format": settings.time_format
                }
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get account settings: {str(e)}"
        )

@router.put("/account-settings")
async def update_account_settings(
    settings_data: dict,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Update user's account settings"""
    try:
        settings = db.query(UserSettings).filter(
            UserSettings.user_id == current_user["id"]
        ).first()
        
        if not settings:
            settings = UserSettings(user_id=current_user["id"])
            db.add(settings)
            
        # Update settings based on category
        if "notifications" in settings_data:
            notif = settings_data["notifications"]
            settings.email_notifications = notif.get("email", settings.email_notifications)
            settings.sms_notifications = notif.get("sms", settings.sms_notifications)
            settings.push_notifications = notif.get("push", settings.push_notifications)
            settings.trade_alerts = notif.get("trade_alerts", settings.trade_alerts)
            settings.price_alerts = notif.get("price_alerts", settings.price_alerts)
            settings.strategy_alerts = notif.get("strategy_alerts", settings.strategy_alerts)
            
        if "trading" in settings_data:
            trading = settings_data["trading"]
            settings.default_product = trading.get("default_product", settings.default_product)
            settings.default_validity = trading.get("default_validity", settings.default_validity)
            settings.auto_square_off = trading.get("auto_square_off", settings.auto_square_off)
            settings.risk_management = trading.get("risk_management", settings.risk_management)
            settings.max_loss_percent = trading.get("max_loss_percent", settings.max_loss_percent)
            
        if "privacy" in settings_data:
            privacy = settings_data["privacy"]
            settings.share_data = privacy.get("share_data", settings.share_data)
            settings.analytics_tracking = privacy.get("analytics_tracking", settings.analytics_tracking)
            settings.marketing_communications = privacy.get("marketing_communications", settings.marketing_communications)
            
        if "preferences" in settings_data:
            prefs = settings_data["preferences"]
            settings.theme = prefs.get("theme", settings.theme)
            settings.language = prefs.get("language", settings.language)
            settings.timezone = prefs.get("timezone", settings.timezone)
            settings.date_format = prefs.get("date_format", settings.date_format)
            settings.time_format = prefs.get("time_format", settings.time_format)
            
        db.commit()
        
        return {
            "status": "success",
            "message": "Account settings updated successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update account settings: {str(e)}"
        )

# ==========================================================================
# RISK PREFERENCES
# ==========================================================================

@router.get("/risk-preferences")
async def get_risk_preferences(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get user's risk preferences"""
    try:
        user = db.query(User).filter(User.id == current_user["id"]).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
            
        return {
            "status": "success",
            "data": {
                "max_loss_percent": user.max_loss_percent,
                "max_position_size": user.max_position_size,
                "max_daily_loss": user.max_daily_loss,
                "max_monthly_loss": user.max_monthly_loss,
                "risk_tolerance": user.risk_tolerance,
                "position_sizing_method": user.position_sizing_method,
                "stop_loss_enabled": user.stop_loss_enabled,
                "stop_loss_percent": user.stop_loss_percent,
                "trailing_stop_enabled": user.trailing_stop_enabled,
                "trailing_stop_percent": user.trailing_stop_percent,
                "max_positions": user.max_positions,
                "max_orders_per_day": user.max_orders_per_day,
                "auto_square_off_time": user.auto_square_off_time
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get risk preferences: {str(e)}"
        )

@router.put("/risk-preferences")
async def update_risk_preferences(
    risk_data: dict,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Update user's risk preferences"""
    try:
        user = db.query(User).filter(User.id == current_user["id"]).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
            
        # Update risk preferences
        allowed_fields = [
            "max_loss_percent", "max_position_size", "max_daily_loss",
            "max_monthly_loss", "risk_tolerance", "position_sizing_method",
            "stop_loss_enabled", "stop_loss_percent", "trailing_stop_enabled",
            "trailing_stop_percent", "max_positions", "max_orders_per_day",
            "auto_square_off_time"
        ]
        
        for field in allowed_fields:
            if field in risk_data:
                setattr(user, field, risk_data[field])
                
        user.updated_at = datetime.utcnow()
        db.commit()
        
        return {
            "status": "success",
            "message": "Risk preferences updated successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update risk preferences: {str(e)}"
        )

# ==========================================================================
# AI PREFERENCES
# ==========================================================================

@router.get("/ai-preferences")
async def get_ai_preferences(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get user's AI trading preferences"""
    try:
        user = db.query(User).filter(User.id == current_user["id"]).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
            
        return {
            "status": "success",
            "data": {
                "ai_trading_enabled": user.ai_trading_enabled,
                "auto_execute_strategies": user.auto_execute_strategies,
                "ai_risk_level": user.ai_risk_level,
                "max_ai_positions": user.max_ai_positions,
                "ai_position_size": user.ai_position_size,
                "ai_stop_loss": user.ai_stop_loss,
                "ai_take_profit": user.ai_take_profit,
                "ai_notification_frequency": user.ai_notification_frequency,
                "ai_preferred_strategies": user.ai_preferred_strategies,
                "ai_excluded_instruments": user.ai_excluded_instruments,
                "ai_learning_mode": user.ai_learning_mode,
                "ai_feedback_enabled": user.ai_feedback_enabled
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get AI preferences: {str(e)}"
        )

@router.put("/ai-preferences")
async def update_ai_preferences(
    ai_data: dict,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Update user's AI trading preferences"""
    try:
        user = db.query(User).filter(User.id == current_user["id"]).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
            
        # Update AI preferences
        allowed_fields = [
            "ai_trading_enabled", "auto_execute_strategies", "ai_risk_level",
            "max_ai_positions", "ai_position_size", "ai_stop_loss",
            "ai_take_profit", "ai_notification_frequency", "ai_preferred_strategies",
            "ai_excluded_instruments", "ai_learning_mode", "ai_feedback_enabled"
        ]
        
        for field in allowed_fields:
            if field in ai_data:
                setattr(user, field, ai_data[field])
                
        user.updated_at = datetime.utcnow()
        db.commit()
        
        return {
            "status": "success",
            "message": "AI preferences updated successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update AI preferences: {str(e)}"
        )

# ==========================================================================
# UPSTOX ACCOUNT LINKING
# ==========================================================================

@router.post("/link-upstox")
async def link_upstox_account(
    auth_code: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Link Upstox account using authorization code"""
    try:
        user = db.query(User).filter(User.id == current_user["id"]).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
            
        # Exchange authorization code for access token
        token_data = await upstox_service.exchange_code_for_token(auth_code, db)
        
        # Store encrypted tokens
        user.upstox_access_token = encrypt_token(token_data['access_token'])
        user.upstox_refresh_token = encrypt_token(token_data['refresh_token'])
        user.upstox_token_expires_at = token_data['expires_at']
        user.upstox_linked_at = datetime.utcnow()
        
        # Get user profile from Upstox
        profile_data = await upstox_service.get_user_profile(token_data['access_token'])
        if profile_data.get('status') == 'success':
            profile = profile_data['data']
            user.upstox_user_id = profile.get('user_id')
            user.upstox_user_name = profile.get('user_name')
            user.upstox_user_shortname = profile.get('user_shortname')
            user.upstox_email = profile.get('email')
            user.upstox_user_type = profile.get('user_type')
            
        db.commit()
        
        return {
            "status": "success",
            "message": "Upstox account linked successfully",
            "data": {
                "upstox_user_id": user.upstox_user_id,
                "upstox_user_name": user.upstox_user_name
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to link Upstox account: {str(e)}"
        )

@router.post("/refresh-upstox-token")
async def refresh_upstox_token(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Refresh Upstox access token"""
    try:
        user = db.query(User).filter(User.id == current_user["id"]).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
            
        if not user.upstox_refresh_token:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Upstox account not linked"
            )
            
        # Refresh token
        refresh_token = decrypt_token(user.upstox_refresh_token)
        token_data = await upstox_service.refresh_access_token(refresh_token, db)
        
        # Update tokens
        user.upstox_access_token = encrypt_token(token_data['access_token'])
        if token_data.get('refresh_token'):
            user.upstox_refresh_token = encrypt_token(token_data['refresh_token'])
        user.upstox_token_expires_at = token_data['expires_at']
        
        db.commit()
        
        return {
            "status": "success",
            "message": "Token refreshed successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to refresh token: {str(e)}"
        )