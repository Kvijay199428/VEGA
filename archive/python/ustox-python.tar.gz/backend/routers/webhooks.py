"""
Webhooks Router - Handles webhooks and notifications
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query, Request
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from typing import Dict, Any, List, Optional
from database.connection import get_db
from middleware.auth import get_current_user

router = APIRouter(prefix="/api/v1/webhooks", tags=["Webhooks"])
security = HTTPBearer()

@router.get("")
async def get_webhooks(
    status: Optional[str] = Query(None, description="Filter by webhook status"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get user's webhooks"""
    try:
        # Mock webhooks
        webhooks = [
            {
                "id": 1,
                "name": "Trade Notifications",
                "url": "https://example.com/webhooks/trades",
                "event_types": ["ORDER_PLACED", "ORDER_EXECUTED", "ORDER_CANCELLED"],
                "status": "ACTIVE",
                "created_at": "2024-06-13T10:30:00Z",
                "last_triggered": "2024-06-13T15:45:00Z"
            },
            {
                "id": 2,
                "name": "Strategy Alerts",
                "url": "https://example.com/webhooks/strategies",
                "event_types": ["STRATEGY_SIGNAL", "STRATEGY_EXECUTION"],
                "status": "ACTIVE",
                "created_at": "2024-06-13T11:15:00Z",
                "last_triggered": None
            }
        ]
        
        if status:
            webhooks = [w for w in webhooks if w["status"] == status]
            
        return {
            "status": "success",
            "data": {
                "webhooks": webhooks,
                "total": len(webhooks)
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get webhooks: {str(e)}"
        )

@router.post("")
async def create_webhook(
    webhook_data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Create webhook"""
    try:
        # Validate input
        required_fields = ["name", "url", "event_types"]
        for field in required_fields:
            if field not in webhook_data:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"{field} is required"
                )
                
        # Mock creation
        webhook = {
            "id": 3,
            "name": webhook_data["name"],
            "url": webhook_data["url"],
            "event_types": webhook_data["event_types"],
            "secret": "webhook_secret_12345",
            "status": "ACTIVE",
            "created_at": datetime.utcnow().isoformat(),
            "headers": webhook_data.get("headers", {}),
            "retry_config": webhook_data.get("retry_config", {"max_retries": 3, "retry_delay": 60})
        }
        
        return {
            "status": "success",
            "data": webhook
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create webhook: {str(e)}"
        )

@router.put("/{webhook_id}")
async def update_webhook(
    webhook_id: int,
    webhook_data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Update webhook"""
    try:
        return {
            "status": "success",
            "message": "Webhook updated successfully"
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update webhook: {str(e)}"
        )

@router.delete("/{webhook_id}")
async def delete_webhook(
    webhook_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Delete webhook"""
    try:
        return {
            "status": "success",
            "message": "Webhook deleted successfully"
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete webhook: {str(e)}"
        )

@router.post("/{webhook_id}/test")
async def test_webhook(
    webhook_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Test webhook"""
    try:
        # Mock test result
        return {
            "status": "success",
            "data": {
                "test_id": "test_12345",
                "status": "DELIVERED",
                "response_code": 200,
                "response_time": 150,  # milliseconds
                "timestamp": datetime.utcnow().isoformat()
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to test webhook: {str(e)}"
        )

@router.post("/{webhook_id}/trigger")
async def trigger_webhook(
    webhook_id: int,
    event_data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Manually trigger webhook"""
    try:
        # Mock webhook trigger
        return {
            "status": "success",
            "data": {
                "event_id": "evt_67890",
                "webhook_id": webhook_id,
                "status": "DELIVERED",
                "response_code": 200,
                "timestamp": datetime.utcnow().isoformat()
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to trigger webhook: {str(e)}"
        )

@router.get("/notifications")
async def get_notifications(
    limit: int = Query(50, ge=1, le=100),
    unread_only: bool = Query(False, description="Show only unread notifications"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get notifications"""
    try:
        # Mock notifications
        notifications = [
            {
                "id": 1,
                "type": "ORDER_EXECUTED",
                "title": "Order Executed",
                "message": "Your BUY order for RELIANCE has been executed",
                "data": {
                    "order_id": "ORD2406128020001",
                    "tradingsymbol": "RELIANCE",
                    "quantity": 10,
                    "price": 2500.50
                },
                "is_read": False,
                "created_at": "2024-06-13T15:30:00Z"
            },
            {
                "id": 2,
                "type": "STRATEGY_SIGNAL",
                "title": "New Strategy Signal",
                "message": "Momentum strategy generated a BUY signal for TCS",
                "data": {
                    "strategy_id": 1,
                    "tradingsymbol": "TCS",
                    "signal": "BUY",
                    "confidence": 0.85
                },
                "is_read": True,
                "created_at": "2024-06-13T14:20:00Z"
            },
            {
                "id": 3,
                "type": "PRICE_ALERT",
                "title": "Price Alert Triggered",
                "message": "RELIANCE has reached your target price of 2550",
                "data": {
                    "tradingsymbol": "RELIANCE",
                    "target_price": 2550.00,
                    "current_price": 2555.20
                },
                "is_read": False,
                "created_at": "2024-06-13T13:45:00Z"
            }
        ]
        
        if unread_only:
            notifications = [n for n in notifications if not n["is_read"]]
            
        return {
            "status": "success",
            "data": {
                "notifications": notifications[:limit],
                "total": len(notifications),
                "unread_count": len([n for n in notifications if not n["is_read"]])
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get notifications: {str(e)}"
        )

@router.post("/notifications/{notification_id}/read")
async def mark_notification_read(
    notification_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Mark notification as read"""
    try:
        return {
            "status": "success",
            "message": "Notification marked as read"
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to mark notification as read: {str(e)}"
        )