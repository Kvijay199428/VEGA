"""
Options Router - Option chain, expiry dates, and underlyings API
Proxies to Upstox Option Chain API
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from typing import Optional, List
from datetime import datetime, date
import logging
import requests

from database.connection import get_db
from middleware.auth import get_current_user
from services.upstox_service import upstox_service
from services.valuation_calculator import calculate_option_chain_valuations
from models.instrument_models import OptionsInstrument, IndexInstrument, EquityInstrument

router = APIRouter(prefix="/api/v1/options", tags=["Options"])
security = HTTPBearer()
logger = logging.getLogger(__name__)


@router.get("/underlyings")
async def get_option_underlyings(
    segment: str = Query("index", description="Segment: index or equity"),
    exchange: str = Query("NSE", description="Exchange: NSE or BSE"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Get list of underlyings that have options contracts.
    
    For index options: Fetches from index_instruments that have matching
    underlying_key in options_instruments table.
    
    - segment: 'index' for index options, 'equity' for stock options
    - exchange: NSE or BSE
    """
    try:
        if segment == "index":
            # Get unique underlying_keys from options_instruments that match index patterns
            # Then join with index_instruments to get the index name
            from sqlalchemy import distinct
            
            # Get all unique underlying_keys from options where underlying is an index
            underlying_keys = db.query(distinct(OptionsInstrument.underlying_key)).filter(
                OptionsInstrument.underlying_key.ilike(f"{exchange.upper()}_INDEX%")
            ).all()
            
            underlying_key_list = [k[0] for k in underlying_keys if k[0]]
            
            # Get matching index instruments
            indices = db.query(IndexInstrument).filter(
                IndexInstrument.instrument_key.in_(underlying_key_list),
                IndexInstrument.exchange == exchange.upper()
            ).all()
            
            underlyings = [
                {
                    "instrument_key": idx.instrument_key,
                    "name": idx.name,
                    "trading_symbol": idx.trading_symbol,
                    "exchange": idx.exchange
                }
                for idx in indices
            ]
            
            return {
                "status": "success",
                "data": underlyings,
                "count": len(underlyings)
            }
        else:
            # Get equity symbols with options (from options_instruments table)
            query = db.query(OptionsInstrument.underlying_symbol, OptionsInstrument.underlying_key).filter(
                OptionsInstrument.exchange == exchange.upper(),
                ~OptionsInstrument.underlying_key.ilike("%_INDEX%")  # Exclude indices
            ).distinct()
            
            results = query.limit(100).all()
            
            underlyings = [
                {
                    "instrument_key": r.underlying_key,
                    "name": r.underlying_symbol,
                    "exchange": exchange.upper()
                }
                for r in results if r.underlying_symbol
            ]
            
            return {
                "status": "success",
                "data": underlyings,
                "count": len(underlyings)
            }
            
    except Exception as e:
        logger.error(f"Error fetching underlyings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/expiries/{instrument_key:path}")
async def get_expiry_dates(
    instrument_key: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Get available expiry dates for an underlying instrument.
    
    Returns list of expiry dates in YYYY-MM-DD format.
    """
    try:
        # Get unique expiry dates from options_instruments table
        query = db.query(OptionsInstrument.expiry).filter(
            OptionsInstrument.underlying_key == instrument_key,
            OptionsInstrument.expiry >= date.today()
        ).distinct().order_by(OptionsInstrument.expiry)
        
        results = query.all()
        
        expiries = [r.expiry.strftime("%Y-%m-%d") for r in results if r.expiry]
        
        return {
            "status": "success",
            "data": expiries,
            "count": len(expiries),
            "underlying": instrument_key
        }
        
    except Exception as e:
        logger.error(f"Error fetching expiries: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/chain")
async def get_option_chain(
    instrument_key: str = Query(..., description="Underlying instrument key"),
    expiry_date: str = Query(..., description="Expiry date in YYYY-MM-DD format"),
    force_refresh: bool = Query(False, description="Force refresh from API (bypass cache)"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Get option chain for an underlying symbol and expiry date.
    
    Proxies to Upstox Option Chain API and returns call/put options with Greeks.
    Uses cached data when available for instant response.
    """
    try:
        # Check cache first (unless force refresh is requested)
        if not force_refresh:
            from optionchain_ws import oc_cache
            cached = oc_cache.get(instrument_key, expiry_date)
            
            if cached:
                logger.info(f"Cache hit for option chain: {instrument_key} | {expiry_date}")
                return {
                    "status": "success",
                    "data": cached.get("data", []),
                    "underlying": instrument_key,
                    "expiry": expiry_date,
                    "count": cached.get("count", 0),
                    "cached": True,
                    "updated_at": cached.get("updated_at")
                }
        
        # Fetch OPTIONCHAIN1 token from database (api_index=4)
        from models.upstox_token import UpstoxToken
        
        optionchain_token = db.query(UpstoxToken).filter(
            UpstoxToken.api_index == 4,  # OPTIONCHAIN1
            UpstoxToken.is_active == True
        ).first()
        
        if optionchain_token:
            access_token = optionchain_token.access_token
            logger.info(f"Using OPTIONCHAIN1 token from database (api_name: {optionchain_token.api_name})")
        else:
            # Fallback to PRIMARY token from current_user
            access_token = current_user.get("upstox_token")
            logger.info("OPTIONCHAIN1 not found, falling back to PRIMARY token")
        
        logger.info(f"Option chain request - instrument: {instrument_key}, expiry: {expiry_date}")
        logger.info(f"Access token available: {bool(access_token)}")
        
        if not access_token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Upstox not authenticated. Please login to Upstox first."
            )
        
        # Call Upstox Option Chain API
        # URL encode the instrument_key properly (NSE_INDEX|Nifty 50 -> NSE_INDEX%7CNifty%2050)
        from urllib.parse import quote
        
        url = "https://api.upstox.com/v2/option/chain"
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {access_token}"
        }
        params = {
            "instrument_key": instrument_key,
            "expiry_date": expiry_date
        }
        
        logger.info(f"Calling Upstox API: {url} with params: {params}")
        
        response = requests.get(url, headers=headers, params=params, timeout=30)
        
        logger.info(f"Upstox response status: {response.status_code}")
        
        if response.status_code != 200:
            logger.error(f"Upstox option chain error ({response.status_code}): {response.text}")
            raise HTTPException(
                status_code=response.status_code,
                detail=f"Upstox API error: {response.text}"
            )
        
        data = response.json()
        
        if data.get("status") != "success":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=data.get("message", "Failed to fetch option chain")
            )
        
        # Transform the data to include all option greeks and market data fields
        raw_data = data.get("data", [])
        transformed_data = []
        
        for item in raw_data:
            chain_item = {
                "strike_price": item.get("strike_price"),
                "expiry": item.get("expiry"),
                "pcr": item.get("pcr"),
                "underlying_key": item.get("underlying_key"),
                "underlying_spot_price": item.get("underlying_spot_price"),
            }
            
            # Process Call Options
            call_options = item.get("call_options", {})
            call_market_data = call_options.get("market_data", {})
            call_greeks = call_options.get("option_greeks", {})
            
            chain_item["call"] = {
                "instrument_key": call_options.get("instrument_key"),
                # Market Data
                "ltp": call_market_data.get("ltp"),
                "close_price": call_market_data.get("close_price"),
                "volume": call_market_data.get("volume"),
                "oi": call_market_data.get("oi"),
                "bid_price": call_market_data.get("bid_price"),
                "bid_qty": call_market_data.get("bid_qty"),
                "ask_price": call_market_data.get("ask_price"),
                "ask_qty": call_market_data.get("ask_qty"),
                "prev_oi": call_market_data.get("prev_oi"),
                # Option Greeks
                "vega": call_greeks.get("vega"),
                "theta": call_greeks.get("theta"),
                "gamma": call_greeks.get("gamma"),
                "delta": call_greeks.get("delta"),
                "iv": call_greeks.get("iv"),
                "pop": call_greeks.get("pop"),
            }
            
            # Process Put Options
            put_options = item.get("put_options", {})
            put_market_data = put_options.get("market_data", {})
            put_greeks = put_options.get("option_greeks", {})
            
            chain_item["put"] = {
                "instrument_key": put_options.get("instrument_key"),
                # Market Data
                "ltp": put_market_data.get("ltp"),
                "close_price": put_market_data.get("close_price"),
                "volume": put_market_data.get("volume"),
                "oi": put_market_data.get("oi"),
                "bid_price": put_market_data.get("bid_price"),
                "bid_qty": put_market_data.get("bid_qty"),
                "ask_price": put_market_data.get("ask_price"),
                "ask_qty": put_market_data.get("ask_qty"),
                "prev_oi": put_market_data.get("prev_oi"),
                # Option Greeks
                "vega": put_greeks.get("vega"),
                "theta": put_greeks.get("theta"),
                "gamma": put_greeks.get("gamma"),
                "delta": put_greeks.get("delta"),
                "iv": put_greeks.get("iv"),
                "pop": put_greeks.get("pop"),
            }
            
            transformed_data.append(chain_item)
        
        # Enrich with valuation data using Black-Scholes pricing
        try:
            logger.info(f"Calculating valuations for {len(transformed_data)} strikes")
            transformed_data = calculate_option_chain_valuations(transformed_data)
        except Exception as valuation_error:
            # Log error but don't fail the entire request if valuation calculation fails
            logger.error(f"Valuation calculation failed: {valuation_error}", exc_info=True)
        
        return {
            "status": "success",
            "data": transformed_data,
            "underlying": instrument_key,
            "expiry": expiry_date,
            "count": len(transformed_data)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching option chain: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/contracts")
async def get_option_contracts(
    underlying_key: str = Query(None, description="Filter by underlying"),
    expiry: str = Query(None, description="Filter by expiry YYYY-MM-DD"),
    option_type: str = Query(None, description="CE or PE"),
    exchange: str = Query("NSE", description="Exchange: NSE or BSE"),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Get option contracts from database with filters.
    """
    try:
        query = db.query(OptionsInstrument).filter(
            OptionsInstrument.exchange == exchange.upper()
        )
        
        if underlying_key:
            query = query.filter(OptionsInstrument.underlying_key == underlying_key)
        
        if expiry:
            expiry_date = datetime.strptime(expiry, "%Y-%m-%d").date()
            query = query.filter(OptionsInstrument.expiry == expiry_date)
        
        if option_type:
            query = query.filter(OptionsInstrument.option_type == option_type.upper())
        
        total = query.count()
        contracts = query.offset(offset).limit(limit).all()
        
        return {
            "status": "success",
            "total": total,
            "count": len(contracts),
            "data": [
                {
                    "instrument_key": c.instrument_key,
                    "trading_symbol": c.trading_symbol,
                    "name": c.name,
                    "option_type": c.option_type,
                    "strike_price": c.strike_price,
                    "expiry": c.expiry.strftime("%Y-%m-%d") if c.expiry else None,
                    "underlying_symbol": c.underlying_symbol,
                    "lot_size": c.lot_size,
                    "exchange": c.exchange
                }
                for c in contracts
            ]
        }
        
    except Exception as e:
        logger.error(f"Error fetching option contracts: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/background-status")
async def get_background_service_status(
    current_user: dict = Depends(get_current_user)
):
    """
    Get the status of the option chain background service.
    
    Returns information about the cache and service health.
    """
    try:
        from optionchain_ws import option_chain_service, oc_cache
        
        service_status = option_chain_service.get_status()
        cache_stats = oc_cache.stats()
        
        return {
            "status": "success",
            "data": {
                "service": {
                    "is_running": service_status.get("is_running", False),
                    "fetch_interval_seconds": service_status.get("fetch_interval", 3),
                    "total_instruments": service_status.get("total_instruments", 0),
                    "current_index": service_status.get("current_index", 0)
                },
                "cache": {
                    "total_entries": cache_stats.get("total_entries", 0),
                    "unique_instruments": cache_stats.get("unique_instruments", 0),
                    "instruments": cache_stats.get("instruments", []),
                    "memory_estimate_mb": cache_stats.get("memory_estimate_mb", 0)
                }
            }
        }
        
    except Exception as e:
        logger.error(f"Error getting background service status: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

