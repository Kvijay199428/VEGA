"""
Instruments Router - API endpoints for instrument management
"""

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
import logging

from database.connection import get_db
from middleware.auth import get_current_user
from services.instrument_service import instrument_sync_service
from services.instrument_search import instrument_search_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/instruments", tags=["Instruments"])


# ==========================================================================
# SEARCH & FILTER ENDPOINTS
# ==========================================================================

@router.get("")
async def get_instruments(
    segment: Optional[str] = Query(None, description="Filter by segment (NSE_EQ, NSE_FO, etc.)"),
    instrument_type: Optional[str] = Query(None, description="Filter by type (EQ, FUT, CE, PE, INDEX)"),
    symbol: Optional[str] = Query(None, description="Search by trading symbol"),
    exchange: Optional[str] = Query(None, description="Filter by exchange (NSE, BSE, MCX)"),
    limit: int = Query(100, ge=1, le=1000, description="Max results"),
    offset: int = Query(0, ge=0, description="Pagination offset"),
    db: Session = Depends(get_db)
):
    """
    Get all instruments with optional filters.
    
    **Examples:**
    - `/instruments?segment=NSE_EQ&instrument_type=EQ` - All NSE equities
    - `/instruments?symbol=INFY` - Search for INFY
    - `/instruments?segment=NSE_FO&instrument_type=FUT` - All futures
    """
    try:
        result = instrument_search_service.search_instruments(
            db,
            segment=segment,
            instrument_type=instrument_type,
            trading_symbol=symbol,
            exchange=exchange,
            limit=limit,
            offset=offset
        )
        
        return {
            "status": "success",
            "total": result['total'],
            "count": result['count'],
            "instruments": result['instruments']
        }
    except Exception as e:
        logger.error(f"Error fetching instruments: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/search")
async def search_instruments(
    q: str = Query(..., min_length=1, description="Search query"),
    segment: Optional[str] = Query(None),
    instrument_type: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db)
):
    """
    Search instruments by symbol or name.
    
    **Examples:**
    - `/instruments/search?q=INFY` - Search for INFY
    - `/instruments/search?q=NIFTY&instrument_type=INDEX` - Search indices
    """
    try:
        result = instrument_search_service.search_instruments(
            db,
            segment=segment,
            instrument_type=instrument_type,
            trading_symbol=q,
            limit=limit
        )
        
        return {
            "status": "success",
            "query": q,
            "total": result['total'],
            "instruments": result['instruments']
        }
    except Exception as e:
        logger.error(f"Error searching instruments: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


# ==========================================================================
# TYPE-SPECIFIC ENDPOINTS
# ==========================================================================

@router.get("/equity")
async def get_equity_instruments(
    symbol: Optional[str] = Query(None, description="Filter by symbol"),
    q: Optional[str] = Query(None, description="General search (symbol, name, sector)"),
    exchange: Optional[str] = Query(None, description="Filter by exchange (NSE, BSE)"),
    limit: int = Query(50, ge=1, le=5000),
    offset: int = Query(0, ge=0, description="Pagination offset"),
    db: Session = Depends(get_db)
):
    """
    Get all equity instruments from database with pagination.
    Supports smart search by symbol, name, or sector.
    """
    try:
        from helpers.instruments.equity import EquityHelper
        from models.instrument_models import EquityInstrument
        
        # Determine search query
        search_query = q or symbol

        # Use EquityHelper to get instruments and total filtered count
        instruments, total_count = EquityHelper.get_instruments_paginated(
            db, exchange=exchange, limit=limit, offset=offset, search_query=search_query
        )
        
        # Log for debugging
        logger.info(f"Equity endpoint returning {len(instruments)} instruments (total {total_count}) for q={search_query}, exchange={exchange}")
        
        # Log for debugging
        logger.info(f"Equity endpoint returning {len(instruments)} instruments for exchange={exchange}, offset={offset}")
        
        return {
            "status": "success",
            "total": total_count,
            "count": len(instruments),
            "instruments": instruments,
            "message": "Please sync instruments first." if not instruments and total_count == 0 else None
        }
    except Exception as e:
        logger.error(f"Error fetching equities: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )



@router.get("/futures")
async def get_futures(
    underlying: Optional[str] = Query(None, description="Filter by underlying symbol"),
    limit: int = Query(1000, ge=1, le=5000),
    db: Session = Depends(get_db)
):
    """Get all futures instruments"""
    try:
        instruments = instrument_search_service.get_futures(db, underlying=underlying, limit=limit)
        
        return {
            "status": "success",
            "count": len(instruments),
            "instruments": instruments
        }
    except Exception as e:
        logger.error(f"Error fetching futures: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/options")
async def get_options(
    underlying: Optional[str] = Query(None, description="Filter by underlying"),
    option_type: Optional[str] = Query(None, description="CE or PE"),
    limit: int = Query(1000, ge=1, le=5000),
    db: Session = Depends(get_db)
):
    """Get options instruments"""
    try:
        instruments = instrument_search_service.get_options(
            db, 
            underlying=underlying, 
            option_type=option_type,
            limit=limit
        )
        
        return {
            "status": "success",
            "count": len(instruments),
            "instruments": instruments
        }
    except Exception as e:
        logger.error(f"Error fetching options: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/indices")
async def get_indices(
    exchange: Optional[str] = Query(None, description="Filter by exchange"),
    db: Session = Depends(get_db)
):
    """Get all index instruments"""
    try:
        instruments = instrument_search_service.get_indices(db, exchange=exchange)
        
        return {
            "status": "success",
            "count": len(instruments),
            "instruments": instruments
        }
    except Exception as e:
        logger.error(f"Error fetching indices: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/mtf")
async def get_mtf_enabled(
    limit: int = Query(1000, ge=1, le=5000),
    db: Session = Depends(get_db)
):
    """Get MTF (Margin Trading Facility) enabled instruments"""
    try:
        instruments = instrument_search_service.get_mtf_enabled(db, limit=limit)
        
        return {
            "status": "success",
            "count": len(instruments),
            "instruments": instruments
        }
    except Exception as e:
        logger.error(f"Error fetching MTF instruments: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/mis")
async def get_mis_enabled(
    limit: int = Query(1000, ge=1, le=5000),
    db: Session = Depends(get_db)
):
    """Get MIS (Intraday) enabled instruments"""
    try:
        instruments = instrument_search_service.get_mis_enabled(db, limit=limit)
        
        return {
            "status": "success",
            "count": len(instruments),
            "instruments": instruments
        }
    except Exception as e:
        logger.error(f"Error fetching MIS instruments: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


# ==========================================================================
# SYNC & MANAGEMENT
# ==========================================================================

@router.post("/sync")
async def sync_instruments(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Download and sync all instruments from Upstox.
    
    This endpoint downloads ~45,000 instruments from Upstox and saves them to the database.
    Takes about 30-60 seconds to complete.
    """
    try:
        result = instrument_sync_service.sync_instruments(db)
        
        return {
            "status": result['status'],
            "message": f"Synced {result['total_downloaded']} instruments",
            "total_downloaded": result['total_downloaded'],
            "saved_count": result['saved_count'],
            "total_saved": result['total_saved'],
            "synced_at": result['synced_at'],
            "duration_seconds": result['duration_seconds']
        }
    except Exception as e:
        logger.error(f"Sync failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Sync failed: {str(e)}"
        )


# ==========================================================================
# SINGLE & BATCH LOOKUP
# ==========================================================================

@router.get("/{instrument_key:path}")
async def get_instrument_by_key(
    instrument_key: str,
    db: Session = Depends(get_db)
):
    """
    Get single instrument by key.
    
    **Example:** `/instruments/NSE_EQ|INE009A01021`
    """
    try:
        instrument = instrument_search_service.get_by_key(db, instrument_key)
        
        if not instrument:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Instrument not found: {instrument_key}"
            )
        
        return {
            "status": "success",
            "instrument": instrument
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching instrument: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.post("/batch")
async def get_instruments_batch(
    instrument_keys: List[str],
    db: Session = Depends(get_db)
):
    """
    Get multiple instruments by keys.
    
    **Request body:**
    ```json
    ["NSE_EQ|INE009A01021", "NSE_EQ|INE467B01029"]
    ```
    """
    try:
        if len(instrument_keys) > 100:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Maximum 100 instrument keys allowed per request"
            )
        
        instruments = instrument_search_service.get_batch(db, instrument_keys)
        
        return {
            "status": "success",
            "requested": len(instrument_keys),
            "found": len(instruments),
            "instruments": instruments
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching batch: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )
