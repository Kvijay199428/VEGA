"""
Portfolio Router - Handles portfolio management, P&L, and position tracking
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from typing import Dict, Any, Optional
import logging
from database.connection import get_db
from middleware.auth import get_current_user
from services.portfolio_service import portfolio_service

router = APIRouter(prefix="/api/v1/portfolio", tags=["Portfolio"])
security = HTTPBearer()
logger = logging.getLogger(__name__)


def get_primary_token(db: Session) -> Optional[str]:
    """
    Fetch PRIMARY access token from database (api_index=0).
    Used for orders, portfolio, and other critical API calls.
    """
    from models.upstox_token import UpstoxToken
    
    primary_token = db.query(UpstoxToken).filter(
        UpstoxToken.api_index == 0,  # PRIMARY
        UpstoxToken.is_active == True
    ).first()
    
    if primary_token:
        logger.debug(f"Using PRIMARY token from database (api_name: {primary_token.api_name})")
        return primary_token.access_token
    
    return None


# ==========================================================================
# PORTFOLIO SUMMARY
# ==========================================================================

@router.get("/summary")
async def get_portfolio_summary(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get comprehensive portfolio summary using PRIMARY token"""
    try:
        # Fetch PRIMARY token from database
        access_token = get_primary_token(db)
        
        if not access_token:
            logger.warning("PRIMARY token not found in DB")
        if access_token:
            # Fetch directly from Upstox API
            from services.upstox_service import upstox_service
            funds_data = await upstox_service.get_funds(access_token)
            
            # Extract margin data
            margin_data = funds_data.get("data", {})
            equity = margin_data.get("equity", {})
            commodity = margin_data.get("commodity", {})
            
            # Calculate flat values for frontend
            used_margin = float(equity.get("used_margin", 0)) + float(commodity.get("used_margin", 0))
            available_margin = float(equity.get("available_margin", 0)) + float(commodity.get("available_margin", 0))
            payin_amount = float(equity.get("payin_amount", 0)) + float(commodity.get("payin_amount", 0))
            
            return {
                "status": "success",
                "data": {
                    # Flat fields for frontend compatibility
                    "net_worth": payin_amount + available_margin,
                    "pnl_day": 0,  # TODO: Calculate from positions
                    "pnl_total": 0,  # TODO: Calculate from P&L history
                    "margin_used": used_margin,
                    "margin_available": available_margin,
                    "buying_power": available_margin,
                    
                    # Legacy/detailed fields
                    "total_value": available_margin,
                    "positions_value": 0,
                    "holdings_value": 0,
                    "total_pnl": {
                        "realized": 0,
                        "unrealized": 0,
                        "today": 0
                    },
                    "margin": margin_data,
                    "positions_count": 0,
                    "holdings_count": 0,
                    "from_upstox": True
                }
            }
        
        # For database users, use the portfolio service
        result = await portfolio_service.get_portfolio_summary(db, current_user["id"])
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get portfolio summary: {str(e)}"
        )

# ==========================================================================
# POSITIONS
# ==========================================================================

@router.get("/positions")
async def get_positions(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get all open positions using PRIMARY token"""
    try:
        # Fetch PRIMARY token from database
        access_token = get_primary_token(db)
        
        if not access_token:
            # Fallback to token from request header
            access_token = current_user.get("upstox_token")
        
        if access_token:
            # Fetch directly from Upstox API
            from services.upstox_service import upstox_service
            positions_data = await upstox_service.get_positions(access_token)
            return positions_data
        
        # For database users, use the portfolio service
        result = await portfolio_service.get_positions(db, current_user["id"])
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get positions: {str(e)}"
        )

@router.get("/positions/{instrument_token}")
async def get_position(
    instrument_token: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get position for specific instrument"""
    try:
        result = await portfolio_service.get_position_by_instrument(
            db, current_user["id"], instrument_token
        )
        
        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Position not found"
            )
            
        return {
            "status": "success",
            "data": result
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get position: {str(e)}"
        )

# ==========================================================================
# HOLDINGS
# ==========================================================================

@router.get("/holdings")
async def get_holdings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get all holdings using PRIMARY token"""
    try:
        # Fetch PRIMARY token from database
        access_token = get_primary_token(db)
        
        if not access_token:
            # Fallback to token from request header
            access_token = current_user.get("upstox_token")
        
        if access_token:
            # Fetch directly from Upstox API
            from services.upstox_service import upstox_service
            holdings_data = await upstox_service.get_holdings(access_token)
            return holdings_data
        
        # For database users, use the portfolio service
        result = await portfolio_service.get_holdings(db, current_user["id"])
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get holdings: {str(e)}"
        )

# ==========================================================================
# PERFORMANCE
# ==========================================================================

@router.get("/performance")
async def get_performance(
    period: str = Query("1M", description="Time period for performance analysis", 
                       regex="^(1D|1W|1M|3M|6M|1Y)$"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get portfolio performance for a specific period"""
    try:
        result = await portfolio_service.get_performance(db, current_user["id"], period)
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get performance: {str(e)}"
        )

# ==========================================================================
# PORTFOLIO SNAPSHOTS
# ==========================================================================

@router.post("/snapshots")
async def create_snapshot(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Create portfolio snapshot"""
    try:
        result = await portfolio_service.create_snapshot(db, current_user["id"])
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create snapshot: {str(e)}"
        )

@router.get("/snapshots")
async def get_snapshots(
    limit: int = Query(30, ge=1, le=100, description="Number of snapshots to return"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get portfolio snapshots"""
    try:
        result = await portfolio_service.get_snapshots(db, current_user["id"], limit)
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get snapshots: {str(e)}"
        )

# ==========================================================================
# ALLOCATION
# ==========================================================================

@router.get("/allocation")
async def get_allocation(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get portfolio allocation by sector and instrument type"""
    try:
        result = await portfolio_service.get_allocation(db, current_user["id"])
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get allocation: {str(e)}"
        )

# ==========================================================================
# P&L REPORTS
# ==========================================================================

@router.get("/pnl-report")
async def get_pnl_report(
    start_date: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    instrument_token: Optional[str] = Query(None, description="Filter by instrument"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get detailed P&L report"""
    try:
        # Parse dates
        start_dt = None
        end_dt = None
        
        if start_date:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        if end_date:
            end_dt = datetime.strptime(end_date, "%Y-%m-%d")
            
        # Build query
        query = db.query(Trade).filter(Trade.user_id == current_user["id"])
        
        if start_dt:
            query = query.filter(Trade.trade_timestamp >= start_dt)
        if end_dt:
            query = query.filter(Trade.trade_timestamp <= end_dt)
        if instrument_token:
            query = query.filter(Trade.instrument_token == instrument_token)
            
        trades = query.order_by(Trade.trade_timestamp.desc()).all()
        
        # Calculate P&L summary
        total_pnl = sum(trade.pnl for trade in trades)
        gross_profit = sum(trade.pnl for trade in trades if trade.pnl > 0)
        gross_loss = sum(trade.pnl for trade in trades if trade.pnl < 0)
        
        profitable_trades = len([t for t in trades if t.pnl > 0])
        losing_trades = len([t for t in trades if t.pnl < 0])
        
        # Prepare trade data
        trade_data = []
        for trade in trades:
            trade_dict = {
                "id": trade.id,
                "trade_id": trade.trade_id,
                "order_id": trade.order_id,
                "instrument_token": trade.instrument_token,
                "tradingsymbol": trade.tradingsymbol,
                "transaction_type": trade.transaction_type,
                "quantity": trade.quantity,
                "price": trade.price,
                "trade_timestamp": trade.trade_timestamp.isoformat() if trade.trade_timestamp else None,
                "pnl": trade.pnl,
                "brokerage": trade.brokerage,
                "other_charges": trade.other_charges,
                "net_pnl": trade.net_pnl
            }
            trade_data.append(trade_dict)
            
        return {
            "status": "success",
            "data": {
                "summary": {
                    "total_trades": len(trades),
                    "profitable_trades": profitable_trades,
                    "losing_trades": losing_trades,
                    "total_pnl": total_pnl,
                    "gross_profit": gross_profit,
                    "gross_loss": gross_loss,
                    "net_pnl": total_pnl,
                    "win_rate": (profitable_trades / len(trades) * 100) if trades else 0,
                    "average_pnl": total_pnl / len(trades) if trades else 0,
                    "average_profit": gross_profit / profitable_trades if profitable_trades else 0,
                    "average_loss": gross_loss / losing_trades if losing_trades else 0
                },
                "trades": trade_data
            }
        }
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid date format: {str(e)}"
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get P&L report: {str(e)}"
        )

# ==========================================================================
# RISK METRICS
# ==========================================================================

@router.get("/risk-metrics")
async def get_risk_metrics(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get portfolio risk metrics"""
    try:
        # Get positions
        positions = db.query(Position).filter(
            Position.user_id == current_user["id"],
            Position.quantity != 0
        ).all()
        
        # Calculate risk metrics
        total_value = sum(pos.market_value for pos in positions)
        total_margin = sum(pos.margin_used for pos in positions)
        
        # Calculate concentration risk
        if positions:
            largest_position = max(positions, key=lambda x: abs(x.market_value))
            concentration_risk = (abs(largest_position.market_value) / total_value * 100) if total_value > 0 else 0
        else:
            concentration_risk = 0
            
        # Calculate sector concentration (simplified)
        sector_exposure = {}
        for pos in positions:
            instrument = db.query(Instrument).filter(
                Instrument.instrument_token == pos.instrument_token
            ).first()
            
            if instrument and instrument.sector:
                sector = instrument.sector
                if sector not in sector_exposure:
                    sector_exposure[sector] = 0
                sector_exposure[sector] += abs(pos.market_value)
                
        # Find largest sector exposure
        max_sector_exposure = max(sector_exposure.values()) if sector_exposure else 0
        sector_concentration = (max_sector_exposure / total_value * 100) if total_value > 0 else 0
        
        # Calculate beta (simplified - would need market data)
        portfolio_beta = 1.0  # Placeholder
        
        # Calculate VaR (Value at Risk) - simplified
        # In real implementation, this would use historical data
        var_95 = total_value * 0.02  # 2% daily VaR as placeholder
        
        return {
            "status": "success",
            "data": {
                "portfolio_value": total_value,
                "margin_used": total_margin,
                "margin_utilization": (total_margin / total_value * 100) if total_value > 0 else 0,
                "concentration_risk": {
                    "largest_position": concentration_risk,
                    "largest_sector": sector_concentration
                },
                "diversification": {
                    "num_positions": len(positions),
                    "num_sectors": len(sector_exposure),
                    "sector_exposure": sector_exposure
                },
                "risk_metrics": {
                    "portfolio_beta": portfolio_beta,
                    "var_95": var_95,
                    "max_drawdown": 0  # This would be calculated from historical data
                }
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get risk metrics: {str(e)}"
        )