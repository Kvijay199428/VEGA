"""
GTT (Good Till Triggered) Orders Router
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from typing import Dict, Any, List, Optional
from database.connection import get_db
from middleware.auth import get_current_user

router = APIRouter(prefix="/api/v1/gtt", tags=["GTT Orders"])
security = HTTPBearer()

@router.get("/orders")
async def get_gtt_orders(
    status: Optional[str] = Query(None, description="Filter by order status"),
    limit: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get GTT orders"""
    try:
        # Mock GTT orders
        orders = [
            {
                "id": 1,
                "order_id": "GTT2406128020000001",
                "tradingsymbol": "RELIANCE",
                "transaction_type": "BUY",
                "quantity": 10,
                "price": 2500.00,
                "trigger_price": 2490.00,
                "status": "ACTIVE",
                "created_at": "2024-06-13T10:30:00Z",
                "expires_at": "2024-07-13T10:30:00Z"
            },
            {
                "id": 2,
                "order_id": "GTT2406128020000002",
                "tradingsymbol": "TCS",
                "transaction_type": "SELL",
                "quantity": 5,
                "price": 3200.00,
                "trigger_price": 3220.00,
                "status": "ACTIVE",
                "created_at": "2024-06-13T11:15:00Z",
                "expires_at": "2024-07-13T11:15:00Z"
            }
        ]
        
        if status:
            orders = [o for o in orders if o["status"] == status]
            
        return {
            "status": "success",
            "data": {
                "orders": orders[:limit],
                "total": len(orders)
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get GTT orders: {str(e)}"
        )

@router.post("/orders")
async def create_gtt_order(
    order_data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Create GTT order"""
    try:
        # Validate input
        required_fields = ["tradingsymbol", "transaction_type", "quantity", "trigger_price"]
        for field in required_fields:
            if field not in order_data:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"{field} is required"
                )
                
        # Mock creation
        order = {
            "id": 3,
            "order_id": "GTT2406128020000003",
            "tradingsymbol": order_data["tradingsymbol"],
            "transaction_type": order_data["transaction_type"],
            "quantity": order_data["quantity"],
            "price": order_data.get("price"),
            "trigger_price": order_data["trigger_price"],
            "status": "ACTIVE",
            "created_at": datetime.utcnow().isoformat(),
            "expires_at": (datetime.utcnow() + timedelta(days=30)).isoformat()
        }
        
        return {
            "status": "success",
            "data": order
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create GTT order: {str(e)}"
        )

@router.get("/orders/{order_id}")
async def get_gtt_order(
    order_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get specific GTT order"""
    try:
        # Mock order
        order = {
            "id": 1,
            "order_id": order_id,
            "tradingsymbol": "RELIANCE",
            "transaction_type": "BUY",
            "quantity": 10,
            "price": 2500.00,
            "trigger_price": 2490.00,
            "status": "ACTIVE",
            "created_at": "2024-06-13T10:30:00Z",
            "expires_at": "2024-07-13T10:30:00Z",
            "triggered_at": None,
            "triggered_price": None,
            "order_history": []
        }
        
        return {
            "status": "success",
            "data": order
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get GTT order: {str(e)}"
        )

@router.put("/orders/{order_id}")
async def update_gtt_order(
    order_id: str,
    order_data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Update GTT order"""
    try:
        # Mock update
        return {
            "status": "success",
            "message": "GTT order updated successfully"
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update GTT order: {str(e)}"
        )

@router.delete("/orders/{order_id}")
async def cancel_gtt_order(
    order_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Cancel GTT order"""
    try:
        return {
            "status": "success",
            "message": "GTT order cancelled successfully"
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to cancel GTT order: {str(e)}"
        )