"""
Market Router - Handles market data, quotes, and watchlist
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from datetime import datetime

from database.connection import get_db, get_redis
from middleware.auth import get_current_user
from models.trading import Instrument
from services.market_data_service import market_data_service

import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/market", tags=["Market"])


# ==========================================================================
# MARKET OVERVIEW
# ==========================================================================

@router.get("/overview")
async def get_market_overview(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get market overview with indices and market status"""
    try:
        overview = await market_data_service.get_market_overview()
        return {
            "status": "success",
            "data": overview
        }
    except Exception as e:
        logger.error(f"Error fetching market overview: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch market overview"
        )


@router.get("/indices")
async def get_indices(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get all major indices"""
    try:
        # Get the access token from Upstox-authenticated user
        access_token = current_user.get("upstox_token")
        
        if not access_token:
            # Return empty data if no Upstox token available
            return {
                "status": "success",
                "data": {
                    "indices": [],
                    "message": "Upstox token required for live data"
                }
            }
        
        indices = await market_data_service.get_market_indices(access_token)
        return {
            "status": "success",
            "data": indices
        }
    except Exception as e:
        logger.error(f"Error fetching indices: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch indices"
        )


# ==========================================================================
# QUOTES
# ==========================================================================

@router.get("/quote/{symbol}")
async def get_quote(
    symbol: str,
    exchange: str = Query("NSE", description="Exchange (NSE, BSE)"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get real-time quote for a symbol"""
    try:
        quote = await market_data_service.get_quote(symbol, exchange)
        
        if not quote:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Quote not found for {symbol}"
            )
        
        return {
            "status": "success",
            "data": quote
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching quote for {symbol}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch quote"
        )


@router.post("/quotes")
async def get_multiple_quotes(
    symbols: List[str],
    exchange: str = "NSE",
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get quotes for multiple symbols"""
    try:
        quotes = await market_data_service.get_multiple_quotes(symbols, exchange)
        return {
            "status": "success",
            "data": quotes
        }
    except Exception as e:
        logger.error(f"Error fetching multiple quotes: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch quotes"
        )


# ==========================================================================
# MARKET DEPTH
# ==========================================================================

@router.get("/depth/{symbol}")
async def get_market_depth(
    symbol: str,
    exchange: str = Query("NSE", description="Exchange (NSE, BSE)"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get market depth (order book) for a symbol"""
    try:
        depth = await market_data_service.get_market_depth(symbol, exchange)
        
        if not depth:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Market depth not found for {symbol}"
            )
        
        return {
            "status": "success",
            "data": depth
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching market depth for {symbol}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch market depth"
        )


# ==========================================================================
# HISTORICAL DATA
# ==========================================================================

@router.get("/historical/{symbol}")
async def get_historical_data(
    symbol: str,
    exchange: str = Query("NSE", description="Exchange"),
    interval: str = Query("1D", description="Candle interval (1, 5, 15, 30, 60, 1D, 1W, 1M)"),
    from_date: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    to_date: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get historical OHLCV data for a symbol"""
    try:
        historical = await market_data_service.get_historical_data(
            symbol=symbol,
            exchange=exchange,
            interval=interval,
            from_date=from_date,
            to_date=to_date
        )
        
        return {
            "status": "success",
            "data": historical
        }
    except Exception as e:
        logger.error(f"Error fetching historical data for {symbol}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch historical data"
        )


# ==========================================================================
# INSTRUMENT SEARCH
# ==========================================================================

@router.get("/search")
async def search_instruments(
    query: str = Query(..., min_length=1, description="Search query"),
    exchange: Optional[str] = Query(None, description="Filter by exchange"),
    segment: Optional[str] = Query(None, description="Filter by segment"),
    limit: int = Query(20, ge=1, le=100, description="Maximum results"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Search for instruments"""
    try:
        # Build query
        db_query = db.query(Instrument).filter(
            (Instrument.symbol.ilike(f"%{query}%")) |
            (Instrument.name.ilike(f"%{query}%")) |
            (Instrument.trading_symbol.ilike(f"%{query}%"))
        )
        
        if exchange:
            db_query = db_query.filter(Instrument.exchange == exchange)
        if segment:
            db_query = db_query.filter(Instrument.segment == segment)
        
        instruments = db_query.filter(Instrument.is_active == True).limit(limit).all()
        
        return {
            "status": "success",
            "data": [
                {
                    "id": i.id,
                    "symbol": i.symbol,
                    "name": i.name,
                    "exchange": i.exchange,
                    "segment": i.segment,
                    "instrument_type": i.instrument_type,
                    "trading_symbol": i.trading_symbol,
                    "instrument_key": i.instrument_key
                }
                for i in instruments
            ]
        }
    except Exception as e:
        logger.error(f"Error searching instruments: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to search instruments"
        )


# ==========================================================================
# WATCHLIST
# ==========================================================================

@router.get("/watchlist")
async def get_watchlist(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get user's watchlist"""
    try:
        redis = get_redis()
        watchlist_key = f"watchlist:{current_user['id']}"
        
        watchlist = redis.hgetall(watchlist_key)
        
        if not watchlist:
            # Return default watchlist
            watchlist = {}
        
        return {
            "status": "success",
            "data": watchlist
        }
    except Exception as e:
        logger.error(f"Error fetching watchlist: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch watchlist"
        )


@router.post("/watchlist")
async def add_to_watchlist(
    instrument_key: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Add instrument to watchlist"""
    try:
        redis = get_redis()
        watchlist_key = f"watchlist:{current_user['id']}"
        
        redis.hset(watchlist_key, instrument_key, datetime.utcnow().isoformat())
        
        return {
            "status": "success",
            "message": "Added to watchlist"
        }
    except Exception as e:
        logger.error(f"Error adding to watchlist: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to add to watchlist"
        )


@router.delete("/watchlist/{instrument_key}")
async def remove_from_watchlist(
    instrument_key: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Remove instrument from watchlist"""
    try:
        redis = get_redis()
        watchlist_key = f"watchlist:{current_user['id']}"
        
        redis.hdel(watchlist_key, instrument_key)
        
        return {
            "status": "success",
            "message": "Removed from watchlist"
        }
    except Exception as e:
        logger.error(f"Error removing from watchlist: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to remove from watchlist"
        )

# ==========================================================================
# MARKET STATUS
# ==========================================================================

@router.get("/status")
async def get_market_status(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get current market status"""
    try:
        status_data = await market_data_service.get_market_status()
        return {
            "status": "success",
            "data": status_data
        }
    except Exception as e:
        logger.error(f"Error fetching market status: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch market status"
        )


# ==========================================================================
# MARKET DATA FEED V3 - WebSocket Authentication & Subscription
# ==========================================================================

@router.get("/market-feed/auth")
async def get_market_feed_auth(
    current_user: dict = Depends(get_current_user)
):
    """
    Get authenticated WebSocket URL for Market Data Feed V3.
    
    Returns WebSocket URL that can be used to connect and receive real-time data.
    """
    try:
        from services.upstox_service import upstox_service
        
        access_token = current_user.get("upstox_token")
        if not access_token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Upstox token required for market feed"
            )
        
        auth_data = await upstox_service.get_market_feed_auth(access_token)
        
        return {
            "status": "success",
            "data": {
                "websocket_url": auth_data.get("data", {}).get("authorizedRedirectUri"),
                "mode": "market_data_feed_v3",
                "subscription_limits": {
                    "ltpc": 5000,
                    "option_greeks": 3000,
                    "full": 2000,
                    "full_d30": 50
                }
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting market feed auth: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get market feed auth: {str(e)}"
        )


@router.post("/market-feed/connect")
async def connect_market_feed(
    types: Optional[List[str]] = Query(None, description="Instrument types to subscribe (index, equity, futures, options). Default: all"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Connect to Upstox WebSocket and subscribe to ALL instruments from all helpers.
    
    This uses the subscription_manager to collect instrument keys from:
    - IndexHelper (NSE_INDEX, BSE_INDEX)
    - EquityHelper (NSE_EQ, BSE_EQ)
    - FuturesHelper (NSE_FO futures)
    - OptionsHelper (NSE_FO options)
    
    The WebSocket runs in background and prices are cached.
    Use type-specific endpoints to get filtered prices.
    """
    try:
        from services.market_data_background import market_data_service
        
        access_token = current_user.get("upstox_token")
        if not access_token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Upstox token required"
            )
        
        # Start background service with all instruments
        await market_data_service.start(access_token, db)
        
        # Get subscription summary
        status_info = market_data_service.get_status()
        
        return {
            "status": "success",
            "message": f"Connected and subscribed to {status_info['total_subscribed']} instruments",
            "subscriptions": status_info['subscriptions'],
            "total_subscribed": status_info['total_subscribed'],
            "mode": "ltpc"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error connecting to market feed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to connect: {str(e)}"
        )


@router.post("/market-feed/disconnect")
async def disconnect_market_feed(
    current_user: dict = Depends(get_current_user)
):
    """Disconnect from Upstox WebSocket"""
    try:
        from services.market_data_background import market_data_service
        
        await market_data_service.stop()
        
        return {
            "status": "success",
            "message": "Disconnected from market feed"
        }
    except Exception as e:
        logger.error(f"Error disconnecting: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to disconnect: {str(e)}"
        )


@router.get("/market-feed/status")
async def get_market_feed_status(
    current_user: dict = Depends(get_current_user)
):
    """
    Get current WebSocket connection status with subscription breakdown by type.
    """
    try:
        from services.market_data_background import market_data_service
        
        status_info = market_data_service.get_status()
        
        return {
            "status": "success",
            "data": status_info
        }
    except Exception as e:
        logger.error(f"Error getting status: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/market-feed/indices")
async def get_live_index_prices(
    current_user: dict = Depends(get_current_user)
):
    """
    Get live INDEX prices only (filtered from all prices).
    
    Returns LTPC data for subscribed index instruments only.
    """
    try:
        from services.market_data_background import market_data_service
        
        if not market_data_service.is_running:
            return {
                "status": "error",
                "message": "Not connected to market feed",
                "data": {}
            }
        
        # Get only index prices
        index_prices = market_data_service.get_prices_by_type('index')
        
        return {
            "status": "success",
            "type": "index",
            "data": index_prices,
            "count": len(index_prices)
        }
    except Exception as e:
        logger.error(f"Error getting index prices: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


# ==========================================================================
# EQUITY LIVE FEED ENDPOINTS
# ==========================================================================

@router.post("/market-feed/equity/connect")
async def connect_equity_feed(
    exchange: Optional[str] = Query('NSE', description="Exchange (NSE, BSE)"),
    limit: int = Query(100, ge=1, le=1000, description="Max instruments to subscribe"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Connect to Upstox WebSocket and subscribe to equity instruments.
    
    Uses EquityHelper to extract equity instrument keys and subscribes with LTPC mode.
    """
    try:
        from services.market_data_websocket import market_data_ws
        from helpers.instruments.equity import EquityHelper
        
        access_token = current_user.get("upstox_token")
        if not access_token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Upstox token required"
            )
        
        # Get equity instruments from database using EquityHelper
        equity_keys = EquityHelper.get_all_keys(db, exchange=exchange)
        
        if not equity_keys:
            return {
                "status": "error",
                "message": "No equity instruments found. Please sync instruments first.",
                "subscribed_instruments": 0
            }
        
        # Limit the number of subscriptions
        instrument_keys = equity_keys[:limit]
        
        logger.info(f"Connecting with {len(instrument_keys)} equity instruments from {exchange}")
        
        # Connect and subscribe
        await market_data_ws.connect(access_token, instrument_keys)
        
        return {
            "status": "success",
            "message": f"Connected and subscribed to {len(instrument_keys)} equities",
            "subscribed_instruments": len(instrument_keys),
            "exchange": exchange,
            "mode": "ltpc"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error connecting to equity feed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to connect: {str(e)}"
        )


@router.post("/market-feed/equity/subscribe")
async def subscribe_equity_symbols(
    symbols: List[str] = Query(..., description="List of trading symbols to subscribe"),
    exchange: str = Query('NSE', description="Exchange (NSE, BSE)"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Subscribe to specific equity symbols by trading symbol name.
    """
    try:
        from services.market_data_websocket import market_data_ws
        from helpers.instruments.equity import EquityHelper
        
        if not market_data_ws.is_connected:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Not connected to market feed. Connect first."
            )
        
        # Get instrument keys for the symbols
        instrument_keys = []
        for symbol in symbols:
            key = EquityHelper.get_by_symbol(db, symbol)
            if key:
                instrument_keys.append(key)
        
        if not instrument_keys:
            return {
                "status": "error",
                "message": "No matching instruments found",
                "subscribed": 0
            }
        
        # Subscribe
        await market_data_ws.subscribe(instrument_keys, mode='ltpc')
        
        return {
            "status": "success",
            "message": f"Subscribed to {len(instrument_keys)} symbols",
            "subscribed": len(instrument_keys),
            "symbols": symbols[:10]  # Return first 10
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error subscribing to symbols: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/market-feed/equity/prices")
async def get_live_equity_prices(
    current_user: dict = Depends(get_current_user)
):
    """
    Get live EQUITY prices only (filtered from all prices).
    
    Returns LTPC data for subscribed equity instruments only.
    """
    try:
        from services.market_data_background import market_data_service
        
        if not market_data_service.is_running:
            return {
                "status": "error",
                "message": "Not connected to market feed",
                "data": {}
            }
        
        # Get only equity prices
        equity_prices = market_data_service.get_prices_by_type('equity')
        
        return {
            "status": "success",
            "type": "equity",
            "data": equity_prices,
            "count": len(equity_prices)
        }
    except Exception as e:
        logger.error(f"Error getting equity prices: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/market-feed/futures/prices")
async def get_live_futures_prices(
    current_user: dict = Depends(get_current_user)
):
    """
    Get live FUTURES prices only (filtered from all prices).
    
    Returns LTPC data for subscribed futures instruments only.
    """
    try:
        from services.market_data_background import market_data_service
        
        if not market_data_service.is_running:
            return {
                "status": "error",
                "message": "Not connected to market feed",
                "data": {}
            }
        
        # Get only futures prices
        futures_prices = market_data_service.get_prices_by_type('futures')
        
        return {
            "status": "success",
            "type": "futures",
            "data": futures_prices,
            "count": len(futures_prices)
        }
    except Exception as e:
        logger.error(f"Error getting futures prices: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/market-feed/options/prices")
async def get_live_options_prices(
    current_user: dict = Depends(get_current_user)
):
    """
    Get live OPTIONS prices only (filtered from all prices).
    
    Returns option greeks data for subscribed options instruments only.
    """
    try:
        from services.market_data_background import market_data_service
        
        if not market_data_service.is_running:
            return {
                "status": "error",
                "message": "Not connected to market feed",
                "data": {}
            }
        
        # Get only options prices
        options_prices = market_data_service.get_prices_by_type('options')
        
        return {
            "status": "success",
            "type": "options",
            "data": options_prices,
            "count": len(options_prices)
        }
    except Exception as e:
        logger.error(f"Error getting options prices: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/market-feed/all/prices")
async def get_all_live_prices(
    current_user: dict = Depends(get_current_user)
):
    """
    Get ALL live prices from WebSocket cache.
    
    Returns all cached prices for all instrument types.
    """
    try:
        from services.market_data_background import market_data_service
        
        if not market_data_service.is_running:
            return {
                "status": "error",
                "message": "Not connected to market feed",
                "data": {}
            }
        
        all_prices = market_data_service.get_all_prices()
        
        return {
            "status": "success",
            "type": "all",
            "data": all_prices,
            "count": len(all_prices)
        }
    except Exception as e:
        logger.error(f"Error getting all prices: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/instruments")
async def get_instruments(
    exchange: Optional[str] = Query(None, description="Filter by exchange (NSE, BSE, MCX)"),
    segment: Optional[str] = Query(None, description="Filter by segment (NSE_EQ, NSE_FO, etc.)"),
    instrument_type: Optional[str] = Query(None, description="Filter by type (EQ, FUT, CE, PE, INDEX)"),
    symbol: Optional[str] = Query(None, description="Search by symbol"),
    limit: int = Query(100, ge=1, le=1000, description="Max results"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Get instruments with optional filters.
    
    Uses database if available, falls back to Upstox API if not.
    """
    try:
        from services.instrument_search import instrument_search_service
        
        # Use instrument search service
        result = instrument_search_service.search_instruments(
            db,
            segment=segment,
            instrument_type=instrument_type,
            trading_symbol=symbol,
            exchange=exchange,
            limit=limit
        )
        
        return {
            "status": "success",
            "total": result.get('total', 0),
            "count": result.get('count', 0),
            "instruments": result.get('instruments', [])
        }
    except Exception as e:
        logger.error(f"Error getting instruments: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get instruments: {str(e)}"
        )


@router.get("/instruments/download")
async def download_instruments(
    exchange: Optional[str] = Query(None, description="Filter by exchange (NSE, BSE, MCX)"),
    segment: Optional[str] = Query(None, description="Filter by segment (EQ, FO, INDEX)"),
    current_user: dict = Depends(get_current_user)
):
    """
    Download all available instruments from Upstox.
    
    Can filter by exchange and segment. Returns instrument keys for subscription.
    """
    try:
        from services.upstox_service import upstox_service
        
        access_token = current_user.get("upstox_token")
        if not access_token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Upstox token required"
            )
        
        instruments = await upstox_service.get_instruments(
            exchange=exchange,
            instrument_type=segment,
            access_token=access_token
        )
        
        return {
            "status": "success",
            "data": instruments.get("data", []),
            "count": len(instruments.get("data", []))
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error downloading instruments: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to download instruments: {str(e)}"
        )


@router.get("/instruments/search")
async def search_instruments_endpoint(
    q: str = Query(..., min_length=1, description="Search query"),
    limit: int = Query(20, ge=1, le=100, description="Max results"),
    current_user: dict = Depends(get_current_user)
):
    """
    Search for instruments by name or symbol.
    
    Returns matching instruments with their instrument keys for subscription.
    """
    try:
        from services.upstox_service import upstox_service
        
        access_token = current_user.get("upstox_token")
        if not access_token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Upstox token required"
            )
        
        results = await upstox_service.search_instruments(
            query=q,
            access_token=access_token,
            limit=limit
        )
        
        return {
            "status": "success",
            "data": results.get("data", []),
            "count": len(results.get("data", []))
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error searching instruments: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to search instruments: {str(e)}"
        )


@router.post("/subscribe")
async def subscribe_to_instruments(
    instrument_keys: List[str],
    mode: str = Query("ltpc", description="Subscription mode: ltpc, full, option_greeks, full_d30"),
    current_user: dict = Depends(get_current_user)
):
    """
    Create subscription request for WebSocket.
    
    Returns the subscription message to be sent via WebSocket.
    
    Modes:
    - ltpc: Last Trade Price & Close (5000 max)
    - full: Full depth + metadata (2000 max)
    - option_greeks: Option Greeks (3000 max)  
    - full_d30: 30-level depth (50 max, Plus only)
    """
    import uuid
    
    # Validate mode
    valid_modes = ["ltpc", "full", "option_greeks", "full_d30"]
    if mode not in valid_modes:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid mode. Must be one of: {valid_modes}"
        )
    
    # Validate limits
    limits = {"ltpc": 5000, "full": 2000, "option_greeks": 3000, "full_d30": 50}
    if len(instrument_keys) > limits[mode]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Exceeded limit for {mode} mode. Maximum: {limits[mode]}"
        )
    
    subscription_request = {
        "guid": str(uuid.uuid4())[:20],
        "method": "sub",
        "data": {
            "mode": mode,
            "instrumentKeys": instrument_keys
        }
    }
    
    return {
        "status": "success",
        "data": subscription_request,
        "message": "Send this payload via WebSocket to subscribe"
    }


@router.post("/unsubscribe")
async def unsubscribe_from_instruments(
    instrument_keys: List[str],
    current_user: dict = Depends(get_current_user)
):
    """
    Create unsubscribe request for WebSocket.
    
    Returns the unsubscribe message to be sent via WebSocket.
    """
    import uuid
    
    unsubscribe_request = {
        "guid": str(uuid.uuid4())[:20],
        "method": "unsub",
        "data": {
            "instrumentKeys": instrument_keys
        }
    }
    
    return {
        "status": "success",
        "data": unsubscribe_request,
        "message": "Send this payload via WebSocket to unsubscribe"
    }


@router.post("/change-mode")
async def change_subscription_mode(
    instrument_keys: List[str],
    mode: str = Query(..., description="New mode: ltpc, full, option_greeks, full_d30"),
    current_user: dict = Depends(get_current_user)
):
    """
    Create mode change request for WebSocket.
    
    Changes the subscription mode for already-subscribed instruments.
    """
    import uuid
    
    valid_modes = ["ltpc", "full", "option_greeks", "full_d30"]
    if mode not in valid_modes:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid mode. Must be one of: {valid_modes}"
        )
    
    change_mode_request = {
        "guid": str(uuid.uuid4())[:20],
        "method": "change_mode",
        "data": {
            "mode": mode,
            "instrumentKeys": instrument_keys
        }
    }
    
    return {
        "status": "success",
        "data": change_mode_request,
        "message": "Send this payload via WebSocket to change mode"
    }
