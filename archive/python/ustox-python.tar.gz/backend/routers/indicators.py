"""
Indicators Router - Handles technical indicators calculation and management
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from typing import Dict, Any, List, Optional
from database.connection import get_db
from middleware.auth import get_current_user
from models.ai_strategy import TechnicalIndicator
from services.ai_service import ai_service

router = APIRouter(prefix="/api/v1/indicators", tags=["Indicators"])
security = HTTPBearer()

# ==========================================================================
# SYSTEM INDICATORS
# ==========================================================================

@router.get("")
async def get_indicators(
    indicator_type: Optional[str] = Query(None, description="Filter by indicator type"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get available technical indicators"""
    try:
        # Mock list of available indicators
        indicators = [
            {
                "id": "sma",
                "name": "Simple Moving Average",
                "type": "TREND",
                "category": "MOVING_AVERAGE",
                "description": "Calculates the average price over a specified period",
                "parameters": [
                    {
                        "name": "period",
                        "type": "integer",
                        "default": 20,
                        "min": 1,
                        "max": 200,
                        "description": "Number of periods to calculate average"
                    }
                ],
                "applicable_to": ["PRICE"],
                "calculation": "SUM(CLOSE, N) / N"
            },
            {
                "id": "ema",
                "name": "Exponential Moving Average",
                "type": "TREND",
                "category": "MOVING_AVERAGE",
                "description": "Exponential moving average giving more weight to recent prices",
                "parameters": [
                    {
                        "name": "period",
                        "type": "integer",
                        "default": 20,
                        "min": 1,
                        "max": 200,
                        "description": "Number of periods for EMA calculation"
                    },
                    {
                        "name": "smoothing",
                        "type": "float",
                        "default": 2.0,
                        "min": 1.0,
                        "max": 3.0,
                        "description": "Smoothing factor for EMA"
                    }
                ],
                "applicable_to": ["PRICE"],
                "calculation": "EMA = (Close * (2 / (N + 1))) + (EMA_previous * (1 - (2 / (N + 1))))"
            },
            {
                "id": "rsi",
                "name": "Relative Strength Index",
                "type": "MOMENTUM",
                "category": "OSCILLATOR",
                "description": "Measures the speed and change of price movements",
                "parameters": [
                    {
                        "name": "period",
                        "type": "integer",
                        "default": 14,
                        "min": 5,
                        "max": 50,
                        "description": "Period for RSI calculation"
                    }
                ],
                "applicable_to": ["PRICE"],
                "calculation": "RSI = 100 - (100 / (1 + RS)) where RS = Average Gain / Average Loss"
            },
            {
                "id": "macd",
                "name": "Moving Average Convergence Divergence",
                "type": "MOMENTUM",
                "category": "OSCILLATOR",
                "description": "Trend-following momentum indicator",
                "parameters": [
                    {
                        "name": "fast_period",
                        "type": "integer",
                        "default": 12,
                        "min": 5,
                        "max": 50,
                        "description": "Fast EMA period"
                    },
                    {
                        "name": "slow_period",
                        "type": "integer",
                        "default": 26,
                        "min": 10,
                        "max": 100,
                        "description": "Slow EMA period"
                    },
                    {
                        "name": "signal_period",
                        "type": "integer",
                        "default": 9,
                        "min": 5,
                        "max": 30,
                        "description": "Signal line EMA period"
                    }
                ],
                "applicable_to": ["PRICE"],
                "calculation": "MACD = EMA(fast) - EMA(slow), Signal = EMA(MACD)"
            },
            {
                "id": "bollinger_bands",
                "name": "Bollinger Bands",
                "type": "VOLATILITY",
                "category": "BAND",
                "description": "Bands that expand and contract based on volatility",
                "parameters": [
                    {
                        "name": "period",
                        "type": "integer",
                        "default": 20,
                        "min": 5,
                        "max": 50,
                        "description": "Period for moving average"
                    },
                    {
                        "name": "std_dev",
                        "type": "float",
                        "default": 2.0,
                        "min": 1.0,
                        "max": 3.0,
                        "description": "Number of standard deviations"
                    }
                ],
                "applicable_to": ["PRICE"],
                "calculation": "Upper Band = SMA + (StdDev * N), Lower Band = SMA - (StdDev * N)"
            },
            {
                "id": "stochastic",
                "name": "Stochastic Oscillator",
                "type": "MOMENTUM",
                "category": "OSCILLATOR",
                "description": "Compares closing price to price range over time",
                "parameters": [
                    {
                        "name": "k_period",
                        "type": "integer",
                        "default": 14,
                        "min": 5,
                        "max": 50,
                        "description": "Period for %K calculation"
                    },
                    {
                        "name": "d_period",
                        "type": "integer",
                        "default": 3,
                        "min": 1,
                        "max": 10,
                        "description": "Period for %D smoothing"
                    }
                ],
                "applicable_to": ["PRICE"],
                "calculation": "%K = (Close - Low(N)) / (High(N) - Low(N)) * 100"
            },
            {
                "id": "atr",
                "name": "Average True Range",
                "type": "VOLATILITY",
                "category": "INDICATOR",
                "description": "Measures market volatility",
                "parameters": [
                    {
                        "name": "period",
                        "type": "integer",
                        "default": 14,
                        "min": 5,
                        "max": 50,
                        "description": "Period for ATR calculation"
                    }
                ],
                "applicable_to": ["PRICE"],
                "calculation": "ATR = Average of True Range over N periods"
            },
            {
                "id": "volume",
                "name": "Volume",
                "type": "VOLUME",
                "category": "VOLUME",
                "description": "Trading volume",
                "parameters": [],
                "applicable_to": ["VOLUME"],
                "calculation": "Raw volume data"
            },
            {
                "id": "vwap",
                "name": "Volume Weighted Average Price",
                "type": "TREND",
                "category": "AVERAGE",
                "description": "Average price weighted by volume",
                "parameters": [],
                "applicable_to": ["PRICE", "VOLUME"],
                "calculation": "VWAP = Cumulative(Price * Volume) / Cumulative(Volume)"
            }
        ]
        
        # Filter by type if specified
        if indicator_type:
            indicators = [
                ind for ind in indicators 
                if ind["type"].lower() == indicator_type.lower()
            ]
            
        return {
            "status": "success",
            "data": {
                "indicators": indicators,
                "total": len(indicators)
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get indicators: {str(e)}"
        )

@router.post("/{indicator_id}")
async def calculate_indicator(
    indicator_id: str,
    instrument_token: str,
    parameters: Dict[str, Any],
    period: int = Query(20, ge=1, le=200, description="Number of data points"),
    interval: str = Query("1D", description="Data interval"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Calculate indicator values for an instrument"""
    try:
        # Validate indicator
        valid_indicators = ["sma", "ema", "rsi", "macd", "bollinger_bands", "stochastic", "atr", "vwap"]
        if indicator_id not in valid_indicators:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid indicator ID"
            )
            
        # Calculate indicator using AI service
        indicators_to_calculate = [indicator_id.upper()]
        result = await ai_service.calculate_technical_indicators(
            db, instrument_token, indicators_to_calculate
        )
        
        # Add calculation parameters to result
        result["data"]["parameters"] = parameters
        result["data"]["period"] = period
        result["data"]["interval"] = interval
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to calculate indicator: {str(e)}"
        )

# ==========================================================================
# USER CUSTOM INDICATORS
# ==========================================================================

@router.get("/user")
async def get_user_indicators(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get user's custom indicators"""
    try:
        indicators = db.query(TechnicalIndicator).filter(
            TechnicalIndicator.user_id == current_user["id"]
        ).order_by(TechnicalIndicator.created_at.desc()).all()
        
        indicator_data = []
        for indicator in indicators:
            indicator_dict = {
                "id": indicator.id,
                "name": indicator.name,
                "description": indicator.description,
                "formula": indicator.formula,
                "parameters": json.loads(indicator.parameters) if indicator.parameters else {},
                "is_active": indicator.is_active,
                "created_at": indicator.created_at.isoformat(),
                "updated_at": indicator.updated_at.isoformat()
            }
            indicator_data.append(indicator_dict)
            
        return {
            "status": "success",
            "data": {
                "indicators": indicator_data,
                "total": len(indicators)
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get user indicators: {str(e)}"
        )

@router.post("/user")
async def create_custom_indicator(
    indicator_data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Create custom technical indicator"""
    try:
        # Validate required fields
        if "name" not in indicator_data or "formula" not in indicator_data:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Name and formula are required"
            )
            
        indicator = TechnicalIndicator(
            user_id=current_user["id"],
            name=indicator_data["name"],
            description=indicator_data.get("description", ""),
            formula=indicator_data["formula"],
            parameters=json.dumps(indicator_data.get("parameters", {})),
            is_active=indicator_data.get("is_active", True),
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
        
        db.add(indicator)
        db.commit()
        
        return {
            "status": "success",
            "data": {
                "id": indicator.id,
                "name": indicator.name,
                "message": "Custom indicator created successfully"
            }
        }
        
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create custom indicator: {str(e)}"
        )

@router.put("/user/{indicator_id}")
async def update_custom_indicator(
    indicator_id: int,
    indicator_data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Update custom technical indicator"""
    try:
        indicator = db.query(TechnicalIndicator).filter(
            and_(TechnicalIndicator.id == indicator_id, TechnicalIndicator.user_id == current_user["id"])
        ).first()
        
        if not indicator:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Custom indicator not found"
            )
            
        # Update fields
        if "name" in indicator_data:
            indicator.name = indicator_data["name"]
        if "description" in indicator_data:
            indicator.description = indicator_data["description"]
        if "formula" in indicator_data:
            indicator.formula = indicator_data["formula"]
        if "parameters" in indicator_data:
            indicator.parameters = json.dumps(indicator_data["parameters"])
        if "is_active" in indicator_data:
            indicator.is_active = indicator_data["is_active"]
            
        indicator.updated_at = datetime.utcnow()
        db.commit()
        
        return {
            "status": "success",
            "message": "Custom indicator updated successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update custom indicator: {str(e)}"
        )

@router.delete("/user/{indicator_id}")
async def delete_custom_indicator(
    indicator_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Delete custom technical indicator"""
    try:
        indicator = db.query(TechnicalIndicator).filter(
            and_(TechnicalIndicator.id == indicator_id, TechnicalIndicator.user_id == current_user["id"])
        ).first()
        
        if not indicator:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Custom indicator not found"
            )
            
        db.delete(indicator)
        db.commit()
        
        return {
            "status": "success",
            "message": "Custom indicator deleted successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete custom indicator: {str(e)}"
        )