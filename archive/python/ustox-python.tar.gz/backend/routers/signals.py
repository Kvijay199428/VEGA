"""
Signals Router - Handles market signals and notifications
"""

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from typing import Dict, Any
from database.connection import get_db
from middleware.auth import get_current_user
from services.ai_service import ai_service

router = APIRouter(prefix="/api/v1/signals", tags=["Signals"])
security = HTTPBearer()

@router.get("")
async def get_signals(
    status: str = "PENDING",
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get market signals"""
    try:
        result = await ai_service.get_market_signals(db, current_user["id"], limit)
        
        # Filter by status if needed
        if status != "ALL":
            result["data"]["signals"] = [
                s for s in result["data"]["signals"] 
                if s.get("status") == status
            ]
            
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get signals: {str(e)}"
        )

@router.get("/{signal_id}")
async def get_signal(
    signal_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get specific signal details"""
    try:
        # This would fetch signal details
        # For now, return mock data
        return {
            "status": "success",
            "data": {
                "id": signal_id,
                "instrument_token": "NSE_EQ|INE467B01029",
                "tradingsymbol": "RELIANCE",
                "signal_type": "BUY",
                "confidence": 0.85,
                "reason": "Breakout above resistance with volume confirmation",
                "parameters": {
                    "price": 2500.50,
                    "target": 2600.00,
                    "stop_loss": 2450.00
                },
                "status": "PENDING",
                "generated_at": "2024-01-15T10:30:00Z"
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get signal: {str(e)}"
        )

@router.post("/{signal_id}/execute")
async def execute_signal(
    signal_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Execute a market signal"""
    try:
        result = await ai_service.execute_market_signal(db, signal_id, current_user["id"])
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to execute signal: {str(e)}"
        )

@router.post("/{signal_id}/dismiss")
async def dismiss_signal(
    signal_id: int,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Dismiss a market signal"""
    try:
        # Update signal status
        # This would be implemented in the service
        return {
            "status": "success",
            "message": "Signal dismissed successfully"
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to dismiss signal: {str(e)}"
        )