"""
Authentication Router - Handles user authentication, registration, and token management
"""

from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.security import HTTPBearer
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from typing import Optional
from pydantic import BaseModel, EmailStr

from database.connection import get_db
from models.user import User, Session as SessionModel, AuditLog
from utils.auth import (
    verify_password, 
    get_password_hash, 
    create_access_token, 
    create_refresh_token,
    decode_token
)

import logging
import secrets
import json
import subprocess
import sys
from pathlib import Path

# Configure logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/auth", tags=["Authentication"])
security = HTTPBearer(auto_error=False)


# Request/Response Models
class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    name: Optional[str] = None
    phone: Optional[str] = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class LaunchLoginRequest(BaseModel):
    start_index: int = 0  # Start from API index (0=all, 1=skip primary)


# ==========================================================================
# REGISTRATION
# ==========================================================================

@router.post("/register", status_code=status.HTTP_201_CREATED)
async def register(
    request: RegisterRequest,
    db: Session = Depends(get_db)
):
    """Register a new user account"""
    try:
        existing_user = db.query(User).filter(User.email == request.email).first()
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already registered"
            )
        
        user = User(
            email=request.email,
            hashed_password=get_password_hash(request.password),
            name=request.name,
            phone=request.phone,
            is_active=True,
            is_verified=False
        )
        
        db.add(user)
        db.commit()
        db.refresh(user)
        
        access_token = create_access_token(
            data={"sub": str(user.id), "email": user.email, "name": user.name}
        )
        refresh_token = create_refresh_token(
            data={"sub": str(user.id), "email": user.email}
        )
        
        return {
            "status": "success",
            "message": "Registration successful",
            "data": {
                "user": {
                    "id": user.id,
                    "email": user.email,
                    "name": user.name
                },
                "tokens": {
                    "access_token": access_token,
                    "refresh_token": refresh_token,
                    "token_type": "bearer",
                    "expires_in": 3600
                }
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Registration error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Registration failed: {str(e)}"
        )


# ==========================================================================
# LOGIN
# ==========================================================================

@router.post("/login")
async def login(
    request: LoginRequest,
    http_request: Request,
    db: Session = Depends(get_db)
):
    """Authenticate user and return tokens"""
    try:
        user = db.query(User).filter(User.email == request.email).first()
        
        if not user or not verify_password(request.password, user.hashed_password):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password"
            )
        
        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Account is deactivated"
            )
        
        access_token = create_access_token(
            data={
                "sub": str(user.id), 
                "email": user.email, 
                "name": user.name,
                "is_verified": user.is_verified
            }
        )
        refresh_token = create_refresh_token(
            data={"sub": str(user.id), "email": user.email}
        )
        
        session = SessionModel(
            user_id=user.id,
            token=access_token,
            refresh_token=refresh_token,
            ip_address=http_request.client.host if http_request.client else None,
            user_agent=http_request.headers.get("user-agent"),
            is_active=True,
            expires_at=datetime.utcnow() + timedelta(days=7)
        )
        db.add(session)
        db.commit()
        
        return {
            "status": "success",
            "message": "Login successful",
            "data": {
                "user": {
                    "id": user.id,
                    "email": user.email,
                    "name": user.name,
                    "is_verified": user.is_verified,
                    "upstox_linked": user.upstox_access_token is not None
                },
                "tokens": {
                    "access_token": access_token,
                    "refresh_token": refresh_token,
                    "token_type": "bearer",
                    "expires_in": 3600
                }
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Login error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Login failed: {str(e)}"
        )


# ==========================================================================
# LOGOUT
# ==========================================================================

@router.post("/logout")
async def logout(db: Session = Depends(get_db)):
    """Logout user and invalidate session"""
    return {
        "status": "success",
        "message": "Logged out successfully"
    }


# ==========================================================================
# UPSTOX OAUTH
# ==========================================================================

@router.get("/upstox/login-url")
async def get_upstox_login_url():
    """Get Upstox OAuth login URL"""
    from config import settings
    
    if not settings.UPSTOX_CLIENT_ID:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Upstox API not configured"
        )
    
    login_url = (
        f"https://api.upstox.com/v2/login/authorization/dialog"
        f"?response_type=code"
        f"&client_id={settings.UPSTOX_CLIENT_ID}"
        f"&redirect_uri={settings.UPSTOX_REDIRECT_URI}"
    )
    
    return {
        "status": "success",
        "data": {
            "login_url": login_url
        }
    }


@router.get("/upstox/capture-code")
async def capture_code_callback(
    code: str,
    state: Optional[str] = None
):
    """
    Capture callback for multi-login - returns auth code WITHOUT consuming it.
    
    This endpoint is used by the Selenium-based multi-login script.
    Instead of exchanging the code for a token (which would consume it),
    this returns an HTML page with the code embedded for the script to read
    and exchange using the correct API-specific credentials.
    """
    logger.info(f"Capture-code callback received: code={code[:8]}..., state={state}")
    
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Auth Code Captured</title>
        <style>
            body {{ 
                font-family: Arial, sans-serif; 
                text-align: center; 
                padding: 50px; 
                background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                color: #fff;
            }}
            .container {{
                background: rgba(255,255,255,0.1);
                padding: 40px;
                border-radius: 20px;
                max-width: 500px;
                margin: 0 auto;
                backdrop-filter: blur(10px);
            }}
            .success-icon {{ font-size: 60px; margin-bottom: 20px; }}
            .code {{ 
                font-family: monospace; 
                background: rgba(0,0,0,0.3); 
                padding: 10px 20px; 
                border-radius: 8px;
                word-break: break-all;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="success-icon">🔐</div>
            <h1>Authorization Code Captured</h1>
            <p>The multi-login script will process this automatically.</p>
            <div id="auth-code" data-code="{code}" data-state="{state or ''}" class="code">
                {code}
            </div>
        </div>
    </body>
    </html>
    """
    
    return HTMLResponse(content=html_content)


@router.get("/upstox/callback")
async def upstox_callback(
    code: str,
    state: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Handle Upstox OAuth callback - exchange code for access token.
    
    MULTI-LOGIN MODE: If state starts with 'ML:', return HTML with code
    for the Selenium script to extract and exchange with correct credentials.
    
    NORMAL MODE: Exchange code for token using PRIMARY credentials.
    """
    import httpx
    from config import settings
    
    # === MULTI-LOGIN MODE DETECTION ===
    # If state starts with 'ML:', this is from multi-login script
    # Return the code in HTML without consuming it
    if state and state.startswith("ML:"):
        actual_state = state[3:]  # Remove 'ML:' prefix
        logger.info(f"MULTI-LOGIN MODE detected for callback. State: {actual_state}")
        
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Auth Code Captured</title>
            <style>
                body {{ 
                    font-family: Arial, sans-serif; 
                    text-align: center; 
                    padding: 50px; 
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    color: #fff;
                }}
                .container {{
                    background: rgba(255,255,255,0.1);
                    padding: 40px;
                    border-radius: 20px;
                    max-width: 500px;
                    margin: 0 auto;
                    backdrop-filter: blur(10px);
                }}
                .success-icon {{ font-size: 60px; margin-bottom: 20px; }}
                .code {{ 
                    font-family: monospace; 
                    background: rgba(0,0,0,0.3); 
                    padding: 10px 20px; 
                    border-radius: 8px;
                    word-break: break-all;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="success-icon">🔐</div>
                <h1>Authorization Code Captured</h1>
                <p>Multi-login script will process this automatically.</p>
                <div id="auth-code" data-code="{code}" data-state="{actual_state}" class="code">
                    {code}
                </div>
            </div>
        </body>
        </html>
        """
        return HTMLResponse(content=html_content)
    
    # === NORMAL LOGIN MODE ===
    try:
        if not settings.UPSTOX_CLIENT_ID or not settings.UPSTOX_CLIENT_SECRET:
            return HTMLResponse(content="<script>window.opener.postMessage({type: 'LOGIN_ERROR', error: 'Upstox API not configured'}, '*'); window.close();</script>")
        
        # Exchange auth code for access token
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://api.upstox.com/v2/login/authorization/token",
                headers={
                    "accept": "application/json",
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                data={
                    "code": code,
                    "client_id": settings.UPSTOX_CLIENT_ID,
                    "client_secret": settings.UPSTOX_CLIENT_SECRET,
                    "redirect_uri": settings.UPSTOX_REDIRECT_URI,
                    "grant_type": "authorization_code"
                }
            )
            
            if response.status_code != 200:
                logger.error(f"Upstox token exchange failed: {response.text}")
                return HTMLResponse(content=f"<script>window.opener.postMessage({{type: 'LOGIN_ERROR', error: 'Token exchange failed'}}, '*'); window.close();</script>")
            
            token_data = response.json()
        
        access_token = token_data.get("access_token")
        if not access_token:
            return HTMLResponse(content="<script>window.opener.postMessage({type: 'LOGIN_ERROR', error: 'No access token received'}, '*'); window.close();</script>")
            
        # Get User Profile from Upstox
        async with httpx.AsyncClient() as client:
            profile_response = await client.get(
                "https://api.upstox.com/v2/user/profile",
                headers={
                    "Authorization": f"Bearer {access_token}",
                    "Accept": "application/json"
                }
            )
            
            if profile_response.status_code != 200:
                return HTMLResponse(content="<script>window.opener.postMessage({type: 'LOGIN_ERROR', error: 'Failed to fetch user profile'}, '*'); window.close();</script>")
            
            profile_data = profile_response.json().get("data", {})
            
        upstox_email = profile_data.get("email")
        upstox_user_id = profile_data.get("user_id")
        upstox_name = profile_data.get("user_name")
        
        if not upstox_email:
             return HTMLResponse(content="<script>window.opener.postMessage({type: 'LOGIN_ERROR', error: 'Could not retrieve email from Upstox'}, '*'); window.close();</script>")

        # Find or Create User
        user = db.query(User).filter(User.email == upstox_email).first()
        
        if not user:
            user = User(
                email=upstox_email,
                name=upstox_name,
                hashed_password=get_password_hash(secrets.token_urlsafe(16)),
                is_active=True,
                is_verified=True,
                upstox_user_id=upstox_user_id,
                upstox_user_name=upstox_name,
                upstox_access_token=access_token,
                upstox_linked_at=datetime.utcnow()
            )
            db.add(user)
            db.flush()
        else:
            user.upstox_access_token = access_token
            user.upstox_user_id = upstox_user_id
            user.upstox_user_name = upstox_name
            user.upstox_linked_at = datetime.utcnow()
            
        db.commit()
        db.refresh(user)
        
        # ===== Save PRIMARY token to upstox_tokens table =====
        try:
            from models.upstox_token import UpstoxToken, API_CONFIG
            
            now = datetime.now()
            if now.hour >= 3:
                validity_at = (now + timedelta(days=1)).replace(hour=3, minute=0, second=0, microsecond=0)
            else:
                validity_at = now.replace(hour=3, minute=0, second=0, microsecond=0)
            
            existing_token = db.query(UpstoxToken).filter(
                UpstoxToken.user_id == user.id,
                UpstoxToken.api_index == 0
            ).first()
            
            if existing_token:
                existing_token.access_token = access_token
                existing_token.client_id = settings.UPSTOX_CLIENT_ID
                existing_token.generated_at = now
                existing_token.validity_at = validity_at
                existing_token.is_active = True
                logger.info(f"Updated PRIMARY token for user {user.id}")
            else:
                new_token = UpstoxToken(
                    user_id=user.id,
                    api_index=0,
                    api_name="PRIMARY",
                    client_id=settings.UPSTOX_CLIENT_ID,
                    access_token=access_token,
                    token_type="Bearer",
                    purpose="primary",
                    is_active=True,
                    generated_at=now,
                    validity_at=validity_at
                )
                db.add(new_token)
                logger.info(f"Created PRIMARY token for user {user.id}")
            
            db.commit()
        except Exception as token_error:
            logger.error(f"Error saving PRIMARY token to DB: {token_error}")
        # ===== End token save =====

        # Generate Application Tokens (JWT)
        app_access_token = create_access_token(
            data={
                "sub": str(user.id), 
                "email": user.email, 
                "name": user.name,
                "is_verified": user.is_verified
            }
        )
        refresh_token = create_refresh_token(
            data={"sub": str(user.id), "email": user.email}
        )
        
        user_data = {
            "id": user.id,
            "email": user.email,
            "name": user.name,
            "upstox_linked": True
        }
        
        # HTML Response
        html_content = f"""
        <!DOCTYPE html>
        <html>
            <head>
                <title>Login Successful</title>
                <style>
                    body {{ font-family: Arial, sans-serif; text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }}
                    .container {{ background: rgba(255,255,255,0.1); padding: 40px; border-radius: 20px; max-width: 400px; margin: 0 auto; backdrop-filter: blur(10px); }}
                    h1 {{ margin-bottom: 20px; }}
                    .success-icon {{ font-size: 60px; margin-bottom: 20px; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="success-icon">✅</div>
                    <h1>Login Successful!</h1>
                    <p id="status">Processing...</p>
                </div>
                <script>
                    if (window.opener && !window.opener.closed) {{
                        try {{
                            window.opener.postMessage({{
                                type: 'LOGIN_SUCCESS',
                                token: '{app_access_token}',
                                refresh_token: '{refresh_token}',
                                user: {json.dumps(user_data)}
                            }}, '*');
                            document.getElementById('status').textContent = 'Redirecting...';
                            setTimeout(function() {{ window.close(); }}, 1000);
                        }} catch(e) {{
                            document.getElementById('status').textContent = 'Authenticated! You can close this window.';
                        }}
                    }} else {{
                        document.getElementById('status').textContent = 'Token generated! This window will be handled by automation.';
                    }}
                </script>
            </body>
        </html>
        """
        
        return HTMLResponse(content=html_content)
        
    except Exception as e:
        logger.error(f"Upstox callback error: {e}")
        return HTMLResponse(content=f"<script>window.opener.postMessage({{type: 'LOGIN_ERROR', error: '{str(e)}'}}, '*'); window.close();</script>")


@router.get("/upstox/tokens/db-status")
async def get_db_token_status(
    db: Session = Depends(get_db)
):
    """
    Get the status of Upstox tokens from the database.
    Returns which APIs have valid tokens for the navbar button logic.
    Enhanced with PRIMARY token expiry detection.
    """
    try:
        from models.upstox_token import UpstoxToken, API_CONFIG
        
        tokens = db.query(UpstoxToken).filter(UpstoxToken.is_active == True).all()
        token_map = {t.api_index: t for t in tokens}
        
        now = datetime.now()
        api_statuses = []
        valid_count = 0
        
        # Track PRIMARY token specifically
        primary_token = token_map.get(0)
        primary_expired = False
        primary_expiry = None
        
        for idx in range(6):
            config = API_CONFIG.get(idx, {})
            token = token_map.get(idx)
            
            has_token = token is not None
            is_valid = False
            
            if token and token.validity_at:
                is_valid = token.validity_at > now
            elif token:
                if token.generated_at:
                    is_valid = token.generated_at.date() == now.date()
                else:
                    is_valid = True
            
            # Track PRIMARY token expiry
            if idx == 0 and has_token:
                primary_expired = not is_valid
                primary_expiry = token.validity_at.isoformat() if token.validity_at else None
            
            if is_valid:
                valid_count += 1
            
            api_statuses.append({
                "api_index": idx,
                "api_name": config.get("name", f"API_{idx}"),
                "purpose": config.get("purpose", "unknown"),
                "description": config.get("description", ""),
                "has_token": has_token,
                "is_valid": is_valid,
                "generated_at": token.generated_at.isoformat() if token and token.generated_at else None,
                "validity_at": token.validity_at.isoformat() if token and token.validity_at else None
            })
        
        missing_count = 6 - valid_count
        has_primary = primary_token is not None and not primary_expired
        
        return {
            "status": "success",
            "data": {
                "tokens": api_statuses,
                "total": 6,
                "valid_count": valid_count,
                "missing_count": missing_count,
                "all_valid": valid_count == 6,
                "has_primary": has_primary,
                "primary_expired": primary_expired,
                "primary_expiry": primary_expiry
            }
        }
    except Exception as e:
        logger.error(f"DB Token status error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get token status: {str(e)}"
        )


@router.get("/upstox/token")
async def get_upstox_token(
    db: Session = Depends(get_db)
):
    """
    Get the PRIMARY Upstox access token from the database.
    Used by frontend to auto-login after multi-login generates tokens.
    """
    try:
        from models.upstox_token import UpstoxToken
        
        # Get PRIMARY token (api_index = 0)
        primary_token = db.query(UpstoxToken).filter(
            UpstoxToken.api_index == 0,
            UpstoxToken.is_active == True
        ).first()
        
        if not primary_token:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No PRIMARY token found in database"
            )
        
        # Check if token is still valid
        now = datetime.now()
        is_valid = primary_token.validity_at > now if primary_token.validity_at else False
        
        if not is_valid:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="PRIMARY token has expired"
            )
        
        return {
            "status": "success",
            "access_token": primary_token.access_token,
            "token_type": "Bearer",
            "api_name": primary_token.api_name,
            "generated_at": primary_token.generated_at.isoformat() if primary_token.generated_at else None,
            "validity_at": primary_token.validity_at.isoformat() if primary_token.validity_at else None
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get token error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get token: {str(e)}"
        )

@router.post("/upstox/automated-single-login")
async def automated_single_login(
    db: Session = Depends(get_db)
):
    """
    Launch the login.py script to generate PRIMARY token only (automated).
    This runs login.py --single which opens Chrome and automates the login.
    """
    try:
        project_root = Path(__file__).parent.parent.parent
        login_script = project_root / "backend" / "upstox_auth" / "login.py"
        
        if not login_script.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"login.py script not found at {login_script}"
            )
        
        cmd = [
            sys.executable,
            str(login_script),
            "--mode", "single"
        ]
        
        logger.info(f"Launching single login script: {' '.join(cmd)}")
        
        # Start subprocess in background (no new console window)
        # Output goes to backend console for debugging
        process = subprocess.Popen(
            cmd,
            cwd=str(project_root),
            stdout=None,
            stderr=None
        )
        
        return {
            "status": "success",
            "message": "Single login script launched. Please complete the login in the Chrome window.",
            "data": {
                "process_id": process.pid,
                "mode": "single",
                "script_path": str(login_script)
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error launching single login script: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to launch single login script: {str(e)}"
        )


@router.post("/upstox/launch-remaining-login")
async def launch_remaining_login(
    request: LaunchLoginRequest = LaunchLoginRequest(),
    db: Session = Depends(get_db)
):
    """
    Launch the login.py script to generate tokens for remaining APIs.
    This runs login.py as a subprocess which opens a Chrome window for the user.
    """
    try:
        project_root = Path(__file__).parent.parent.parent
        login_script = project_root / "backend" / "upstox_auth" / "login.py"
        
        if not login_script.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"login.py script not found at {login_script}"
            )
        
        cmd = [
            sys.executable,
            str(login_script),
            "--mode", "multi",
            "--start-index", str(request.start_index)
        ]
        
        logger.info(f"Launching login script: {' '.join(cmd)}")
        
        # Start subprocess in background (no new console window)
        # Output goes to backend console for debugging
        process = subprocess.Popen(
            cmd,
            cwd=str(project_root),
            # Don't redirect - let output go to backend console
            stdout=None,
            stderr=None
        )
        
        return {
            "status": "success",
            "message": "Login script launched. Please complete the login in the Chrome window.",
            "data": {
                "process_id": process.pid,
                "start_index": request.start_index,
                "script_path": str(login_script)
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error launching login script: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to launch login script: {str(e)}"
        )
