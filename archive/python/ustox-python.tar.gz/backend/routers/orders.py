"""
Orders Router - Handles order placement, modification, and management
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from typing import Dict, Any, List, Optional
from database.connection import get_db
from middleware.auth import get_current_user
from models.trading import Order, Instrument
from services.order_service import order_service
from schemas.order import OrderRequest, OrderUpdateRequest, BatchOrderRequest

router = APIRouter(prefix="/api/v1/orders", tags=["Orders"])
security = HTTPBearer()

# ==========================================================================
# ORDER PLACEMENT
# ==========================================================================

@router.post("/place")
async def place_order(
    order_request: OrderRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Place a new order"""
    try:
        # Validate instrument
        instrument = db.query(Instrument).filter(
            Instrument.instrument_token == order_request.instrument_token
        ).first()
        
        if not instrument:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid instrument token"
            )
            
        # Prepare order data
        order_data = {
            "instrument_token": order_request.instrument_token,
            "transaction_type": order_request.transaction_type,
            "quantity": order_request.quantity,
            "order_type": order_request.order_type,
            "product": order_request.product,
            "validity": order_request.validity,
            "price": order_request.price,
            "trigger_price": order_request.trigger_price,
            "disclosed_quantity": order_request.disclosed_quantity,
            "tag": order_request.tag,
            "is_amo": order_request.is_amo
        }
        
        # Place order
        result = await order_service.place_order(db, current_user["id"], order_data)
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to place order: {str(e)}"
        )

@router.post("/batch")
async def place_batch_orders(
    batch_request: BatchOrderRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Place multiple orders in batch"""
    try:
        # Validate all instruments
        for order_req in batch_request.orders:
            instrument = db.query(Instrument).filter(
                Instrument.instrument_token == order_req.instrument_token
            ).first()
            
            if not instrument:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid instrument token: {order_req.instrument_token}"
                )
                
        # Prepare orders list
        orders_list = []
        for order_req in batch_request.orders:
            order_data = {
                "instrument_token": order_req.instrument_token,
                "transaction_type": order_req.transaction_type,
                "quantity": order_req.quantity,
                "order_type": order_req.order_type,
                "product": order_req.product,
                "validity": order_req.validity,
                "price": order_req.price,
                "trigger_price": order_req.trigger_price,
                "disclosed_quantity": order_req.disclosed_quantity,
                "tag": order_req.tag,
                "is_amo": order_req.is_amo
            }
            orders_list.append(order_data)
            
        # Execute batch orders
        result = await order_service.execute_batch_orders(db, current_user["id"], orders_list)
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to place batch orders: {str(e)}"
        )

# ==========================================================================
# ORDER MANAGEMENT
# ==========================================================================

@router.get("")
async def get_orders(
    status: Optional[str] = Query(None, description="Filter by order status"),
    limit: int = Query(50, ge=1, le=100, description="Number of orders to return"),
    offset: int = Query(0, ge=0, description="Offset for pagination"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get user's orders with optional filtering"""
    try:
        result = await order_service.get_orders(
            db, current_user["id"], status, limit, offset
        )
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get orders: {str(e)}"
        )

@router.get("/{order_id}")
async def get_order(
    order_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get single order by ID"""
    try:
        result = await order_service.get_order_by_id(db, current_user["id"], order_id)
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get order: {str(e)}"
        )

@router.put("/{order_id}")
async def modify_order(
    order_id: str,
    order_update: OrderUpdateRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Modify an existing order"""
    try:
        modifications = {
            "quantity": order_update.quantity,
            "price": order_update.price,
            "trigger_price": order_update.trigger_price,
            "validity": order_update.validity,
            "disclosed_quantity": order_update.disclosed_quantity
        }
        
        # Remove None values
        modifications = {k: v for k, v in modifications.items() if v is not None}
        
        result = await order_service.modify_order(
            db, current_user["id"], order_id, modifications
        )
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to modify order: {str(e)}"
        )

@router.post("/{order_id}/cancel")
async def cancel_order(
    order_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Cancel an order"""
    try:
        result = await order_service.cancel_order(db, current_user["id"], order_id)
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to cancel order: {str(e)}"
        )

# ==========================================================================
# ORDER STATUS SYNC
# ==========================================================================

@router.post("/{order_id}/sync")
async def sync_order_status(
    order_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Sync order status with Upstox"""
    try:
        result = await order_service.sync_order_status(db, current_user["id"], order_id)
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to sync order status: {str(e)}"
        )

# ==========================================================================
# TRADES
# ==========================================================================

@router.get("/trades")
async def get_trades(
    order_id: Optional[str] = Query(None, description="Filter by order ID"),
    limit: int = Query(50, ge=1, le=100, description="Number of trades to return"),
    offset: int = Query(0, ge=0, description="Offset for pagination"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get user's trades with optional filtering"""
    try:
        result = await order_service.get_trades(
            db, current_user["id"], order_id, limit, offset
        )
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get trades: {str(e)}"
        )

# ==========================================================================
# UTILITY ENDPOINTS
# ==========================================================================

@router.post("/{order_id}/margin")
async def calculate_order_margin(
    order_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Calculate margin required for an order"""
    try:
        # Get order details
        order = db.query(Order).filter(
            Order.user_id == current_user["id"],
            Order.order_id == order_id
        ).first()
        
        if not order:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Order not found"
            )
            
        # Prepare order data for margin calculation
        order_data = {
            "quantity": order.quantity,
            "price": order.price or 0,
            "product": order.product
        }
        
        result = await order_service.calculate_order_margin(db, current_user["id"], order_data)
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to calculate margin: {str(e)}"
        )

@router.get("/positions")
async def get_positions(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get user's open positions"""
    try:
        # This would integrate with portfolio service
        # For now, return empty response
        return {
            "status": "success",
            "data": {
                "positions": [],
                "total_pnl": 0,
                "total_value": 0
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get positions: {str(e)}"
        )

@router.get("/holdings")
async def get_holdings(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get user's holdings"""
    try:
        # This would integrate with portfolio service
        # For now, return empty response
        return {
            "status": "success",
            "data": {
                "holdings": [],
                "total_value": 0,
                "total_pnl": 0
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get holdings: {str(e)}"
        )

# ==========================================================================
# ORDER VALIDATION
# ==========================================================================

@router.post("/validate")
async def validate_order(
    order_request: OrderRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Validate order parameters without placing it"""
    try:
        errors = []
        warnings = []
        
        # Validate instrument
        instrument = db.query(Instrument).filter(
            Instrument.instrument_token == order_request.instrument_token
        ).first()
        
        if not instrument:
            errors.append("Invalid instrument token")
            
        # Validate quantity
        if order_request.quantity <= 0:
            errors.append("Quantity must be greater than 0")
            
        if instrument and order_request.quantity % instrument.lot_size != 0:
            warnings.append(f"Quantity should be in multiples of lot size ({instrument.lot_size})")
            
        # Validate price for limit orders
        if order_request.order_type == "LIMIT":
            if not order_request.price:
                errors.append("Price is required for LIMIT orders")
            elif order_request.price <= 0:
                errors.append("Price must be greater than 0")
                
        # Validate trigger price for stop orders
        if order_request.order_type in ["SL", "SL-M"]:
            if not order_request.trigger_price:
                errors.append("Trigger price is required for stop orders")
                
        # Check if user has sufficient funds (simplified)
        # In real implementation, this would check actual margin requirements
        
        return {
            "status": "success",
            "data": {
                "valid": len(errors) == 0,
                "errors": errors,
                "warnings": warnings,
                "estimated_margin": 0,  # This would be calculated
                "estimated_brokerage": 0  # This would be calculated
            }
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to validate order: {str(e)}"
        )