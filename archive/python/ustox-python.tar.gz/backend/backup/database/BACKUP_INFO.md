# Database Module Backup
# Created: 2025-12-26T10:32:32+05:30

## Directory: database/

### Files

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `connection.py` | SQLAlchemy connection | `DatabaseConfig.java` |
| `connection.py` (MockRedis) | In-memory cache | `InMemoryCache.java` |

### Subdirectory: database/db/

Contains SQLite database file `vegatrade.db`

---

## Java Equivalent Location

`backend/java/vega-trader/src/main/java/com/vegatrader/`
- `config/DatabaseConfig.java` - DataSource config
- `cache/InMemoryCache.java` - Mock Redis
- JPA auto-creates tables via entities

## Configuration

`application.properties`:
```properties
spring.datasource.url=jdbc:sqlite:database/db/db/vegatrade.db
spring.jpa.hibernate.ddl-auto=update
```
