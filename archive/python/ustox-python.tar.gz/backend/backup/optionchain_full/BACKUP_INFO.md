# Option Chain Backend Backup Info
# Created: 2025-12-26T02:27:00+05:30

## Backup Contents

Complete backup of Python option chain backend before Java migration.

---

## Files Backed Up

### optionchain_ws Module

| Original Path | Backup Path | Lines | Description |
|--------------|-------------|-------|-------------|
| `optionchain_ws/__init__.py` | `optionchain_ws/__init__.py` | 35 | Module exports |
| `optionchain_ws/optionchain_ws.py` | `optionchain_ws/optionchain_ws.py` | 60 | Service entry point |
| `optionchain_ws/helper/__init__.py` | `optionchain_ws/helper/__init__.py` | 10 | Helper exports |
| `optionchain_ws/helper/option_chain_background.py` | `optionchain_ws/helper/option_chain_background.py` | 389 | Background fetcher |
| `optionchain_ws/helper/oc_cache/__init__.py` | `optionchain_ws/helper/oc_cache/__init__.py` | 7 | Cache exports |
| `optionchain_ws/helper/oc_cache/oc_cache.py` | `optionchain_ws/helper/oc_cache/oc_cache.py` | 164 | Thread-safe cache |

### Routers

| Original Path | Backup Path | Lines | Description |
|--------------|-------------|-------|-------------|
| `routers/options.py` | `routers/options.py` | 430 | REST API endpoints |

### Server WebSocket

| Original Path | Backup Path | Lines | Description |
|--------------|-------------|-------|-------------|
| `server/websocket/handlers.py` | `server/websocket/handlers.py` | 174 | WS message handlers |

### Helpers

| Original Path | Backup Path | Lines | Description |
|--------------|-------------|-------|-------------|
| `helpers/instruments/options.py` | `helpers/instruments/options.py` | 261 | DB query helper |

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          OPTION CHAIN BACKEND                            │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌─────────────────────┐    ┌─────────────────────────────────────┐     │
│  │  routers/options.py │    │  server/websocket/handlers.py       │     │
│  │  REST API Endpoints │    │  WebSocket Message Handlers          │     │
│  │  - GET /underlyings │    │  - subscribe_option_chain            │     │
│  │  - GET /expiries    │    │  - unsubscribe_option_chain          │     │
│  │  - GET /chain       │    │                                       │     │
│  │  - GET /contracts   │    │                                       │     │
│  └─────────┬───────────┘    └────────────────┬──────────────────────┘     │
│            │                                  │                           │
│            └──────────────┬───────────────────┘                           │
│                           │                                               │
│            ┌──────────────▼────────────────────┐                         │
│            │      optionchain_ws/              │                         │
│            │  ┌────────────────────────────┐   │                         │
│            │  │ OptionChainBackgroundService│   │                         │
│            │  │  - Continuous polling       │   │                         │
│            │  │  - Upstox API calls         │   │                         │
│            │  │  - Data transformation      │   │                         │
│            │  │  - Valuation calculation    │   │                         │
│            │  └─────────────┬──────────────┘   │                         │
│            │                │                   │                         │
│            │  ┌─────────────▼──────────────┐   │                         │
│            │  │    OptionChainCache        │   │                         │
│            │  │  - Thread-safe storage     │   │                         │
│            │  │  - TTL-based expiry        │   │                         │
│            │  │  - Instrument/expiry keys  │   │                         │
│            │  └────────────────────────────┘   │                         │
│            └───────────────────────────────────┘                         │
│                                                                          │
│            ┌───────────────────────────────────┐                         │
│            │  helpers/instruments/options.py   │                         │
│            │  - Database queries               │                         │
│            │  - Instrument key extraction      │                         │
│            └───────────────────────────────────┘                         │
│                                                                          │
│            ┌───────────────────────────────────┐                         │
│            │  services/valuation_calculator.py │  ← Backed up separately │
│            │  config/valuation_config.py       │    in backup/valuation_ │
│            └───────────────────────────────────┘    calculator/          │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Key Dependencies

### External Dependencies (pip)
- `fastapi` - Web framework
- `sqlalchemy` - Database ORM
- `requests` - HTTP client for Upstox API
- `numpy`, `scipy` - Numerical calculations

### Internal Dependencies

| File | Depends On |
|------|------------|
| `optionchain_ws.py` | `helper/option_chain_background.py`, `helper/oc_cache/` |
| `option_chain_background.py` | `oc_cache.py`, `valuation_calculator.py`, `websocket_manager` |
| `routers/options.py` | `valuation_calculator.py`, `optionchain_ws`, `instrument_models` |
| `server/websocket/handlers.py` | `optionchain_ws` (oc_cache) |

---

## Configuration Used

From `config/valuation_config.py`:
- `RISK_FREE_RATE`: 0.07 (7%)
- `OVERVALUED_THRESHOLD_PCT`: 5.0%
- `VALUATION_CACHE_TTL_SEC`: 30 seconds

---

## Java Migration

After Java migration, see:
- `backend/java/optionchain/` - New Java implementation
- `backend/java/optionchain/docs/` - Java documentation
