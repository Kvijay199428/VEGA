# Upstox Auth Module Backup
# Created: 2025-12-26T10:32:32+05:30

## Directory: upstox_auth/upstox/

### Files

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `auth_flow.py` | OAuth authentication flow | `UpstoxAuthService.java` |
| `multi_login.py` | Multi-API token generation | `UpstoxAuthService.java` |
| `single_login.py` | Single account login | `UpstoxAuthService.java` |
| `token_manager.py` | Token storage & refresh | `UpstoxTokenRepository.java` |
| `selenium_driver.py` | Browser automation for login | N/A (Manual flow in Java) |

---

## Directory: upstox_auth/helpers/

### Files

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `api_client.py` | Upstox API HTTP client | `UpstoxClient.java` |
| `token_utils.py` | Token utilities | `JwtUtil.java` |

---

## Java Equivalent Location

`backend/java/vega-trader/src/main/java/com/vegatrader/`
- `service/UpstoxAuthService.java`
- `client/UpstoxClient.java`
- `security/JwtUtil.java`
- `repository/UpstoxTokenRepository.java`
