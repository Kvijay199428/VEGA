# Server Module Backup
# Created: 2025-12-26T10:32:32+05:30

## Directory: server/

### Files

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `app.py` | FastAPI application setup | `VegaTraderApplication.java` |

### Subdirectory: server/helpers/

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `instrument_sync.py` | Instrument download/sync | `InstrumentSyncService.java` |
| `lifespan.py` | App startup/shutdown | `@PostConstruct/@PreDestroy` |
| `logging_config.py` | Logging configuration | `application.properties` |

### Subdirectory: server/websocket/

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `handlers.py` | WebSocket handlers | `MarketDataWebSocketHandler.java` |

---

## Java Equivalent Location

- `VegaTraderApplication.java` - Main app
- `config/WebSocketConfig.java` - WS config
- `service/InstrumentSyncService.java` - Sync
