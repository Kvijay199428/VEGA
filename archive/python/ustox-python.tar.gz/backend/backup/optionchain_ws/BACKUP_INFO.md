# Option Chain WebSocket Module Backup
# Created: 2025-12-26T10:32:32+05:30

## Directory: optionchain_ws/

### Files

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `optionchain_ws.py` | Main WebSocket handler | `optionchain` project |

### Subdirectory: helper/

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `option_chain_background.py` | Background polling | `OptionChainBackgroundService.java` |

### Subdirectory: helper/oc_cache/

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `oc_cache.py` | Option chain cache | `OptionChainCache.java` |

---

## Java Equivalent Location

`backend/java/optionchain/` (Separate Spring Boot project)
- Port: 8081
- WebSocket: `ws://localhost:8081/ws/optionchain`
