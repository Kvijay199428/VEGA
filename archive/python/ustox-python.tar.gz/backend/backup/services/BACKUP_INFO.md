# Services Module Backup
# Created: 2025-12-26T10:32:32+05:30

## Directory: services/

### Files

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `ai_service.py` | AI/ML integration | `AiService.java` (future) |
| `instrument_search.py` | Instrument search | `InstrumentSearchService.java` |
| `instrument_service.py` | Instrument master | `InstrumentMasterService.java` |
| `market_data_background.py` | Background polling | `MarketDataBackgroundService.java` |
| `market_data_websocket.py` | WebSocket client | `MarketDataWebSocketService.java` |
| `order_service.py` | Order management | `OrderService.java` |
| `portfolio_service.py` | Portfolio tracking | `PortfolioService.java` |
| `subscription_settings_service.py` | Subscription mgmt | `SubscriptionSettingsService.java` |
| `upstox_service.py` | Upstox API wrapper | `UpstoxClient.java` |
| `valuation_calculator.py` | Options valuation | `valuation-calculator` project |

---

## Java Equivalent Location

`backend/java/vega-trader/src/main/java/com/vegatrader/service/`
