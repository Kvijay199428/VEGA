# Models Module Backup
# Created: 2025-12-26T10:32:32+05:30

## Directory: models/

### Files (SQLAlchemy Models → JPA Entities)

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `user.py` | User model | `User.java` |
| `upstox_token.py` | Token storage | `UpstoxToken.java` |
| `trading.py` | Order/Position models | `TradingOrder.java`, `TradingPosition.java` |
| `ai_strategy.py` | AI strategies | `AiStrategy.java` |
| `subscription_settings.py` | Subscriptions | `SubscriptionSettings.java` |
| `instrument_models.py` | Instruments | `OptionsInstrument.java` |

---

## Java Equivalent Location

`backend/java/vega-trader/src/main/java/com/vegatrader/model/entity/`
