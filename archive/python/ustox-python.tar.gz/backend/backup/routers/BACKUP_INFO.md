# Routers Module Backup
# Created: 2025-12-26T10:32:32+05:30

## Directory: routers/

### Files (FastAPI Routers → Spring Controllers)

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `auth.py` | Authentication | `AuthController.java` |
| `gtt.py` | GTT orders | `GttController.java` |
| `indicators.py` | Technical indicators | `IndicatorController.java` |
| `instruments.py` | Instruments | `InstrumentController.java` |
| `market.py` | Market data | `MarketController.java` |
| `options.py` | Options chain | `optionchain` project |
| `orders.py` | Order management | `OrderController.java` |
| `portfolio.py` | Portfolio | `PortfolioController.java` |
| `settings.py` | User settings | `SettingsController.java` |
| `signals.py` | Trading signals | `SignalController.java` |
| `strategies.py` | AI strategies | `StrategyController.java` |
| `user.py` | User profile | `UserController.java` |
| `webhooks.py` | Webhooks | `WebhookController.java` |

---

## Java Equivalent Location

`backend/java/vega-trader/src/main/java/com/vegatrader/controller/`
