# Middleware Module Backup
# Created: 2025-12-26T10:32:32+05:30

## Directory: middleware/

### Files

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `auth.py` | Auth middleware | `JwtAuthenticationFilter.java` |
| `websocket.py` | WS middleware | `WebSocketConfig.java` |

### Subdirectory: helper/

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `market_data_decoder.py` | Binary decoder | `MarketDataDecoder.java` |

---

## Java Equivalent Location

`backend/java/vega-trader/src/main/java/com/vegatrader/`
- `security/JwtAuthenticationFilter.java`
- `security/SecurityConfig.java`
- `config/WebSocketConfig.java`
- `util/MarketDataDecoder.java`
