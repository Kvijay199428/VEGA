# App Utils Module Backup
# Created: 2025-12-26T10:32:32+05:30

## Directory: app/utils/

### Files

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `upstox_errors.py` | Error code handling | `UpstoxErrors.java` |

---

## Java Equivalent Location

`backend/java/vega-trader/src/main/java/com/vegatrader/util/`
- `UpstoxErrors.java` - Error code mapping
- `MarketDataDecoder.java` - Data decoding

## Error Codes Handled

| Code | Description |
|------|-------------|
| UDAPI10001 | Invalid request |
| UDAPI10002 | Invalid API key |
| UDAPI10003 | Invalid access token |
| UDAPI10004 | Token expired |
| UDAPI100057 | Invalid state |
| UDAPI100068 | Invalid redirect URI |
