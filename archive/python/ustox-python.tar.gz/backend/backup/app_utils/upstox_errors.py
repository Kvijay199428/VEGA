"""
Upstox API Error Handler
Handles all Upstox-specific error codes and provides user-friendly messages
"""

class UpstoxError(Exception):
    """Base exception for Upstox API errors"""
    def __init__(self, error_code: str, message: str, status_code: int = 400):
        self.error_code = error_code
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)

# Error code mappings with user-friendly messages
UPSTOX_ERROR_MESSAGES = {
    # ============================================
    # HTTP 4XX Error Codes
    # ============================================
    "HTTP_400": {
        "message": "Bad Request: Your request parameters are incorrect.",
        "severity": "error",
        "status_code": 400
    },
    "HTTP_401": {
        "message": "Unauthorized: Your API key is wrong or missing.",
        "severity": "error",
        "status_code": 401
    },
    "HTTP_403": {
        "message": "Forbidden: The requested resource is hidden for administrators only.",
        "severity": "error",
        "status_code": 403
    },
    "HTTP_404": {
        "message": "Not Found: The specified resource could not be found.",
        "severity": "warning",
        "status_code": 404
    },
    "HTTP_405": {
        "message": "Method Not Allowed: You tried to access a resource with an invalid method.",
        "severity": "error",
        "status_code": 405
    },
    "HTTP_406": {
        "message": "Not Acceptable: You requested a format that isn't json.",
        "severity": "error",
        "status_code": 406
    },
    "HTTP_410": {
        "message": "Gone: The resource requested has been removed from our servers.",
        "severity": "warning",
        "status_code": 410
    },
    "HTTP_429": {
        "message": "Too Many Requests: You're requesting too many resources! Slow down!",
        "severity": "warning",
        "status_code": 429
    },
    
    # ============================================
    # Common API Error Codes (4XX Responses)
    # ============================================
    "UDAPI1000": {
        "message": "This request is not supported by Upstox API.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI100016": {
        "message": "Invalid credentials. Please check your login details.",
        "severity": "error",
        "status_code": 401
    },
    "UDAPI10005": {
        "message": "Too many requests sent. Please wait and try again.",
        "severity": "warning",
        "status_code": 429
    },
    "UDAPI100015": {
        "message": "API version does not exist. Please contact support.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI100050": {
        "message": "Invalid token used to access API. Please login again.",
        "severity": "error",
        "status_code": 401
    },
    "UDAPI100067": {
        "message": "The API you are trying to access is not permitted with an extended_token.",
        "severity": "warning",
        "status_code": 403
    },
    "UDAPI100036": {
        "message": "Invalid input provided. Please check your request.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI100038": {
        "message": "Invalid input passed to the API. Please verify your data.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI100073": {
        "message": "Your 'client_id' is inactive. Please contact support.",
        "severity": "error",
        "status_code": 403
    },
    "UDAPI100500": {
        "message": "Something went wrong... please contact support.",
        "severity": "error",
        "status_code": 500
    },
    
    # ============================================
    # Login API Error Codes
    # ============================================
    "UDAPI100068": {
        "message": "Check your 'client_id' and 'redirect_uri'; one or both are incorrect.",
        "severity": "error",
        "status_code": 401
    },
    "UDAPI100069": {
        "message": "Check your 'client_id' and 'client_secret'; one or both are incorrect.",
        "severity": "error",
        "status_code": 401
    },
    "UDAPI100070": {
        "message": "The 'redirect_uri' provided is invalid.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI100057": {
        "message": "Invalid authorization code. Please login again.",
        "severity": "error",
        "status_code": 401
    },
    
    # ============================================
    # Place Order V3 API Error Codes
    # ============================================
    "UDAPI1026": {
        "message": "Instrument key is required.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI1004": {
        "message": "Valid order type is required.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI1056": {
        "message": "The 'order_type' is invalid.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI1055": {
        "message": "The 'validity' is invalid.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI1008": {
        "message": "Price is required for this order type.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI100049": {
        "message": "Access to this API has been restricted for your account.",
        "severity": "error",
        "status_code": 403
    },
    "UDAPI1052": {
        "message": "The order 'quantity' cannot be zero.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI1040": {
        "message": "Price not required for this order type.",
        "severity": "warning",
        "status_code": 400
    },
    "UDAPI1043": {
        "message": "The 'price' is required for this order type.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI1041": {
        "message": "The 'price' and 'trigger_price' both are required.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI1042": {
        "message": "Only 'trigger_price' is required for this order type.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI1037": {
        "message": "Trigger price should be less than limit price.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI100074": {
        "message": "The Place order API is accessible from 5:30 AM to 12:00 AM IST daily.",
        "severity": "info",
        "status_code": 503
    },
    "UDAPI1118": {
        "message": "Maximum order limit exceeded.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI1119": {
        "message": "Tag length exceeds limit.",
        "severity": "error",
        "status_code": 400
    },
    
    # ============================================
    # Place Multi Order API Error Codes
    # ============================================
    "UDAPI1114": {
        "message": "Request payload should have at least one order line.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI1115": {
        "message": "Missing correlation_id.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI1116": {
        "message": "Invalid correlation_id: Length must be between 1 and 20 characters.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI1117": {
        "message": "Duplicate correlation_id found.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI1054": {
        "message": "The 'product' is invalid.",
        "severity": "error",
        "status_code": 400
    },
    
    # ============================================
    # Legacy/Additional Error Codes
    # ============================================
    "UDAPI10000": {
        "message": "Invalid API request. Please try again.",
        "severity": "error",
        "status_code": 400
    },
    "UDAPI100072": {
        "message": "This service is only available during market hours (5:30 AM - 12:00 AM IST).",
        "severity": "info",
        "status_code": 503
    },
    "UDAPI100060": {
        "message": "Resource not found. Please check your request.",
        "severity": "warning",
        "status_code": 404
    },
}

def parse_upstox_error(error_response: dict) -> dict:
    """
    Parse Upstox error response and return structured error info
    
    Args:
        error_response: Error response from Upstox API
        
    Returns:
        dict with error_code, message, severity, status_code
    """
    if not isinstance(error_response, dict):
        return {
            "error_code": "UNKNOWN",
            "message": "An unexpected error occurred.",
            "severity": "error",
            "status_code": 500
        }
    
    # Extract error from response
    errors = error_response.get("errors", [])
    if not errors:
        return {
            "error_code": "UNKNOWN",
            "message": error_response.get("message", "An unexpected error occurred."),
            "severity": "error",
            "status_code": 500
        }
    
    # Get first error
    first_error = errors[0] if isinstance(errors, list) else errors
    error_code = first_error.get("errorCode") or first_error.get("error_code", "UNKNOWN")
    original_message = first_error.get("message", "")
    
    # Get mapped error info or use original
    error_info = UPSTOX_ERROR_MESSAGES.get(error_code, {
        "message": original_message or "An error occurred with the trading service.",
        "severity": "error",
        "status_code": 500
    })
    
    return {
        "error_code": error_code,
        "message": error_info["message"],
        "original_message": original_message,
        "severity": error_info["severity"],
        "status_code": error_info["status_code"]
    }

def handle_upstox_error(error_response: dict, context: str = "") -> dict:
    """
    Handle Upstox error and return formatted response for API
    
    Args:
        error_response: Error response from Upstox API
        context: Additional context about where the error occurred
        
    Returns:
        dict formatted for FastAPI response
    """
    error_info = parse_upstox_error(error_response)
    
    response = {
        "error": {
            "code": error_info["error_code"],
            "message": error_info["message"],
            "severity": error_info["severity"]
        }
    }
    
    if context:
        response["error"]["context"] = context
    
    # Include original message in development/debug mode
    if error_info.get("original_message"):
        response["error"]["details"] = error_info["original_message"]
    
    return response

def is_service_hours_error(error_code: str) -> bool:
    """Check if error is due to service hours restriction"""
    return error_code in ["UDAPI100072", "UDAPI100074"]

def is_auth_error(error_code: str) -> bool:
    """Check if error is authentication related"""
    auth_errors = [
        "UDAPI100016",  # Invalid Credentials
        "UDAPI100050",  # Invalid token
        "UDAPI100057",  # Invalid Auth code
        "UDAPI100068",  # Check client_id and redirect_uri
        "UDAPI100069",  # Check client_id and client_secret
        "UDAPI100073",  # client_id is inactive
        "HTTP_401"      # HTTP Unauthorized
    ]
    return error_code in auth_errors

def should_retry(error_code: str) -> bool:
    """Check if the error is retryable"""
    retryable_errors = [
        "UDAPI10005",    # Too Many Requests
        "UDAPI100500",   # Something went wrong
        "UDAPI100072",   # Service hours (market hours)
        "UDAPI100074",   # Place order API hours
        "HTTP_429"       # HTTP Too Many Requests
    ]
    return error_code in retryable_errors
