# Option Chain Backend Backup
# Created: 2025-12-24T22:18:55+05:30
# Original Path: backend/services/option_chain_background.py

"""
Option Chain Background Service - Continuously fetches option chain data for all instruments
Runs in the background and populates the cache with option chain data
"""

import asyncio
import logging
import requests
from typing import Dict, List, Any, Optional
from datetime import datetime, date
from sqlalchemy.orm import Session
from sqlalchemy import distinct

from database.connection import get_db, SessionLocal
from models.upstox_token import UpstoxToken
from models.instrument_models import OptionsInstrument, IndexInstrument
from services.option_chain_cache import option_chain_cache
from services.valuation_calculator import calculate_option_chain_valuations
from server.websocket.manager import websocket_manager

logger = logging.getLogger(__name__)


class OptionChainBackgroundService:
    """
    Background service that continuously fetches option chain data
    for all instruments and expiries.
    """
    
    def __init__(self, fetch_interval: int = 3):
        """
        Initialize the background service.
        
        Args:
            fetch_interval: Seconds between fetch cycles
        """
        self.fetch_interval = fetch_interval
        self.is_running = False
        self._task: Optional[asyncio.Task] = None
        self._instruments: List[Dict] = []
        self._current_index = 0
        
    async def start(self) -> None:
        """Start the background service."""
        if self.is_running:
            logger.warning("Option chain background service already running")
            return
            
        self.is_running = True
        logger.info(f"🚀 Starting option chain background service (interval: {self.fetch_interval}s)")
        
        # Load instruments on startup
        await self._load_instruments()
        
        # Start the fetch loop
        self._task = asyncio.create_task(self._fetch_loop())
        
    async def stop(self) -> None:
        """Stop the background service."""
        self.is_running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("⏹️ Option chain background service stopped")
        
    async def _load_instruments(self) -> None:
        """Load all instruments with their expiries from database."""
        try:
            db = SessionLocal()
            try:
                # Get all index underlyings that have options
                underlying_keys = db.query(distinct(OptionsInstrument.underlying_key)).filter(
                    OptionsInstrument.underlying_key.ilike("NSE_INDEX%")
                ).all()
                
                underlying_key_list = [k[0] for k in underlying_keys if k[0]]
                
                self._instruments = []
                
                # For each underlying, get all valid expiries
                for underlying_key in underlying_key_list:
                    expiries = db.query(distinct(OptionsInstrument.expiry)).filter(
                        OptionsInstrument.underlying_key == underlying_key,
                        OptionsInstrument.expiry >= date.today()
                    ).order_by(OptionsInstrument.expiry).all()
                    
                    expiry_list = [e[0].strftime("%Y-%m-%d") for e in expiries if e[0]]
                    
                    # Get index name for logging
                    index = db.query(IndexInstrument).filter(
                        IndexInstrument.instrument_key == underlying_key
                    ).first()
                    index_name = index.name if index else underlying_key
                    
                    for expiry in expiry_list:
                        self._instruments.append({
                            "instrument_key": underlying_key,
                            "expiry_date": expiry,
                            "name": index_name
                        })
                
                logger.info(f"📋 Loaded {len(self._instruments)} instrument/expiry combinations")
                
                # Log summary
                if self._instruments:
                    unique_instruments = set(i["instrument_key"] for i in self._instruments)
                    logger.info(f"   Instruments: {len(unique_instruments)}")
                    for inst in unique_instruments:
                        count = sum(1 for i in self._instruments if i["instrument_key"] == inst)
                        logger.info(f"   - {inst}: {count} expiries")
                        
            finally:
                db.close()
                
        except Exception as e:
            logger.error(f"Failed to load instruments: {e}", exc_info=True)
            
    def _get_access_token(self) -> Optional[str]:
        """Get access token for option chain API."""
        try:
            db = SessionLocal()
            try:
                # Try OPTIONCHAIN1 token first (api_index=4)
                token = db.query(UpstoxToken).filter(
                    UpstoxToken.api_index == 4,
                    UpstoxToken.is_active == True
                ).first()
                
                if token:
                    return token.access_token
                    
                # Fallback to PRIMARY token
                token = db.query(UpstoxToken).filter(
                    UpstoxToken.api_name == "PRIMARY",
                    UpstoxToken.is_active == True
                ).first()
                
                if token:
                    return token.access_token
                    
                logger.warning("No active access token found")
                return None
                
            finally:
                db.close()
                
        except Exception as e:
            logger.error(f"Failed to get access token: {e}")
            return None
            
    async def _fetch_loop(self) -> None:
        """Main fetch loop - cycles through all instruments."""
        while self.is_running:
            try:
                if not self._instruments:
                    logger.warning("No instruments to fetch, reloading...")
                    await self._load_instruments()
                    await asyncio.sleep(10)
                    continue
                
                # Get the next instrument to fetch
                instrument = self._instruments[self._current_index]
                
                # Fetch the option chain
                await self._fetch_option_chain(
                    instrument["instrument_key"],
                    instrument["expiry_date"]
                )
                
                # Move to next instrument
                self._current_index = (self._current_index + 1) % len(self._instruments)
                
                # Wait before next fetch
                await asyncio.sleep(self.fetch_interval)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in fetch loop: {e}", exc_info=True)
                await asyncio.sleep(5)
                
    async def _fetch_option_chain(self, instrument_key: str, expiry_date: str) -> None:
        """
        Fetch option chain for a specific instrument/expiry.
        
        Args:
            instrument_key: Underlying instrument key
            expiry_date: Expiry date in YYYY-MM-DD format
        """
        try:
            access_token = self._get_access_token()
            if not access_token:
                return
                
            # Call Upstox API
            url = "https://api.upstox.com/v2/option/chain"
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "Authorization": f"Bearer {access_token}"
            }
            params = {
                "instrument_key": instrument_key,
                "expiry_date": expiry_date
            }
            
            # Run blocking request in thread pool
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: requests.get(url, headers=headers, params=params, timeout=30)
            )
            
            if response.status_code != 200:
                logger.warning(f"Option chain fetch failed ({response.status_code}): {instrument_key} | {expiry_date}")
                return
                
            data = response.json()
            
            if data.get("status") != "success":
                logger.warning(f"Option chain error: {data.get('message', 'Unknown error')}")
                return
                
            # Transform the data
            raw_data = data.get("data", [])
            transformed_data = self._transform_option_chain(raw_data)
            
            # Calculate valuations
            try:
                transformed_data = calculate_option_chain_valuations(transformed_data)
            except Exception as e:
                logger.debug(f"Valuation calculation failed: {e}")
            
            # Store in cache
            option_chain_cache.set(instrument_key, expiry_date, transformed_data)
            
            # Broadcast to WebSocket subscribers
            await self._broadcast_update(instrument_key, expiry_date, transformed_data)
            
            logger.debug(f"✅ Fetched: {instrument_key} | {expiry_date} ({len(transformed_data)} strikes)")
            
        except Exception as e:
            logger.error(f"Failed to fetch option chain {instrument_key} | {expiry_date}: {e}")
            
    def _transform_option_chain(self, raw_data: List[Dict]) -> List[Dict]:
        """Transform raw Upstox data to our format."""
        transformed_data = []
        
        for item in raw_data:
            chain_item = {
                "strike_price": item.get("strike_price"),
                "expiry": item.get("expiry"),
                "pcr": item.get("pcr"),
                "underlying_key": item.get("underlying_key"),
                "underlying_spot_price": item.get("underlying_spot_price"),
            }
            
            # Process Call Options
            call_options = item.get("call_options", {})
            call_market_data = call_options.get("market_data", {})
            call_greeks = call_options.get("option_greeks", {})
            
            chain_item["call"] = {
                "instrument_key": call_options.get("instrument_key"),
                "ltp": call_market_data.get("ltp"),
                "close_price": call_market_data.get("close_price"),
                "volume": call_market_data.get("volume"),
                "oi": call_market_data.get("oi"),
                "bid_price": call_market_data.get("bid_price"),
                "bid_qty": call_market_data.get("bid_qty"),
                "ask_price": call_market_data.get("ask_price"),
                "ask_qty": call_market_data.get("ask_qty"),
                "prev_oi": call_market_data.get("prev_oi"),
                "vega": call_greeks.get("vega"),
                "theta": call_greeks.get("theta"),
                "gamma": call_greeks.get("gamma"),
                "delta": call_greeks.get("delta"),
                "iv": call_greeks.get("iv"),
                "pop": call_greeks.get("pop"),
            }
            
            # Process Put Options
            put_options = item.get("put_options", {})
            put_market_data = put_options.get("market_data", {})
            put_greeks = put_options.get("option_greeks", {})
            
            chain_item["put"] = {
                "instrument_key": put_options.get("instrument_key"),
                "ltp": put_market_data.get("ltp"),
                "close_price": put_market_data.get("close_price"),
                "volume": put_market_data.get("volume"),
                "oi": put_market_data.get("oi"),
                "bid_price": put_market_data.get("bid_price"),
                "bid_qty": put_market_data.get("bid_qty"),
                "ask_price": put_market_data.get("ask_price"),
                "ask_qty": put_market_data.get("ask_qty"),
                "prev_oi": put_market_data.get("prev_oi"),
                "vega": put_greeks.get("vega"),
                "theta": put_greeks.get("theta"),
                "gamma": put_greeks.get("gamma"),
                "delta": put_greeks.get("delta"),
                "iv": put_greeks.get("iv"),
                "pop": put_greeks.get("pop"),
            }
            
            transformed_data.append(chain_item)
            
        return transformed_data
        
    async def _broadcast_update(self, instrument_key: str, expiry_date: str, data: List[Dict]) -> None:
        """Broadcast option chain update to WebSocket subscribers."""
        try:
            channel = f"option_chain:{instrument_key}:{expiry_date}"
            
            message = {
                "type": "option_chain_update",
                "channel": channel,
                "data": {
                    "status": "success",
                    "data": data,
                    "underlying": instrument_key,
                    "expiry": expiry_date,
                    "count": len(data),
                    "updated_at": datetime.now().isoformat()
                }
            }
            
            await websocket_manager.broadcast_to_channel(channel, message)
            
        except Exception as e:
            logger.debug(f"WebSocket broadcast failed: {e}")
            
    def get_status(self) -> Dict[str, Any]:
        """Get service status."""
        return {
            "is_running": self.is_running,
            "fetch_interval": self.fetch_interval,
            "total_instruments": len(self._instruments),
            "current_index": self._current_index,
            "cache_stats": option_chain_cache.stats()
        }


# Global singleton instance
option_chain_background_service = OptionChainBackgroundService(fetch_interval=3)
