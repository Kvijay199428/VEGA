# Schemas Module Backup
# Created: 2025-12-26T10:32:32+05:30

## Directory: schemas/

### Files (Pydantic Models → Java DTOs)

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `order.py` | Order request/response | `OrderRequest.java`, `OrderDto.java` |
| `strategy.py` | Strategy schema | `StrategyDto.java` |
| `user.py` | User schemas | `AuthRequest.java`, `AuthResponse.java` |
| `instrument.py` | Instrument schemas | Part of Entity classes |
| `market.py` | Market data schemas | Part of response maps |

---

## Java Equivalent Location

`backend/java/vega-trader/src/main/java/com/vegatrader/dto/`
- `AuthRequest.java`
- `AuthResponse.java`
- `OrderRequest.java`
- `OrderDto.java`
- `StrategyDto.java`
