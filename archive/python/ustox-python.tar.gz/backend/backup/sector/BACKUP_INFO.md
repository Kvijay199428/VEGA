# Sector Module Backup
# Created: 2025-12-26T10:32:32+05:30

## Directory: sector/

### Files

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `sector_router.py` | Sector API endpoints | `SectorController.java` |
| `sector_sync.py` | Sector data sync | `SectorService.java` |
| `sectoral_indices.py` | Index definitions | `SectorService.java` (static map) |

---

## Java Equivalent Location

`backend/java/vega-trader/src/main/java/com/vegatrader/`
- `controller/SectorController.java`
- `service/SectorService.java`
