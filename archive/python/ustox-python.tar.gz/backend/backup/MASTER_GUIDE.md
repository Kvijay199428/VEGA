# VEGA TRADER - Complete Backup Guide
# Created: 2025-12-26T10:32:32+05:30

## Backup Structure

```
backup/
├── upstox_auth/
│   ├── upstox/          # OAuth flow, multi-login
│   ├── helpers/         # API client, token utils
│   └── BACKUP_INFO.md
├── services/            # All business logic
│   └── BACKUP_INFO.md
├── server/              # FastAPI app, helpers
│   └── BACKUP_INFO.md
├── sector/              # Sectoral indices
│   └── BACKUP_INFO.md
├── schemas/             # Pydantic models
│   └── BACKUP_INFO.md
├── routers/             # API endpoints
│   └── BACKUP_INFO.md
├── optionchain_ws/      # Option chain WebSocket
│   └── BACKUP_INFO.md
├── models/              # SQLAlchemy entities
│   └── BACKUP_INFO.md
├── middleware/          # Auth, WS middleware
│   └── BACKUP_INFO.md
├── helpers/             # Instrument helpers
│   └── BACKUP_INFO.md
├── database/            # Connection, cache
│   └── BACKUP_INFO.md
├── app_utils/           # Error handling
│   └── BACKUP_INFO.md
└── MASTER_GUIDE.md      # This file
```

---

## Java Projects

| Project | Location | Port |
|---------|----------|------|
| vega-trader | `java/vega-trader/` | 8080 |
| optionchain | `java/optionchain/` | 8081 |
| valuation-calculator | `java/valuation-calculator/` | CLI |

---

## Run Java Backend

```bash
# Main backend
java -jar java/vega-trader/target/vega-trader-1.0.0.jar

# Option chain service
java -jar java/optionchain/target/optionchain-1.0.0.jar
```

---

## Migration Complete ✓

All Python scripts have Java equivalents.
See individual BACKUP_INFO.md files for mappings.
