# Valuation Calculator Backup Info
# Created: 2025-12-26T01:51:00+05:30

## Backup Contents

This directory contains backups of the valuation calculator files before Java migration.

### Files Backed Up

| Original Path | Backup Path | Description |
|--------------|-------------|-------------|
| `backend/services/valuation_calculator.py` | `valuation_calculator.py` | Main Black-Scholes pricing and valuation logic |
| `backend/config/valuation_config.py` | `valuation_config.py` | Configuration parameters and thresholds |

### Dependency Files (Referenced by valuation_calculator.py)

These files import and use `valuation_calculator.py`:

| File | Import Used |
|------|------------|
| `backend/routers/options.py` | `from services.valuation_calculator import calculate_option_chain_valuations` |
| `backend/optionchain_ws/helper/option_chain_background.py` | `from services.valuation_calculator import calculate_option_chain_valuations` |

### Original Python Implementation Summary

The Python `valuation_calculator.py` provides:

1. **Black-Scholes Pricing** (`black_scholes_call`, `black_scholes_put`)
   - European call/put option pricing
   - Handles expired options via intrinsic value

2. **Implied Volatility** (`implied_volatility_from_price`)
   - Newton-Raphson solver
   - Maximum 100 iterations

3. **Fair Value Calculation** (`calculate_fair_iv_baseline`, `calculate_time_to_expiry`)
   - ATM strike IV baseline
   - Time to expiry in years

4. **Valuation Status Detection** (`detect_valuation_status`, `calculate_confidence_level`)
   - Overvalued/Undervalued/Fair classification
   - Confidence scoring based on bid-ask spread, volume, OI

5. **Batch Processing** (`calculate_option_chain_valuations`)
   - Processes entire option chain
   - Returns enriched data with valuation objects

### Configuration Parameters (valuation_config.py)

| Parameter | Value | Description |
|-----------|-------|-------------|
| `OVERVALUED_THRESHOLD_PCT` | 5.0 | % above fair value to flag overvalued |
| `UNDERVALUED_THRESHOLD_PCT` | -5.0 | % below fair value to flag undervalued |
| `RISK_FREE_RATE` | 0.07 | India 10-year bond yield (7%) |
| `DEFAULT_HISTORICAL_VOLATILITY` | 0.15 | Fallback IV (15%) |
| `MAX_ALLOWED_IV` | 200.0 | Maximum valid IV (200%) |
| `MIN_DAYS_TO_EXPIRY` | 0 | Skip expired options |
| `CONFIDENCE_SPREAD_THRESHOLD` | 0.10 | >10% spread = Low confidence |
| `LOW_VOLUME_THRESHOLD` | 100 | Contracts |
| `LOW_OI_THRESHOLD` | 500 | Contracts |

### Java Migration Notes

After Java migration:
- Original Python implementation remains as fallback
- Java JAR called via subprocess for performance-critical calculations
- See `backend/java/valuation-calculator/` for Java implementation
- See `backend/java/valuation-calculator/docs/VALUATION_CALCULATOR.md` for Java documentation
