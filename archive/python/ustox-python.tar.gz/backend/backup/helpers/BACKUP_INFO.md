# Helpers Module Backup
# Created: 2025-12-26T10:32:32+05:30

## Directory: helpers/

### Subdirectory: helpers/instruments/

| File | Description | Java Equivalent |
|------|-------------|-----------------|
| `equity.py` | Equity instruments | `InstrumentMasterService.java` |
| `futures.py` | Futures instruments | `InstrumentMasterService.java` |
| `index.py` | Index instruments | `InstrumentMasterService.java` |
| `mis.py` | MIS (intraday) | `InstrumentMasterService.java` |
| `mtf.py` | MTF (margin) | `InstrumentMasterService.java` |
| `options.py` | Options | `InstrumentService.java` |
| `subscription_manager.py` | Subscriptions | `SubscriptionSettingsService.java` |

---

## Java Equivalent Location

`backend/java/vega-trader/src/main/java/com/vegatrader/service/`
- `InstrumentMasterService.java` (consolidated)
- `InstrumentService.java`
- `SubscriptionSettingsService.java`
