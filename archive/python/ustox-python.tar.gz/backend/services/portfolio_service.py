"""
Portfolio Service - Handles portfolio calculations, P&L, and position management
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_, func
from models.trading import Position, Holding, Trade, Order, PortfolioSnapshot, Instrument
from models.user import User
from services.upstox_service import upstox_service
from utils.auth import decrypt_token

logger = logging.getLogger(__name__)

class PortfolioService:
    """Service for portfolio management and P&L calculations"""
    
    def __init__(self):
        pass
        
    # ==========================================================================
    # PORTFOLIO SUMMARY
    # ==========================================================================
    
    async def get_portfolio_summary(self, db: Session, user_id: int) -> Dict[str, Any]:
        """Get comprehensive portfolio summary"""
        try:
            # Get user
            user = db.query(User).filter(User.id == user_id).first()
            if not user:
                raise Exception("User not found")
                
            # Get positions
            positions = db.query(Position).filter(
                Position.user_id == user_id,
                Position.quantity != 0
            ).all()
            
            # Get holdings
            holdings = db.query(Holding).filter(
                Holding.user_id == user_id,
                Holding.quantity != 0
            ).all()
            
            # Calculate totals
            total_positions_value = sum(pos.market_value for pos in positions)
            total_holdings_value = sum(holding.market_value for holding in holdings)
            total_portfolio_value = total_positions_value + total_holdings_value
            
            # Calculate P&L
            total_realized_pnl = sum(pos.realized_pnl for pos in positions)
            total_unrealized_pnl = sum(pos.unrealized_pnl for pos in positions)
            total_holdings_pnl = sum(holding.unrealized_pnl for holding in holdings)
            
            # Get today's P&L
            today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
            
            today_trades = db.query(Trade).filter(
                and_(
                    Trade.user_id == user_id,
                    Trade.trade_timestamp >= today_start
                )
            ).all()
            
            today_realized_pnl = sum(trade.pnl for trade in today_trades)
            
            # Calculate margin used (simplified)
            margin_used = sum(pos.margin_used for pos in positions)
            
            # Get available margin from Upstox if linked
            available_margin = 0
            if user.upstox_access_token:
                try:
                    access_token = decrypt_token(user.upstox_access_token)
                    funds_data = await upstox_service.get_funds(access_token)
                    if funds_data.get('status') == 'success':
                        available_margin = funds_data['data'].get('total_balance', 0)
                except Exception as e:
                    logger.warning(f"Failed to get Upstox funds: {e}")
                    
            return {
                "status": "success",
                "data": {
                    "total_value": total_portfolio_value,
                    "positions_value": total_positions_value,
                    "holdings_value": total_holdings_value,
                    "total_pnl": {
                        "realized": total_realized_pnl,
                        "unrealized": total_unrealized_pnl + total_holdings_pnl,
                        "today": today_realized_pnl
                    },
                    "margin": {
                        "used": margin_used,
                        "available": available_margin
                    },
                    "positions_count": len(positions),
                    "holdings_count": len(holdings),
                    "last_updated": datetime.utcnow().isoformat()
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to get portfolio summary: {e}")
            raise
            
    # ==========================================================================
    # POSITIONS
    # ==========================================================================
    
    async def get_positions(self, db: Session, user_id: int) -> Dict[str, Any]:
        """Get all open positions"""
        try:
            positions = db.query(Position).filter(
                Position.user_id == user_id,
                Position.quantity != 0
            ).all()
            
            position_data = []
            for position in positions:
                instrument = db.query(Instrument).filter(
                    Instrument.instrument_token == position.instrument_token
                ).first()
                
                position_dict = {
                    "instrument_token": position.instrument_token,
                    "tradingsymbol": position.tradingsymbol,
                    "name": instrument.name if instrument else position.tradingsymbol,
                    "exchange": position.exchange,
                    "product": position.product,
                    "quantity": position.quantity,
                    "buy_quantity": position.buy_quantity,
                    "sell_quantity": position.sell_quantity,
                    "buy_value": position.buy_value,
                    "sell_value": position.sell_value,
                    "buy_average": position.buy_average,
                    "sell_average": position.sell_average,
                    "last_price": position.last_price,
                    "multiplier": position.multiplier,
                    "realized_pnl": position.realized_pnl,
                    "unrealized_pnl": position.unrealized_pnl,
                    "total_pnl": position.realized_pnl + position.unrealized_pnl,
                    "market_value": position.market_value,
                    "margin_used": position.margin_used,
                    "created_at": position.created_at.isoformat(),
                    "updated_at": position.updated_at.isoformat()
                }
                position_data.append(position_dict)
                
            # Calculate totals
            total_quantity = sum(pos.quantity for pos in positions)
            total_value = sum(pos.market_value for pos in positions)
            total_pnl = sum(pos.realized_pnl + pos.unrealized_pnl for pos in positions)
            total_margin = sum(pos.margin_used for pos in positions)
            
            return {
                "status": "success",
                "data": {
                    "positions": position_data,
                    "summary": {
                        "total_positions": len(positions),
                        "total_quantity": total_quantity,
                        "total_value": total_value,
                        "total_pnl": total_pnl,
                        "total_margin_used": total_margin
                    }
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to get positions: {e}")
            raise
            
    async def get_position_by_instrument(self, db: Session, user_id: int, 
                                        instrument_token: str) -> Optional[Dict[str, Any]]:
        """Get position for specific instrument"""
        try:
            position = db.query(Position).filter(
                and_(
                    Position.user_id == user_id,
                    Position.instrument_token == instrument_token
                )
            ).first()
            
            if not position:
                return None
                
            instrument = db.query(Instrument).filter(
                Instrument.instrument_token == instrument_token
            ).first()
            
            return {
                "instrument_token": position.instrument_token,
                "tradingsymbol": position.tradingsymbol,
                "name": instrument.name if instrument else position.tradingsymbol,
                "quantity": position.quantity,
                "buy_average": position.buy_average,
                "sell_average": position.sell_average,
                "last_price": position.last_price,
                "realized_pnl": position.realized_pnl,
                "unrealized_pnl": position.unrealized_pnl,
                "total_pnl": position.realized_pnl + position.unrealized_pnl,
                "market_value": position.market_value
            }
            
        except Exception as e:
            logger.error(f"Failed to get position: {e}")
            raise
            
    # ==========================================================================
    # HOLDINGS
    # ==========================================================================
    
    async def get_holdings(self, db: Session, user_id: int) -> Dict[str, Any]:
        """Get all holdings"""
        try:
            holdings = db.query(Holding).filter(
                Holding.user_id == user_id,
                Holding.quantity != 0
            ).all()
            
            holding_data = []
            for holding in holdings:
                instrument = db.query(Instrument).filter(
                    Instrument.instrument_token == holding.instrument_token
                ).first()
                
                holding_dict = {
                    "instrument_token": holding.instrument_token,
                    "tradingsymbol": holding.tradingsymbol,
                    "name": instrument.name if instrument else holding.tradingsymbol,
                    "exchange": holding.exchange,
                    "quantity": holding.quantity,
                    "t1_quantity": holding.t1_quantity,
                    "average_price": holding.average_price,
                    "last_price": holding.last_price,
                    "close_price": holding.close_price,
                    "pnl": holding.unrealized_pnl,
                    "pnl_percent": holding.pnl_percentage,
                    "day_change": holding.day_change,
                    "day_change_percent": holding.day_change_percentage,
                    "market_value": holding.market_value,
                    "created_at": holding.created_at.isoformat(),
                    "updated_at": holding.updated_at.isoformat()
                }
                holding_data.append(holding_dict)
                
            # Calculate totals
            total_quantity = sum(holding.quantity for holding in holdings)
            total_value = sum(holding.market_value for holding in holdings)
            total_pnl = sum(holding.unrealized_pnl for holding in holdings)
            total_day_change = sum(holding.day_change for holding in holdings)
            
            return {
                "status": "success",
                "data": {
                    "holdings": holding_data,
                    "summary": {
                        "total_holdings": len(holdings),
                        "total_quantity": total_quantity,
                        "total_value": total_value,
                        "total_pnl": total_pnl,
                        "total_day_change": total_day_change,
                        "total_pnl_percent": (total_pnl / (total_value - total_pnl)) * 100 if (total_value - total_pnl) > 0 else 0
                    }
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to get holdings: {e}")
            raise
            
    # ==========================================================================
    # PERFORMANCE
    # ==========================================================================
    
    async def get_performance(self, db: Session, user_id: int, 
                            period: str = "1M") -> Dict[str, Any]:
        """Get portfolio performance for a period"""
        try:
            # Calculate date range
            end_date = datetime.utcnow()
            if period == "1D":
                start_date = end_date - timedelta(days=1)
            elif period == "1W":
                start_date = end_date - timedelta(weeks=1)
            elif period == "1M":
                start_date = end_date - timedelta(days=30)
            elif period == "3M":
                start_date = end_date - timedelta(days=90)
            elif period == "6M":
                start_date = end_date - timedelta(days=180)
            elif period == "1Y":
                start_date = end_date - timedelta(days=365)
            else:
                start_date = end_date - timedelta(days=30)
                
            # Get trades in the period
            trades = db.query(Trade).filter(
                and_(
                    Trade.user_id == user_id,
                    Trade.trade_timestamp >= start_date,
                    Trade.trade_timestamp <= end_date
                )
            ).all()
            
            # Calculate performance metrics
            total_trades = len(trades)
            profitable_trades = len([t for t in trades if t.pnl > 0])
            losing_trades = len([t for t in trades if t.pnl < 0])
            
            total_pnl = sum(trade.pnl for trade in trades)
            gross_profit = sum(trade.pnl for trade in trades if trade.pnl > 0)
            gross_loss = sum(trade.pnl for trade in trades if trade.pnl < 0)
            
            win_rate = (profitable_trades / total_trades * 100) if total_trades > 0 else 0
            average_pnl = total_pnl / total_trades if total_trades > 0 else 0
            average_profit = gross_profit / profitable_trades if profitable_trades > 0 else 0
            average_loss = gross_loss / losing_trades if losing_trades > 0 else 0
            
            # Calculate risk metrics
            risk_reward_ratio = abs(average_profit / average_loss) if average_loss != 0 else 0
            
            # Get daily P&L breakdown
            daily_pnl = {}
            for trade in trades:
                date_key = trade.trade_timestamp.strftime("%Y-%m-%d") if trade.trade_timestamp else "unknown"
                if date_key not in daily_pnl:
                    daily_pnl[date_key] = 0
                daily_pnl[date_key] += trade.pnl
                
            # Calculate drawdown
            cumulative_pnl = 0
            peak_pnl = 0
            max_drawdown = 0
            
            for trade in trades:
                cumulative_pnl += trade.pnl
                if cumulative_pnl > peak_pnl:
                    peak_pnl = cumulative_pnl
                drawdown = peak_pnl - cumulative_pnl
                if drawdown > max_drawdown:
                    max_drawdown = drawdown
                    
            return {
                "status": "success",
                "data": {
                    "period": period,
                    "summary": {
                        "total_trades": total_trades,
                        "profitable_trades": profitable_trades,
                        "losing_trades": losing_trades,
                        "win_rate": win_rate,
                        "total_pnl": total_pnl,
                        "gross_profit": gross_profit,
                        "gross_loss": gross_loss,
                        "net_pnl": total_pnl,
                        "average_pnl": average_pnl,
                        "average_profit": average_profit,
                        "average_loss": average_loss,
                        "risk_reward_ratio": risk_reward_ratio,
                        "max_drawdown": max_drawdown
                    },
                    "daily_pnl": [
                        {"date": date, "pnl": pnl}
                        for date, pnl in sorted(daily_pnl.items())
                    ]
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to get performance: {e}")
            raise
            
    # ==========================================================================
    # PORTFOLIO SNAPSHOTS
    # ==========================================================================
    
    async def create_snapshot(self, db: Session, user_id: int) -> Dict[str, Any]:
        """Create portfolio snapshot"""
        try:
            # Get current portfolio state
            summary = await self.get_portfolio_summary(db, user_id)
            positions = await self.get_positions(db, user_id)
            holdings = await self.get_holdings(db, user_id)
            
            # Create snapshot
            snapshot = PortfolioSnapshot(
                user_id=user_id,
                date=datetime.utcnow().date(),
                total_value=summary["data"]["total_value"],
                positions_value=summary["data"]["positions_value"],
                holdings_value=summary["data"]["holdings_value"],
                total_pnl=summary["data"]["total_pnl"]["realized"] + summary["data"]["total_pnl"]["unrealized"],
                positions_count=len(positions["data"]["positions"]),
                holdings_count=len(holdings["data"]["holdings"]),
                margin_used=summary["data"]["margin"]["used"],
                snapshot_data={
                    "positions": positions["data"]["positions"],
                    "holdings": holdings["data"]["holdings"]
                }
            )
            
            db.add(snapshot)
            db.commit()
            
            logger.info(f"Portfolio snapshot created for user {user_id}")
            
            return {
                "status": "success",
                "data": {
                    "snapshot_id": snapshot.id,
                    "date": snapshot.date.isoformat(),
                    "total_value": snapshot.total_value
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to create snapshot: {e}")
            db.rollback()
            raise
            
    async def get_snapshots(self, db: Session, user_id: int, 
                          limit: int = 30) -> Dict[str, Any]:
        """Get portfolio snapshots"""
        try:
            snapshots = db.query(PortfolioSnapshot).filter(
                PortfolioSnapshot.user_id == user_id
            ).order_by(PortfolioSnapshot.date.desc()).limit(limit).all()
            
            snapshot_data = []
            for snapshot in snapshots:
                snapshot_dict = {
                    "id": snapshot.id,
                    "date": snapshot.date.isoformat(),
                    "total_value": snapshot.total_value,
                    "positions_value": snapshot.positions_value,
                    "holdings_value": snapshot.holdings_value,
                    "total_pnl": snapshot.total_pnl,
                    "positions_count": snapshot.positions_count,
                    "holdings_count": snapshot.holdings_count,
                    "margin_used": snapshot.margin_used,
                    "created_at": snapshot.created_at.isoformat()
                }
                snapshot_data.append(snapshot_dict)
                
            return {
                "status": "success",
                "data": {
                    "snapshots": snapshot_data,
                    "total": len(snapshots)
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to get snapshots: {e}")
            raise
            
    # ==========================================================================
    # ALLOCATION
    # ==========================================================================
    
    async def get_allocation(self, db: Session, user_id: int) -> Dict[str, Any]:
        """Get portfolio allocation by sector and instrument type"""
        try:
            holdings = db.query(Holding).filter(
                Holding.user_id == user_id,
                Holding.quantity != 0
            ).all()
            
            positions = db.query(Position).filter(
                Position.user_id == user_id,
                Position.quantity != 0
            ).all()
            
            # Get instruments for sector information
            all_items = holdings + positions
            
            sector_allocation = {}
            type_allocation = {}
            total_value = 0
            
            for item in all_items:
                instrument = db.query(Instrument).filter(
                    Instrument.instrument_token == item.instrument_token
                ).first()
                
                if instrument:
                    # Sector allocation
                    sector = instrument.sector or "Unknown"
                    if sector not in sector_allocation:
                        sector_allocation[sector] = {
                            "value": 0,
                            "percentage": 0,
                            "count": 0
                        }
                    sector_allocation[sector]["value"] += item.market_value
                    sector_allocation[sector]["count"] += 1
                    
                    # Type allocation
                    inst_type = instrument.instrument_type
                    if inst_type not in type_allocation:
                        type_allocation[inst_type] = {
                            "value": 0,
                            "percentage": 0,
                            "count": 0
                        }
                    type_allocation[inst_type]["value"] += item.market_value
                    type_allocation[inst_type]["count"] += 1
                    
                    total_value += item.market_value
                    
            # Calculate percentages
            for sector in sector_allocation:
                sector_allocation[sector]["percentage"] = (
                    sector_allocation[sector]["value"] / total_value * 100
                ) if total_value > 0 else 0
                
            for inst_type in type_allocation:
                type_allocation[inst_type]["percentage"] = (
                    type_allocation[inst_type]["value"] / total_value * 100
                ) if total_value > 0 else 0
                
            return {
                "status": "success",
                "data": {
                    "total_value": total_value,
                    "sector_allocation": sector_allocation,
                    "type_allocation": type_allocation,
                    "summary": {
                        "total_sectors": len(sector_allocation),
                        "total_types": len(type_allocation),
                        "largest_sector": max(sector_allocation.items(), key=lambda x: x[1]["value"]) if sector_allocation else None,
                        "largest_type": max(type_allocation.items(), key=lambda x: x[1]["value"]) if type_allocation else None
                    }
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to get allocation: {e}")
            raise

# Global instance
portfolio_service = PortfolioService()