"""
Market Data Background Service - Runs WebSocket in background on application startup

This service:
1. Starts automatically when the backend starts (if user has Upstox token)
2. Collects all instrument keys from helpers via subscription_manager
3. Connects to Upstox WebSocket and subscribes to all instruments
4. Keeps connection alive and handles reconnection
5. Caches prices that are then served by API endpoints filtered by type
"""

import asyncio
import logging
from typing import Optional
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)


class MarketDataBackgroundService:
    """
    Background service that manages the WebSocket connection.
    
    Runs independently and keeps the WebSocket connected to Upstox,
    subscribing to all instruments from the helpers.
    """
    
    def __init__(self):
        self.is_running = False
        self.task: Optional[asyncio.Task] = None
        self.access_token: Optional[str] = None
    
    async def start(self, access_token: str, db: Session):
        """
        Start the background WebSocket service.
        
        Args:
            access_token: Upstox access token
            db: Database session for fetching instruments
        """
        if self.is_running:
            logger.warning("Market data service already running")
            return
        
        self.access_token = access_token
        self.is_running = True
        
        logger.info("🚀 Starting Market Data Background Service...")
        
        try:
            from services.market_data_websocket import market_data_ws
            from helpers.instruments.subscription_manager import subscription_manager
            
            # Get all instrument keys from all helpers
            all_keys = subscription_manager.get_combined_keys(db)
            
            if not all_keys:
                logger.warning("No instrument keys found. Please sync instruments first.")
                self.is_running = False
                return
            
            logger.info(f"📊 Subscribing to {len(all_keys)} instruments from all types")
            
            # Log subscription summary
            summary = subscription_manager.get_subscription_summary()
            for inst_type, count in summary.items():
                if count > 0:
                    logger.info(f"  - {inst_type}: {count} instruments")
            
            # Connect to WebSocket
            await market_data_ws.connect(access_token, all_keys)
            
            logger.info("✅ Market Data Background Service started successfully")
            
        except Exception as e:
            logger.error(f"❌ Failed to start Market Data Service: {e}")
            self.is_running = False
            raise
    
    async def stop(self):
        """Stop the background WebSocket service"""
        if not self.is_running:
            return
        
        logger.info("Stopping Market Data Background Service...")
        
        try:
            from services.market_data_websocket import market_data_ws
            await market_data_ws.disconnect()
        except Exception as e:
            logger.error(f"Error stopping service: {e}")
        
        self.is_running = False
        self.access_token = None
        
        logger.info("Market Data Background Service stopped")
    
    async def restart(self, access_token: str, db: Session):
        """Restart the service with new token or instruments"""
        await self.stop()
        await asyncio.sleep(1)
        await self.start(access_token, db)
    
    def get_status(self) -> dict:
        """Get current service status"""
        from services.market_data_websocket import market_data_ws
        from helpers.instruments.subscription_manager import subscription_manager
        
        return {
            "service_running": self.is_running,
            "websocket_connected": market_data_ws.is_connected,
            "subscriptions": subscription_manager.get_subscription_summary(),
            "total_subscribed": len(market_data_ws.subscriptions),
            "cached_prices": len(market_data_ws.index_prices)
        }
    
    def get_prices_by_type(self, instrument_type: str) -> dict:
        """
        Get cached prices filtered by instrument type.
        
        Args:
            instrument_type: Type to filter (index, equity, futures, options)
            
        Returns:
            Dict of prices for the specified type only
        """
        from services.market_data_websocket import market_data_ws
        from helpers.instruments.subscription_manager import subscription_manager
        
        all_prices = market_data_ws.get_index_prices()
        return subscription_manager.filter_prices_by_type(all_prices, instrument_type)
    
    def get_all_prices(self) -> dict:
        """Get all cached prices"""
        from services.market_data_websocket import market_data_ws
        return market_data_ws.get_index_prices()


# Singleton instance
market_data_service = MarketDataBackgroundService()


async def start_market_data_on_login(access_token: str, db: Session):
    """
    Convenience function to start market data service after login.
    Called from the login endpoint or auth flow.
    """
    await market_data_service.start(access_token, db)
