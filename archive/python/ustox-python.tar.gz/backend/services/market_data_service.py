"""
Market Data Service - Handles market data aggregation and caching
Integrates with Upstox service to provide real-time and historical market data
"""

import asyncio
import json
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_
from database.connection import get_redis
from models.trading import Instrument
from services.upstox_service import upstox_service

logger = logging.getLogger(__name__)

class MarketDataService:
    """Service for managing market data with caching and aggregation"""
    
    def __init__(self):
        self.redis = None
        self.quote_cache_ttl = 30  # 30 seconds for quotes
        self.historical_cache_ttl = 300  # 5 minutes for historical data
        
    async def initialize(self):
        """Initialize market data service"""
        self.redis = get_redis()
        
    async def cleanup(self):
        """Clean up resources"""
        if self.redis:
            # Check if redis has close method (real Redis vs MockRedis)
            if hasattr(self.redis, 'close') and callable(self.redis.close):
                self.redis.close()
                if hasattr(self.redis, 'wait_closed'):
                    await self.redis.wait_closed()
            
    # ==========================================================================
    # INSTRUMENT MANAGEMENT
    # ==========================================================================
    
    async def get_instruments(self, db: Session, exchange: str = None, 
                            instrument_type: str = None) -> List[Dict[str, Any]]:
        """Get all instruments with optional filtering"""
        try:
            query = db.query(Instrument)
            
            if exchange:
                query = query.filter(Instrument.exchange == exchange)
            if instrument_type:
                query = query.filter(Instrument.instrument_type == instrument_type)
                
            instruments = query.all()
            
            return [{
                'instrument_token': inst.instrument_token,
                'exchange_token': inst.exchange_token,
                'tradingsymbol': inst.tradingsymbol,
                'name': inst.name,
                'exchange': inst.exchange,
                'instrument_type': inst.instrument_type,
                'segment': inst.segment,
                'expiry': inst.expiry.isoformat() if inst.expiry else None,
                'strike': inst.strike,
                'tick_size': inst.tick_size,
                'lot_size': inst.lot_size
            } for inst in instruments]
            
        except Exception as e:
            logger.error(f"Failed to get instruments: {e}")
            raise
            
    async def search_instruments(self, db: Session, query: str, 
                               limit: int = 20) -> List[Dict[str, Any]]:
        """Search instruments by name or symbol"""
        try:
            instruments = db.query(Instrument).filter(
                and_(
                    Instrument.is_tradable == True,
                    (Instrument.name.ilike(f'%{query}%')) |
                    (Instrument.tradingsymbol.ilike(f'%{query}%'))
                )
            ).limit(limit).all()
            
            return [{
                'instrument_token': inst.instrument_token,
                'tradingsymbol': inst.tradingsymbol,
                'name': inst.name,
                'exchange': inst.exchange,
                'instrument_type': inst.instrument_type,
                'segment': inst.segment
            } for inst in instruments]
            
        except Exception as e:
            logger.error(f"Failed to search instruments: {e}")
            raise
            
    async def sync_instruments_with_upstox(self, db: Session, access_token: str):
        """Sync instruments database with Upstox"""
        try:
            # Get instruments from Upstox
            upstox_instruments = await upstox_service.get_instruments(access_token=access_token)
            
            if upstox_instruments.get('status') == 'success':
                instruments_data = upstox_instruments.get('data', [])
                
                # Update database
                for instrument_data in instruments_data:
                    inst = db.query(Instrument).filter(
                        Instrument.instrument_token == instrument_data.get('instrument_key')
                    ).first()
                    
                    if not inst:
                        inst = Instrument()
                        
                    # Update fields
                    inst.instrument_token = instrument_data.get('instrument_key')
                    inst.exchange_token = instrument_data.get('exchange_token')
                    inst.tradingsymbol = instrument_data.get('tradingsymbol')
                    inst.name = instrument_data.get('name')
                    inst.exchange = instrument_data.get('exchange')
                    inst.instrument_type = instrument_data.get('instrument_type')
                    inst.segment = instrument_data.get('segment')
                    inst.expiry = instrument_data.get('expiry')
                    inst.strike = instrument_data.get('strike')
                    inst.tick_size = instrument_data.get('tick_size')
                    inst.lot_size = instrument_data.get('lot_size')
                    inst.is_tradable = instrument_data.get('is_tradable', True)
                    
                    if not inst.id:
                        db.add(inst)
                        
                db.commit()
                logger.info(f"Synced {len(instruments_data)} instruments")
                
        except Exception as e:
            logger.error(f"Failed to sync instruments: {e}")
            db.rollback()
            raise
            
    # ==========================================================================
    # QUOTES & MARKET DATA
    # ==========================================================================
    
    async def get_quote(self, instrument_token: str, access_token: str, 
                       db: Session) -> Dict[str, Any]:
        """Get live quote with caching"""
        cache_key = f"quote:{instrument_token}"
        
        try:
            # Check cache first
            cached_data = await self.redis.get(cache_key)
            if cached_data:
                return json.loads(cached_data)
                
            # Get from Upstox
            quote_data = await upstox_service.get_quote(instrument_token, access_token)
            
            if quote_data.get('status') == 'success':
                data = quote_data.get('data', {})
                
                # Cache the result
                await self.redis.setex(
                    cache_key, 
                    self.quote_cache_ttl, 
                    json.dumps(data)
                )
                
                return data
            else:
                raise Exception(f"Quote fetch failed: {quote_data}")
                
        except Exception as e:
            logger.error(f"Failed to get quote: {e}")
            raise
            
    async def get_batch_quotes(self, instrument_tokens: List[str], access_token: str,
                              db: Session) -> Dict[str, Any]:
        """Get quotes for multiple instruments"""
        try:
            # Check cache for each token
            cached_quotes = {}
            tokens_to_fetch = []
            
            for token in instrument_tokens:
                cache_key = f"quote:{token}"
                cached = await self.redis.get(cache_key)
                if cached:
                    cached_quotes[token] = json.loads(cached)
                else:
                    tokens_to_fetch.append(token)
                    
            # Fetch missing quotes from Upstox
            if tokens_to_fetch:
                quotes_data = await upstox_service.get_batch_quotes(tokens_to_fetch, access_token)
                
                if quotes_data.get('status') == 'success':
                    for quote in quotes_data.get('data', []):
                        token = quote.get('instrument_key')
                        cached_quotes[token] = quote
                        
                        # Cache each quote
                        cache_key = f"quote:{token}"
                        await self.redis.setex(
                            cache_key,
                            self.quote_cache_ttl,
                            json.dumps(quote)
                        )
                        
            return {'status': 'success', 'data': cached_quotes}
            
        except Exception as e:
            logger.error(f"Failed to get batch quotes: {e}")
            raise
            
    # ==========================================================================
    # HISTORICAL DATA
    # ==========================================================================
    
    async def get_historical_data(self, instrument_token: str, interval: str,
                                 from_date: str, to_date: str, access_token: str,
                                 db: Session) -> Dict[str, Any]:
        """Get historical OHLC data with caching"""
        cache_key = f"historical:{instrument_token}:{interval}:{from_date}:{to_date}"
        
        try:
            # Check cache
            cached_data = await self.redis.get(cache_key)
            if cached_data:
                return json.loads(cached_data)
                
            # Get from Upstox
            ohlc_data = await upstox_service.get_ohlc_data(
                instrument_token, interval, from_date, to_date, access_token
            )
            
            if ohlc_data.get('status') == 'success':
                data = ohlc_data.get('data', [])
                
                # Cache the result
                await self.redis.setex(
                    cache_key,
                    self.historical_cache_ttl,
                    json.dumps(data)
                )
                
                return {'status': 'success', 'data': data}
            else:
                raise Exception(f"Historical data fetch failed: {ohlc_data}")
                
        except Exception as e:
            logger.error(f"Failed to get historical data: {e}")
            raise
            
    # ==========================================================================
    # MARKET INDICES & HEAT MAP
    # ==========================================================================
    
    async def get_market_indices(self, access_token: str = None) -> Dict[str, Any]:
        """Get market indices data"""
        try:
            # Return mock data if no access token or Redis unavailable
            if not access_token:
                return {
                    'status': 'success',
                    'data': {
                        'nifty_50': {'ltp': 0, 'change': 0, 'change_percent': 0},
                        'sensex': {'ltp': 0, 'change': 0, 'change_percent': 0},
                        'nifty_bank': {'ltp': 0, 'change': 0, 'change_percent': 0},
                        'message': 'Upstox token required for live data'
                    }
                }
            
            # Try cache first
            if self.redis:
                try:
                    cached_data = self.redis.get("market_indices")
                    if cached_data:
                        return json.loads(cached_data)
                except:
                    pass  # Redis unavailable, continue without cache
                    
            # Get indices data from Upstox
            indices_data = {
                'nifty_50': await self._get_index_quote('NSE_INDEX|Nifty 50', access_token),
                'sensex': await self._get_index_quote('BSE_INDEX|SENSEX', access_token),
                'nifty_bank': await self._get_index_quote('NSE_INDEX|Nifty Bank', access_token)
            }
            
            # Try to cache result
            if self.redis:
                try:
                    self.redis.set("market_indices", json.dumps(indices_data), ex=self.quote_cache_ttl)
                except:
                    pass  # Redis unavailable, continue without caching
            
            return {'status': 'success', 'data': indices_data}
            
        except Exception as e:
            logger.error(f"Failed to get market indices: {e}")
            # Return empty data instead of raising
            return {
                'status': 'error',
                'data': {
                    'nifty_50': {'ltp': 0, 'change': 0, 'change_percent': 0},
                    'sensex': {'ltp': 0, 'change': 0, 'change_percent': 0},
                    'nifty_bank': {'ltp': 0, 'change': 0, 'change_percent': 0}
                },
                'error': str(e)
            }
            
    async def get_market_heat_map(self, segment: str, access_token: str) -> Dict[str, Any]:
        """Get market heat map (gainers/losers)"""
        try:
            # Try cache first
            if self.redis:
                try:
                    cached_data = self.redis.get(f"heat_map:{segment}")
                    if cached_data:
                        return json.loads(cached_data)
                except:
                    pass
                    
            # Get top gainers and losers
            heat_map_data = {
                'gainers': [],  # Top 10 gainers
                'losers': [],   # Top 10 losers
                'most_active': []  # Most active by volume
            }
            
            # Try to cache result
            if self.redis:
                try:
                    self.redis.set(f"heat_map:{segment}", json.dumps(heat_map_data), ex=self.quote_cache_ttl)
                except:
                    pass
            
            return {'status': 'success', 'data': heat_map_data}
            
        except Exception as e:
            logger.error(f"Failed to get heat map: {e}")
            return {'status': 'error', 'data': {'gainers': [], 'losers': [], 'most_active': []}}
            
    async def _get_index_quote(self, index_token: str, access_token: str) -> Dict[str, Any]:
        """Helper to get index quote"""
        try:
            # Use upstox service directly to get quote
            quote = await upstox_service.get_quote(index_token, access_token)
            if quote.get('status') == 'success':
                data = quote.get('data', {}).get(index_token, {})
                return {
                    'ltp': data.get('last_price', 0),
                    'change': data.get('net_change', 0),
                    'change_percent': data.get('percent_change', 0),
                    'open': data.get('ohlc', {}).get('open', 0),
                    'high': data.get('ohlc', {}).get('high', 0),
                    'low': data.get('ohlc', {}).get('low', 0),
                    'close': data.get('ohlc', {}).get('close', 0)
                }
            return {'ltp': 0, 'change': 0, 'change_percent': 0}
        except Exception as e:
            logger.error(f"Failed to get index quote for {index_token}: {e}")
            return {'ltp': 0, 'change': 0, 'change_percent': 0}
            
    # ==========================================================================
    # OPTIONS CHAIN
    # ==========================================================================
    
    async def get_options_chain(self, underlying_token: str, access_token: str) -> Dict[str, Any]:
        """Get options chain for an underlying"""
        cache_key = f"options_chain:{underlying_token}"
        
        try:
            cached_data = await self.redis.get(cache_key)
            if cached_data:
                return json.loads(cached_data)
                
            # This would fetch all options for the underlying
            # For now, return mock structure
            options_chain = {
                'underlying': {
                    'token': underlying_token,
                    'price': 0.0,  # Current price
                    'change': 0.0,
                    'change_percent': 0.0
                },
                'calls': [],  # List of call options
                'puts': []    # List of put options
            }
            
            # Cache result
            await self.redis.setex(cache_key, self.quote_cache_ttl, json.dumps(options_chain))
            
            return {'status': 'success', 'data': options_chain}
            
        except Exception as e:
            logger.error(f"Failed to get options chain: {e}")
            raise
            
    # ==========================================================================
    # UTILITY METHODS
    # ==========================================================================
    
    async def clear_cache(self, pattern: str = None):
        """Clear cache entries matching pattern"""
        try:
            if pattern:
                # Get all keys matching pattern
                cursor = 0
                while True:
                    cursor, keys = await self.redis.scan(cursor, match=pattern, count=100)
                    if keys:
                        await self.redis.delete(*keys)
                    if cursor == 0:
                        break
            else:
                await self.redis.flushdb()
                
        except Exception as e:
            logger.error(f"Failed to clear cache: {e}")
            raise
            
    async def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        try:
            info = await self.redis.info()
            return {
                'connected': True,
                'db_size': info.get('db0', {}).get('keys', 0),
                'memory_used': info.get('used_memory_human', '0B'),
                'uptime': info.get('uptime_in_days', 0)
            }
        except Exception as e:
            logger.error(f"Failed to get cache stats: {e}")
            return {'connected': False, 'error': str(e)}

# Global instance
market_data_service = MarketDataService()

# Initialize function for main.py
async def initialize_market_data_service():
    """Initialize market data service"""
    await market_data_service.initialize()