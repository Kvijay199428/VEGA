"""
Instrument Search Service - Search and filter instruments from separate tables
"""

import logging
from typing import Dict, List, Optional, Any
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from models.instrument_models import (
    EquityInstrument, IndexInstrument, FuturesInstrument, 
    OptionsInstrument, MTFInstrument, MISInstrument
)

logger = logging.getLogger(__name__)


class InstrumentSearchService:
    """Service for searching and filtering instruments from separate tables"""
    
    @staticmethod
    def search_instruments(
        db: Session,
        segment: Optional[str] = None,
        instrument_type: Optional[str] = None,
        trading_symbol: Optional[str] = None,
        exchange: Optional[str] = None,
        limit: int = 100,
        offset: int = 0
    ) -> Dict[str, Any]:
        """
        Search instruments across all tables
        """
        results = []
        
        # Search equity
        equity_query = db.query(EquityInstrument)
        if trading_symbol:
            equity_query = equity_query.filter(
                EquityInstrument.trading_symbol.ilike(f"%{trading_symbol}%")
            )
        if exchange:
            equity_query = equity_query.filter(EquityInstrument.exchange == exchange)
        if segment:
            equity_query = equity_query.filter(EquityInstrument.segment == segment)
        
        for eq in equity_query.limit(limit).all():
            results.append(InstrumentSearchService._format_equity(eq))
        
        # Search indices
        if not segment or 'INDEX' in segment:
            index_query = db.query(IndexInstrument)
            if trading_symbol:
                index_query = index_query.filter(
                    IndexInstrument.trading_symbol.ilike(f"%{trading_symbol}%")
                )
            if exchange:
                index_query = index_query.filter(IndexInstrument.exchange == exchange)
            
            for idx in index_query.limit(limit).all():
                results.append(InstrumentSearchService._format_index(idx))
        
        return {
            'total': len(results),
            'count': len(results),
            'instruments': results[:limit]
        }
    
    @staticmethod
    def get_equity_instruments(
        db: Session,
        symbol: Optional[str] = None,
        exchange: Optional[str] = None,
        limit: int = 1000
    ) -> List[Dict]:
        """Get equity instruments from equity_instruments table"""
        query = db.query(EquityInstrument)
        
        if symbol:
            query = query.filter(
                EquityInstrument.trading_symbol.ilike(f"%{symbol}%")
            )
        
        if exchange:
            query = query.filter(EquityInstrument.exchange == exchange.upper())
        
        results = query.order_by(EquityInstrument.trading_symbol).limit(limit).all()
        return [InstrumentSearchService._format_equity(inst) for inst in results]
    
    @staticmethod
    def get_futures(
        db: Session,
        underlying: Optional[str] = None,
        limit: int = 1000
    ) -> List[Dict]:
        """Get futures instruments from futures_instruments table"""
        query = db.query(FuturesInstrument)
        
        if underlying:
            query = query.filter(
                FuturesInstrument.underlying_symbol.ilike(f"%{underlying}%")
            )
        
        results = query.order_by(FuturesInstrument.trading_symbol).limit(limit).all()
        return [InstrumentSearchService._format_futures(inst) for inst in results]
    
    @staticmethod
    def get_options(
        db: Session,
        underlying: Optional[str] = None,
        option_type: Optional[str] = None,
        limit: int = 1000
    ) -> List[Dict]:
        """Get options instruments from options_instruments table"""
        query = db.query(OptionsInstrument)
        
        if option_type:
            query = query.filter(OptionsInstrument.option_type == option_type)
        
        if underlying:
            query = query.filter(
                OptionsInstrument.underlying_symbol.ilike(f"%{underlying}%")
            )
        
        results = query.order_by(OptionsInstrument.trading_symbol).limit(limit).all()
        return [InstrumentSearchService._format_options(inst) for inst in results]
    
    @staticmethod
    def get_indices(
        db: Session,
        exchange: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict]:
        """Get index instruments from index_instruments table"""
        query = db.query(IndexInstrument)
        
        if exchange:
            query = query.filter(IndexInstrument.exchange == exchange)
        
        results = query.order_by(IndexInstrument.trading_symbol).limit(limit).all()
        return [InstrumentSearchService._format_index(inst) for inst in results]
    
    @staticmethod
    def get_mtf_enabled(db: Session, limit: int = 1000) -> List[Dict]:
        """Get MTF enabled instruments from mtf_instruments table"""
        results = db.query(MTFInstrument).order_by(
            MTFInstrument.trading_symbol
        ).limit(limit).all()
        
        return [InstrumentSearchService._format_mtf(inst) for inst in results]
    
    @staticmethod
    def get_mis_enabled(db: Session, limit: int = 1000) -> List[Dict]:
        """Get MIS (Intraday) enabled instruments from mis_instruments table"""
        results = db.query(MISInstrument).order_by(
            MISInstrument.trading_symbol
        ).limit(limit).all()
        
        return [InstrumentSearchService._format_mis(inst) for inst in results]
    
    @staticmethod
    def get_by_key(db: Session, instrument_key: str) -> Optional[Dict]:
        """Get single instrument by key - searches all tables"""
        # Check equity
        eq = db.query(EquityInstrument).filter(
            EquityInstrument.instrument_key == instrument_key
        ).first()
        if eq:
            return InstrumentSearchService._format_equity(eq)
        
        # Check index
        idx = db.query(IndexInstrument).filter(
            IndexInstrument.instrument_key == instrument_key
        ).first()
        if idx:
            return InstrumentSearchService._format_index(idx)
        
        # Check futures
        fut = db.query(FuturesInstrument).filter(
            FuturesInstrument.instrument_key == instrument_key
        ).first()
        if fut:
            return InstrumentSearchService._format_futures(fut)
        
        # Check options
        opt = db.query(OptionsInstrument).filter(
            OptionsInstrument.instrument_key == instrument_key
        ).first()
        if opt:
            return InstrumentSearchService._format_options(opt)
        
        return None
    
    @staticmethod
    def get_batch(db: Session, instrument_keys: List[str]) -> List[Dict]:
        """Get multiple instruments by keys"""
        results = []
        for key in instrument_keys:
            inst = InstrumentSearchService.get_by_key(db, key)
            if inst:
                results.append(inst)
        return results
    
    # Format methods for each table type
    @staticmethod
    def _format_equity(inst: EquityInstrument) -> Dict:
        """Format equity instrument"""
        return {
            'instrument_key': inst.instrument_key,
            'exchange_token': inst.exchange_token,
            'trading_symbol': inst.trading_symbol,
            'segment': inst.segment,
            'exchange': inst.exchange,
            'instrument_type': 'EQ',
            'name': inst.name,
            'short_name': inst.short_name,
            'isin': inst.isin,
            'lot_size': inst.lot_size,
            'tick_size': inst.tick_size,
            'security_type': inst.security_type
        }
    
    @staticmethod
    def _format_index(inst: IndexInstrument) -> Dict:
        """Format index instrument"""
        return {
            'instrument_key': inst.instrument_key,
            'exchange_token': inst.exchange_token,
            'trading_symbol': inst.trading_symbol,
            'segment': inst.segment,
            'exchange': inst.exchange,
            'instrument_type': 'INDEX',
            'name': inst.name,
            'short_name': inst.short_name
        }
    
    @staticmethod
    def _format_futures(inst: FuturesInstrument) -> Dict:
        """Format futures instrument"""
        return {
            'instrument_key': inst.instrument_key,
            'exchange_token': inst.exchange_token,
            'trading_symbol': inst.trading_symbol,
            'segment': inst.segment,
            'exchange': inst.exchange,
            'instrument_type': 'FUT',
            'name': inst.name,
            'short_name': inst.short_name,
            'lot_size': inst.lot_size,
            'underlying_symbol': inst.underlying_symbol,
            'expiry': str(inst.expiry) if inst.expiry else None
        }
    
    @staticmethod
    def _format_options(inst: OptionsInstrument) -> Dict:
        """Format options instrument"""
        return {
            'instrument_key': inst.instrument_key,
            'exchange_token': inst.exchange_token,
            'trading_symbol': inst.trading_symbol,
            'segment': inst.segment,
            'exchange': inst.exchange,
            'instrument_type': inst.option_type,
            'name': inst.name,
            'short_name': inst.short_name,
            'lot_size': inst.lot_size,
            'strike_price': inst.strike_price,
            'underlying_symbol': inst.underlying_symbol,
            'expiry': str(inst.expiry) if inst.expiry else None
        }
    
    @staticmethod
    def _format_mtf(inst: MTFInstrument) -> Dict:
        """Format MTF instrument"""
        return {
            'instrument_key': inst.instrument_key,
            'trading_symbol': inst.trading_symbol,
            'name': inst.name,
            'exchange': inst.exchange,
            'segment': inst.segment,
            'mtf_bracket': inst.mtf_bracket
        }
    
    @staticmethod
    def _format_mis(inst: MISInstrument) -> Dict:
        """Format MIS instrument"""
        return {
            'instrument_key': inst.instrument_key,
            'trading_symbol': inst.trading_symbol,
            'name': inst.name,
            'exchange': inst.exchange,
            'segment': inst.segment,
            'intraday_margin': inst.intraday_margin,
            'intraday_leverage': inst.intraday_leverage
        }


# Global instance
instrument_search_service = InstrumentSearchService()
