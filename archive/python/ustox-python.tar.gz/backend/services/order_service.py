"""
Order Service - Handles order execution and management
Integrates with Upstox service for real order placement
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import and_
from models.trading import Order, Trade, Position, Instrument
from models.user import User
from services.upstox_service import upstox_service
from utils.auth import decrypt_token

logger = logging.getLogger(__name__)

class OrderService:
    """Service for order execution and management"""
    
    def __init__(self):
        pass
        
    # ==========================================================================
    # ORDER PLACEMENT
    # ==========================================================================
    
    async def place_order(self, db: Session, user_id: int, order_data: Dict[str, Any]) -> Dict[str, Any]:
        """Place a new order"""
        try:
            # Get user and decrypt access token
            user = db.query(User).filter(User.id == user_id).first()
            if not user or not user.upstox_access_token:
                raise Exception("User not authenticated with Upstox")
                
            access_token = decrypt_token(user.upstox_access_token)
            
            # Validate instrument
            instrument = db.query(Instrument).filter(
                Instrument.instrument_token == order_data.get('instrument_token')
            ).first()
            
            if not instrument:
                raise Exception("Invalid instrument token")
                
            # Prepare order for Upstox
            upstox_order = {
                'quantity': order_data['quantity'],
                'product': order_data.get('product', 'MIS'),
                'validity': order_data.get('validity', 'DAY'),
                'price': order_data.get('price'),
                'tag': order_data.get('tag', ''),
                'instrument_token': order_data['instrument_token'],
                'order_type': order_data.get('order_type', 'MARKET'),
                'transaction_type': order_data['transaction_type'],
                'disclosed_quantity': order_data.get('disclosed_quantity', 0),
                'trigger_price': order_data.get('trigger_price'),
                'is_amo': order_data.get('is_amo', False)
            }
            
            # Place order via Upstox
            upstox_response = await upstox_service.place_order(upstox_order, access_token)
            
            if upstox_response.get('status') == 'success':
                order_result = upstox_response['data']
                
                # Create order record in database
                order = Order(
                    user_id=user_id,
                    order_id=order_result['order_id'],
                    exchange_order_id=order_result.get('exchange_order_id'),
                    parent_order_id=order_result.get('parent_order_id'),
                    instrument_token=order_data['instrument_token'],
                    tradingsymbol=instrument.tradingsymbol,
                    name=instrument.name,
                    transaction_type=order_data['transaction_type'],
                    quantity=order_data['quantity'],
                    filled_quantity=0,
                    disclosed_quantity=order_data.get('disclosed_quantity', 0),
                    price=order_data.get('price'),
                    trigger_price=order_data.get('trigger_price'),
                    order_type=order_data.get('order_type', 'MARKET'),
                    product=order_data.get('product', 'MIS'),
                    validity=order_data.get('validity', 'DAY'),
                    status='OPEN',
                    tag=order_data.get('tag', ''),
                    is_amo=order_data.get('is_amo', False),
                    placed_at=datetime.utcnow()
                )
                
                db.add(order)
                db.commit()
                
                logger.info(f"Order placed successfully: {order_result['order_id']}")
                
                return {
                    'status': 'success',
                    'data': {
                        'order_id': order_result['order_id'],
                        'exchange_order_id': order_result.get('exchange_order_id'),
                        'status': 'OPEN'
                    }
                }
            else:
                raise Exception(f"Upstox order placement failed: {upstox_response}")
                
        except Exception as e:
            logger.error(f"Failed to place order: {e}")
            db.rollback()
            raise
            
    async def modify_order(self, db: Session, user_id: int, order_id: str, 
                          modifications: Dict[str, Any]) -> Dict[str, Any]:
        """Modify an existing order"""
        try:
            # Get order from database
            order = db.query(Order).filter(
                and_(Order.user_id == user_id, Order.order_id == order_id)
            ).first()
            
            if not order:
                raise Exception("Order not found")
                
            # Get user access token
            user = db.query(User).filter(User.id == user_id).first()
            if not user or not user.upstox_access_token:
                raise Exception("User not authenticated with Upstox")
                
            access_token = decrypt_token(user.upstox_access_token)
            
            # Prepare modifications for Upstox
            upstox_modifications = {
                'quantity': modifications.get('quantity', order.quantity),
                'price': modifications.get('price', order.price),
                'trigger_price': modifications.get('trigger_price', order.trigger_price),
                'validity': modifications.get('validity', order.validity),
                'disclosed_quantity': modifications.get('disclosed_quantity', order.disclosed_quantity)
            }
            
            # Modify order via Upstox
            upstox_response = await upstox_service.modify_order(
                order_id, upstox_modifications, access_token
            )
            
            if upstox_response.get('status') == 'success':
                # Update order in database
                for key, value in modifications.items():
                    if hasattr(order, key):
                        setattr(order, key, value)
                        
                order.modified_at = datetime.utcnow()
                db.commit()
                
                logger.info(f"Order modified successfully: {order_id}")
                
                return {
                    'status': 'success',
                    'data': {
                        'order_id': order_id,
                        'message': 'Order modified successfully'
                    }
                }
            else:
                raise Exception(f"Upstox order modification failed: {upstox_response}")
                
        except Exception as e:
            logger.error(f"Failed to modify order: {e}")
            db.rollback()
            raise
            
    async def cancel_order(self, db: Session, user_id: int, order_id: str) -> Dict[str, Any]:
        """Cancel an order"""
        try:
            # Get order from database
            order = db.query(Order).filter(
                and_(Order.user_id == user_id, Order.order_id == order_id)
            ).first()
            
            if not order:
                raise Exception("Order not found")
                
            if order.status in ['CANCELLED', 'REJECTED']:
                raise Exception("Order already cancelled or rejected")
                
            # Get user access token
            user = db.query(User).filter(User.id == user_id).first()
            if not user or not user.upstox_access_token:
                raise Exception("User not authenticated with Upstox")
                
            access_token = decrypt_token(user.upstox_access_token)
            
            # Cancel order via Upstox
            upstox_response = await upstox_service.cancel_order(order_id, access_token)
            
            if upstox_response.get('status') == 'success':
                # Update order status
                order.status = 'CANCELLED'
                order.cancelled_at = datetime.utcnow()
                db.commit()
                
                logger.info(f"Order cancelled successfully: {order_id}")
                
                return {
                    'status': 'success',
                    'data': {
                        'order_id': order_id,
                        'status': 'CANCELLED'
                    }
                }
            else:
                raise Exception(f"Upstox order cancellation failed: {upstox_response}")
                
        except Exception as e:
            logger.error(f"Failed to cancel order: {e}")
            db.rollback()
            raise
            
    # ==========================================================================
    # ORDER MANAGEMENT
    # ==========================================================================
    
    async def get_orders(self, db: Session, user_id: int, status: str = None,
                        limit: int = 50, offset: int = 0) -> Dict[str, Any]:
        """Get user's orders with optional filtering"""
        try:
            query = db.query(Order).filter(Order.user_id == user_id)
            
            if status:
                query = query.filter(Order.status == status)
                
            total = query.count()
            orders = query.order_by(Order.placed_at.desc()).limit(limit).offset(offset).all()
            
            return {
                'status': 'success',
                'data': {
                    'orders': [self._order_to_dict(order) for order in orders],
                    'total': total,
                    'limit': limit,
                    'offset': offset
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to get orders: {e}")
            raise
            
    async def get_order_by_id(self, db: Session, user_id: int, order_id: str) -> Dict[str, Any]:
        """Get single order by ID"""
        try:
            order = db.query(Order).filter(
                and_(Order.user_id == user_id, Order.order_id == order_id)
            ).first()
            
            if not order:
                raise Exception("Order not found")
                
            return {
                'status': 'success',
                'data': self._order_to_dict(order)
            }
            
        except Exception as e:
            logger.error(f"Failed to get order: {e}")
            raise
            
    async def sync_order_status(self, db: Session, user_id: int, order_id: str) -> Dict[str, Any]:
        """Sync order status with Upstox"""
        try:
            order = db.query(Order).filter(
                and_(Order.user_id == user_id, Order.order_id == order_id)
            ).first()
            
            if not order:
                raise Exception("Order not found")
                
            # Get user access token
            user = db.query(User).filter(User.id == user_id).first()
            if not user or not user.upstox_access_token:
                raise Exception("User not authenticated with Upstox")
                
            access_token = decrypt_token(user.upstox_access_token)
            
            # Get order status from Upstox
            orders_data = await upstox_service.get_orders(access_token)
            
            if orders_data.get('status') == 'success':
                orders = orders_data.get('data', [])
                
                # Find our order
                upstox_order = None
                for o in orders:
                    if o.get('order_id') == order_id:
                        upstox_order = o
                        break
                        
                if upstox_order:
                    # Update order status
                    order.status = upstox_order.get('status', order.status)
                    order.filled_quantity = upstox_order.get('filled_quantity', order.filled_quantity)
                    order.pending_quantity = upstox_order.get('pending_quantity', order.pending_quantity)
                    order.cancelled_quantity = upstox_order.get('cancelled_quantity', order.cancelled_quantity)
                    order.disclosed_quantity = upstox_order.get('disclosed_quantity', order.disclosed_quantity)
                    order.market_protection = upstox_order.get('market_protection', order.market_protection)
                    
                    order.modified_at = datetime.utcnow()
                    db.commit()
                    
                    logger.info(f"Order status synced: {order_id}")
                    
                    return {
                        'status': 'success',
                        'data': self._order_to_dict(order)
                    }
                else:
                    raise Exception("Order not found in Upstox")
            else:
                raise Exception(f"Failed to get orders from Upstox: {orders_data}")
                
        except Exception as e:
            logger.error(f"Failed to sync order status: {e}")
            db.rollback()
            raise
            
    # ==========================================================================
    # TRADE MANAGEMENT
    # ==========================================================================
    
    async def get_trades(self, db: Session, user_id: int, order_id: str = None,
                        limit: int = 50, offset: int = 0) -> Dict[str, Any]:
        """Get user's trades"""
        try:
            # Get user access token
            user = db.query(User).filter(User.id == user_id).first()
            if not user or not user.upstox_access_token:
                raise Exception("User not authenticated with Upstox")
                
            access_token = decrypt_token(user.upstox_access_token)
            
            # Get trades from Upstox
            trades_data = await upstox_service.get_trades(access_token)
            
            if trades_data.get('status') == 'success':
                trades = trades_data.get('data', [])
                
                # Filter by order_id if provided
                if order_id:
                    trades = [trade for trade in trades if trade.get('order_id') == order_id]
                    
                total = len(trades)
                paginated_trades = trades[offset:offset + limit]
                
                return {
                    'status': 'success',
                    'data': {
                        'trades': paginated_trades,
                        'total': total,
                        'limit': limit,
                        'offset': offset
                    }
                }
            else:
                raise Exception(f"Failed to get trades from Upstox: {trades_data}")
                
        except Exception as e:
            logger.error(f"Failed to get trades: {e}")
            raise
            
    # ==========================================================================
    # BATCH OPERATIONS
    # ==========================================================================
    
    async def execute_batch_orders(self, db: Session, user_id: int, 
                                  orders_list: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Execute multiple orders in batch"""
        results = []
        errors = []
        
        for i, order_data in enumerate(orders_list):
            try:
                result = await self.place_order(db, user_id, order_data)
                results.append({
                    'index': i,
                    'status': 'success',
                    'order_id': result['data']['order_id']
                })
            except Exception as e:
                errors.append({
                    'index': i,
                    'status': 'error',
                    'error': str(e)
                })
                
        return {
            'status': 'success',
            'data': {
                'results': results,
                'errors': errors,
                'total': len(orders_list),
                'successful': len(results),
                'failed': len(errors)
            }
        }
        
    # ==========================================================================
    # UTILITY METHODS
    # ==========================================================================
    
    def _order_to_dict(self, order: Order) -> Dict[str, Any]:
        """Convert Order model to dictionary"""
        return {
            'id': order.id,
            'order_id': order.order_id,
            'exchange_order_id': order.exchange_order_id,
            'parent_order_id': order.parent_order_id,
            'instrument_token': order.instrument_token,
            'tradingsymbol': order.tradingsymbol,
            'name': order.name,
            'transaction_type': order.transaction_type,
            'quantity': order.quantity,
            'filled_quantity': order.filled_quantity,
            'pending_quantity': order.pending_quantity,
            'cancelled_quantity': order.cancelled_quantity,
            'disclosed_quantity': order.disclosed_quantity,
            'price': order.price,
            'trigger_price': order.trigger_price,
            'order_type': order.order_type,
            'product': order.product,
            'validity': order.validity,
            'status': order.status,
            'tag': order.tag,
            'is_amo': order.is_amo,
            'market_protection': order.market_protection,
            'placed_at': order.placed_at.isoformat() if order.placed_at else None,
            'modified_at': order.modified_at.isoformat() if order.modified_at else None,
            'cancelled_at': order.cancelled_at.isoformat() if order.cancelled_at else None
        }
        
    async def calculate_order_margin(self, db: Session, user_id: int, 
                                   order_data: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate margin required for an order"""
        try:
            # This would integrate with margin calculation APIs
            # For now, return a basic calculation
            quantity = order_data['quantity']
            price = order_data.get('price', 0)
            
            # Basic margin calculation (this is simplified)
            margin_required = quantity * price * 0.2  # 20% margin
            
            return {
                'status': 'success',
                'data': {
                    'margin_required': margin_required,
                    'quantity': quantity,
                    'price': price,
                    'product': order_data.get('product', 'MIS')
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to calculate margin: {e}")
            raise

# Global instance
order_service = OrderService()