"""
Option Valuation Calculator
Black-Scholes pricing and valuation status detection for option chain
"""

import logging
import numpy as np
from scipy.stats import norm
from scipy.optimize import newton
from datetime import datetime, date
from typing import Dict, List, Optional, Tuple, Any

# Import valuation config
from config.valuation_config import (
    OVERVALUED_THRESHOLD_PCT,
    UNDERVALUED_THRESHOLD_PCT,
    RISK_FREE_RATE,
    DEFAULT_HISTORICAL_VOLATILITY,
    MAX_ALLOWED_IV,
    MIN_DAYS_TO_EXPIRY,
    CONFIDENCE_SPREAD_THRESHOLD,
    LOW_VOLUME_THRESHOLD,
    LOW_OI_THRESHOLD,
    CURRENCY_SYMBOL,
    PRICE_DECIMAL_PLACES,
    PERCENTAGE_DECIMAL_PLACES,
    ENABLE_BLINKING_ANIMATION,
    ENABLE_TOOLTIP,
    ENABLE_VALUATION_ICONS,
    ENABLE_VALUATION_LOGGING
)

logger = logging.getLogger(__name__)


# ============================================================================
# BLACK-SCHOLES PRICING FUNCTIONS
# ============================================================================

def black_scholes_call(S: float, K: float, T: float, r: float, sigma: float) -> float:
    """
    Calculate Black-Scholes price for a European call option.
    
    Args:
        S: Current spot price of underlying
        K: Strike price
        T: Time to expiration (in years)
        r: Risk-free interest rate (annual)
        sigma: Volatility (annual)
    
    Returns:
        Call option price
    """
    if T <= 0:
        # Expired option - intrinsic value only
        return max(0, S - K)
    
    if sigma <= 0:
        logger.warning(f"Invalid sigma={sigma}, using default")
        sigma = DEFAULT_HISTORICAL_VOLATILITY
    
    try:
        d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
        d2 = d1 - sigma * np.sqrt(T)
        
        call_price = S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
        return call_price
    except Exception as e:
        logger.error(f"Black-Scholes call calculation failed: S={S}, K={K}, T={T}, r={r}, sigma={sigma}, error={e}")
        return 0.0


def black_scholes_put(S: float, K: float, T: float, r: float, sigma: float) -> float:
    """
    Calculate Black-Scholes price for a European put option.
    
    Args:
        S: Current spot price of underlying
        K: Strike price
        T: Time to expiration (in years)
        r: Risk-free interest rate (annual)
        sigma: Volatility (annual)
    
    Returns:
        Put option price
    """
    if T <= 0:
        # Expired option - intrinsic value only
        return max(0, K - S)
    
    if sigma <= 0:
        logger.warning(f"Invalid sigma={sigma}, using default")
        sigma = DEFAULT_HISTORICAL_VOLATILITY
    
    try:
        d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
        d2 = d1 - sigma * np.sqrt(T)
        
        put_price = K * np.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)
        return put_price
    except Exception as e:
        logger.error(f"Black-Scholes put calculation failed: S={S}, K={K}, T={T}, r={r}, sigma={sigma}, error={e}")
        return 0.0


# ============================================================================
# IMPLIED VOLATILITY CALCULATION
# ============================================================================

def implied_volatility_from_price(
    market_price: float,
    S: float,
    K: float,
    T: float,
    r: float,
    option_type: str = 'call',
    initial_guess: float = 0.3,
    max_iterations: int = 100
) -> float:
    """
    Calculate implied volatility from market price using Newton-Raphson method.
    
    Args:
        market_price: Market price of the option
        S: Current spot price
        K: Strike price
        T: Time to expiration (years)
        r: Risk-free rate
        option_type: 'call' or 'put'
        initial_guess: Starting volatility guess
        max_iterations: Maximum iterations for Newton-Raphson
    
    Returns:
        Implied volatility (as decimal, e.g., 0.20 for 20%)
    """
    if T <= 0 or market_price <= 0:
        return 0.0
    
    # Intrinsic value
    if option_type.lower() == 'call':
        intrinsic = max(0, S - K)
        price_func = lambda sigma: black_scholes_call(S, K, T, r, sigma)
    else:
        intrinsic = max(0, K - S)
        price_func = lambda sigma: black_scholes_put(S, K, T, r, sigma)
    
    # If market price is below intrinsic, IV calculation will fail
    if market_price < intrinsic:
        logger.warning(f"Market price {market_price} < intrinsic {intrinsic}, returning 0")
        return 0.0
    
    try:
        # Define objective function
        objective = lambda sigma: price_func(sigma) - market_price
        
        # Newton-Raphson method
        iv = newton(objective, initial_guess, maxiter=max_iterations, tol=1e-6)
        
        # Sanity check
        if iv < 0 or iv > MAX_ALLOWED_IV / 100:
            logger.warning(f"Calculated IV {iv*100:.2f}% is out of bounds, using default")
            return DEFAULT_HISTORICAL_VOLATILITY
        
        return iv
    except Exception as e:
        logger.warning(f"IV calculation failed for price={market_price}, using default. Error: {e}")
        return DEFAULT_HISTORICAL_VOLATILITY


# ============================================================================
# FAIR VALUE CALCULATION
# ============================================================================

def calculate_fair_iv_baseline(chain_data: List[Dict]) -> float:
    """
    Calculate fair IV baseline using ATM (At-The-Money) strike's IV.
    
    Args:
        chain_data: List of option chain rows with strike_price and option_greeks
    
    Returns:
        Fair IV baseline (as decimal)
    """
    if not chain_data:
        return DEFAULT_HISTORICAL_VOLATILITY
    
    try:
        # Find ATM strike (closest to spot price)
        spot = chain_data[0].get('underlying_spot_price', 0)
        if spot == 0:
            logger.warning("No spot price found, using default IV")
            return DEFAULT_HISTORICAL_VOLATILITY
        
        # Find closest strike to spot
        atm_strike = min(chain_data, key=lambda x: abs(x.get('strike_price', 0) - spot))
        
        # Get call IV from ATM strike (flattened structure)
        atm_iv = atm_strike.get('call', {}).get('iv', 0)
        
        if atm_iv <= 0 or atm_iv > MAX_ALLOWED_IV:
            logger.warning(f"ATM IV {atm_iv} is invalid, using default")
            return DEFAULT_HISTORICAL_VOLATILITY
        
        # Convert from percentage to decimal
        return atm_iv / 100.0
    except Exception as e:
        logger.error(f"Failed to calculate fair IV baseline: {e}")
        return DEFAULT_HISTORICAL_VOLATILITY


def calculate_time_to_expiry(expiry: str) -> float:
    """
    Calculate time to expiry in years.
    
    Args:
        expiry: Expiry date in YYYY-MM-DD format
    
    Returns:
        Time to expiry in years
    """
    try:
        if isinstance(expiry, str):
            expiry_date = datetime.strptime(expiry, "%Y-%m-%d").date()
        else:
            expiry_date = expiry
        
        today = date.today()
        days_to_expiry = (expiry_date - today).days
        
        # Return 0 if expired
        if days_to_expiry < MIN_DAYS_TO_EXPIRY:
            return 0.0
        
        # Convert to years (using 365 days)
        return days_to_expiry / 365.0
    except Exception as e:
        logger.error(f"Failed to calculate time to expiry for {expiry}: {e}")
        return 0.0


# ============================================================================
# VALUATION STATUS DETECTION
# ============================================================================

def detect_valuation_status(
    market_price: float,
    fair_price: float,
    threshold: float = OVERVALUED_THRESHOLD_PCT
) -> Dict[str, Any]:
    """
    Detect if option is overvalued, undervalued, or fair.
    
    Args:
        market_price: Current market price (LTP)
        fair_price: Theoretical fair price from Black-Scholes
        threshold: Mispricing threshold percentage
    
    Returns:
        Dictionary with status, mispricing_pct, action, blinking
    """
    if fair_price <= 0:
        return {
            'status': 'Fair',
            'mispricing_pct': 0.0,
            'action': 'HOLD',
            'blinking': False
        }
    
    # Calculate mispricing percentage
    mispricing_pct = ((market_price - fair_price) / fair_price) * 100
    
    # Determine status
    if mispricing_pct > threshold:
        status = 'Overvalued'
        action = 'SELL'
        blinking = True
    elif mispricing_pct < -threshold:
        status = 'Undervalued'
        action = 'BUY'
        blinking = True
    else:
        status = 'Fair'
        action = 'HOLD'
        blinking = False
    
    return {
        'status': status,
        'mispricing_pct': mispricing_pct,
        'action': action,
        'blinking': blinking
    }


def calculate_confidence_level(
    bid: float,
    ask: float,
    volume: int,
    oi: int
) -> str:
    """
    Calculate confidence level based on spread, volume, and OI.
    
    Args:
        bid: Bid price
        ask: Ask price
        volume: Trading volume
        oi: Open interest
    
    Returns:
        'High', 'Medium', or 'Low'
    """
    # Calculate spread percentage
    mid_price = (bid + ask) / 2 if (bid + ask) > 0 else 1
    spread_pct = ((ask - bid) / mid_price) if mid_price > 0 else 1
    
    # Check criteria
    wide_spread = spread_pct > CONFIDENCE_SPREAD_THRESHOLD
    low_volume = volume < LOW_VOLUME_THRESHOLD
    low_oi = oi < LOW_OI_THRESHOLD
    
    # Determine confidence
    if wide_spread or (low_volume and low_oi):
        return 'Low'
    elif low_volume or low_oi:
        return 'Medium'
    else:
        return 'High'


# ============================================================================
# VALUATION RESPONSE BUILDER
# ============================================================================

def build_valuation_response(
    strike_data: Dict,
    fair_volatility: float,
    option_type: str = 'call'
) -> Optional[Dict]:
    """
    Build complete valuation response object for a single option.
    
    Args:
        strike_data: Option data for a single strike
        fair_volatility: Fair IV baseline
        option_type: 'call' or 'put'
    
    Returns:
        Valuation dictionary or None if calculation fails
    """
    try:
        # Extract data
        spot = strike_data.get('underlying_spot_price', 0)
        strike = strike_data.get('strike_price', 0)
        expiry = strike_data.get('expiry', '')
        
        # Get option-specific data (flattened structure)
        option_data = strike_data.get(option_type, {})
        
        market_price = option_data.get('ltp', 0)
        bid = option_data.get('bid_price', 0)
        ask = option_data.get('ask_price', 0)
        volume = option_data.get('volume', 0)
        oi = option_data.get('oi', 0)
        
        # Calculate time to expiry
        T = calculate_time_to_expiry(expiry)
        
        # Skip if expired
        if T <= 0:
            return None
        
        # Calculate fair price using Black-Scholes
        r = RISK_FREE_RATE
        if option_type == 'call':
            fair_price = black_scholes_call(spot, strike, T, r, fair_volatility)
        else:
            fair_price = black_scholes_put(spot, strike, T, r, fair_volatility)
        
        # Detect valuation status
        valuation_status = detect_valuation_status(market_price, fair_price)
        
        # Calculate confidence level
        confidence = calculate_confidence_level(bid, ask, volume, oi)
        
        # Format tooltip details
        tooltip_details = {
            'fair_price_formatted': f"{CURRENCY_SYMBOL}{fair_price:,.{PRICE_DECIMAL_PLACES}f}",
            'market_price_formatted': f"{CURRENCY_SYMBOL}{market_price:,.{PRICE_DECIMAL_PLACES}f}",
            'mispricing_pct_formatted': f"{'+' if valuation_status['mispricing_pct'] > 0 else ''}{valuation_status['mispricing_pct']:.{PERCENTAGE_DECIMAL_PLACES}f}%",
            'confidence_level': confidence
        }
        
        # Build complete response
        valuation = {
            'status': valuation_status['status'],
            'fair_price': round(fair_price, PRICE_DECIMAL_PLACES),
            'market_price': round(market_price, PRICE_DECIMAL_PLACES),
            'mispricing_pct': round(valuation_status['mispricing_pct'], PERCENTAGE_DECIMAL_PLACES),
            'action': valuation_status['action'],
            'blinking': valuation_status['blinking'] if ENABLE_BLINKING_ANIMATION else False,
            'tooltip_details': tooltip_details if ENABLE_TOOLTIP else {}
        }
        
        if ENABLE_VALUATION_LOGGING:
            logger.info(
                f"Valuation for {option_type} {strike}: "
                f"status={valuation['status']}, "
                f"fair={fair_price:.2f}, "
                f"market={market_price:.2f}, "
                f"mispricing={valuation['mispricing_pct']:.2f}%"
            )
        
        return valuation
        
    except Exception as e:
        logger.error(f"Failed to build valuation response for {option_type} {strike_data.get('strike_price')}: {e}")
        return None


# ============================================================================
# BATCH PROCESSING
# ============================================================================

def calculate_option_chain_valuations(chain_data: List[Dict]) -> List[Dict]:
    """
    Calculate valuations for entire option chain.
    
    Args:
        chain_data: List of option chain rows
    
    Returns:
        Updated chain data with valuation objects
    """
    if not ENABLE_VALUATION_ICONS:
        return chain_data
    
    try:
        # Calculate fair IV baseline
        fair_iv = calculate_fair_iv_baseline(chain_data)
        logger.info(f"Using fair IV baseline: {fair_iv*100:.2f}%")
        
        # Process each strike
        for strike_data in chain_data:
            # Calculate call valuation
            call_valuation = build_valuation_response(strike_data, fair_iv, 'call')
            if call_valuation and 'call' in strike_data:
                strike_data['call']['valuation'] = call_valuation
            
            # Calculate put valuation
            put_valuation = build_valuation_response(strike_data, fair_iv, 'put')
            if put_valuation and 'put' in strike_data:
                strike_data['put']['valuation'] = put_valuation
        
        return chain_data
        
    except Exception as e:
        logger.error(f"Failed to calculate option chain valuations: {e}")
        return chain_data
