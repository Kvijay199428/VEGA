"""
Subscription Settings Service - Manage user preferences for WebSocket subscriptions
"""

import logging
from typing import Dict, List, Optional
from sqlalchemy.orm import Session

from models.subscription_settings import SubscriptionSettings

logger = logging.getLogger(__name__)


class SubscriptionSettingsService:
    """Service for managing subscription settings"""
    
    @staticmethod
    def get_settings(db: Session) -> SubscriptionSettings:
        """
        Get current subscription settings.
        Creates default settings if none exist.
        """
        settings = db.query(SubscriptionSettings).first()
        
        if not settings:
            # Create default settings
            settings = SubscriptionSettings(
                equity_enabled=True,
                index_enabled=True,
                futures_enabled=False,
                options_enabled=False,
                mtf_enabled=False,
                mis_enabled=False
            )
            db.add(settings)
            db.commit()
            db.refresh(settings)
            logger.info("Created default subscription settings")
        
        return settings
    
    @staticmethod
    def update_settings(
        db: Session,
        equity_enabled: Optional[bool] = None,
        index_enabled: Optional[bool] = None,
        futures_enabled: Optional[bool] = None,
        options_enabled: Optional[bool] = None,
        mtf_enabled: Optional[bool] = None,
        mis_enabled: Optional[bool] = None
    ) -> SubscriptionSettings:
        """Update subscription settings"""
        settings = SubscriptionSettingsService.get_settings(db)
        
        if equity_enabled is not None:
            settings.equity_enabled = equity_enabled
        if index_enabled is not None:
            settings.index_enabled = index_enabled
        if futures_enabled is not None:
            settings.futures_enabled = futures_enabled
        if options_enabled is not None:
            settings.options_enabled = options_enabled
        if mtf_enabled is not None:
            settings.mtf_enabled = mtf_enabled
        if mis_enabled is not None:
            settings.mis_enabled = mis_enabled
        
        db.commit()
        db.refresh(settings)
        
        logger.info(f"Updated subscription settings: {SubscriptionSettings.get_enabled_types(settings)}")
        return settings
    
    @staticmethod
    def get_enabled_types(db: Session) -> List[str]:
        """Get list of enabled instrument types"""
        settings = SubscriptionSettingsService.get_settings(db)
        return SubscriptionSettings.get_enabled_types(settings)
    
    @staticmethod
    def toggle_type(db: Session, instrument_type: str, enabled: bool) -> SubscriptionSettings:
        """Toggle a specific instrument type"""
        settings = SubscriptionSettingsService.get_settings(db)
        
        type_map = {
            'equity': 'equity_enabled',
            'index': 'index_enabled',
            'futures': 'futures_enabled',
            'options': 'options_enabled',
            'mtf': 'mtf_enabled',
            'mis': 'mis_enabled'
        }
        
        if instrument_type in type_map:
            setattr(settings, type_map[instrument_type], enabled)
            db.commit()
            db.refresh(settings)
            logger.info(f"Toggled {instrument_type} to {enabled}")
        
        return settings


# Global instance
subscription_settings_service = SubscriptionSettingsService()
