"""
AI Service - Handles AI strategy generation and execution
Integrates with Claude/GPT APIs for intelligent trading strategies
"""

import asyncio
import json
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import and_
from models.ai_strategy import Strategy, StrategyExecution, AIGenerationLog, MarketSignal, TechnicalIndicator
from models.trading import Instrument, Order, Trade
from models.user import User
from services.upstox_service import upstox_service
from utils.auth import decrypt_token

logger = logging.getLogger(__name__)

class AIService:
    """Service for AI-powered trading strategies and signal generation"""
    
    def __init__(self):
        self.claude_api_key = None
        self.gpt_api_key = None
        self.enabled = False
        
    def initialize(self, claude_key: str = None, gpt_key: str = None):
        """Initialize AI service with API keys"""
        self.claude_api_key = claude_key
        self.gpt_api_key = gpt_key
        self.enabled = bool(claude_key or gpt_key)
        
    # ==========================================================================
    # STRATEGY GENERATION
    # ==========================================================================
    
    async def generate_strategy(self, db: Session, user_id: int, 
                              prompt: str, model: str = "claude") -> Dict[str, Any]:
        """Generate trading strategy using AI"""
        if not self.enabled:
            raise Exception("AI service not configured")
            
        try:
            # Log the generation request
            generation_log = AIGenerationLog(
                user_id=user_id,
                model=model,
                prompt=prompt,
                status="processing",
                created_at=datetime.utcnow()
            )
            db.add(generation_log)
            db.commit()
            
            # Prepare context for AI
            context = await self._prepare_strategy_context(db, user_id, prompt)
            
            # Generate strategy based on model
            if model.lower() == "claude" and self.claude_api_key:
                strategy_data = await self._generate_with_claude(prompt, context)
            elif model.lower() == "gpt" and self.gpt_api_key:
                strategy_data = await self._generate_with_gpt(prompt, context)
            else:
                raise Exception(f"Unsupported model: {model}")
                
            # Create strategy
            strategy = Strategy(
                user_id=user_id,
                name=strategy_data.get("name", "AI Generated Strategy"),
                description=strategy_data.get("description", ""),
                strategy_type=strategy_data.get("type", "AI_GENERATED"),
                parameters=json.dumps(strategy_data.get("parameters", {})),
                rules=json.dumps(strategy_data.get("rules", [])),
                instruments=json.dumps(strategy_data.get("instruments", [])),
                risk_management=json.dumps(strategy_data.get("risk_management", {})),
                is_active=False,  # Created as draft
                created_at=datetime.utcnow()
            )
            
            db.add(strategy)
            db.commit()
            
            # Update generation log
            generation_log.status = "completed"
            generation_log.response = json.dumps(strategy_data)
            generation_log.strategy_id = strategy.id
            db.commit()
            
            logger.info(f"Strategy generated successfully for user {user_id}: {strategy.id}")
            
            return {
                "status": "success",
                "data": {
                    "strategy_id": strategy.id,
                    "name": strategy.name,
                    "description": strategy.description,
                    "parameters": strategy_data.get("parameters", {}),
                    "rules": strategy_data.get("rules", [])
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to generate strategy: {e}")
            if 'generation_log' in locals():
                generation_log.status = "failed"
                generation_log.error = str(e)
                db.commit()
            db.rollback()
            raise
            
    async def _prepare_strategy_context(self, db: Session, user_id: int, prompt: str) -> Dict[str, Any]:
        """Prepare context for AI strategy generation"""
        try:
            # Get user's trading history
            recent_trades = db.query(Trade).filter(
                Trade.user_id == user_id
            ).order_by(Trade.trade_timestamp.desc()).limit(10).all()
            
            # Get user's risk preferences
            user = db.query(User).filter(User.id == user_id).first()
            
            # Get market data for context
            instruments = db.query(Instrument).limit(20).all()
            
            context = {
                "user_id": user_id,
                "risk_preferences": {
                    "max_loss_percent": user.max_loss_percent,
                    "max_position_size": user.max_position_size,
                    "risk_tolerance": user.risk_tolerance
                },
                "recent_trades": [
                    {
                        "instrument_token": trade.instrument_token,
                        "tradingsymbol": trade.tradingsymbol,
                        "transaction_type": trade.transaction_type,
                        "quantity": trade.quantity,
                        "price": trade.price,
                        "pnl": trade.pnl
                    }
                    for trade in recent_trades
                ],
                "market_instruments": [
                    {
                        "token": inst.instrument_token,
                        "symbol": inst.tradingsymbol,
                        "name": inst.name,
                        "type": inst.instrument_type,
                        "exchange": inst.exchange
                    }
                    for inst in instruments
                ],
                "current_date": datetime.utcnow().isoformat()
            }
            
            return context
            
        except Exception as e:
            logger.error(f"Failed to prepare context: {e}")
            raise
            
    async def _generate_with_claude(self, prompt: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Generate strategy using Claude API"""
        try:
            # This would integrate with Anthropic Claude API
            # For now, return mock response
            
            strategy_data = {
                "name": "AI Momentum Strategy",
                "description": "A momentum-based strategy that identifies trending stocks using technical indicators",
                "type": "MOMENTUM",
                "parameters": {
                    "lookback_period": 20,
                    "momentum_threshold": 0.05,
                    "rsi_period": 14,
                    "rsi_overbought": 70,
                    "rsi_oversold": 30,
                    "volume_threshold": 1.5
                },
                "rules": [
                    {
                        "name": "Entry Signal",
                        "condition": "Price > SMA(20) AND RSI(14) < 70 AND Volume > 1.5 * AVG(20)",
                        "action": "BUY"
                    },
                    {
                        "name": "Exit Signal",
                        "condition": "RSI(14) > 70 OR Price < SMA(20) * 0.95",
                        "action": "SELL"
                    }
                ],
                "instruments": ["NSE_EQ|INE467B01029", "NSE_EQ|INE009A01021"],  # Example tokens
                "risk_management": {
                    "stop_loss_percent": 2.0,
                    "take_profit_percent": 5.0,
                    "max_positions": 5,
                    "position_size": 0.1
                }
            }
            
            return strategy_data
            
        except Exception as e:
            logger.error(f"Claude API call failed: {e}")
            raise
            
    async def _generate_with_gpt(self, prompt: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Generate strategy using GPT API"""
        try:
            # This would integrate with OpenAI GPT API
            # For now, return mock response similar to Claude
            
            return await self._generate_with_claude(prompt, context)  # Same structure for now
            
        except Exception as e:
            logger.error(f"GPT API call failed: {e}")
            raise
            
    # ==========================================================================
    # STRATEGY EXECUTION
    # ==========================================================================
    
    async def execute_strategy(self, db: Session, strategy_id: int, 
                             user_id: int, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """Execute a trading strategy"""
        try:
            # Get strategy
            strategy = db.query(Strategy).filter(
                and_(Strategy.id == strategy_id, Strategy.user_id == user_id)
            ).first()
            
            if not strategy:
                raise Exception("Strategy not found")
                
            # Create execution record
            execution = StrategyExecution(
                strategy_id=strategy_id,
                user_id=user_id,
                status="RUNNING",
                parameters=json.dumps(parameters or {}),
                started_at=datetime.utcnow()
            )
            
            db.add(execution)
            db.commit()
            
            # Execute strategy logic
            signals = await self._generate_signals(db, strategy, parameters)
            
            # Process signals
            executed_trades = []
            for signal in signals:
                try:
                    trade_result = await self._execute_signal(db, user_id, signal)
                    executed_trades.append(trade_result)
                except Exception as e:
                    logger.error(f"Failed to execute signal: {e}")
                    
            # Update execution record
            execution.status = "COMPLETED"
            execution.completed_at = datetime.utcnow()
            execution.results = json.dumps({
                "signals_generated": len(signals),
                "trades_executed": len(executed_trades),
                "trades": executed_trades
            })
            
            db.commit()
            
            logger.info(f"Strategy execution completed: {execution.id}")
            
            return {
                "status": "success",
                "data": {
                    "execution_id": execution.id,
                    "signals_generated": len(signals),
                    "trades_executed": len(executed_trades),
                    "results": executed_trades
                }
            }
            
        except Exception as e:
            logger.error(f"Strategy execution failed: {e}")
            if 'execution' in locals():
                execution.status = "FAILED"
                execution.error = str(e)
                execution.completed_at = datetime.utcnow()
                db.commit()
            db.rollback()
            raise
            
    async def _generate_signals(self, db: Session, strategy: Strategy, 
                               parameters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate trading signals based on strategy"""
        try:
            strategy_params = json.loads(strategy.parameters)
            strategy_rules = json.loads(strategy.rules)
            
            signals = []
            
            # Get instruments to analyze
            instruments = json.loads(strategy.instruments)
            
            for instrument_token in instruments:
                # Get current market data
                # This would integrate with market data service
                
                # Apply strategy rules
                for rule in strategy_rules:
                    if await self._evaluate_rule(db, instrument_token, rule, strategy_params):
                        signal = {
                            "instrument_token": instrument_token,
                            "action": rule["action"],
                            "rule_name": rule["name"],
                            "confidence": 0.8,  # This would be calculated
                            "parameters": parameters,
                            "timestamp": datetime.utcnow().isoformat()
                        }
                        signals.append(signal)
                        
            return signals
            
        except Exception as e:
            logger.error(f"Failed to generate signals: {e}")
            raise
            
    async def _evaluate_rule(self, db: Session, instrument_token: str, 
                           rule: Dict[str, Any], parameters: Dict[str, Any]) -> bool:
        """Evaluate a single strategy rule"""
        try:
            # This would implement the actual rule logic
            # For now, return mock evaluation
            
            # Example: RSI < 70 AND Price > SMA(20)
            condition = rule.get("condition", "")
            
            # Mock evaluation - in real implementation, this would:
            # 1. Get current market data
            # 2. Calculate technical indicators
            # 3. Evaluate the condition
            
            return True  # Mock return for now
            
        except Exception as e:
            logger.error(f"Failed to evaluate rule: {e}")
            return False
            
    async def _execute_signal(self, db: Session, user_id: int, 
                            signal: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a trading signal"""
        try:
            # Get user
            user = db.query(User).filter(User.id == user_id).first()
            if not user or not user.upstox_access_token:
                raise Exception("User not authenticated with Upstox")
                
            access_token = decrypt_token(user.upstox_access_token)
            
            # Prepare order
            order_data = {
                "instrument_token": signal["instrument_token"],
                "transaction_type": signal["action"],
                "quantity": 1,  # This would be calculated based on position sizing
                "order_type": "MARKET",
                "product": "MIS",
                "validity": "DAY",
                "tag": f"AI_STRATEGY_{signal.get('rule_name', 'GENERAL')}"
            }
            
            # Place order via Upstox
            # This would integrate with order service
            # For now, return mock execution
            
            return {
                "signal_id": signal.get("id"),
                "order_id": f"AI_{datetime.utcnow().timestamp()}",
                "status": "EXECUTED",
                "executed_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Failed to execute signal: {e}")
            raise
            
    # ==========================================================================
    # MARKET SIGNALS
    # ==========================================================================
    
    async def generate_market_signals(self, db: Session, user_id: int) -> List[Dict[str, Any]]:
        """Generate market-wide trading signals"""
        try:
            signals = []
            
            # Get active strategies for user
            strategies = db.query(Strategy).filter(
                and_(Strategy.user_id == user_id, Strategy.is_active == True)
            ).all()
            
            for strategy in strategies:
                strategy_signals = await self._generate_strategy_signals(db, strategy)
                signals.extend(strategy_signals)
                
            # Store signals in database
            for signal in signals:
                market_signal = MarketSignal(
                    user_id=user_id,
                    instrument_token=signal["instrument_token"],
                    signal_type=signal["type"],
                    action=signal["action"],
                    confidence=signal["confidence"],
                    parameters=json.dumps(signal.get("parameters", {})),
                    reason=signal.get("reason", ""),
                    generated_at=datetime.utcnow()
                )
                db.add(market_signal)
                
            db.commit()
            
            logger.info(f"Generated {len(signals)} market signals for user {user_id}")
            
            return signals
            
        except Exception as e:
            logger.error(f"Failed to generate market signals: {e}")
            db.rollback()
            raise
            
    async def _generate_strategy_signals(self, db: Session, strategy: Strategy) -> List[Dict[str, Any]]:
        """Generate signals for a specific strategy"""
        try:
            signals = []
            
            # Get strategy parameters
            parameters = json.loads(strategy.parameters)
            
            # Get instruments for strategy
            instruments = json.loads(strategy.instruments)
            
            # Generate signals for each instrument
            for instrument_token in instruments:
                # Analyze instrument
                signal_data = await self._analyze_instrument(db, instrument_token, parameters)
                
                if signal_data:
                    signal = {
                        "instrument_token": instrument_token,
                        "type": strategy.strategy_type,
                        "action": signal_data["action"],
                        "confidence": signal_data["confidence"],
                        "parameters": signal_data.get("parameters", {}),
                        "reason": signal_data.get("reason", ""),
                        "strategy_id": strategy.id
                    }
                    signals.append(signal)
                    
            return signals
            
        except Exception as e:
            logger.error(f"Failed to generate strategy signals: {e}")
            raise
            
    async def _analyze_instrument(self, db: Session, instrument_token: str, 
                                parameters: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Analyze instrument for trading signals"""
        try:
            # This would implement technical analysis
            # For now, return mock analysis
            
            # Example: Check if price is above moving average
            # This would require historical data and indicator calculations
            
            return {
                "action": "BUY",
                "confidence": 0.75,
                "parameters": parameters,
                "reason": "Price above 20-day moving average with positive momentum"
            }
            
        except Exception as e:
            logger.error(f"Failed to analyze instrument: {e}")
            return None
            
    async def get_market_signals(self, db: Session, user_id: int, 
                               limit: int = 50) -> Dict[str, Any]:
        """Get market signals for user"""
        try:
            signals = db.query(MarketSignal).filter(
                MarketSignal.user_id == user_id
            ).order_by(MarketSignal.generated_at.desc()).limit(limit).all()
            
            signal_data = []
            for signal in signals:
                signal_dict = {
                    "id": signal.id,
                    "instrument_token": signal.instrument_token,
                    "signal_type": signal.signal_type,
                    "action": signal.action,
                    "confidence": signal.confidence,
                    "parameters": json.loads(signal.parameters) if signal.parameters else {},
                    "reason": signal.reason,
                    "status": signal.status,
                    "executed_at": signal.executed_at.isoformat() if signal.executed_at else None,
                    "generated_at": signal.generated_at.isoformat()
                }
                signal_data.append(signal_dict)
                
            return {
                "status": "success",
                "data": {
                    "signals": signal_data,
                    "total": len(signals)
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to get market signals: {e}")
            raise
            
    async def execute_market_signal(self, db: Session, signal_id: int, 
                                  user_id: int) -> Dict[str, Any]:
        """Execute a market signal"""
        try:
            signal = db.query(MarketSignal).filter(
                and_(MarketSignal.id == signal_id, MarketSignal.user_id == user_id)
            ).first()
            
            if not signal:
                raise Exception("Signal not found")
                
            if signal.status != "PENDING":
                raise Exception(f"Signal already {signal.status.lower()}")
                
            # Execute the signal
            execution_result = await self._execute_signal(db, user_id, {
                "instrument_token": signal.instrument_token,
                "action": signal.action,
                "confidence": signal.confidence,
                "parameters": json.loads(signal.parameters) if signal.parameters else {}
            })
            
            # Update signal status
            signal.status = "EXECUTED"
            signal.executed_at = datetime.utcnow()
            db.commit()
            
            return {
                "status": "success",
                "data": execution_result
            }
            
        except Exception as e:
            logger.error(f"Failed to execute market signal: {e}")
            db.rollback()
            raise
            
    # ==========================================================================
    # TECHNICAL INDICATORS
    # ==========================================================================
    
    async def calculate_technical_indicators(self, db: Session, 
                                           instrument_token: str, 
                                           indicators: List[str]) -> Dict[str, Any]:
        """Calculate technical indicators for an instrument"""
        try:
            # This would calculate various technical indicators
            # For now, return mock data
            
            calculated_indicators = {}
            
            for indicator in indicators:
                if indicator.upper() == "SMA":
                    calculated_indicators["SMA_20"] = 150.25
                    calculated_indicators["SMA_50"] = 145.80
                elif indicator.upper() == "RSI":
                    calculated_indicators["RSI_14"] = 65.5
                elif indicator.upper() == "MACD":
                    calculated_indicators["MACD"] = 2.5
                    calculated_indicators["MACD_SIGNAL"] = 1.8
                elif indicator.upper() == "BB":
                    calculated_indicators["BB_UPPER"] = 155.50
                    calculated_indicators["BB_MIDDLE"] = 150.25
                    calculated_indicators["BB_LOWER"] = 145.00
                    
            return {
                "status": "success",
                "data": {
                    "instrument_token": instrument_token,
                    "indicators": calculated_indicators,
                    "calculated_at": datetime.utcnow().isoformat()
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to calculate indicators: {e}")
            raise

# Global instance
ai_service = AIService()