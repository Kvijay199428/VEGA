"""
Market Data WebSocket Service - Connects to Upstox v3 Market Data Feed
"""

import asyncio
import json
import logging
import websockets
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime
import struct

logger = logging.getLogger(__name__)


class MarketDataWebSocket:
    """
    WebSocket client for Upstox Market Data Feed V3
    
    Connects to Upstox, subscribes to instruments, and decodes Protobuf messages.
    """
    
    def __init__(self):
        self.ws = None
        self.is_connected = False
        self.is_connecting = False
        self.access_token: Optional[str] = None
        self.websocket_url: Optional[str] = None
        self.subscriptions: Dict[str, str] = {}  # instrument_key -> mode
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = 5
        self.reconnect_delay = 2
        
        # Callbacks
        self.on_feed: Optional[Callable] = None
        self.on_market_info: Optional[Callable] = None
        self.on_connect: Optional[Callable] = None
        self.on_disconnect: Optional[Callable] = None
        self.on_error: Optional[Callable] = None
        
        # Latest data cache
        self.market_status: Dict[str, str] = {}
        self.index_prices: Dict[str, Dict] = {}

    async def get_websocket_url(self, access_token: str) -> str:
        """Get WebSocket URL from Upstox v3 API"""
        import aiohttp
        
        url = "https://api.upstox.com/v3/feed/market-data-feed/authorize"
        headers = {
            'Authorization': f'Bearer {access_token}',
            'Accept': '*/*'
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers, allow_redirects=False) as response:
                if response.status == 302:
                    # Get redirect URL
                    redirect_url = response.headers.get('Location')
                    if redirect_url:
                        return redirect_url
                    raise Exception("No redirect URL in response")
                elif response.status == 200:
                    data = await response.json()
                    if data.get('status') == 'success':
                        return data.get('data', {}).get('authorizedRedirectUri')
                    raise Exception(f"Auth failed: {data}")
                else:
                    error = await response.text()
                    raise Exception(f"Auth failed ({response.status}): {error}")

    async def connect(self, access_token: str, instrument_keys: List[str] = None):
        """
        Connect to Upstox WebSocket and subscribe to instruments
        
        Args:
            access_token: Upstox access token
            instrument_keys: List of instrument keys to subscribe (optional)
        """
        if self.is_connected or self.is_connecting:
            logger.warning("Already connected or connecting")
            return
            
        self.is_connecting = True
        self.access_token = access_token
        
        try:
            # Get WebSocket URL
            self.websocket_url = await self.get_websocket_url(access_token)
            logger.info(f"Got WebSocket URL: {self.websocket_url[:50]}...")
            
            # Connect to WebSocket
            # Note: Headers may already be embedded in the redirect URL
            # For websockets 11+, use additional_headers instead of extra_headers
            self.ws = await websockets.connect(
                self.websocket_url,
                ping_interval=30,
                ping_timeout=10
            )
            
            self.is_connected = True
            self.is_connecting = False
            self.reconnect_attempts = 0
            
            logger.info("✅ Connected to Upstox Market Data Feed V3")
            
            if self.on_connect:
                await self.on_connect()
            
            # Subscribe to instruments if provided
            if instrument_keys:
                await self.subscribe(instrument_keys, mode='ltpc')
            
            # Start message receiver
            asyncio.create_task(self._receive_messages())
            
        except Exception as e:
            self.is_connecting = False
            logger.error(f"❌ Failed to connect: {e}")
            if self.on_error:
                await self.on_error(str(e))
            raise

    async def subscribe(self, instrument_keys: List[str], mode: str = 'ltpc'):
        """
        Subscribe to instruments
        
        Args:
            instrument_keys: List of instrument keys
            mode: Subscription mode (ltpc, option_greeks, full, full_d30)
        """
        if not self.is_connected or not self.ws:
            logger.error("Not connected to WebSocket")
            return
            
        # Build subscription request
        request = {
            "guid": self._generate_guid(),
            "method": "sub",
            "data": {
                "mode": mode,
                "instrumentKeys": instrument_keys
            }
        }
        
        # Send as binary (JSON encoded as bytes)
        message = json.dumps(request).encode('utf-8')
        await self.ws.send(message)
        
        # Track subscriptions
        for key in instrument_keys:
            self.subscriptions[key] = mode
            
        logger.info(f"📊 Subscribed to {len(instrument_keys)} instruments with mode '{mode}'")

    async def unsubscribe(self, instrument_keys: List[str]):
        """Unsubscribe from instruments"""
        if not self.is_connected or not self.ws:
            return
            
        request = {
            "guid": self._generate_guid(),
            "method": "unsub",
            "data": {
                "instrumentKeys": instrument_keys
            }
        }
        
        message = json.dumps(request).encode('utf-8')
        await self.ws.send(message)
        
        for key in instrument_keys:
            self.subscriptions.pop(key, None)
            
        logger.info(f"Unsubscribed from {len(instrument_keys)} instruments")

    async def change_mode(self, instrument_keys: List[str], mode: str):
        """Change subscription mode for instruments"""
        if not self.is_connected or not self.ws:
            return
            
        request = {
            "guid": self._generate_guid(),
            "method": "change_mode",
            "data": {
                "mode": mode,
                "instrumentKeys": instrument_keys
            }
        }
        
        message = json.dumps(request).encode('utf-8')
        await self.ws.send(message)
        
        for key in instrument_keys:
            if key in self.subscriptions:
                self.subscriptions[key] = mode

    async def _receive_messages(self):
        """Receive and process WebSocket messages"""
        try:
            async for message in self.ws:
                try:
                    # Decode message (binary Protobuf)
                    decoded = self._decode_message(message)
                    
                    if decoded:
                        await self._handle_message(decoded)
                        
                except Exception as e:
                    logger.error(f"Error processing message: {e}")
                    
        except websockets.ConnectionClosed as e:
            logger.warning(f"WebSocket connection closed: {e}")
            self.is_connected = False
            
            if self.on_disconnect:
                await self.on_disconnect()
                
            # Attempt reconnect
            await self._reconnect()
            
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
            self.is_connected = False
            
            if self.on_error:
                await self.on_error(str(e))

    def _decode_message(self, data: bytes) -> Optional[Dict]:
        """
        Decode Protobuf message from Upstox
        
        For simplicity, we'll try JSON first (some messages may be JSON),
        then fall back to basic Protobuf parsing.
        """
        try:
            # Try JSON first
            return json.loads(data.decode('utf-8'))
        except (json.JSONDecodeError, UnicodeDecodeError):
            pass
        
        # Try Protobuf decoding
        try:
            # Use protobuf library if available
            from google.protobuf import json_format
            # Import generated proto classes
            try:
                from middleware.helper import MarketDataFeed_pb2
                feed_response = MarketDataFeed_pb2.FeedResponse()
                feed_response.ParseFromString(data)
                return json_format.MessageToDict(feed_response)
            except ImportError:
                # Proto file not compiled, use basic parsing
                return self._basic_protobuf_decode(data)
        except Exception as e:
            logger.warning(f"Failed to decode protobuf: {e}")
            return None
    
    def _basic_protobuf_decode(self, data: bytes) -> Optional[Dict]:
        """
        Basic protobuf field extraction without compiled proto
        This is a simplified decoder for LTPC messages
        """
        try:
            result = {
                "type": "live_feed",
                "feeds": {},
                "raw_data": True
            }
            
            # Log raw data length for debugging
            logger.debug(f"Received {len(data)} bytes of data")
            
            return result
        except Exception as e:
            logger.error(f"Basic protobuf decode failed: {e}")
            return None

    async def _handle_message(self, data: Dict):
        """Handle decoded message"""
        msg_type = data.get('type', '').lower()
        
        if msg_type == 'market_info':
            # Market status update
            market_info = data.get('marketInfo', {})
            self.market_status = market_info.get('segmentStatus', {})
            
            logger.info(f"📈 Market status: {len(self.market_status)} segments")
            
            if self.on_market_info:
                await self.on_market_info(data)
                
        elif msg_type in ('live_feed', 'initial_feed'):
            # Price update
            feeds = data.get('feeds', {})
            
            for instrument_key, feed_data in feeds.items():
                ltpc = feed_data.get('ltpc', {})
                if ltpc:
                    self.index_prices[instrument_key] = {
                        'ltp': ltpc.get('ltp', 0),
                        'ltt': ltpc.get('ltt', ''),
                        'ltq': ltpc.get('ltq', ''),
                        'cp': ltpc.get('cp', 0),
                        'change': ((ltpc.get('ltp', 0) - ltpc.get('cp', 0)) / ltpc.get('cp', 1)) * 100 if ltpc.get('cp') else 0,
                        'updated_at': datetime.now().isoformat()
                    }
            
            if self.on_feed:
                await self.on_feed(data)
        else:
            logger.debug(f"Unknown message type: {msg_type}")

    async def _reconnect(self):
        """Attempt to reconnect"""
        if self.reconnect_attempts >= self.max_reconnect_attempts:
            logger.error("Max reconnect attempts reached")
            return
            
        self.reconnect_attempts += 1
        delay = self.reconnect_delay * (2 ** (self.reconnect_attempts - 1))
        
        logger.info(f"Reconnecting in {delay}s (attempt {self.reconnect_attempts})")
        await asyncio.sleep(delay)
        
        try:
            if self.access_token:
                # Get stored subscriptions
                instrument_keys = list(self.subscriptions.keys())
                await self.connect(self.access_token, instrument_keys)
        except Exception as e:
            logger.error(f"Reconnect failed: {e}")
            await self._reconnect()

    async def disconnect(self):
        """Disconnect from WebSocket"""
        if self.ws:
            await self.ws.close()
            self.ws = None
        
        self.is_connected = False
        self.subscriptions.clear()
        self.index_prices.clear()
        
        logger.info("Disconnected from Market Data Feed")

    def _generate_guid(self) -> str:
        """Generate unique GUID for requests"""
        import uuid
        return str(uuid.uuid4())[:20]

    def get_index_prices(self) -> Dict[str, Dict]:
        """Get current cached index prices"""
        return self.index_prices.copy()

    def get_market_status(self) -> Dict[str, str]:
        """Get current market status"""
        return self.market_status.copy()


# Global singleton instance
market_data_ws = MarketDataWebSocket()
