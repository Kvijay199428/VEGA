"""
Instrument Sync Service - Download and sync instruments from Upstox
Saves to separate tables for each instrument type
"""

import gzip
import json
import io
import logging
from typing import Dict, List, Any
from datetime import datetime
import requests
from sqlalchemy.orm import Session
from sqlalchemy import text

from models.instrument_models import (
    EquityInstrument,
    IndexInstrument,
    FuturesInstrument,
    OptionsInstrument,
    MTFInstrument,
    MISInstrument,
    SyncMetadata
)
from database.connection import Base, engine

logger = logging.getLogger(__name__)


class InstrumentSyncService:
    """Service for downloading and syncing Upstox instruments to separate tables"""
    
    UPSTOX_INSTRUMENTS_URL = "https://assets.upstox.com/market-quote/instruments/exchange/complete.json.gz"
    
    # Type classifications
    EQUITY_TYPES = {'EQ', 'SM'}
    FUTURE_TYPES = {'FUT'}
    OPTION_TYPES = {'CE', 'PE'}
    INDEX_TYPES = {'INDEX'}
    
    # Segment mappings
    EQUITY_SEGMENTS = {'NSE_EQ', 'BSE_EQ'}
    INDEX_SEGMENTS = {'NSE_INDEX', 'BSE_INDEX', 'MCX_INDEX'}
    FO_SEGMENTS = {'NSE_FO', 'BSE_FO', 'MCX_FO', 'NCD_FO', 'BCD_FO'}
    
    def __init__(self):
        self.sync_time = None
    
    def download_instruments(self) -> List[Dict[str, Any]]:
        """Download instruments from Upstox GZ file"""
        try:
            logger.info("📥 Downloading instruments from Upstox...")
            
            response = requests.get(
                self.UPSTOX_INSTRUMENTS_URL,
                timeout=120,
                stream=True
            )
            response.raise_for_status()
            
            # Decompress and parse JSON
            compressed_data = io.BytesIO(response.content)
            with gzip.GzipFile(fileobj=compressed_data) as gzip_file:
                data = json.loads(gzip_file.read().decode('utf-8'))
            
            logger.info(f"✅ Downloaded {len(data)} instruments")
            return data
            
        except Exception as e:
            logger.error(f"❌ Instrument download failed: {e}")
            raise
    
    def classify_instruments(self, instruments: List[Dict]) -> Dict[str, List[Dict]]:
        """Classify instruments into separate categories"""
        classified = {
            'equity': [],
            'index': [],
            'futures': [],
            'options': [],
            'mtf': [],
            'mis': []
        }
        
        for inst in instruments:
            segment = inst.get('segment', '')
            inst_type = inst.get('instrument_type', '')
            
            # Index instruments
            if inst_type == 'INDEX' or segment in self.INDEX_SEGMENTS:
                classified['index'].append(inst)
            
            # Equity instruments
            elif inst_type in self.EQUITY_TYPES and segment in self.EQUITY_SEGMENTS:
                classified['equity'].append(inst)
                
                # Check MTF
                if inst.get('mtf_enabled'):
                    classified['mtf'].append(inst)
                
                # Check MIS
                if inst.get('intraday_margin') or inst.get('intraday_leverage'):
                    classified['mis'].append(inst)
            
            # Futures instruments
            elif inst_type in self.FUTURE_TYPES:
                classified['futures'].append(inst)
            
            # Options instruments
            elif inst_type in self.OPTION_TYPES:
                classified['options'].append(inst)
        
        logger.info(
            f"📊 Classified: EQ={len(classified['equity'])}, "
            f"IDX={len(classified['index'])}, "
            f"FUT={len(classified['futures'])}, "
            f"OPT={len(classified['options'])}, "
            f"MTF={len(classified['mtf'])}, "
            f"MIS={len(classified['mis'])}"
        )
        
        return classified
    
    def create_tables(self):
        """Create all instrument tables"""
        logger.info("Creating instrument tables...")
        Base.metadata.create_all(bind=engine)
        logger.info("✅ Tables created")
    
    def clear_tables(self, db: Session):
        """Clear all instrument tables before sync"""
        tables = [
            'mis_instruments',
            'mtf_instruments',
            'options_instruments',
            'futures_instruments',
            'index_instruments',
            'equity_instruments'
        ]
        
        for table in tables:
            try:
                db.execute(text(f"DELETE FROM {table}"))
            except Exception:
                pass  # Table might not exist yet
        
        db.commit()
        logger.info("🗑️ Cleared existing data")
    
    def save_equity(self, db: Session, instruments: List[Dict]) -> int:
        """Save equity instruments"""
        count = 0
        for inst in instruments:
            try:
                equity = EquityInstrument(
                    instrument_key=inst.get('instrument_key'),
                    exchange_token=str(inst.get('exchange_token', '')),
                    trading_symbol=inst.get('trading_symbol', ''),
                    name=inst.get('name', ''),
                    short_name=inst.get('short_name'),
                    isin=inst.get('isin'),
                    segment=inst.get('segment', ''),
                    exchange=inst.get('exchange', ''),
                    lot_size=inst.get('lot_size', 1),
                    tick_size=inst.get('tick_size', 0.05),
                    security_type=inst.get('security_type'),
                    mtf_enabled=inst.get('mtf_enabled', False),
                    mtf_bracket=inst.get('mtf_bracket'),
                    intraday_margin=inst.get('intraday_margin'),
                    intraday_leverage=inst.get('intraday_leverage'),
                    last_synced=self.sync_time
                )
                db.merge(equity)
                count += 1
            except Exception as e:
                logger.debug(f"Error saving equity {inst.get('trading_symbol')}: {e}")
        
        db.commit()
        return count
    
    def save_index(self, db: Session, instruments: List[Dict]) -> int:
        """Save index instruments"""
        count = 0
        for inst in instruments:
            try:
                index = IndexInstrument(
                    instrument_key=inst.get('instrument_key'),
                    exchange_token=str(inst.get('exchange_token', '')),
                    trading_symbol=inst.get('trading_symbol', ''),
                    name=inst.get('name', ''),
                    short_name=inst.get('short_name'),
                    segment=inst.get('segment', ''),
                    exchange=inst.get('exchange', ''),
                    last_synced=self.sync_time
                )
                db.merge(index)
                count += 1
            except Exception as e:
                logger.debug(f"Error saving index {inst.get('trading_symbol')}: {e}")
        
        db.commit()
        return count
    
    def save_futures(self, db: Session, instruments: List[Dict]) -> int:
        """Save futures instruments"""
        count = 0
        for inst in instruments:
            try:
                # Parse expiry date - keep original in expiry_str
                expiry = None
                expiry_raw = inst.get('expiry')
                expiry_str_original = str(expiry_raw) if expiry_raw else None
                
                if expiry_raw:
                    try:
                        # Handle epoch milliseconds
                        if isinstance(expiry_raw, (int, float)) or (isinstance(expiry_raw, str) and expiry_raw.isdigit()):
                            expiry_ms = int(expiry_raw)
                            expiry = datetime.fromtimestamp(expiry_ms / 1000).date()
                        else:
                            # Handle ISO format YYYY-MM-DD
                            expiry = datetime.strptime(expiry_raw, '%Y-%m-%d').date()
                    except:
                        pass
                
                futures = FuturesInstrument(
                    instrument_key=inst.get('instrument_key'),
                    exchange_token=str(inst.get('exchange_token', '')),
                    trading_symbol=inst.get('trading_symbol', ''),
                    name=inst.get('name', ''),
                    short_name=inst.get('short_name'),
                    segment=inst.get('segment', ''),
                    exchange=inst.get('exchange', ''),
                    lot_size=inst.get('lot_size', 1),
                    tick_size=inst.get('tick_size', 0.05),
                    underlying_key=inst.get('underlying_key'),
                    underlying_symbol=inst.get('underlying_symbol'),
                    underlying_type=inst.get('underlying_type'),
                    expiry=expiry,
                    expiry_str=expiry_str_original,  # Store original epoch/value
                    minimum_lot=inst.get('minimum_lot'),
                    weekly=inst.get('weekly', False),
                    last_synced=self.sync_time
                )
                db.merge(futures)
                count += 1
            except Exception as e:
                logger.debug(f"Error saving futures {inst.get('trading_symbol')}: {e}")
        
        db.commit()
        return count
    
    def save_options(self, db: Session, instruments: List[Dict]) -> int:
        """Save options instruments"""
        count = 0
        for inst in instruments:
            try:
                # Parse expiry date - keep original in expiry_str
                expiry = None
                expiry_raw = inst.get('expiry')
                expiry_str_original = str(expiry_raw) if expiry_raw else None
                
                if expiry_raw:
                    try:
                        # Handle epoch milliseconds
                        if isinstance(expiry_raw, (int, float)) or (isinstance(expiry_raw, str) and expiry_raw.isdigit()):
                            expiry_ms = int(expiry_raw)
                            expiry = datetime.fromtimestamp(expiry_ms / 1000).date()
                        else:
                            # Handle ISO format YYYY-MM-DD
                            expiry = datetime.strptime(expiry_raw, '%Y-%m-%d').date()
                    except:
                        pass
                
                option = OptionsInstrument(
                    instrument_key=inst.get('instrument_key'),
                    exchange_token=str(inst.get('exchange_token', '')),
                    trading_symbol=inst.get('trading_symbol', ''),
                    name=inst.get('name', ''),
                    short_name=inst.get('short_name'),
                    segment=inst.get('segment', ''),
                    exchange=inst.get('exchange', ''),
                    lot_size=inst.get('lot_size', 1),
                    tick_size=inst.get('tick_size', 0.05),
                    option_type=inst.get('instrument_type', 'CE'),
                    strike_price=inst.get('strike_price'),
                    underlying_key=inst.get('underlying_key'),
                    underlying_symbol=inst.get('underlying_symbol'),
                    underlying_type=inst.get('underlying_type'),
                    expiry=expiry,
                    expiry_str=expiry_str_original,  # Store original epoch/value
                    minimum_lot=inst.get('minimum_lot'),
                    weekly=inst.get('weekly', False),
                    last_synced=self.sync_time
                )
                db.merge(option)
                count += 1
            except Exception as e:
                logger.debug(f"Error saving option {inst.get('trading_symbol')}: {e}")
        
        db.commit()
        return count
    
    def save_mtf(self, db: Session, instruments: List[Dict]) -> int:
        """Save MTF instruments"""
        count = 0
        for inst in instruments:
            try:
                mtf = MTFInstrument(
                    instrument_key=inst.get('instrument_key'),
                    trading_symbol=inst.get('trading_symbol', ''),
                    name=inst.get('name', ''),
                    exchange=inst.get('exchange', ''),
                    segment=inst.get('segment', ''),
                    mtf_bracket=inst.get('mtf_bracket'),
                    last_synced=self.sync_time
                )
                db.merge(mtf)
                count += 1
            except Exception as e:
                logger.debug(f"Error saving MTF {inst.get('trading_symbol')}: {e}")
        
        db.commit()
        return count
    
    def save_mis(self, db: Session, instruments: List[Dict]) -> int:
        """Save MIS instruments"""
        count = 0
        for inst in instruments:
            try:
                mis = MISInstrument(
                    instrument_key=inst.get('instrument_key'),
                    trading_symbol=inst.get('trading_symbol', ''),
                    name=inst.get('name', ''),
                    exchange=inst.get('exchange', ''),
                    segment=inst.get('segment', ''),
                    intraday_margin=inst.get('intraday_margin'),
                    intraday_leverage=inst.get('intraday_leverage'),
                    last_synced=self.sync_time
                )
                db.merge(mis)
                count += 1
            except Exception as e:
                logger.debug(f"Error saving MIS {inst.get('trading_symbol')}: {e}")
        
        db.commit()
        return count
    
    def update_sync_metadata(self, db: Session, table_name: str, count: int, status: str = 'success'):
        """Update sync metadata"""
        try:
            meta = db.query(SyncMetadata).filter(SyncMetadata.table_name == table_name).first()
            if meta:
                meta.last_sync = self.sync_time
                meta.records_count = count
                meta.status = status
            else:
                meta = SyncMetadata(
                    table_name=table_name,
                    last_sync=self.sync_time,
                    records_count=count,
                    status=status
                )
                db.add(meta)
            db.commit()
        except Exception as e:
            logger.error(f"Error updating metadata: {e}")
    
    def sync_instruments(self, db: Session) -> Dict[str, Any]:
        """
        Full sync: Download and save all instruments to separate tables
        """
        start_time = datetime.utcnow()
        self.sync_time = start_time
        
        # Create tables if needed
        self.create_tables()
        
        # Clear existing data
        self.clear_tables(db)
        
        # Download instruments
        instruments = self.download_instruments()
        
        # Classify
        classified = self.classify_instruments(instruments)
        
        # Save to separate tables
        logger.info("💾 Saving instruments to database...")
        
        counts = {
            'equity': self.save_equity(db, classified['equity']),
            'index': self.save_index(db, classified['index']),
            'futures': self.save_futures(db, classified['futures']),
            'options': self.save_options(db, classified['options']),
            'mtf': self.save_mtf(db, classified['mtf']),
            'mis': self.save_mis(db, classified['mis'])
        }
        
        # Update metadata
        for table, count in counts.items():
            self.update_sync_metadata(db, f"{table}_instruments", count)
        
        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()
        
        total_saved = sum(counts.values())
        
        logger.info(f"✅ Sync complete in {duration:.1f}s - Saved {total_saved} instruments")
        
        return {
            'status': 'success',
            'total_downloaded': len(instruments),
            'saved_count': counts,
            'total_saved': total_saved,
            'synced_at': end_time.isoformat(),
            'duration_seconds': duration
        }


# Global instance
instrument_sync_service = InstrumentSyncService()
