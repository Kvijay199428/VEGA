"""
Upstox API Service - Complete Integration
Handles all Upstox API v2 operations including authentication, market data, orders, and WebSocket
"""

import asyncio
import aiohttp
import json
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from urllib.parse import urlencode
import base64
import hashlib
import secrets
from sqlalchemy.orm import Session
from models.user import User, Session as SessionModel
from models.trading import Instrument, Order, Trade, Position, Holding
from utils.auth import decrypt_token, encrypt_token

logger = logging.getLogger(__name__)

class UpstoxService:
    """Complete Upstox API v2 service with OAuth2, market data, and trading"""
    
    def __init__(self):
        self.client_id = None
        self.client_secret = None
        self.redirect_uri = None
        self.base_url = "https://api.upstox.com/v2"
        self.session = None
        
    async def initialize(self, client_id: str, client_secret: str, redirect_uri: str):
        """Initialize with Upstox credentials"""
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30),
            connector=aiohttp.TCPConnector(limit=100, limit_per_host=10)
        )
        
    async def cleanup(self):
        """Clean up session"""
        if self.session:
            await self.session.close()
            
    # ==========================================================================
    # AUTHENTICATION & AUTHORIZATION
    # ==========================================================================
    
    def get_oauth_url(self, state: str = None) -> str:
        """Generate OAuth authorization URL"""
        if not state:
            state = secrets.token_urlsafe(32)
            
        params = {
            'client_id': self.client_id,
            'redirect_uri': self.redirect_uri,
            'response_type': 'code',
            'scope': 'read write trade',
            'state': state
        }
        
        return f"{self.base_url}/login/authorization/dialog?{urlencode(params)}"
        
    async def exchange_code_for_token(self, code: str, db: Session) -> Dict[str, Any]:
        """Exchange authorization code for access token"""
        url = f"{self.base_url}/login/authorization/token"
        
        payload = {
            'code': code,
            'client_id': self.client_id,
            'client_secret': self.client_secret,
            'redirect_uri': self.redirect_uri,
            'grant_type': 'authorization_code'
        }
        
        try:
            async with self.session.post(url, data=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    # Store tokens encrypted
                    access_token = data.get('access_token')
                    refresh_token = data.get('refresh_token')
                    expires_in = data.get('expires_in')
                    
                    if access_token:
                        # Calculate expiry
                        expires_at = datetime.utcnow() + timedelta(seconds=expires_in)
                        
                        return {
                            'access_token': access_token,
                            'refresh_token': refresh_token,
                            'expires_at': expires_at,
                            'token_type': data.get('token_type', 'Bearer')
                        }
                else:
                    error_data = await response.json()
                    logger.error(f"Token exchange failed: {error_data}")
                    raise Exception(f"Upstox API error: {response.status}")
                    
        except Exception as e:
            logger.error(f"Failed to exchange code for token: {e}")
            raise
            
    async def refresh_access_token(self, refresh_token: str, db: Session) -> Dict[str, Any]:
        """Refresh access token using refresh token"""
        url = f"{self.base_url}/login/authorization/token"
        
        payload = {
            'refresh_token': refresh_token,
            'client_id': self.client_id,
            'client_secret': self.client_secret,
            'grant_type': 'refresh_token'
        }
        
        try:
            async with self.session.post(url, data=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    expires_in = data.get('expires_in', 3600)
                    expires_at = datetime.utcnow() + timedelta(seconds=expires_in)
                    
                    return {
                        'access_token': data.get('access_token'),
                        'refresh_token': data.get('refresh_token', refresh_token),
                        'expires_at': expires_at,
                        'token_type': data.get('token_type', 'Bearer')
                    }
                else:
                    error_data = await response.json()
                    raise Exception(f"Token refresh failed: {error_data}")
                    
        except Exception as e:
            logger.error(f"Failed to refresh token: {e}")
            raise
            
    async def get_user_profile(self, access_token: str) -> Dict[str, Any]:
        """Get user profile from Upstox"""
        url = f"{self.base_url}/user/profile"
        headers = {'Authorization': f'Bearer {access_token}'}
        
        try:
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    raise Exception(f"Failed to get profile: {response.status}")
        except Exception as e:
            logger.error(f"Profile fetch failed: {e}")
            raise
            
    # ==========================================================================
    # MARKET DATA
    # ==========================================================================
    
    async def get_quote(self, instrument_token: str, access_token: str) -> Dict[str, Any]:
        """Get live quote for an instrument"""
        url = f"{self.base_url}/market/quote"
        headers = {'Authorization': f'Bearer {access_token}'}
        params = {'instrument_key': instrument_token, 'mode': 'FULL'}
        
        try:
            async with self.session.get(url, headers=headers, params=params) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error = await response.json()
                    raise Exception(f"Quote fetch failed: {error}")
        except Exception as e:
            logger.error(f"Failed to get quote: {e}")
            raise
            
    async def get_batch_quotes(self, instrument_tokens: List[str], access_token: str) -> Dict[str, Any]:
        """Get quotes for multiple instruments"""
        url = f"{self.base_url}/market/quote"
        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        }
        
        payload = {
            'instrument_keys': instrument_tokens,
            'mode': 'FULL'
        }
        
        try:
            async with self.session.get(url, headers=headers, json=payload) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error = await response.json()
                    raise Exception(f"Batch quotes failed: {error}")
        except Exception as e:
            logger.error(f"Failed to get batch quotes: {e}")
            raise
            
    async def get_ohlc_data(self, instrument_token: str, interval: str, 
                           from_date: str, to_date: str, access_token: str) -> Dict[str, Any]:
        """Get OHLC candlestick data"""
        url = f"{self.base_url}/market/ohlc"
        headers = {'Authorization': f'Bearer {access_token}'}
        
        params = {
            'instrument_key': instrument_token,
            'interval': interval,
            'from_date': from_date,
            'to_date': to_date
        }
        
        try:
            async with self.session.get(url, headers=headers, params=params) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error = await response.json()
                    raise Exception(f"OHLC fetch failed: {error}")
        except Exception as e:
            logger.error(f"Failed to get OHLC data: {e}")
            raise
            
    async def get_market_depth(self, instrument_token: str, access_token: str) -> Dict[str, Any]:
        """Get market depth for an instrument"""
        url = f"{self.base_url}/market/depth"
        headers = {'Authorization': f'Bearer {access_token}'}
        params = {'instrument_key': instrument_token}
        
        try:
            async with self.session.get(url, headers=headers, params=params) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error = await response.json()
                    raise Exception(f"Market depth failed: {error}")
        except Exception as e:
            logger.error(f"Failed to get market depth: {e}")
            raise
            
    async def get_instruments(self, exchange: str = None, instrument_type: str = None, 
                             access_token: str = None) -> Dict[str, Any]:
        """Get all tradable instruments"""
        url = f"{self.base_url}/market/instruments"
        headers = {'Authorization': f'Bearer {access_token}'} if access_token else {}
        
        params = {}
        if exchange:
            params['exchange'] = exchange
        if instrument_type:
            params['instrument_type'] = instrument_type
            
        try:
            async with self.session.get(url, headers=headers, params=params) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error = await response.json()
                    raise Exception(f"Instruments fetch failed: {error}")
        except Exception as e:
            logger.error(f"Failed to get instruments: {e}")
            raise
    
    async def get_market_feed_auth(self, access_token: str) -> Dict[str, Any]:
        """
        Get WebSocket authentication URL for Market Data Feed V3.
        
        Returns:
            {
                "status": "success",
                "data": {
                    "authorizedRedirectUri": "wss://api.upstox.com/feed/market-data/v3/..."
                }
            }
        """
        # Use v3 endpoint as v2 is deprecated
        # Note: base_url is v2, but v3 endpoint is at root /v3 path
        url = "https://api.upstox.com/v3/feed/market-data-feed/authorize"
        headers = {'Authorization': f'Bearer {access_token}'}
        
        try:
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error = await response.json()
                    raise Exception(f"Market feed auth failed: {error}")
        except Exception as e:
            logger.error(f"Failed to get market feed auth: {e}")
            raise
    
    async def search_instruments(self, query: str, access_token: str, 
                                 limit: int = 20) -> List[Dict[str, Any]]:
        """
        Search instruments by name or symbol.
        
        Args:
            query: Search query (instrument name or symbol)
            access_token: Upstox access token
            limit: Maximum results to return
            
        Returns:
            List of matching instruments
        """
        url = f"{self.base_url}/market/instruments/search"
        headers = {'Authorization': f'Bearer {access_token}'}
        params = {
            'query': query,
            'limit': limit
        }
        
        try:
            async with self.session.get(url, headers=headers, params=params) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error = await response.json()
                    raise Exception(f"Instrument search failed: {error}")
        except Exception as e:
            logger.error(f"Failed to search instruments: {e}")
            raise
            
    # ==========================================================================
    # ORDERS & TRADING
    # ==========================================================================
    
    async def place_order(self, order_data: Dict[str, Any], access_token: str) -> Dict[str, Any]:
        """Place a new order"""
        url = f"{self.base_url}/order/place"
        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        }
        
        try:
            async with self.session.post(url, headers=headers, json=order_data) as response:
                data = await response.json()
                
                if response.status == 200:
                    return data
                else:
                    raise Exception(f"Order placement failed: {data}")
        except Exception as e:
            logger.error(f"Failed to place order: {e}")
            raise
            
    async def modify_order(self, order_id: str, modifications: Dict[str, Any], 
                          access_token: str) -> Dict[str, Any]:
        """Modify an existing order"""
        url = f"{self.base_url}/order/modify/{order_id}"
        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        }
        
        try:
            async with self.session.post(url, headers=headers, json=modifications) as response:
                data = await response.json()
                
                if response.status == 200:
                    return data
                else:
                    raise Exception(f"Order modification failed: {data}")
        except Exception as e:
            logger.error(f"Failed to modify order: {e}")
            raise
            
    async def cancel_order(self, order_id: str, access_token: str) -> Dict[str, Any]:
        """Cancel an order"""
        url = f"{self.base_url}/order/cancel/{order_id}"
        headers = {'Authorization': f'Bearer {access_token}'}
        
        try:
            async with self.session.delete(url, headers=headers) as response:
                data = await response.json()
                
                if response.status == 200:
                    return data
                else:
                    raise Exception(f"Order cancellation failed: {data}")
        except Exception as e:
            logger.error(f"Failed to cancel order: {e}")
            raise
            
    async def get_orders(self, access_token: str, status: str = None) -> Dict[str, Any]:
        """Get all orders"""
        url = f"{self.base_url}/order/retrieve-all"
        headers = {'Authorization': f'Bearer {access_token}'}
        
        params = {}
        if status:
            params['status'] = status
            
        try:
            async with self.session.get(url, headers=headers, params=params) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error = await response.json()
                    raise Exception(f"Orders fetch failed: {error}")
        except Exception as e:
            logger.error(f"Failed to get orders: {e}")
            raise
            
    async def get_trades(self, access_token: str) -> Dict[str, Any]:
        """Get all trades"""
        url = f"{self.base_url}/order/trades"
        headers = {'Authorization': f'Bearer {access_token}'}
        
        try:
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error = await response.json()
                    raise Exception(f"Trades fetch failed: {error}")
        except Exception as e:
            logger.error(f"Failed to get trades: {e}")
            raise
            
    # ==========================================================================
    # PORTFOLIO
    # ==========================================================================
    
    async def get_holdings(self, access_token: str) -> Dict[str, Any]:
        """Get all holdings"""
        url = f"{self.base_url}/portfolio/long-term-holdings"
        headers = {'Authorization': f'Bearer {access_token}'}
        
        try:
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error = await response.json()
                    raise Exception(f"Holdings fetch failed: {error}")
        except Exception as e:
            logger.error(f"Failed to get holdings: {e}")
            raise
            
    async def get_positions(self, access_token: str) -> Dict[str, Any]:
        """Get all positions"""
        url = f"{self.base_url}/portfolio/short-term-positions"
        headers = {'Authorization': f'Bearer {access_token}'}
        
        try:
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error = await response.json()
                    raise Exception(f"Positions fetch failed: {error}")
        except Exception as e:
            logger.error(f"Failed to get positions: {e}")
            raise
            
    async def get_funds(self, access_token: str) -> Dict[str, Any]:
        """Get funds and margin"""
        url = f"{self.base_url}/user/get-funds-and-margin"
        headers = {'Authorization': f'Bearer {access_token}'}
        
        try:
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    error = await response.json()
                    raise Exception(f"Funds fetch failed: {error}")
        except Exception as e:
            logger.error(f"Failed to get funds: {e}")
            raise

# Global instance
upstox_service = UpstoxService()

# Initialize function for main.py
async def initialize_upstox_service():
    """Initialize Upstox service with credentials"""
    from config import settings
    await upstox_service.initialize(
        client_id=settings.UPSTOX_CLIENT_ID,
        client_secret=settings.UPSTOX_CLIENT_SECRET,
        redirect_uri=settings.UPSTOX_REDIRECT_URI
    )