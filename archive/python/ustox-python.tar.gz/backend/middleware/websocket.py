"""
WebSocket Manager Middleware
Backwards compatibility wrapper - imports from server.websocket
"""

# Re-export from new location for backwards compatibility
from server.websocket.manager import WebSocketManager, websocket_manager

__all__ = ["WebSocketManager", "websocket_manager"]

# Legacy logger reference  
import logging
logger = logging.getLogger(__name__)
