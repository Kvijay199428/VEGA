"""
Market Data Decoder - Decodes Protobuf messages from Upstox Market Data Feed V3
"""

import struct
import json
import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)


class MarketDataDecoder:
    """
    Decodes Protobuf binary messages from Upstox Market Data Feed V3.
    
    Message Types:
    - initial_feed (0): Initial snapshot on subscription
    - live_feed (1): Real-time price updates  
    - market_info (2): Market status information
    
    Request Modes:
    - ltpc (0): Latest Trading Price & Close
    - full_d5 (1): Full with 5 depth levels
    - option_greeks (2): Option Greeks
    - full_d30 (3): Full with 30 depth levels
    """
    
    # Market Status mapping
    MARKET_STATUS = {
        0: "PRE_OPEN_START",
        1: "PRE_OPEN_END",
        2: "NORMAL_OPEN",
        3: "NORMAL_CLOSE",
        4: "CLOSING_START",
        5: "CLOSING_END"
    }
    
    # Message type mapping
    MESSAGE_TYPES = {
        0: "initial_feed",
        1: "live_feed",
        2: "market_info"
    }
    
    # Request mode mapping
    REQUEST_MODES = {
        0: "ltpc",
        1: "full_d5",
        2: "option_greeks",
        3: "full_d30"
    }
    
    @staticmethod
    def decode_message(binary_data: bytes) -> Optional[Dict[str, Any]]:
        """
        Decode binary Protobuf message to JSON dictionary.
        
        Args:
            binary_data: Raw binary data from WebSocket
            
        Returns:
            Decoded message as dictionary, or None if decoding fails
        """
        try:
            # Try to import generated protobuf classes
            try:
                from middleware.helper import MarketDataFeed_pb2
                
                # Create FeedResponse message object
                feed_response = MarketDataFeed_pb2.FeedResponse()
                feed_response.ParseFromString(binary_data)
                
                # Convert to dictionary
                return MarketDataDecoder._proto_to_dict(feed_response)
                
            except ImportError:
                # Fallback: Try to decode without generated classes
                logger.warning("Protobuf classes not generated, using fallback decoder")
                return MarketDataDecoder._fallback_decode(binary_data)
                
        except Exception as e:
            logger.error(f"Failed to decode message: {e}")
            return None
    
    @staticmethod
    def _proto_to_dict(feed_response) -> Dict[str, Any]:
        """Convert protobuf FeedResponse to dictionary"""
        from google.protobuf.json_format import MessageToDict
        
        result = MessageToDict(
            feed_response,
            preserving_proto_field_name=True,
            including_default_value_fields=False
        )
        
        # Map type enum to string
        if 'type' in result:
            result['type'] = MarketDataDecoder.MESSAGE_TYPES.get(result['type'], 'unknown')
        
        return result
    
    @staticmethod
    def _fallback_decode(binary_data: bytes) -> Optional[Dict[str, Any]]:
        """
        Fallback decoder when protobuf classes are not available.
        Uses simple JSON parsing for text-based messages.
        """
        try:
            # Try JSON first (some messages may be JSON)
            return json.loads(binary_data.decode('utf-8'))
        except:
            # Return raw hex for debugging
            return {
                "raw_hex": binary_data.hex(),
                "length": len(binary_data),
                "error": "Unable to decode - protobuf classes not generated"
            }
    
    @staticmethod
    def decode_ltpc(message_dict: Dict) -> Dict[str, Any]:
        """
        Extract and format LTPC (Last Trade Price Close) data.
        
        Args:
            message_dict: Decoded protobuf message
            
        Returns:
            Formatted LTPC data
        """
        try:
            feed_data = {
                "type": message_dict.get('type', 'live_feed'),
                "feeds": {},
                "currentTs": message_dict.get('currentTs')
            }
            
            if 'feeds' in message_dict:
                for instrument_key, feed in message_dict['feeds'].items():
                    # Check for LTPC data in various formats
                    ltpc = None
                    
                    if 'ltpc' in feed:
                        ltpc = feed['ltpc']
                    elif 'fullFeed' in feed:
                        full_feed = feed['fullFeed']
                        if 'marketFF' in full_feed and 'ltpc' in full_feed['marketFF']:
                            ltpc = full_feed['marketFF']['ltpc']
                        elif 'indexFF' in full_feed and 'ltpc' in full_feed['indexFF']:
                            ltpc = full_feed['indexFF']['ltpc']
                    
                    if ltpc:
                        feed_data['feeds'][instrument_key] = {
                            "ltpc": {
                                "ltp": float(ltpc.get('ltp', 0)),
                                "ltt": str(ltpc.get('ltt', '')),
                                "ltq": str(ltpc.get('ltq', '')),
                                "cp": float(ltpc.get('cp', 0))
                            }
                        }
            
            return feed_data
            
        except Exception as e:
            logger.error(f"Failed to decode LTPC: {e}")
            return {"error": str(e)}
    
    @staticmethod
    def decode_full(message_dict: Dict) -> Dict[str, Any]:
        """
        Extract full market data (LTPC + Depth + Metadata).
        
        Args:
            message_dict: Decoded protobuf message
            
        Returns:
            Formatted full market data
        """
        try:
            feed_data = {
                "type": message_dict.get('type', 'live_feed'),
                "feeds": {},
                "currentTs": message_dict.get('currentTs')
            }
            
            if 'feeds' in message_dict:
                for instrument_key, feed in message_dict['feeds'].items():
                    instrument_data = {}
                    
                    # Get full feed data
                    full_feed = None
                    if 'fullFeed' in feed:
                        if 'marketFF' in feed['fullFeed']:
                            full_feed = feed['fullFeed']['marketFF']
                        elif 'indexFF' in feed['fullFeed']:
                            full_feed = feed['fullFeed']['indexFF']
                    
                    if full_feed:
                        # LTPC
                        if 'ltpc' in full_feed:
                            instrument_data['ltpc'] = {
                                "ltp": float(full_feed['ltpc'].get('ltp', 0)),
                                "ltt": str(full_feed['ltpc'].get('ltt', '')),
                                "ltq": str(full_feed['ltpc'].get('ltq', '')),
                                "cp": float(full_feed['ltpc'].get('cp', 0))
                            }
                        
                        # Market depth
                        if 'marketLevel' in full_feed:
                            instrument_data['depth'] = MarketDataDecoder._extract_depth(
                                full_feed['marketLevel']
                            )
                        
                        # Metadata
                        instrument_data['metadata'] = {
                            "atp": float(full_feed.get('atp', 0)),
                            "vtt": str(full_feed.get('vtt', '')),
                            "oi": float(full_feed.get('oi', 0)),
                            "iv": float(full_feed.get('iv', 0)),
                            "tbq": float(full_feed.get('tbq', 0)),
                            "tsq": float(full_feed.get('tsq', 0))
                        }
                        
                        # Option Greeks
                        if 'optionGreeks' in full_feed:
                            instrument_data['optionGreeks'] = MarketDataDecoder._extract_greeks(
                                full_feed['optionGreeks']
                            )
                    
                    feed_data['feeds'][instrument_key] = instrument_data
            
            return feed_data
            
        except Exception as e:
            logger.error(f"Failed to decode full feed: {e}")
            return {"error": str(e)}
    
    @staticmethod
    def decode_option_greeks(message_dict: Dict) -> Dict[str, Any]:
        """
        Extract option greeks data.
        
        Args:
            message_dict: Decoded protobuf message
            
        Returns:
            Formatted option greeks data
        """
        try:
            feed_data = {
                "type": message_dict.get('type', 'live_feed'),
                "feeds": {},
                "currentTs": message_dict.get('currentTs')
            }
            
            if 'feeds' in message_dict:
                for instrument_key, feed in message_dict['feeds'].items():
                    greeks = None
                    
                    if 'firstLevelWithGreeks' in feed:
                        flwg = feed['firstLevelWithGreeks']
                        if 'optionGreeks' in flwg:
                            greeks = flwg['optionGreeks']
                    elif 'fullFeed' in feed and 'marketFF' in feed['fullFeed']:
                        if 'optionGreeks' in feed['fullFeed']['marketFF']:
                            greeks = feed['fullFeed']['marketFF']['optionGreeks']
                    
                    if greeks:
                        feed_data['feeds'][instrument_key] = {
                            "optionGreeks": MarketDataDecoder._extract_greeks(greeks)
                        }
            
            return feed_data
            
        except Exception as e:
            logger.error(f"Failed to decode option greeks: {e}")
            return {"error": str(e)}
    
    @staticmethod
    def decode_market_info(message_dict: Dict) -> Dict[str, Any]:
        """
        Extract market status information.
        
        Args:
            message_dict: Decoded protobuf message
            
        Returns:
            Market status by segment
        """
        try:
            result = {
                "type": "market_info",
                "currentTs": message_dict.get('currentTs'),
                "segmentStatus": {}
            }
            
            if 'marketInfo' in message_dict and 'segmentStatus' in message_dict['marketInfo']:
                for segment, status in message_dict['marketInfo']['segmentStatus'].items():
                    result['segmentStatus'][segment] = MarketDataDecoder.MARKET_STATUS.get(
                        status, f"UNKNOWN_{status}"
                    )
            
            return result
            
        except Exception as e:
            logger.error(f"Failed to decode market info: {e}")
            return {"error": str(e)}
    
    @staticmethod
    def _extract_depth(market_level: Dict) -> Dict[str, List]:
        """Extract market depth (bid/ask quotes)"""
        depth = {"buy": [], "sell": []}
        
        if 'bidAskQuote' in market_level:
            for quote in market_level['bidAskQuote']:
                if quote.get('bidQ', 0) > 0:
                    depth['buy'].append({
                        "price": float(quote.get('bidP', 0)),
                        "quantity": str(quote.get('bidQ', 0)),
                        "orders": "0"  # Not provided in this format
                    })
                if quote.get('askQ', 0) > 0:
                    depth['sell'].append({
                        "price": float(quote.get('askP', 0)),
                        "quantity": str(quote.get('askQ', 0)),
                        "orders": "0"
                    })
        
        return depth
    
    @staticmethod
    def _extract_greeks(greeks: Dict) -> Dict[str, float]:
        """Extract option greeks"""
        return {
            "delta": float(greeks.get('delta', 0)),
            "gamma": float(greeks.get('gamma', 0)),
            "theta": float(greeks.get('theta', 0)),
            "vega": float(greeks.get('vega', 0)),
            "rho": float(greeks.get('rho', 0))
        }


# Export decoder instance for convenience
market_data_decoder = MarketDataDecoder()
