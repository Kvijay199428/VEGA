"""
Authentication Middleware
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from datetime import datetime
from typing import Dict, Optional
import os
import logging

# Configure logging
logger = logging.getLogger(__name__)

# JWT Configuration
SECRET_KEY = os.getenv("SECRET_KEY", "your-super-secret-key-change-in-production-vega-trader-2024")
ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")

# Security scheme
security = HTTPBearer(auto_error=False)


def decode_token(token: str) -> Optional[Dict]:
    """
    Decode and validate a JWT token.
    First tries to decode as a backend JWT, then as an Upstox token.
    
    Args:
        token: JWT token string
        
    Returns:
        Decoded token payload or None if invalid
    """
    # First try to decode as a backend JWT
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        payload["token_type"] = "backend"
        return payload
    except JWTError as e:
        logger.debug(f"Backend token decode error: {e}")
    
    # Try to decode as an Upstox token (without signature verification)
    # Upstox tokens are signed by Upstox, not us
    try:
        # Decode without verification - we trust Upstox's token as it came from their OAuth
        # Pass empty string as key since python-jose requires it even with verify_signature=False
        payload = jwt.decode(token, "", options={"verify_signature": False})
        payload["token_type"] = "upstox"
        return payload
    except JWTError as e:
        logger.debug(f"Upstox token decode error: {e}")
    
    return None


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> Dict:
    """
    Dependency to get current authenticated user from JWT token.
    Accepts both backend JWTs and Upstox access tokens.
    
    Args:
        credentials: HTTP Authorization credentials
        
    Returns:
        User payload from token
        
    Raises:
        HTTPException: If authentication fails
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    if credentials is None:
        raise credentials_exception
    
    token = credentials.credentials
    payload = decode_token(token)
    
    if payload is None:
        raise credentials_exception
    
    token_type = payload.get("token_type", "backend")
    
    # Check if token is expired
    exp = payload.get("exp")
    if exp is not None:
        if datetime.utcnow().timestamp() > exp:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired",
                headers={"WWW-Authenticate": "Bearer"},
            )
    
    # Extract user info based on token type
    if token_type == "upstox":
        # Upstox token format
        user_id = payload.get("user_id") or payload.get("sub")
        return {
            "id": user_id,  # This is the Upstox user ID (e.g., "7EAHBJ")
            "email": payload.get("email"),
            "name": payload.get("user_name"),
            "is_verified": True,  # Upstox tokens are from verified OAuth
            "token_type": "upstox",
            "upstox_token": token  # Include the original token for API calls
        }
    else:
        # Backend JWT token
        user_id = payload.get("sub") or payload.get("user_id")
        if user_id is None:
            raise credentials_exception
        
        return {
            "id": int(user_id) if isinstance(user_id, str) and user_id.isdigit() else user_id,
            "email": payload.get("email"),
            "name": payload.get("name"),
            "is_verified": payload.get("is_verified", False),
            "token_type": "backend"
        }


async def get_optional_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> Optional[Dict]:
    """
    Dependency to optionally get current user (doesn't raise exception if not authenticated).
    
    Args:
        credentials: HTTP Authorization credentials
        
    Returns:
        User payload from token or None
    """
    if credentials is None:
        return None
    
    try:
        return await get_current_user(credentials)
    except HTTPException:
        return None
