"""
Database Connection Configuration
"""

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from typing import Generator
import os
import logging
import shutil

# Configure logging
logger = logging.getLogger(__name__)

# Database path - single vegatrade.db in database/db/db/
DB_DIR = os.path.join(os.path.dirname(__file__), "db", "db")
os.makedirs(DB_DIR, exist_ok=True)

# Single database file
DB_PATH = os.path.join(DB_DIR, "vegatrade.db")

# Database URL - SQLite for development
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{DB_PATH}")

# Create engine
if DATABASE_URL.startswith("sqlite"):
    engine = create_engine(
        DATABASE_URL,
        connect_args={"check_same_thread": False}
    )
else:
    engine = create_engine(DATABASE_URL, pool_pre_ping=True)

# Create SessionLocal class
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create Base class for models
Base = declarative_base()


def get_db() -> Generator:
    """
    Dependency that provides a database session.
    Yields a database session and ensures it is closed after use.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_db_path() -> str:
    """
    Get the absolute path to the SQLite database file.
    Use this for scripts that need direct file access.
    """
    return DB_PATH


def get_sqlite_connection():
    """
    Get a raw sqlite3 connection to the database.
    Use this for scripts that need direct SQL access without SQLAlchemy.
    Remember to close the connection when done.
    
    Usage:
        conn = get_sqlite_connection()
        cursor = conn.cursor()
        # ... do work ...
        conn.close()
    """
    import sqlite3
    return sqlite3.connect(DB_PATH)


# Redis connection (optional - mock if not available)
class MockRedis:
    """Mock Redis client for development without Redis"""
    
    def __init__(self):
        self._data = {}
    
    def get(self, key):
        return self._data.get(key)
    
    def set(self, key, value, ex=None):
        self._data[key] = value
        return True
    
    def delete(self, key):
        self._data.pop(key, None)
        return True
    
    def exists(self, key):
        return key in self._data
    
    def hset(self, name, key=None, value=None, mapping=None):
        if name not in self._data:
            self._data[name] = {}
        if mapping:
            self._data[name].update(mapping)
        elif key and value:
            self._data[name][key] = value
        return True
    
    def hget(self, name, key):
        if name in self._data:
            return self._data[name].get(key)
        return None
    
    def hgetall(self, name):
        return self._data.get(name, {})
    
    def hdel(self, name, *keys):
        if name in self._data:
            for key in keys:
                self._data[name].pop(key, None)
        return True
    
    def publish(self, channel, message):
        logger.debug(f"Mock publish to {channel}: {message}")
        return 0
    
    def subscribe(self, *channels):
        return self


_redis_client = None


def get_redis():
    """
    Get Redis client instance.
    Returns a mock Redis client if Redis is not available.
    """
    global _redis_client
    
    if _redis_client is None:
        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379")
        
        try:
            import redis
            _redis_client = redis.from_url(redis_url, decode_responses=True)
            # Test connection
            _redis_client.ping()
            logger.info("Connected to Redis successfully")
        except Exception as e:
            logger.warning(f"Redis not available, using mock: {e}")
            _redis_client = MockRedis()
    
    return _redis_client
