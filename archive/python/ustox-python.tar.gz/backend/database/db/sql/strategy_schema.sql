-- ============================================================================
-- VEGA TRADER - AI Strategy Schema
-- Tables: strategies, strategy_executions, ai_generation_logs, 
--         market_signals, technical_indicators
-- ============================================================================

-- ============================================================================
-- STRATEGIES TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS strategies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    
    -- Strategy details
    name TEXT NOT NULL,
    description TEXT,
    strategy_type TEXT DEFAULT 'custom',  -- predefined, custom, ai_generated
    category TEXT,                         -- momentum, mean_reversion, trend_following
    
    -- Strategy configuration
    parameters TEXT DEFAULT '{}',          -- JSON
    entry_conditions TEXT DEFAULT '[]',    -- JSON
    exit_conditions TEXT DEFAULT '[]',     -- JSON
    indicators_used TEXT DEFAULT '[]',     -- JSON
    
    -- Risk management
    stop_loss_percent REAL DEFAULT 2.0,
    take_profit_percent REAL DEFAULT 5.0,
    max_position_size REAL DEFAULT 10000,
    max_trades_per_day INTEGER DEFAULT 5,
    trailing_stop_enabled INTEGER DEFAULT 0,
    trailing_stop_percent REAL DEFAULT 1.0,
    
    -- Target instruments
    target_instruments TEXT DEFAULT '[]',  -- JSON
    target_exchanges TEXT DEFAULT '[]',    -- JSON
    target_segments TEXT DEFAULT '[]',     -- JSON
    
    -- Execution settings
    is_active INTEGER DEFAULT 0,
    auto_execute INTEGER DEFAULT 0,
    paper_trading INTEGER DEFAULT 1,
    execution_frequency TEXT DEFAULT 'realtime',
    
    -- Performance tracking
    total_trades INTEGER DEFAULT 0,
    winning_trades INTEGER DEFAULT 0,
    losing_trades INTEGER DEFAULT 0,
    total_pnl REAL DEFAULT 0,
    win_rate REAL DEFAULT 0,
    sharpe_ratio REAL,
    max_drawdown REAL,
    
    -- AI generation details
    ai_generated INTEGER DEFAULT 0,
    ai_model_used TEXT,
    generation_prompt TEXT,
    
    -- Metadata
    version INTEGER DEFAULT 1,
    is_public INTEGER DEFAULT 0,
    forked_from INTEGER,
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_executed_at DATETIME,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_strategies_user ON strategies(user_id);
CREATE INDEX IF NOT EXISTS idx_strategies_type ON strategies(strategy_type);
CREATE INDEX IF NOT EXISTS idx_strategies_active ON strategies(is_active);

-- ============================================================================
-- STRATEGY EXECUTIONS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS strategy_executions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    strategy_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    
    -- Execution details
    execution_type TEXT DEFAULT 'signal',  -- signal, trade, manual
    signal_type TEXT,                       -- BUY, SELL, HOLD
    
    -- Instrument
    instrument_key TEXT,
    symbol TEXT,
    exchange TEXT,
    
    -- Trade details (if executed)
    order_id TEXT,
    quantity INTEGER,
    entry_price REAL,
    exit_price REAL,
    pnl REAL,
    
    -- Signal details
    signal_strength REAL,                   -- 0-1 confidence
    indicators_snapshot TEXT,               -- JSON
    market_conditions TEXT,                 -- JSON
    
    -- Status
    status TEXT DEFAULT 'pending',          -- pending, executed, cancelled, failed
    error_message TEXT,
    
    -- Timestamps
    signal_time DATETIME,
    execution_time DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (strategy_id) REFERENCES strategies(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_strategy_executions_strategy ON strategy_executions(strategy_id);
CREATE INDEX IF NOT EXISTS idx_strategy_executions_user ON strategy_executions(user_id);
CREATE INDEX IF NOT EXISTS idx_strategy_executions_status ON strategy_executions(status);

-- ============================================================================
-- AI GENERATION LOGS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS ai_generation_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    strategy_id INTEGER,
    
    -- Generation details
    prompt TEXT NOT NULL,
    response TEXT,
    model_used TEXT,
    tokens_used INTEGER,
    generation_time_ms INTEGER,
    
    -- Status
    status TEXT DEFAULT 'pending',  -- pending, success, failed
    error_message TEXT,
    
    -- Metadata
    parameters TEXT,                 -- JSON
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (strategy_id) REFERENCES strategies(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_ai_generation_logs_user ON ai_generation_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_generation_logs_strategy ON ai_generation_logs(strategy_id);

-- ============================================================================
-- MARKET SIGNALS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS market_signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    strategy_id INTEGER,
    
    -- Signal details
    signal_type TEXT NOT NULL,       -- BUY, SELL, HOLD
    signal_strength REAL,            -- 0-1 confidence
    
    -- Instrument
    instrument_key TEXT,
    symbol TEXT,
    exchange TEXT,
    
    -- Price levels
    current_price REAL,
    target_price REAL,
    stop_loss_price REAL,
    
    -- Analysis
    analysis_summary TEXT,
    indicators TEXT,                 -- JSON
    patterns_detected TEXT,          -- JSON
    
    -- Status
    is_active INTEGER DEFAULT 1,
    is_executed INTEGER DEFAULT 0,
    expiry_time DATETIME,
    
    -- Timestamps
    signal_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (strategy_id) REFERENCES strategies(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_market_signals_instrument ON market_signals(instrument_key);
CREATE INDEX IF NOT EXISTS idx_market_signals_user ON market_signals(user_id);
CREATE INDEX IF NOT EXISTS idx_market_signals_active ON market_signals(is_active);

-- ============================================================================
-- TECHNICAL INDICATORS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS technical_indicators (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    
    -- Indicator details
    name TEXT NOT NULL,
    indicator_type TEXT NOT NULL,    -- trend, momentum, volatility, volume
    short_name TEXT,
    description TEXT,
    
    -- Configuration
    parameters TEXT DEFAULT '{}',     -- JSON
    default_parameters TEXT DEFAULT '{}',  -- JSON
    is_custom INTEGER DEFAULT 0,
    formula TEXT,
    
    -- Display settings
    display_type TEXT DEFAULT 'line', -- line, histogram, band
    overlay INTEGER DEFAULT 0,        -- True = overlay on price chart
    colors TEXT DEFAULT '{}',         -- JSON
    
    -- Status
    is_active INTEGER DEFAULT 1,
    is_system INTEGER DEFAULT 0,      -- True = built-in indicator
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_technical_indicators_user ON technical_indicators(user_id);
CREATE INDEX IF NOT EXISTS idx_technical_indicators_type ON technical_indicators(indicator_type);
