-- Upstox Authentication Tables Schema
-- This schema manages Upstox API tokens for multi-API authentication

-- =====================================================
-- Table: upstox_tokens
-- Purpose: Store access tokens for 6 Upstox APIs
-- =====================================================

CREATE TABLE IF NOT EXISTS upstox_tokens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL DEFAULT 1,
    api_index INTEGER NOT NULL,  -- 0-5 for MARKETDATA1, MARKETDATA2, OPTIONCHAIN, ORDERS, HISTORIC, AI
    api_name TEXT NOT NULL,      -- Friendly name: MARKETDATA1, MARKETDATA2, etc.
    client_id TEXT NOT NULL,     -- Upstox API client ID
    access_token TEXT NOT NULL,  -- JWT access token
    token_type TEXT DEFAULT 'Bearer',
    purpose TEXT,                -- PRIMARY, WEBSOCKET1-3, OPTIONCHAIN1-2
    is_active INTEGER DEFAULT 1, -- 1 = active, 0 = inactive
    generated_at TEXT,           -- ISO timestamp when token was generated
    validity_at TEXT,            -- ISO timestamp when token expires (next day 3:00 AM)
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    
    -- Constraints
    UNIQUE(user_id, api_index),  -- One token per API index per user
    CHECK(api_index >= 0 AND api_index <= 5),
    CHECK(is_active IN (0, 1))
);

-- =====================================================
-- Indexes for performance
-- =====================================================

-- Index for quick lookup by user and API index
CREATE INDEX IF NOT EXISTS idx_upstox_tokens_user_api 
ON upstox_tokens(user_id, api_index);

-- Index for checking active tokens
CREATE INDEX IF NOT EXISTS idx_upstox_tokens_active 
ON upstox_tokens(is_active, validity_at);

-- Index for purpose-based queries
CREATE INDEX IF NOT EXISTS idx_upstox_tokens_purpose 
ON upstox_tokens(purpose);

-- =====================================================
-- API Index Mapping Reference
-- =====================================================
-- 0: MARKETDATA1  -> PRIMARY      (Main trading token)
-- 1: MARKETDATA2  -> WEBSOCKET1   (WebSocket feed 1)
-- 2: OPTIONCHAIN  -> WEBSOCKET2   (WebSocket feed 2)
-- 3: ORDERS       -> WEBSOCKET3   (WebSocket feed 3)
-- 4: HISTORIC     -> OPTIONCHAIN1 (Option chain data 1)
-- 5: AI           -> OPTIONCHAIN2 (Option chain data 2)

-- =====================================================
-- Sample Query: Get all active tokens
-- =====================================================
-- SELECT 
--     api_index,
--     api_name,
--     purpose,
--     substr(access_token, 1, 20) || '...' as token_preview,
--     generated_at,
--     validity_at,
--     CASE 
--         WHEN datetime(validity_at) > datetime('now') THEN 'VALID'
--         ELSE 'EXPIRED'
--     END as status
-- FROM upstox_tokens
-- WHERE user_id = 1 AND is_active = 1
-- ORDER BY api_index;

-- =====================================================
-- Sample Query: Check PRIMARY token
-- =====================================================
-- SELECT 
--     access_token,
--     validity_at,
--     datetime(validity_at) > datetime('now') as is_valid
-- FROM upstox_tokens
-- WHERE user_id = 1 AND api_index = 0 AND is_active = 1;
