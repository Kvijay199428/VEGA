-- ============================================================================
-- VEGA TRADER - Instrument Database Schema
-- ============================================================================
-- Separate tables for each instrument type, aligned with instrument helpers:
--   - equity_instruments (EquityHelper)
--   - index_instruments (IndexHelper)
--   - futures_instruments (FuturesHelper)
--   - options_instruments (OptionsHelper)
--   - mtf_instruments (MTFHelper)
--   - mis_instruments (MISHelper)
-- ============================================================================

-- Drop existing tables in reverse order of dependencies
DROP TABLE IF EXISTS mis_instruments;
DROP TABLE IF EXISTS mtf_instruments;
DROP TABLE IF EXISTS options_instruments;
DROP TABLE IF EXISTS futures_instruments;
DROP TABLE IF EXISTS index_instruments;
DROP TABLE IF EXISTS equity_instruments;

-- ============================================================================
-- EQUITY INSTRUMENTS
-- ============================================================================
CREATE TABLE equity_instruments (
    instrument_key TEXT PRIMARY KEY,
    exchange_token TEXT NOT NULL,
    trading_symbol TEXT NOT NULL,
    name TEXT NOT NULL,
    short_name TEXT,
    isin TEXT,
    segment TEXT NOT NULL,  -- NSE_EQ, BSE_EQ
    exchange TEXT NOT NULL, -- NSE, BSE
    lot_size INTEGER DEFAULT 1,
    tick_size REAL DEFAULT 0.05,
    security_type TEXT,     -- NORMAL, IPO, RELIST, PCA, SME
    
    -- MTF/MIS details (for quick filtering)
    mtf_enabled INTEGER DEFAULT 0,
    mtf_bracket REAL,
    intraday_margin REAL,
    intraday_leverage REAL,
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_synced DATETIME
);

CREATE INDEX idx_equity_symbol ON equity_instruments(trading_symbol);
CREATE INDEX idx_equity_exchange ON equity_instruments(exchange);
CREATE INDEX idx_equity_segment ON equity_instruments(segment);
CREATE INDEX idx_equity_isin ON equity_instruments(isin);

-- ============================================================================
-- INDEX INSTRUMENTS
-- ============================================================================
CREATE TABLE index_instruments (
    instrument_key TEXT PRIMARY KEY,
    exchange_token TEXT NOT NULL,
    trading_symbol TEXT NOT NULL,
    name TEXT NOT NULL,
    short_name TEXT,
    segment TEXT NOT NULL,  -- NSE_INDEX, BSE_INDEX, MCX_INDEX
    exchange TEXT NOT NULL, -- NSE, BSE, MCX
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_synced DATETIME
);

CREATE INDEX idx_index_symbol ON index_instruments(trading_symbol);
CREATE INDEX idx_index_exchange ON index_instruments(exchange);

-- ============================================================================
-- FUTURES INSTRUMENTS
-- ============================================================================
CREATE TABLE futures_instruments (
    instrument_key TEXT PRIMARY KEY,
    exchange_token TEXT NOT NULL,
    trading_symbol TEXT NOT NULL,
    name TEXT NOT NULL,
    short_name TEXT,
    segment TEXT NOT NULL,  -- NSE_FO, BSE_FO, MCX_FO
    exchange TEXT NOT NULL, -- NSE, BSE, MCX
    lot_size INTEGER DEFAULT 1,
    tick_size REAL DEFAULT 0.05,
    
    -- Underlying details
    underlying_key TEXT,
    underlying_symbol TEXT,
    underlying_type TEXT,   -- EQUITY, INDEX, COM, CUR
    
    -- Expiry
    expiry DATE,
    expiry_str TEXT,        -- Human readable expiry
    minimum_lot INTEGER,
    weekly INTEGER DEFAULT 0,
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_synced DATETIME
);

CREATE INDEX idx_futures_symbol ON futures_instruments(trading_symbol);
CREATE INDEX idx_futures_underlying ON futures_instruments(underlying_symbol);
CREATE INDEX idx_futures_expiry ON futures_instruments(expiry);
CREATE INDEX idx_futures_exchange ON futures_instruments(exchange);

-- ============================================================================
-- OPTIONS INSTRUMENTS
-- ============================================================================
CREATE TABLE options_instruments (
    instrument_key TEXT PRIMARY KEY,
    exchange_token TEXT NOT NULL,
    trading_symbol TEXT NOT NULL,
    name TEXT NOT NULL,
    short_name TEXT,
    segment TEXT NOT NULL,  -- NSE_FO, BSE_FO
    exchange TEXT NOT NULL, -- NSE, BSE
    lot_size INTEGER DEFAULT 1,
    tick_size REAL DEFAULT 0.05,
    
    -- Option details
    option_type TEXT NOT NULL,   -- CE, PE
    strike_price REAL,
    
    -- Underlying details
    underlying_key TEXT,
    underlying_symbol TEXT,
    underlying_type TEXT,   -- EQUITY, INDEX
    
    -- Expiry
    expiry DATE,
    expiry_str TEXT,
    minimum_lot INTEGER,
    weekly INTEGER DEFAULT 0,
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_synced DATETIME
);

CREATE INDEX idx_options_symbol ON options_instruments(trading_symbol);
CREATE INDEX idx_options_underlying ON options_instruments(underlying_symbol);
CREATE INDEX idx_options_strike ON options_instruments(strike_price);
CREATE INDEX idx_options_expiry ON options_instruments(expiry);
CREATE INDEX idx_options_type ON options_instruments(option_type);
CREATE INDEX idx_options_exchange ON options_instruments(exchange);

-- ============================================================================
-- MTF INSTRUMENTS (View or separate table for quick access)
-- ============================================================================
CREATE TABLE mtf_instruments (
    instrument_key TEXT PRIMARY KEY,
    trading_symbol TEXT NOT NULL,
    name TEXT NOT NULL,
    exchange TEXT NOT NULL,
    segment TEXT NOT NULL,
    mtf_bracket REAL,
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_synced DATETIME,
    
    FOREIGN KEY (instrument_key) REFERENCES equity_instruments(instrument_key)
);

CREATE INDEX idx_mtf_symbol ON mtf_instruments(trading_symbol);
CREATE INDEX idx_mtf_bracket ON mtf_instruments(mtf_bracket);

-- ============================================================================
-- MIS (Intraday) INSTRUMENTS
-- ============================================================================
CREATE TABLE mis_instruments (
    instrument_key TEXT PRIMARY KEY,
    trading_symbol TEXT NOT NULL,
    name TEXT NOT NULL,
    exchange TEXT NOT NULL,
    segment TEXT NOT NULL,
    intraday_margin REAL,
    intraday_leverage REAL,
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_synced DATETIME,
    
    FOREIGN KEY (instrument_key) REFERENCES equity_instruments(instrument_key)
);

CREATE INDEX idx_mis_symbol ON mis_instruments(trading_symbol);
CREATE INDEX idx_mis_margin ON mis_instruments(intraday_margin);

-- ============================================================================
-- SYNC METADATA
-- ============================================================================
CREATE TABLE IF NOT EXISTS sync_metadata (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    table_name TEXT NOT NULL,
    last_sync DATETIME,
    records_count INTEGER,
    status TEXT,
    error_message TEXT
);
