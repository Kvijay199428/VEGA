-- ============================================================================
-- VEGA TRADER - Trading Schema
-- Tables: instruments, orders, trades, positions, holdings, portfolio_snapshots
-- ============================================================================

-- ============================================================================
-- INSTRUMENTS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS instruments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    name TEXT,
    isin TEXT,
    exchange TEXT NOT NULL,  -- NSE, BSE, NFO, etc.
    segment TEXT,            -- EQ, FO, etc.
    instrument_type TEXT,    -- EQ, OPTIDX, FUTSTK, etc.
    instrument_key TEXT UNIQUE,
    trading_symbol TEXT,
    lot_size INTEGER DEFAULT 1,
    tick_size REAL DEFAULT 0.05,
    expiry DATETIME,
    strike REAL,
    option_type TEXT,        -- CE, PE
    
    -- Market data
    last_price REAL DEFAULT 0,
    open_price REAL DEFAULT 0,
    high_price REAL DEFAULT 0,
    low_price REAL DEFAULT 0,
    close_price REAL DEFAULT 0,
    volume INTEGER DEFAULT 0,
    
    -- Metadata
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_instruments_symbol ON instruments(symbol);
CREATE INDEX IF NOT EXISTS idx_instruments_key ON instruments(instrument_key);
CREATE INDEX IF NOT EXISTS idx_instruments_trading_symbol ON instruments(trading_symbol);

-- ============================================================================
-- ORDERS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id TEXT UNIQUE,
    user_id INTEGER NOT NULL,
    
    -- Instrument details
    instrument_id INTEGER,
    instrument_key TEXT,
    symbol TEXT NOT NULL,
    exchange TEXT NOT NULL,
    trading_symbol TEXT,
    
    -- Order details
    transaction_type TEXT NOT NULL,  -- BUY, SELL
    order_type TEXT NOT NULL,        -- MARKET, LIMIT, SL, SL-M
    product TEXT NOT NULL,           -- CNC, INTRADAY, MARGIN
    quantity INTEGER NOT NULL,
    price REAL DEFAULT 0,
    trigger_price REAL DEFAULT 0,
    disclosed_qty INTEGER DEFAULT 0,
    validity TEXT DEFAULT 'DAY',     -- DAY, IOC, GTC
    
    -- Execution details
    filled_qty INTEGER DEFAULT 0,
    pending_qty INTEGER DEFAULT 0,
    average_price REAL DEFAULT 0,
    
    -- Status
    status TEXT DEFAULT 'pending',
    status_message TEXT,
    rejection_reason TEXT,
    
    -- Upstox order details
    upstox_order_id TEXT,
    placed_by TEXT,
    variety TEXT,                    -- REGULAR, AMO
    
    -- Metadata
    is_amo INTEGER DEFAULT 0,
    tag TEXT,
    parent_order_id TEXT,
    
    -- Timestamps
    order_timestamp DATETIME,
    exchange_timestamp DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_order_id ON orders(order_id);
CREATE INDEX IF NOT EXISTS idx_orders_instrument ON orders(instrument_id);

-- ============================================================================
-- TRADES TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trade_id TEXT UNIQUE,
    user_id INTEGER NOT NULL,
    order_id TEXT,
    
    -- Instrument details
    instrument_id INTEGER,
    instrument_key TEXT,
    symbol TEXT NOT NULL,
    exchange TEXT NOT NULL,
    trading_symbol TEXT,
    
    -- Trade details
    transaction_type TEXT NOT NULL,  -- BUY, SELL
    product TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL NOT NULL,
    
    -- Computed values
    trade_value REAL DEFAULT 0,
    brokerage REAL DEFAULT 0,
    exchange_charges REAL DEFAULT 0,
    stt REAL DEFAULT 0,
    gst REAL DEFAULT 0,
    total_charges REAL DEFAULT 0,
    net_value REAL DEFAULT 0,
    
    -- Timestamps
    trade_timestamp DATETIME,
    exchange_timestamp DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_trades_user ON trades(user_id);
CREATE INDEX IF NOT EXISTS idx_trades_order ON trades(order_id);
CREATE INDEX IF NOT EXISTS idx_trades_trade_id ON trades(trade_id);

-- ============================================================================
-- POSITIONS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS positions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    
    -- Instrument details
    instrument_id INTEGER,
    instrument_key TEXT,
    symbol TEXT NOT NULL,
    exchange TEXT NOT NULL,
    trading_symbol TEXT,
    
    -- Position details
    product TEXT NOT NULL,
    quantity INTEGER DEFAULT 0,
    overnight_quantity INTEGER DEFAULT 0,
    multiplier REAL DEFAULT 1,
    
    -- Average prices
    average_price REAL DEFAULT 0,
    buy_value REAL DEFAULT 0,
    sell_value REAL DEFAULT 0,
    buy_quantity INTEGER DEFAULT 0,
    sell_quantity INTEGER DEFAULT 0,
    
    -- Current values
    last_price REAL DEFAULT 0,
    pnl REAL DEFAULT 0,
    pnl_percent REAL DEFAULT 0,
    day_pnl REAL DEFAULT 0,
    realised_pnl REAL DEFAULT 0,
    unrealised_pnl REAL DEFAULT 0,
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_positions_user ON positions(user_id);
CREATE INDEX IF NOT EXISTS idx_positions_instrument ON positions(instrument_id);

-- ============================================================================
-- HOLDINGS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS holdings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    
    -- Instrument details
    instrument_id INTEGER,
    instrument_key TEXT,
    symbol TEXT NOT NULL,
    isin TEXT,
    exchange TEXT NOT NULL,
    trading_symbol TEXT,
    
    -- Holding details
    quantity INTEGER DEFAULT 0,
    t1_quantity INTEGER DEFAULT 0,
    used_quantity INTEGER DEFAULT 0,
    collateral_quantity INTEGER DEFAULT 0,
    collateral_type TEXT,
    
    -- Prices and values
    average_price REAL DEFAULT 0,
    last_price REAL DEFAULT 0,
    close_price REAL DEFAULT 0,
    
    -- P&L
    pnl REAL DEFAULT 0,
    pnl_percent REAL DEFAULT 0,
    day_change REAL DEFAULT 0,
    day_change_percent REAL DEFAULT 0,
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_holdings_user ON holdings(user_id);
CREATE INDEX IF NOT EXISTS idx_holdings_instrument ON holdings(instrument_id);

-- ============================================================================
-- PORTFOLIO SNAPSHOTS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS portfolio_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    
    -- Portfolio values
    total_value REAL DEFAULT 0,
    invested_value REAL DEFAULT 0,
    current_value REAL DEFAULT 0,
    available_cash REAL DEFAULT 0,
    
    -- P&L
    total_pnl REAL DEFAULT 0,
    total_pnl_percent REAL DEFAULT 0,
    day_pnl REAL DEFAULT 0,
    day_pnl_percent REAL DEFAULT 0,
    
    -- Breakdown
    holdings_value REAL DEFAULT 0,
    positions_value REAL DEFAULT 0,
    collateral_value REAL DEFAULT 0,
    
    -- Snapshot date
    snapshot_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_portfolio_snapshots_user ON portfolio_snapshots(user_id);
CREATE INDEX IF NOT EXISTS idx_portfolio_snapshots_date ON portfolio_snapshots(snapshot_date);
