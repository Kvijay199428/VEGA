-- ============================================================================
-- VEGA TRADER - User Schema
-- Tables: users, sessions, user_settings, audit_logs
-- ============================================================================

-- ============================================================================
-- USERS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    hashed_password TEXT NOT NULL,
    name TEXT,
    phone TEXT,
    avatar_url TEXT,
    
    -- Account status
    is_active INTEGER DEFAULT 1,
    is_verified INTEGER DEFAULT 0,
    account_status TEXT DEFAULT 'active',
    account_type TEXT DEFAULT 'individual',
    kyc_status TEXT DEFAULT 'pending',
    
    -- Preferences
    theme TEXT DEFAULT 'dark',
    language TEXT DEFAULT 'en',
    timezone TEXT DEFAULT 'Asia/Kolkata',
    
    -- Risk preferences
    max_loss_percent REAL DEFAULT 5.0,
    max_position_size REAL DEFAULT 100000,
    max_daily_loss REAL DEFAULT 10000,
    max_monthly_loss REAL DEFAULT 50000,
    risk_tolerance TEXT DEFAULT 'moderate',
    position_sizing_method TEXT DEFAULT 'fixed',
    stop_loss_enabled INTEGER DEFAULT 1,
    stop_loss_percent REAL DEFAULT 2.0,
    trailing_stop_enabled INTEGER DEFAULT 0,
    trailing_stop_percent REAL DEFAULT 1.0,
    max_positions INTEGER DEFAULT 10,
    max_orders_per_day INTEGER DEFAULT 50,
    auto_square_off_time TEXT DEFAULT '15:15',
    
    -- AI preferences
    ai_trading_enabled INTEGER DEFAULT 0,
    auto_execute_strategies INTEGER DEFAULT 0,
    ai_risk_level TEXT DEFAULT 'medium',
    max_ai_positions INTEGER DEFAULT 5,
    ai_position_size REAL DEFAULT 10000,
    ai_stop_loss REAL DEFAULT 2.0,
    ai_take_profit REAL DEFAULT 5.0,
    ai_notification_frequency TEXT DEFAULT 'realtime',
    ai_preferred_strategies TEXT DEFAULT '[]',  -- JSON array
    ai_excluded_instruments TEXT DEFAULT '[]',  -- JSON array
    ai_learning_mode INTEGER DEFAULT 1,
    ai_feedback_enabled INTEGER DEFAULT 1,
    
    -- Upstox integration
    upstox_access_token TEXT,
    upstox_refresh_token TEXT,
    upstox_token_expires_at DATETIME,
    upstox_linked_at DATETIME,
    upstox_user_id TEXT,
    upstox_user_name TEXT,
    upstox_user_shortname TEXT,
    upstox_email TEXT,
    upstox_user_type TEXT,
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- ============================================================================
-- SESSIONS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token TEXT UNIQUE NOT NULL,
    refresh_token TEXT,
    ip_address TEXT,
    user_agent TEXT,
    device_info TEXT,  -- JSON
    is_active INTEGER DEFAULT 1,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_activity DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token);

-- ============================================================================
-- USER SETTINGS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS user_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    
    -- Notification settings
    email_notifications INTEGER DEFAULT 1,
    sms_notifications INTEGER DEFAULT 0,
    push_notifications INTEGER DEFAULT 1,
    trade_alerts INTEGER DEFAULT 1,
    price_alerts INTEGER DEFAULT 1,
    strategy_alerts INTEGER DEFAULT 1,
    
    -- Trading settings
    default_product TEXT DEFAULT 'CNC',
    default_validity TEXT DEFAULT 'DAY',
    auto_square_off INTEGER DEFAULT 1,
    risk_management INTEGER DEFAULT 1,
    max_loss_percent REAL DEFAULT 5.0,
    
    -- Privacy settings
    share_data INTEGER DEFAULT 0,
    analytics_tracking INTEGER DEFAULT 1,
    marketing_communications INTEGER DEFAULT 0,
    
    -- Preference settings
    theme TEXT DEFAULT 'dark',
    language TEXT DEFAULT 'en',
    timezone TEXT DEFAULT 'Asia/Kolkata',
    date_format TEXT DEFAULT 'DD/MM/YYYY',
    time_format TEXT DEFAULT '24h',
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_user_settings_user ON user_settings(user_id);

-- ============================================================================
-- AUDIT LOGS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    details TEXT,
    ip_address TEXT,
    user_agent TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(created_at);
