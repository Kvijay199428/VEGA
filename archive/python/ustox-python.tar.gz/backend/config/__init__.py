# Config package initialization
# Re-export from config module to maintain backward compatibility
import sys
import os

# Get parent directory
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Import config module directly as _config_module to avoid name collision
import importlib.util
spec = importlib.util.spec_from_file_location("_config_module", os.path.join(parent_dir, "config.py"))
_config_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(_config_module)

# Re-export settings
settings = _config_module.settings

__all__ = ['settings']
