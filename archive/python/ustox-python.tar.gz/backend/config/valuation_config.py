"""
Valuation Configuration
Tunable parameters for option valuation system
"""

# ============================================================================
# MISPRICING THRESHOLDS
# ============================================================================

# Price-based thresholds (percentage)
OVERVALUED_THRESHOLD_PCT = 5.0  # 5% above fair value
UNDERVALUED_THRESHOLD_PCT = -5.0  # 5% below fair value

# IV-based thresholds (percentage points)
OVERVALUED_IV_THRESHOLD = 5.0  # IV deviation in percentage points
UNDERVALUED_IV_THRESHOLD = -5.0

# ============================================================================
# MARKET PARAMETERS
# ============================================================================

# Risk-free rate (annual) - India 10-year bond yield
RISK_FREE_RATE = 0.07  # 7%

# Historical volatility fallback (if IV calculation fails)
DEFAULT_HISTORICAL_VOLATILITY = 0.15  # 15%

# Maximum allowed IV (to filter extreme values)
MAX_ALLOWED_IV = 200.0  # 200%

# Minimum time to expiry (in days) to calculate valuation
MIN_DAYS_TO_EXPIRY = 0  # Set to 0 to skip expired options

# ============================================================================
# CONFIDENCE SCORING
# ============================================================================

# Spread threshold for confidence level (percentage of mid-price)
CONFIDENCE_SPREAD_THRESHOLD = 0.10  # >10% spread = Low confidence

# Volume threshold for confidence
LOW_VOLUME_THRESHOLD = 100  # Contracts

# Open Interest threshold for confidence
LOW_OI_THRESHOLD = 500  # Contracts

# ============================================================================
# ANIMATION PARAMETERS
# ============================================================================

# Blinking animation
BLINK_INTERVAL_MS = 1000  # 1 second per blink cycle
BLINK_OPACITY_MIN = 0.6  # Minimum opacity during blink

# Pulse glow animation
PULSE_GLOW_DURATION_MS = 1500  # 1.5 seconds per pulse cycle

# ============================================================================
# PERFORMANCE SETTINGS
# ============================================================================

# Cache TTL for valuation calculations
VALUATION_CACHE_TTL_SEC = 30  # 30 seconds

# WebSocket update throttle
WS_UPDATE_THROTTLE_MS = 500  # 500ms minimum interval between updates

# Batch size for processing strikes
VALUATION_BATCH_SIZE = 50  # Process 50 strikes at a time

# ============================================================================
# FEATURE FLAGS
# ============================================================================

# Enable/disable valuation features
ENABLE_VALUATION_ICONS = True
ENABLE_BLINKING_ANIMATION = True
ENABLE_TOOLTIP = True
ENABLE_CACHING = True

# Enable detailed logging
ENABLE_VALUATION_LOGGING = True

# ============================================================================
# DISPLAY FORMATTING
# ============================================================================

# Currency symbol
CURRENCY_SYMBOL = "₹"

# Number of decimal places for prices
PRICE_DECIMAL_PLACES = 2

# Number of decimal places for percentages
PERCENTAGE_DECIMAL_PLACES = 2
