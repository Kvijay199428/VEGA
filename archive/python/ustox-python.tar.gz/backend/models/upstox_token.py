"""
Upstox Token Models - Store multiple API tokens for different purposes
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text
from sqlalchemy.sql import func
from database.connection import Base


class UpstoxToken(Base):
    """Model to store Upstox API tokens for different purposes"""
    __tablename__ = "upstox_tokens"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True, nullable=False)
    
    # API identification
    api_index = Column(Integer, nullable=False)  # 0-5
    api_name = Column(String(50), nullable=False)  # PRIMARY, WEBSOCKET1, etc.
    client_id = Column(String(100))
    
    # Token data
    access_token = Column(Text, nullable=False)
    token_type = Column(String(20), default="Bearer")
    
    # Purpose categorization
    purpose = Column(String(50))  # primary, websocket, optionchain
    
    # Status tracking
    is_active = Column(Boolean, default=True)
    
    # Timestamps
    generated_at = Column(DateTime(timezone=True), server_default=func.now())
    validity_at = Column(DateTime(timezone=True))  # Token expires at 3 AM next day
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


# API Configuration Constants
API_CONFIG = {
    0: {"name": "PRIMARY", "purpose": "primary", "description": "Main trading, orders, portfolio management"},
    1: {"name": "WEBSOCKET1", "purpose": "websocket", "description": "WebSocket Market Data Stream 1"},
    2: {"name": "WEBSOCKET2", "purpose": "websocket", "description": "WebSocket Market Data Stream 2"},
    3: {"name": "WEBSOCKET3", "purpose": "websocket", "description": "WebSocket Market Data Stream 3"},
    4: {"name": "OPTIONCHAIN1", "purpose": "optionchain", "description": "Option Chain Data 1"},
    5: {"name": "OPTIONCHAIN2", "purpose": "optionchain", "description": "Option Chain Data 2"},
}


def get_api_name(index: int) -> str:
    """Get API name by index"""
    return API_CONFIG.get(index, {}).get("name", f"API_{index}")


def get_api_purpose(index: int) -> str:
    """Get API purpose by index"""
    return API_CONFIG.get(index, {}).get("purpose", "unknown")
