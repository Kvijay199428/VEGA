"""
Instrument Models - Separate tables for each instrument type
Aligned with instrument helpers (equity, index, futures, options, mtf, mis)
"""

from sqlalchemy import Column, String, Float, Integer, Boolean, DateTime, Date, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from database.connection import Base


class EquityInstrument(Base):
    """
    Equity instruments table - for EquityHelper
    Includes NSE_EQ, BSE_EQ segments
    """
    __tablename__ = "equity_instruments"
    
    instrument_key = Column(String(100), primary_key=True)
    exchange_token = Column(String(50), nullable=False)
    trading_symbol = Column(String(50), nullable=False, index=True)
    name = Column(String(200), nullable=False)
    short_name = Column(String(100), nullable=True)
    isin = Column(String(20), nullable=True, index=True)
    segment = Column(String(20), nullable=False, index=True)
    exchange = Column(String(10), nullable=False, index=True)
    lot_size = Column(Integer, default=1)
    tick_size = Column(Float, default=0.05)
    security_type = Column(String(50), nullable=True)
    
    # MTF/MIS details
    mtf_enabled = Column(Boolean, default=False)
    mtf_bracket = Column(Float, nullable=True)
    intraday_margin = Column(Float, nullable=True)
    intraday_leverage = Column(Float, nullable=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_synced = Column(DateTime, nullable=True)
    
    __table_args__ = {'extend_existing': True}


class IndexInstrument(Base):
    """
    Index instruments table - for IndexHelper
    Includes NSE_INDEX, BSE_INDEX, MCX_INDEX segments
    """
    __tablename__ = "index_instruments"
    
    instrument_key = Column(String(100), primary_key=True)
    exchange_token = Column(String(50), nullable=False)
    trading_symbol = Column(String(50), nullable=False, index=True)
    name = Column(String(200), nullable=False)
    short_name = Column(String(100), nullable=True)
    segment = Column(String(20), nullable=False)
    exchange = Column(String(10), nullable=False, index=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_synced = Column(DateTime, nullable=True)
    
    __table_args__ = {'extend_existing': True}


class FuturesInstrument(Base):
    """
    Futures instruments table - for FuturesHelper
    Includes NSE_FO, BSE_FO, MCX_FO segments with instrument_type=FUT
    """
    __tablename__ = "futures_instruments"
    
    instrument_key = Column(String(100), primary_key=True)
    exchange_token = Column(String(50), nullable=False)
    trading_symbol = Column(String(100), nullable=False, index=True)
    name = Column(String(200), nullable=False)
    short_name = Column(String(100), nullable=True)
    segment = Column(String(20), nullable=False)
    exchange = Column(String(10), nullable=False, index=True)
    lot_size = Column(Integer, default=1)
    tick_size = Column(Float, default=0.05)
    
    # Underlying details
    underlying_key = Column(String(100), nullable=True)
    underlying_symbol = Column(String(50), nullable=True, index=True)
    underlying_type = Column(String(20), nullable=True)
    
    # Expiry
    expiry = Column(Date, nullable=True, index=True)
    expiry_str = Column(String(20), nullable=True)
    minimum_lot = Column(Integer, nullable=True)
    weekly = Column(Boolean, default=False)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_synced = Column(DateTime, nullable=True)
    
    __table_args__ = {'extend_existing': True}


class OptionsInstrument(Base):
    """
    Options instruments table - for OptionsHelper
    Includes NSE_FO, BSE_FO segments with instrument_type=CE/PE
    """
    __tablename__ = "options_instruments"
    
    instrument_key = Column(String(100), primary_key=True)
    exchange_token = Column(String(50), nullable=False)
    trading_symbol = Column(String(100), nullable=False, index=True)
    name = Column(String(200), nullable=False)
    short_name = Column(String(100), nullable=True)
    segment = Column(String(20), nullable=False)
    exchange = Column(String(10), nullable=False, index=True)
    lot_size = Column(Integer, default=1)
    tick_size = Column(Float, default=0.05)
    
    # Option details
    option_type = Column(String(5), nullable=False, index=True)  # CE, PE
    strike_price = Column(Float, nullable=True, index=True)
    
    # Underlying details
    underlying_key = Column(String(100), nullable=True)
    underlying_symbol = Column(String(50), nullable=True, index=True)
    underlying_type = Column(String(20), nullable=True)
    
    # Expiry
    expiry = Column(Date, nullable=True, index=True)
    expiry_str = Column(String(20), nullable=True)
    minimum_lot = Column(Integer, nullable=True)
    weekly = Column(Boolean, default=False)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_synced = Column(DateTime, nullable=True)
    
    __table_args__ = {'extend_existing': True}


class MTFInstrument(Base):
    """
    MTF-enabled instruments - for MTFHelper
    Quick access to MTF enabled equities
    """
    __tablename__ = "mtf_instruments"
    
    instrument_key = Column(String(100), ForeignKey('equity_instruments.instrument_key'), primary_key=True)
    trading_symbol = Column(String(50), nullable=False, index=True)
    name = Column(String(200), nullable=False)
    exchange = Column(String(10), nullable=False)
    segment = Column(String(20), nullable=False)
    mtf_bracket = Column(Float, nullable=True, index=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    last_synced = Column(DateTime, nullable=True)
    
    __table_args__ = {'extend_existing': True}


class MISInstrument(Base):
    """
    MIS (Intraday) enabled instruments - for MISHelper
    Quick access to intraday enabled instruments
    """
    __tablename__ = "mis_instruments"
    
    instrument_key = Column(String(100), ForeignKey('equity_instruments.instrument_key'), primary_key=True)
    trading_symbol = Column(String(50), nullable=False, index=True)
    name = Column(String(200), nullable=False)
    exchange = Column(String(10), nullable=False)
    segment = Column(String(20), nullable=False)
    intraday_margin = Column(Float, nullable=True, index=True)
    intraday_leverage = Column(Float, nullable=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    last_synced = Column(DateTime, nullable=True)
    
    __table_args__ = {'extend_existing': True}


class SyncMetadata(Base):
    """
    Sync metadata - tracks last sync time for each table
    """
    __tablename__ = "sync_metadata"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    table_name = Column(String(50), nullable=False, unique=True)
    last_sync = Column(DateTime, nullable=True)
    records_count = Column(Integer, nullable=True)
    status = Column(String(20), nullable=True)
    error_message = Column(Text, nullable=True)
    
    __table_args__ = {'extend_existing': True}
