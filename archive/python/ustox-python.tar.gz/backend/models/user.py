"""
User Models
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, Text, JSON
from sqlalchemy.sql import func
from database.connection import Base


class User(Base):
    """User model for authentication and profile"""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    name = Column(String(255))
    phone = Column(String(20))
    avatar_url = Column(String(512))
    
    # Account status
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    account_status = Column(String(50), default="active")
    account_type = Column(String(50), default="individual")
    kyc_status = Column(String(50), default="pending")
    
    # Preferences
    theme = Column(String(50), default="dark")
    language = Column(String(10), default="en")
    timezone = Column(String(50), default="Asia/Kolkata")
    
    # Risk preferences
    max_loss_percent = Column(Float, default=5.0)
    max_position_size = Column(Float, default=100000)
    max_daily_loss = Column(Float, default=10000)
    max_monthly_loss = Column(Float, default=50000)
    risk_tolerance = Column(String(20), default="moderate")
    position_sizing_method = Column(String(50), default="fixed")
    stop_loss_enabled = Column(Boolean, default=True)
    stop_loss_percent = Column(Float, default=2.0)
    trailing_stop_enabled = Column(Boolean, default=False)
    trailing_stop_percent = Column(Float, default=1.0)
    max_positions = Column(Integer, default=10)
    max_orders_per_day = Column(Integer, default=50)
    auto_square_off_time = Column(String(10), default="15:15")
    
    # AI preferences
    ai_trading_enabled = Column(Boolean, default=False)
    auto_execute_strategies = Column(Boolean, default=False)
    ai_risk_level = Column(String(20), default="medium")
    max_ai_positions = Column(Integer, default=5)
    ai_position_size = Column(Float, default=10000)
    ai_stop_loss = Column(Float, default=2.0)
    ai_take_profit = Column(Float, default=5.0)
    ai_notification_frequency = Column(String(20), default="realtime")
    ai_preferred_strategies = Column(JSON, default=list)
    ai_excluded_instruments = Column(JSON, default=list)
    ai_learning_mode = Column(Boolean, default=True)
    ai_feedback_enabled = Column(Boolean, default=True)
    
    # Upstox integration
    upstox_access_token = Column(Text)
    upstox_refresh_token = Column(Text)
    upstox_token_expires_at = Column(DateTime)
    upstox_linked_at = Column(DateTime)
    upstox_user_id = Column(String(100))
    upstox_user_name = Column(String(255))
    upstox_user_shortname = Column(String(100))
    upstox_email = Column(String(255))
    upstox_user_type = Column(String(50))
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class Session(Base):
    """User session model for tracking active sessions"""
    __tablename__ = "sessions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True, nullable=False)
    token = Column(String(512), unique=True, nullable=False)
    refresh_token = Column(String(512))
    ip_address = Column(String(50))
    user_agent = Column(String(512))
    device_info = Column(JSON)
    is_active = Column(Boolean, default=True)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    last_activity = Column(DateTime(timezone=True), server_default=func.now())


class UserSettings(Base):
    """User settings model"""
    __tablename__ = "user_settings"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, unique=True, index=True, nullable=False)
    
    # Notification settings
    email_notifications = Column(Boolean, default=True)
    sms_notifications = Column(Boolean, default=False)
    push_notifications = Column(Boolean, default=True)
    trade_alerts = Column(Boolean, default=True)
    price_alerts = Column(Boolean, default=True)
    strategy_alerts = Column(Boolean, default=True)
    
    # Trading settings
    default_product = Column(String(20), default="CNC")
    default_validity = Column(String(20), default="DAY")
    auto_square_off = Column(Boolean, default=True)
    risk_management = Column(Boolean, default=True)
    max_loss_percent = Column(Float, default=5.0)
    
    # Privacy settings
    share_data = Column(Boolean, default=False)
    analytics_tracking = Column(Boolean, default=True)
    marketing_communications = Column(Boolean, default=False)
    
    # Preference settings
    theme = Column(String(50), default="dark")
    language = Column(String(10), default="en")
    timezone = Column(String(50), default="Asia/Kolkata")
    date_format = Column(String(20), default="DD/MM/YYYY")
    time_format = Column(String(10), default="24h")
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class AuditLog(Base):
    """Audit log for tracking user actions"""
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True, nullable=False)
    action = Column(String(100), nullable=False)
    details = Column(Text)
    ip_address = Column(String(50))
    user_agent = Column(String(512))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
