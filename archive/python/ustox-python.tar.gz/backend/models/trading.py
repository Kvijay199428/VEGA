"""
Trading Models
"""

from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, JSON, Enum
from sqlalchemy.sql import func
from database.connection import Base
import enum


class OrderStatus(str, enum.Enum):
    PENDING = "pending"
    OPEN = "open"
    COMPLETE = "complete"
    CANCELLED = "cancelled"
    REJECTED = "rejected"
    TRIGGER_PENDING = "trigger_pending"


class OrderType(str, enum.Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    SL = "SL"
    SL_M = "SL-M"


class TransactionType(str, enum.Enum):
    BUY = "BUY"
    SELL = "SELL"


class ProductType(str, enum.Enum):
    CNC = "CNC"  # Cash and Carry (Delivery)
    INTRADAY = "INTRADAY"  # Intraday (MIS)
    MARGIN = "MARGIN"  # Margin


class Instrument(Base):
    """Instrument/Stock model"""
    __tablename__ = "instruments"

    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String(50), index=True, nullable=False)
    name = Column(String(255))
    isin = Column(String(20))
    exchange = Column(String(20), nullable=False)  # NSE, BSE, NFO, etc.
    segment = Column(String(20))  # EQ, FO, etc.
    instrument_type = Column(String(20))  # EQ, OPTIDX, FUTSTK, etc.
    instrument_key = Column(String(100), unique=True, index=True)
    trading_symbol = Column(String(100), index=True)
    lot_size = Column(Integer, default=1)
    tick_size = Column(Float, default=0.05)
    expiry = Column(DateTime)
    strike = Column(Float)
    option_type = Column(String(2))  # CE, PE
    
    # Market data
    last_price = Column(Float, default=0)
    open_price = Column(Float, default=0)
    high_price = Column(Float, default=0)
    low_price = Column(Float, default=0)
    close_price = Column(Float, default=0)
    volume = Column(Integer, default=0)
    
    # Metadata
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class Order(Base):
    """Order model"""
    __tablename__ = "orders"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(String(50), unique=True, index=True)
    user_id = Column(Integer, index=True, nullable=False)
    
    # Instrument details
    instrument_id = Column(Integer, index=True)
    instrument_key = Column(String(100))
    symbol = Column(String(50), nullable=False)
    exchange = Column(String(20), nullable=False)
    trading_symbol = Column(String(100))
    
    # Order details
    transaction_type = Column(String(10), nullable=False)  # BUY, SELL
    order_type = Column(String(20), nullable=False)  # MARKET, LIMIT, SL, SL-M
    product = Column(String(20), nullable=False)  # CNC, INTRADAY, MARGIN
    quantity = Column(Integer, nullable=False)
    price = Column(Float, default=0)
    trigger_price = Column(Float, default=0)
    disclosed_qty = Column(Integer, default=0)
    validity = Column(String(10), default="DAY")  # DAY, IOC, GTC
    
    # Execution details
    filled_qty = Column(Integer, default=0)
    pending_qty = Column(Integer, default=0)
    average_price = Column(Float, default=0)
    
    # Status
    status = Column(String(20), default="pending")
    status_message = Column(Text)
    rejection_reason = Column(Text)
    
    # Upstox order details
    upstox_order_id = Column(String(50))
    placed_by = Column(String(50))
    variety = Column(String(20))  # REGULAR, AMO
    
    # Metadata
    is_amo = Column(Boolean, default=False)
    tag = Column(String(50))
    parent_order_id = Column(String(50))
    
    # Timestamps
    order_timestamp = Column(DateTime(timezone=True))
    exchange_timestamp = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class Trade(Base):
    """Trade (executed order) model"""
    __tablename__ = "trades"

    id = Column(Integer, primary_key=True, index=True)
    trade_id = Column(String(50), unique=True, index=True)
    user_id = Column(Integer, index=True, nullable=False)
    order_id = Column(String(50), index=True)
    
    # Instrument details
    instrument_id = Column(Integer, index=True)
    instrument_key = Column(String(100))
    symbol = Column(String(50), nullable=False)
    exchange = Column(String(20), nullable=False)
    trading_symbol = Column(String(100))
    
    # Trade details
    transaction_type = Column(String(10), nullable=False)  # BUY, SELL
    product = Column(String(20), nullable=False)
    quantity = Column(Integer, nullable=False)
    price = Column(Float, nullable=False)
    
    # Computed values
    trade_value = Column(Float, default=0)
    brokerage = Column(Float, default=0)
    exchange_charges = Column(Float, default=0)
    stt = Column(Float, default=0)
    gst = Column(Float, default=0)
    total_charges = Column(Float, default=0)
    net_value = Column(Float, default=0)
    
    # Timestamps
    trade_timestamp = Column(DateTime(timezone=True))
    exchange_timestamp = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Position(Base):
    """Position model for intraday positions"""
    __tablename__ = "positions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True, nullable=False)
    
    # Instrument details
    instrument_id = Column(Integer, index=True)
    instrument_key = Column(String(100))
    symbol = Column(String(50), nullable=False)
    exchange = Column(String(20), nullable=False)
    trading_symbol = Column(String(100))
    
    # Position details
    product = Column(String(20), nullable=False)
    quantity = Column(Integer, default=0)
    overnight_quantity = Column(Integer, default=0)
    multiplier = Column(Float, default=1)
    
    # Average prices
    average_price = Column(Float, default=0)
    buy_value = Column(Float, default=0)
    sell_value = Column(Float, default=0)
    buy_quantity = Column(Integer, default=0)
    sell_quantity = Column(Integer, default=0)
    
    # Current values
    last_price = Column(Float, default=0)
    pnl = Column(Float, default=0)
    pnl_percent = Column(Float, default=0)
    day_pnl = Column(Float, default=0)
    realised_pnl = Column(Float, default=0)
    unrealised_pnl = Column(Float, default=0)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class Holding(Base):
    """Holdings model for delivery holdings"""
    __tablename__ = "holdings"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True, nullable=False)
    
    # Instrument details
    instrument_id = Column(Integer, index=True)
    instrument_key = Column(String(100))
    symbol = Column(String(50), nullable=False)
    isin = Column(String(20))
    exchange = Column(String(20), nullable=False)
    trading_symbol = Column(String(100))
    
    # Holding details
    quantity = Column(Integer, default=0)
    t1_quantity = Column(Integer, default=0)
    used_quantity = Column(Integer, default=0)
    collateral_quantity = Column(Integer, default=0)
    collateral_type = Column(String(20))
    
    # Prices and values
    average_price = Column(Float, default=0)
    last_price = Column(Float, default=0)
    close_price = Column(Float, default=0)
    
    # P&L
    pnl = Column(Float, default=0)
    pnl_percent = Column(Float, default=0)
    day_change = Column(Float, default=0)
    day_change_percent = Column(Float, default=0)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class PortfolioSnapshot(Base):
    """Portfolio snapshot for tracking historical portfolio values"""
    __tablename__ = "portfolio_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True, nullable=False)
    
    # Portfolio values
    total_value = Column(Float, default=0)
    invested_value = Column(Float, default=0)
    current_value = Column(Float, default=0)
    available_cash = Column(Float, default=0)
    
    # P&L
    total_pnl = Column(Float, default=0)
    total_pnl_percent = Column(Float, default=0)
    day_pnl = Column(Float, default=0)
    day_pnl_percent = Column(Float, default=0)
    
    # Breakdown
    holdings_value = Column(Float, default=0)
    positions_value = Column(Float, default=0)
    collateral_value = Column(Float, default=0)
    
    # Snapshot date
    snapshot_date = Column(DateTime(timezone=True), server_default=func.now())
    created_at = Column(DateTime(timezone=True), server_default=func.now())
