"""
Subscription Settings Model - User preferences for WebSocket instrument subscriptions
"""

from sqlalchemy import Column, String, Boolean, Integer, DateTime
from datetime import datetime
from database.connection import Base


class SubscriptionSettings(Base):
    """
    User preferences for which instrument types to subscribe via WebSocket.
    
    Default: equity and index enabled, others disabled.
    """
    __tablename__ = "subscription_settings"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    
    # Instrument type toggles
    equity_enabled = Column(Boolean, default=True)
    index_enabled = Column(Boolean, default=True)
    futures_enabled = Column(Boolean, default=False)
    options_enabled = Column(Boolean, default=False)
    mtf_enabled = Column(Boolean, default=False)
    mis_enabled = Column(Boolean, default=False)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    __table_args__ = {'extend_existing': True}
    
    def to_dict(self):
        """Convert to dictionary"""
        return {
            'id': self.id,
            'equity_enabled': self.equity_enabled,
            'index_enabled': self.index_enabled,
            'futures_enabled': self.futures_enabled,
            'options_enabled': self.options_enabled,
            'mtf_enabled': self.mtf_enabled,
            'mis_enabled': self.mis_enabled,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @staticmethod
    def get_enabled_types(settings: 'SubscriptionSettings') -> list:
        """Get list of enabled instrument types"""
        enabled = []
        if settings.equity_enabled:
            enabled.append('equity')
        if settings.index_enabled:
            enabled.append('index')
        if settings.futures_enabled:
            enabled.append('futures')
        if settings.options_enabled:
            enabled.append('options')
        if settings.mtf_enabled:
            enabled.append('mtf')
        if settings.mis_enabled:
            enabled.append('mis')
        return enabled
