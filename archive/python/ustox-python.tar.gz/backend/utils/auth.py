"""
Authentication Utilities
"""

from jose import jwt
from passlib.context import CryptContext
from cryptography.fernet import Fernet
from datetime import datetime, timedelta
from typing import Optional, Dict
import os
import base64
import logging

# Configure logging
logger = logging.getLogger(__name__)

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT Configuration
SECRET_KEY = os.getenv("SECRET_KEY", "your-super-secret-key-change-in-production-vega-trader-2024")
ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60"))
REFRESH_TOKEN_EXPIRE_DAYS = int(os.getenv("REFRESH_TOKEN_EXPIRE_DAYS", "7"))

# Token encryption key for storing third-party tokens
ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY", None)
if not ENCRYPTION_KEY:
    # Generate a key from the secret key if not provided
    key_material = SECRET_KEY.encode()[:32].ljust(32, b'0')
    ENCRYPTION_KEY = base64.urlsafe_b64encode(key_material).decode()

_fernet = None


def get_fernet():
    """Get Fernet instance for encryption."""
    global _fernet
    if _fernet is None:
        try:
            _fernet = Fernet(ENCRYPTION_KEY.encode())
        except Exception:
            # Create a valid key if the provided one is invalid
            key_material = SECRET_KEY.encode()[:32].ljust(32, b'0')
            valid_key = base64.urlsafe_b64encode(key_material)
            _fernet = Fernet(valid_key)
    return _fernet


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verify a plain password against a hashed password.
    
    Args:
        plain_password: Plain text password
        hashed_password: Hashed password to compare against
        
    Returns:
        True if password matches, False otherwise
    """
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    """
    Hash a plain password.
    
    Args:
        password: Plain text password
        
    Returns:
        Hashed password string
    """
    return pwd_context.hash(password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """
    Create a JWT access token.
    
    Args:
        data: Data to encode in the token
        expires_delta: Optional custom expiration time
        
    Returns:
        Encoded JWT token string
    """
    to_encode = data.copy()
    
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    
    return encoded_jwt


def create_refresh_token(data: dict) -> str:
    """
    Create a JWT refresh token.
    
    Args:
        data: Data to encode in the token
        
    Returns:
        Encoded JWT refresh token string
    """
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire, "type": "refresh"})
    
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> Optional[Dict]:
    """
    Decode and validate a JWT token.
    
    Args:
        token: JWT token string
        
    Returns:
        Decoded token payload or None if invalid
    """
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except Exception as e:
        logger.debug(f"Token decode error: {e}")
        return None


def encrypt_token(token: str) -> str:
    """
    Encrypt a token for secure storage.
    
    Args:
        token: Token string to encrypt
        
    Returns:
        Encrypted token string
    """
    try:
        fernet = get_fernet()
        return fernet.encrypt(token.encode()).decode()
    except Exception as e:
        logger.error(f"Token encryption error: {e}")
        raise


def decrypt_token(encrypted_token: str) -> str:
    """
    Decrypt a stored token.
    
    Args:
        encrypted_token: Encrypted token string
        
    Returns:
        Decrypted token string
    """
    try:
        fernet = get_fernet()
        return fernet.decrypt(encrypted_token.encode()).decode()
    except Exception as e:
        logger.error(f"Token decryption error: {e}")
        raise


def generate_verification_token(email: str) -> str:
    """
    Generate a verification token for email verification.
    
    Args:
        email: User's email address
        
    Returns:
        Verification token string
    """
    data = {"email": email, "type": "verification"}
    expire = datetime.utcnow() + timedelta(hours=24)
    data["exp"] = expire
    
    return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)


def generate_password_reset_token(email: str) -> str:
    """
    Generate a password reset token.
    
    Args:
        email: User's email address
        
    Returns:
        Password reset token string
    """
    data = {"email": email, "type": "password_reset"}
    expire = datetime.utcnow() + timedelta(hours=1)
    data["exp"] = expire
    
    return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)


def verify_token(token: str, token_type: str) -> Optional[str]:
    """
    Verify a specific type of token (verification or password_reset).
    
    Args:
        token: Token string to verify
        token_type: Expected token type
        
    Returns:
        Email from token if valid, None otherwise
    """
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        
        if payload.get("type") != token_type:
            return None
        
        return payload.get("email")
    except Exception:
        return None
