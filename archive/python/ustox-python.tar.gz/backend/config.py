"""
Application Configuration
"""

from pydantic_settings import BaseSettings
from typing import Optional, List
import os
from pathlib import Path

# Get the backend directory path
BACKEND_DIR = Path(__file__).parent


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    # Application
    APP_NAME: str = "Vega Trader"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    
    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 28020
    
    # Database
    DATABASE_URL: str = "sqlite:///./vegatrade.db"
    
    # Redis (optional)
    REDIS_URL: str = "redis://localhost:6379"
    
    # Security
    SECRET_KEY: str = "your-super-secret-key-change-in-production-vega-trader-2024"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    ENCRYPTION_KEY: Optional[str] = None
    
    # CORS
    CORS_ORIGINS: List[str] = ["*"]
    
    # Upstox API
    UPSTOX_CLIENT_ID: Optional[str] = None
    UPSTOX_CLIENT_SECRET: Optional[str] = None
    UPSTOX_REDIRECT_URI: str = "http://localhost:28020/api/v1/auth/upstox/callback"
    
    # Upstox Auto-Login (TOTP-based)
    UPSTOX_MOBILE_NUMBER: Optional[str] = None
    UPSTOX_TOTP: Optional[str] = None  # TOTP secret for 2FA
    UPSTOX_PIN: Optional[str] = None   # 6-digit PIN
    UPSTOX_USER_ID: Optional[str] = None
    
    # AI/LLM Configuration
    OPENAI_API_KEY: Optional[str] = None
    LLM_MODEL: str = "gpt-3.5-turbo"
    LLM_MAX_TOKENS: int = 2000
    
    # Rate Limiting
    RATE_LIMIT_REQUESTS: int = 100
    RATE_LIMIT_PERIOD: int = 60  # seconds
    
    class Config:
        env_file = str(BACKEND_DIR / ".env")
        env_file_encoding = "utf-8"
        case_sensitive = True
        extra = "ignore"  # Ignore extra env variables not defined in Settings


# Create settings instance
settings = Settings()

