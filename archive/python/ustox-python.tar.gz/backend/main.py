"""
Main FastAPI application with all routes configured
"""

from fastapi import FastAPI, Depends, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
from datetime import datetime
import logging
import uvicorn
from typing import List

# Import routers
from routers import (
    auth, user, market, orders, portfolio, strategies, 
    indicators, signals, settings, gtt, webhooks, instruments, options
)
from sector.sector_router import router as sector_router

# Import services
from services.upstox_service import initialize_upstox_service, upstox_service
from services.market_data_service import initialize_market_data_service, market_data_service
from services.ai_service import ai_service
from optionchain_ws import option_chain_service
from database.connection import engine, Base
from middleware.websocket import WebSocketManager
from middleware.auth import get_current_user

# Import models for table creation
from models.instrument_models import (
    EquityInstrument, IndexInstrument, FuturesInstrument, 
    OptionsInstrument, MTFInstrument, MISInstrument, SyncMetadata
)
from models.subscription_settings import SubscriptionSettings
from models.upstox_token import UpstoxToken

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global WebSocket manager
websocket_manager = WebSocketManager()


async def sync_instruments_background():
    """
    Background task to sync instruments and sector CSVs on startup.
    Only syncs once per day after 8 AM IST.
    """
    import asyncio
    from sector.sector_sync import sector_sync_service
    from datetime import datetime, time, timedelta
    import pytz
    from services.instrument_service import instrument_sync_service
    from database.connection import SessionLocal
    from models.instrument_models import SyncMetadata
    
    # Wait a bit for the app to fully start
    await asyncio.sleep(2)
    
    logger.info("🔄 Checking if instrument sync is needed...")
    
    try:
        db = SessionLocal()
        try:
            # Check last sync time from metadata
            sync_meta = db.query(SyncMetadata).filter(
                SyncMetadata.table_name == 'equity_instruments'
            ).first()
            
            # Use IST timezone for consistent 8 AM comparison
            ist = pytz.timezone('Asia/Kolkata')
            now_ist = datetime.now(ist)
            today_8am_ist = ist.localize(datetime.combine(now_ist.date(), time(8, 0)))
            
            should_sync = True
            
            if sync_meta and sync_meta.last_sync:
                last_sync = sync_meta.last_sync
                
                # Convert last_sync to IST if it's naive (assumed UTC)
                if last_sync.tzinfo is None:
                    last_sync_ist = pytz.utc.localize(last_sync).astimezone(ist)
                else:
                    last_sync_ist = last_sync.astimezone(ist)
                
                # If we already synced today after 8 AM IST, skip
                if last_sync_ist >= today_8am_ist:
                    logger.info(
                        f"✅ Instruments already synced today at {last_sync_ist.strftime('%H:%M:%S')} IST. "
                        f"Skipping sync. Next sync will be after 8 AM tomorrow."
                    )
                    should_sync = False
                # If current time is before 8 AM IST, check if we synced yesterday after 8 AM
                elif now_ist < today_8am_ist:
                    yesterday_8am_ist = today_8am_ist - timedelta(days=1)
                    if last_sync_ist >= yesterday_8am_ist:
                        logger.info(
                            f"✅ Current time is before 8 AM IST. Last sync was at {last_sync_ist.strftime('%Y-%m-%d %H:%M:%S')} IST. "
                            f"Skipping sync. Will sync after 8 AM today."
                        )
                        should_sync = False
            
            if should_sync:
                # Additional check: Only sync if current time is after 8 AM IST
                if now_ist < today_8am_ist:
                    logger.info(
                        f"⏰ Current time is {now_ist.strftime('%H:%M:%S')} IST, before 8 AM. "
                        f"Skipping sync until after 8 AM."
                    )
                    should_sync = False
            
            if should_sync:
                logger.info("🔄 Starting instrument sync...")
                result = instrument_sync_service.sync_instruments(db)
                logger.info(
                    f"✅ Sync complete: {result['total_saved']} instruments saved in {result['duration_seconds']:.1f}s"
                )
                logger.info(f"   📊 Breakdown: {result['saved_count']}")
                
                # Also sync sector CSVs
                logger.info("🔄 Starting sector CSV sync...")
                sector_result = sector_sync_service.sync_all_sectors()
                logger.info(
                    f"✅ Sector sync complete: {len(sector_result['successful'])}/{sector_result['total']} CSVs downloaded"
                )
            
        finally:
            db.close()
    except Exception as e:
        logger.error(f"❌ Instrument sync check failed: {e}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management"""
    # Startup
    logger.info("Starting application...")
    
    # Initialize database tables
    Base.metadata.create_all(bind=engine)
    
    # Initialize services
    await initialize_upstox_service()
    await initialize_market_data_service()
    
    # Start background instrument sync
    import asyncio
    asyncio.create_task(sync_instruments_background())
    
    # Start option chain background service (after a delay to ensure instruments are loaded)
    async def start_option_chain_service():
        await asyncio.sleep(5)  # Wait for initial startup
        await option_chain_service.start()
    asyncio.create_task(start_option_chain_service())
    
    logger.info("Application started successfully")
    
    yield
    
    # Shutdown
    logger.info("Shutting down application...")
    
    # Cleanup services gracefully
    async def safe_cleanup(service, name: str):
        """Safely cleanup a service, handling missing methods gracefully"""
        try:
            if hasattr(service, 'cleanup') and callable(getattr(service, 'cleanup')):
                await service.cleanup()
                logger.info(f"✅ {name} cleanup completed")
            else:
                logger.debug(f"ℹ️ {name} has no cleanup method, skipping")
        except Exception as e:
            logger.warning(f"⚠️ {name} cleanup warning: {e}")
    
    # Stop option chain background service first
    try:
        await option_chain_service.stop()
        logger.info("✅ Option chain background service stopped")
    except Exception as e:
        logger.warning(f"⚠️ Option chain service stop warning: {e}")
    
    await safe_cleanup(upstox_service, "Upstox service")
    await safe_cleanup(market_data_service, "Market data service")
    await safe_cleanup(ai_service, "AI service")
    
    logger.info("✅ Application shutdown complete")

# Create FastAPI app
app = FastAPI(
    title="Trading Platform API",
    description="Complete trading platform with AI strategies, real-time data, and order execution",
    version="1.0.0",
    lifespan=lifespan
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router)
app.include_router(user.router)
app.include_router(market.router)
app.include_router(orders.router)
app.include_router(portfolio.router)
app.include_router(strategies.router)
app.include_router(indicators.router)
app.include_router(signals.router)
app.include_router(settings.router)
app.include_router(gtt.router)
app.include_router(webhooks.router)
app.include_router(instruments.router)
app.include_router(options.router)
app.include_router(sector_router)

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "status": "success",
        "message": "Trading Platform API is running",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health"
    }

# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "services": {
            "database": "connected",
            "redis": "connected",
            "upstox": "configured",
            "websocket": "active"
        },
        "timestamp": datetime.utcnow().isoformat()
    }

# WebSocket endpoint
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time data"""
    await websocket_manager.connect(websocket)
    try:
        while True:
            # Handle WebSocket messages
            data = await websocket.receive_text()
            await websocket_manager.handle_message(websocket, data)
    except WebSocketDisconnect:
        await websocket_manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        await websocket.close()

# Error handlers
@app.exception_handler(404)
async def not_found_handler(request, exc):
    return {
        "status": "error",
        "message": "Resource not found",
        "detail": str(exc)
    }

@app.exception_handler(500)
async def internal_error_handler(request, exc):
    logger.error(f"Internal server error: {exc}")
    return {
        "status": "error",
        "message": "Internal server error",
        "detail": "Something went wrong on our end"
    }

if __name__ == "__main__":
    # Run the application
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=28020,
        reload=True,
        log_level="info"
    )