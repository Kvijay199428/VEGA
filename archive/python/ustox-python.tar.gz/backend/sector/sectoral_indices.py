"""
Sectoral Indices Service
Filter equity instruments based on Nifty sector indices.
Matches ISIN codes from sector CSV files with equity_instruments table.
"""

import os
import csv
import logging
from pathlib import Path
from typing import Dict, List, Optional, Set
from sqlalchemy.orm import Session

from models.instrument_models import EquityInstrument

logger = logging.getLogger(__name__)

# Base directory for sector CSV files
SECTOR_DIR = Path(__file__).parent / "sectors"

# Mapping of sector keys to their display names and CSV URLs
SECTOR_INDICES: Dict[str, Dict[str, str]] = {
    "auto": {
        "name": "Nifty Auto",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftyautolist.csv",
        "filename": "ind_niftyautolist.csv"
    },
    "bank": {
        "name": "Nifty Bank",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftybanklist.csv",
        "filename": "ind_niftybanklist.csv"
    },
    "chemicals": {
        "name": "Nifty Chemicals",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftyChemicals_list.csv",
        "filename": "ind_niftyChemicals_list.csv"
    },
    "financial_services": {
        "name": "Nifty Financial Services",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftyfinancelist.csv",
        "filename": "ind_niftyfinancelist.csv"
    },
    "financial_services_2550": {
        "name": "Nifty Financial Services 25/50",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftyfinancialservices25-50list.csv",
        "filename": "ind_niftyfinancialservices25-50list.csv"
    },
    "fmcg": {
        "name": "Nifty FMCG",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftyfmcglist.csv",
        "filename": "ind_niftyfmcglist.csv"
    },
    "healthcare": {
        "name": "Nifty Healthcare",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftyhealthcarelist.csv",
        "filename": "ind_niftyhealthcarelist.csv"
    },
    "it": {
        "name": "Nifty IT",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftyitlist.csv",
        "filename": "ind_niftyitlist.csv"
    },
    "media": {
        "name": "Nifty Media",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftymedialist.csv",
        "filename": "ind_niftymedialist.csv"
    },
    "metal": {
        "name": "Nifty Metal",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftymetallist.csv",
        "filename": "ind_niftymetallist.csv"
    },
    "pharma": {
        "name": "Nifty Pharma",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftypharmalist.csv",
        "filename": "ind_niftypharmalist.csv"
    },
    "private_bank": {
        "name": "Nifty Private Bank",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_nifty_privatebanklist.csv",
        "filename": "ind_nifty_privatebanklist.csv"
    },
    "psu_bank": {
        "name": "Nifty PSU Bank",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftypsubanklist.csv",
        "filename": "ind_niftypsubanklist.csv"
    },
    "realty": {
        "name": "Nifty Realty",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftyrealtylist.csv",
        "filename": "ind_niftyrealtylist.csv"
    },
    "consumer_durables": {
        "name": "Nifty Consumer Durables",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftyconsumerdurableslist.csv",
        "filename": "ind_niftyconsumerdurableslist.csv"
    },
    "oil_gas": {
        "name": "Nifty Oil and Gas",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftyoilgaslist.csv",
        "filename": "ind_niftyoilgaslist.csv"
    },
    "healthcare_500": {
        "name": "Nifty500 Healthcare",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_nifty500Healthcare_list.csv",
        "filename": "ind_nifty500Healthcare_list.csv"
    },
    "midsmall_financial": {
        "name": "Nifty MidSmall Financial Services",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftymidsmallfinancailservice_list.csv",
        "filename": "ind_niftymidsmallfinancailservice_list.csv"
    },
    "midsmall_healthcare": {
        "name": "Nifty MidSmall Healthcare",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftymidsmallhealthcare_list.csv",
        "filename": "ind_niftymidsmallhealthcare_list.csv"
    },
    "midsmall_it_telecom": {
        "name": "Nifty MidSmall IT & Telecom",
        "url": "https://www.niftyindices.com/IndexConstituent/ind_niftymidsmallitAndtelecom_list.csv",
        "filename": "ind_niftymidsmallitAndtelecom_list.csv"
    }
}


class SectorService:
    """Service for filtering instruments by sector"""
    
    def __init__(self):
        self.sector_dir = SECTOR_DIR
    
    def get_all_sectors(self) -> List[Dict[str, str]]:
        """
        Get list of all available sectors with their metadata.
        Returns sectors that have CSV files downloaded.
        """
        sectors = []
        for key, info in SECTOR_INDICES.items():
            csv_path = self.sector_dir / info["filename"]
            sectors.append({
                "key": key,
                "name": info["name"],
                "available": csv_path.exists()
            })
        return sectors
    
    def get_available_sectors(self) -> List[Dict[str, str]]:
        """
        Get only sectors that have CSV files downloaded.
        """
        return [s for s in self.get_all_sectors() if s["available"]]
    
    def get_sector_isin_codes(self, sector_key: str) -> Set[str]:
        """
        Read sector CSV file and extract all ISIN codes.
        
        CSV headers: Company Name, Industry, Symbol, Series, ISIN Code
        """
        if sector_key not in SECTOR_INDICES:
            logger.warning(f"Unknown sector key: {sector_key}")
            return set()
        
        csv_path = self.sector_dir / SECTOR_INDICES[sector_key]["filename"]
        
        if not csv_path.exists():
            logger.warning(f"CSV file not found for sector {sector_key}: {csv_path}")
            return set()
        
        isin_codes = set()
        try:
            with open(csv_path, 'r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    # Try common header variations
                    isin = row.get('ISIN Code') or row.get('ISIN') or row.get('isin_code') or row.get('isin')
                    if isin:
                        isin_codes.add(isin.strip())
            
            logger.info(f"Loaded {len(isin_codes)} ISIN codes for sector {sector_key}")
        except Exception as e:
            logger.error(f"Error reading CSV for sector {sector_key}: {e}")
        
        return isin_codes
    
    def filter_instruments_by_sector(
        self,
        db: Session,
        sector_key: str,
        exchange: Optional[str] = None,
        limit: int = 50,
        offset: int = 0
    ) -> Dict:
        """
        Filter equity instruments by sector using ISIN matching.
        
        Args:
            db: Database session
            sector_key: Sector identifier (e.g., 'bank', 'it')
            exchange: Optional exchange filter (NSE, BSE)
            limit: Max number of results
            offset: Pagination offset
            
        Returns:
            Dict with total count, filtered count, and instruments list
        """
        # Get ISIN codes for the sector
        isin_codes = self.get_sector_isin_codes(sector_key)
        
        if not isin_codes:
            return {
                "status": "success",
                "sector": SECTOR_INDICES.get(sector_key, {}).get("name", sector_key),
                "total": 0,
                "count": 0,
                "instruments": [],
                "message": f"No ISIN codes found for sector '{sector_key}'. CSV may not be downloaded yet."
            }
        
        # Build query
        query = db.query(EquityInstrument).filter(
            EquityInstrument.isin.in_(isin_codes)
        )
        
        # Apply exchange filter
        if exchange:
            query = query.filter(EquityInstrument.exchange == exchange.upper())
        
        # Get total count
        total_count = query.count()
        
        # Apply pagination and get results
        instruments = query.order_by(EquityInstrument.trading_symbol).offset(offset).limit(limit).all()
        
        # Convert to dicts
        instrument_list = []
        for inst in instruments:
            instrument_list.append({
                "instrument_key": inst.instrument_key,
                "trading_symbol": inst.trading_symbol,
                "name": inst.name,
                "exchange": inst.exchange,
                "isin": inst.isin,
                "segment": inst.segment,
                "lot_size": inst.lot_size,
                "tick_size": inst.tick_size,
                "mtf_enabled": inst.mtf_enabled,
                "mtf_bracket": inst.mtf_bracket
            })
        
        return {
            "status": "success",
            "sector": SECTOR_INDICES.get(sector_key, {}).get("name", sector_key),
            "sector_key": sector_key,
            "total": total_count,
            "count": len(instrument_list),
            "instruments": instrument_list
        }
    
    def get_sector_info(self, sector_key: str) -> Optional[Dict]:
        """Get information about a specific sector"""
        if sector_key not in SECTOR_INDICES:
            return None
        
        info = SECTOR_INDICES[sector_key].copy()
        info["key"] = sector_key
        
        csv_path = self.sector_dir / info["filename"]
        info["available"] = csv_path.exists()
        
        if info["available"]:
            isin_codes = self.get_sector_isin_codes(sector_key)
            info["constituent_count"] = len(isin_codes)
        else:
            info["constituent_count"] = 0
        
        return info


# Global instance
sector_service = SectorService()
