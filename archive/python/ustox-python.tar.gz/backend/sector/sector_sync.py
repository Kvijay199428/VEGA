"""
Sector CSV Sync Service
Downloads all sector constituent CSV files from NSE Indices website.
Syncs at 8 AM daily alongside instrument sync.
"""

import os
import logging
import requests
from pathlib import Path
from datetime import datetime
from typing import Dict, List

from .sectoral_indices import SECTOR_INDICES, SECTOR_DIR

logger = logging.getLogger(__name__)


class SectorSyncService:
    """Service for downloading and syncing sector CSV files"""
    
    def __init__(self):
        self.sector_dir = SECTOR_DIR
        # Create sectors directory if it doesn't exist
        self.sector_dir.mkdir(parents=True, exist_ok=True)
    
    def download_sector_csv(self, sector_key: str) -> bool:
        """
        Download a single sector CSV file.
        
        Args:
            sector_key: Sector identifier
            
        Returns:
            True if download successful, False otherwise
        """
        if sector_key not in SECTOR_INDICES:
            logger.error(f"Unknown sector key: {sector_key}")
            return False
        
        sector_info = SECTOR_INDICES[sector_key]
        url = sector_info["url"]
        filename = sector_info["filename"]
        output_path = self.sector_dir / filename
        
        try:
            # Add headers to mimic browser request
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/csv,application/csv,text/plain,*/*',
                'Accept-Language': 'en-US,en;q=0.9',
                'Referer': 'https://www.niftyindices.com/'
            }
            
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            
            # Save CSV file
            with open(output_path, 'wb') as f:
                f.write(response.content)
            
            logger.info(f"✅ Downloaded {sector_info['name']}: {filename}")
            return True
            
        except requests.exceptions.RequestException as e:
            logger.error(f"❌ Failed to download {sector_info['name']}: {e}")
            return False
        except Exception as e:
            logger.error(f"❌ Error saving {sector_info['name']}: {e}")
            return False
    
    def sync_all_sectors(self) -> Dict:
        """
        Download all sector CSV files.
        
        Returns:
            Dict with sync results
        """
        logger.info("🔄 Starting sector CSV sync...")
        start_time = datetime.now()
        
        results = {
            "successful": [],
            "failed": [],
            "total": len(SECTOR_INDICES)
        }
        
        for sector_key in SECTOR_INDICES:
            success = self.download_sector_csv(sector_key)
            if success:
                results["successful"].append(sector_key)
            else:
                results["failed"].append(sector_key)
        
        duration = (datetime.now() - start_time).total_seconds()
        
        logger.info(
            f"✅ Sector sync complete: {len(results['successful'])}/{results['total']} successful "
            f"in {duration:.1f}s"
        )
        
        if results["failed"]:
            logger.warning(f"⚠️ Failed sectors: {', '.join(results['failed'])}")
        
        results["duration_seconds"] = duration
        results["synced_at"] = datetime.now().isoformat()
        
        return results
    
    def get_sync_status(self) -> Dict:
        """
        Get current status of sector CSV files.
        
        Returns:
            Dict with status for each sector
        """
        status = {}
        
        for sector_key, info in SECTOR_INDICES.items():
            csv_path = self.sector_dir / info["filename"]
            
            if csv_path.exists():
                stat = csv_path.stat()
                status[sector_key] = {
                    "name": info["name"],
                    "available": True,
                    "size_bytes": stat.st_size,
                    "modified_at": datetime.fromtimestamp(stat.st_mtime).isoformat()
                }
            else:
                status[sector_key] = {
                    "name": info["name"],
                    "available": False
                }
        
        return status


# Global instance
sector_sync_service = SectorSyncService()
