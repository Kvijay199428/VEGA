"""
Sector Router - API endpoints for sectoral indices filtering
"""

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from typing import Optional
import logging

from database.connection import get_db
from sector.sectoral_indices import sector_service, SECTOR_INDICES
from sector.sector_sync import sector_sync_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1", tags=["Sectors"])


# ==========================================================================
# SECTOR SYNC ENDPOINTS (must come BEFORE parameterized routes)
# ==========================================================================

@router.get("/sectors/sync/status")
async def get_sector_sync_status():
    """
    Get current status of sector CSV files.
    """
    try:
        status_data = sector_sync_service.get_sync_status()
        
        available_count = len([s for s in status_data.values() if s.get("available")])
        
        return {
            "status": "success",
            "total": len(status_data),
            "available": available_count,
            "sectors": status_data
        }
    except Exception as e:
        logger.error(f"Error fetching sync status: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.post("/sectors/sync")
async def sync_sector_csvs():
    """
    Manually trigger sync of all sector CSV files.
    """
    try:
        result = sector_sync_service.sync_all_sectors()
        
        return {
            "status": "success",
            "message": f"Synced {len(result['successful'])}/{result['total']} sector CSVs",
            "successful": result["successful"],
            "failed": result["failed"],
            "duration_seconds": result["duration_seconds"],
            "synced_at": result["synced_at"]
        }
    except Exception as e:
        logger.error(f"Error syncing sectors: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


# ==========================================================================
# SECTOR LIST & DETAILS
# ==========================================================================

@router.get("/sectors")
async def get_sectors():
    """
    Get list of all available sectors for filtering.
    """
    try:
        # Debug log to ensure route is hit
        logger.info("Executing get_sectors endpoint")
        sectors = sector_service.get_all_sectors()
        available_count = len([s for s in sectors if s["available"]])
        
        return {
            "status": "success",
            "total": len(sectors),
            "available": available_count,
            "sectors": sectors
        }
    except Exception as e:
        logger.error(f"Error fetching sectors: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@router.get("/sectors/{sector_key}")
async def get_sector_info(sector_key: str):
    """
    Get detailed information about a specific sector.
    """
    try:
        info = sector_service.get_sector_info(sector_key)
        
        if not info:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Sector not found: {sector_key}"
            )
        
        return {
            "status": "success",
            "sector": info
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching sector info: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


# ==========================================================================
# INSTRUMENT FILTERING BY SECTOR
# ==========================================================================

@router.get("/instruments/equity/sector/{sector_key}")
async def get_instruments_by_sector(
    sector_key: str,
    exchange: Optional[str] = Query(None, description="Filter by exchange (NSE, BSE)"),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db)
):
    """
    Get equity instruments filtered by sector.
    """
    try:
        # Validate sector key
        if sector_key not in SECTOR_INDICES:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Unknown sector: {sector_key}. Valid sectors: {', '.join(SECTOR_INDICES.keys())}"
            )
        
        result = sector_service.filter_instruments_by_sector(
            db,
            sector_key=sector_key,
            exchange=exchange,
            limit=limit,
            offset=offset
        )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error filtering instruments by sector: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )
