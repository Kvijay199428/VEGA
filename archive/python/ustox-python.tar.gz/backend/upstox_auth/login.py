#!/usr/bin/env python3
"""
Upstox Login Initiator - Unified Entry Point
Supports both single API and multi-API login modes

Usage:
    # Multi-login (all APIs with shared browser)
    python login.py --mode multi
    
    # Single login (specific API)
    python login.py --mode single --api PRIMARY
    
    # List available APIs
    python login.py --list
"""

import sys
import logging
import argparse
from pathlib import Path

# Add backend to path for imports
backend_dir = Path(__file__).parent.parent
upstox_auth_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))
sys.path.insert(0, str(upstox_auth_dir))

from dotenv import load_dotenv
load_dotenv()

# Setup logging
LOG_DIR = Path(__file__).parent / "auth_logs"
LOG_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_DIR / 'auth_logs.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


def main():
    """Main entry point for Upstox login initiator"""
    parser = argparse.ArgumentParser(
        description='Upstox Login Initiator - Unified authentication entry point',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python login.py --mode multi              # Login all APIs (shared browser)
  python login.py --mode single --api PRIMARY  # Login single API
  python login.py --list                    # List available APIs
        """
    )
    
    parser.add_argument(
        '--mode', '-m',
        choices=['single', 'multi'],
        default='multi',
        help='Login mode: "single" for one API, "multi" for all APIs (default: multi)'
    )
    
    parser.add_argument(
        '--api', '-a',
        type=str,
        help='API name for single login mode (e.g., PRIMARY, WEBSOCKET1)'
    )
    
    parser.add_argument(
        '--list', '-l',
        action='store_true',
        help='List available API configurations'
    )
    
    parser.add_argument(
        '--start-index',
        type=int,
        default=0,
        help='Starting API index for multi-login mode (default: 0)'
    )
    
    parser.add_argument(
        '--headless',
        action='store_true',
        help='Run browser in headless mode (no visible window)'
    )
    
    args = parser.parse_args()
    
    try:
        # Import here to avoid circular imports
        from upstox.single_login import single_api_login, list_available_apis
        from upstox.multi_login import main as multi_login_main
        from upstox.config_validator import API_CONFIGS
        
        # Import helpers from within the upstox_auth package
        from helpers import Colors, print_colored
        
        # List APIs
        if args.list:
            list_available_apis()
            return 0
        
        # Single login mode
        if args.mode == 'single':
            if not args.api:
                print_colored("❌ Please specify an API name with --api <API_NAME>", Colors.BRIGHT_RED, bold=True)
                list_available_apis()
                return 1
            
            api_name = args.api.upper()
            logger.info(f"Starting single login mode for API: {api_name}")
            print_colored(f"\n🔐 SINGLE LOGIN MODE - {api_name}", Colors.BRIGHT_CYAN, bold=True)
            print_colored("=" * 50, Colors.BRIGHT_CYAN)
            
            success, token = single_api_login(api_name)
            return 0 if success else 1
        
        # Multi-login mode (default)
        else:
            logger.info("Starting multi-login mode for all APIs")
            print_colored("\n🚀 MULTI-LOGIN MODE - All APIs", Colors.BRIGHT_CYAN, bold=True)
            print_colored("=" * 50, Colors.BRIGHT_CYAN)
            print_colored("Using SHARED browser for efficiency", Colors.BRIGHT_YELLOW)
            
            # Modify sys.argv for multi_login_main
            sys.argv = ['multi_login.py']
            if args.start_index > 0:
                sys.argv.extend(['--start-index', str(args.start_index)])
            if args.headless:
                sys.argv.append('--headless')
            
            return multi_login_main()
    
    except ImportError as e:
        logger.error(f"Import error: {e}")
        print(f"[X] Import error: {e}")
        print("Make sure you're running from the correct directory")
        return 1
    except KeyboardInterrupt:
        logger.info("Process interrupted by user")
        print("\n\n[!] Process interrupted by user")
        return 130
    except Exception as e:
        logger.error(f"Unexpected error: {e}", exc_info=True)
        print(f"[X] Unexpected error: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())