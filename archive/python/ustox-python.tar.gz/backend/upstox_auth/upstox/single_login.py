#!/usr/bin/env python3
"""
Upstox Single Login - Authenticate a single API configuration
Used when only one API token needs to be generated
"""

import logging
from datetime import datetime
from typing import Tuple, Optional
from dotenv import load_dotenv

# Load environment variables from .env file FIRST
load_dotenv()

from .config_validator import API_CONFIGS
from .auth_flow import automate_login_process, build_authorization_url
from .token_manager import save_token_to_db, save_tokens_to_json, display_token_file_location

# Import from helpers (sibling to upstox in upstox_auth)
from helpers import (
    Colors, print_colored, calculate_token_validity,
    get_access_token, get_profile_data, print_profile_card
)

logger = logging.getLogger(__name__)


def get_api_index(api_name: str) -> int:
    """Get the index of an API by name"""
    api_names = list(API_CONFIGS.keys())
    try:
        return api_names.index(api_name)
    except ValueError:
        return -1


def single_api_login(api_name: str) -> Tuple[bool, Optional[str]]:
    """
    Authenticate a single API by name.
    Creates a new Selenium driver for the login process.
    
    Args:
        api_name: Name of the API (e.g., 'PRIMARY', 'WEBSOCKET1')
    
    Returns:
        Tuple of (success, access_token or None)
    """
    # Validate API name exists
    if api_name not in API_CONFIGS:
        logger.error(f"API '{api_name}' not found in configuration")
        print_colored(f"❌ API '{api_name}' not found. Available APIs: {list(API_CONFIGS.keys())}", Colors.BRIGHT_RED, bold=True)
        return False, None
    
    config = API_CONFIGS[api_name]
    client_id = config['api_key']
    client_secret = config['api_secret']
    redirect_uri = config.get('redirect_uri')
    color = config.get('color', Colors.BRIGHT_WHITE)
    
    if not client_id or not client_secret:
        logger.error(f"{api_name} - Missing API key or secret")
        print_colored(f"❌ {api_name} - Missing API key or secret in environment", Colors.BRIGHT_RED, bold=True)
        return False, None
    
    logger.info(f"Starting single login for {api_name}...")
    print_colored(f"\n🔐 Starting single login for {api_name}...", color, bold=True)
    
    try:
        # Build authorization URL
        auth_url, expected_state = build_authorization_url(client_id, redirect_uri)
        
        # Perform automated login (will create its own driver)
        logger.info(f"Attempting automated login for {api_name}...")
        returned_code, error_code = automate_login_process(auth_url, expected_state, redirect_uri)
        
        # Check for rate limit error
        if error_code == "RATE_LIMIT":
            logger.warning(f"⚠️ {api_name} - OTP rate limit exceeded [1017069]")
            print_colored(f"⚠️ {api_name} - OTP rate limit hit. Try again in 10 minutes.", Colors.BRIGHT_YELLOW, bold=True)
            return False, None
        
        if not returned_code:
            logger.error(f"❌ {api_name} - Authorization code not found")
            print_colored(f"❌ {api_name} - Failed to get authorization code", Colors.BRIGHT_RED, bold=True)
            return False, None
        
        # Exchange code for token
        logger.info(f"Exchanging authorization code for access token ({api_name})...")
        token, response_data = get_access_token(returned_code, client_id, client_secret, redirect_uri)
        
        if not token:
            logger.error(f"❌ {api_name} - Failed to get access token: {response_data}")
            print_colored(f"❌ {api_name} - Failed to get access token", Colors.BRIGHT_RED, bold=True)
            return False, None
        
        logger.info(f"✅ {api_name} - Access token generated successfully!")
        print_colored(f"✅ {api_name} - Access token generated successfully!", Colors.BRIGHT_GREEN, bold=True)
        
        # Calculate validity
        generation_time = datetime.now()
        validity_time = calculate_token_validity(generation_time)
        
        # Get API index for database
        api_index = get_api_index(api_name)
        
        # Save to database
        save_token_to_db(
            api_index=api_index,
            api_name=api_name,
            access_token=token,
            client_id=client_id,
            validity_at=validity_time
        )
        
        # Save to JSON
        tokens_to_save = {
            api_name: {
                "access_token": token,
                "api_key": client_id,
                "generated_at": generation_time.isoformat(),
                "validity_at": validity_time.isoformat(),
                "status": "active"
            }
        }
        save_tokens_to_json(tokens_to_save)
        display_token_file_location()
        
        # Display validity info
        print_colored(f"⏰ Token valid until: {validity_time.strftime('%Y-%m-%d %H:%M:%S')}", Colors.BRIGHT_CYAN, bold=True)
        
        # Display profile
        profile_data = get_profile_data(token)
        if profile_data:
            print_profile_card(api_name, profile_data, color)
        
        return True, token
        
    except Exception as e:
        logger.error(f"❌ {api_name} - Unexpected error: {e}", exc_info=True)
        print_colored(f"❌ {api_name} - Unexpected error: {e}", Colors.BRIGHT_RED, bold=True)
        return False, None


def list_available_apis():
    """List all available API configurations"""
    print_colored("\n📋 Available API Configurations:", Colors.BRIGHT_WHITE, bold=True)
    for i, (api_name, config) in enumerate(API_CONFIGS.items()):
        color = config.get('color', Colors.BRIGHT_WHITE)
        has_key = "✅" if config.get('api_key') else "❌"
        has_secret = "✅" if config.get('api_secret') else "❌"
        print_colored(f"  {i}. {api_name} (key: {has_key}, secret: {has_secret})", color)


def main():
    """Main function for standalone single login execution"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Upstox Single API Token Generator')
    parser.add_argument('--api', '-a', type=str, help='API name to authenticate (e.g., PRIMARY, WEBSOCKET1)')
    parser.add_argument('--list', '-l', action='store_true', help='List available API configurations')
    args = parser.parse_args()
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('single_login.log', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    
    if args.list:
        list_available_apis()
        return 0
    
    if not args.api:
        print_colored("❌ Please specify an API name with --api <API_NAME>", Colors.BRIGHT_RED, bold=True)
        list_available_apis()
        return 1
    
    api_name = args.api.upper()
    success, token = single_api_login(api_name)
    
    return 0 if success else 1


if __name__ == "__main__":
    import sys
    sys.exit(main())
