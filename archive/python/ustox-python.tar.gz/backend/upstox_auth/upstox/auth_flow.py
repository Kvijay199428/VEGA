"""
Upstox Authentication Flow - Selenium Automation
Handles the automated login process using Selenium WebDriver
Supports both standalone and shared driver modes
"""

import os
import secrets
import urllib.parse
import time
import logging
from datetime import datetime
from urllib.parse import urlparse, parse_qs
from typing import Optional, Tuple

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException

from .selenium_driver import setup_webdriver, DriverManager
from helpers import generate_totp_code

logger = logging.getLogger(__name__)

# Load environment variables from backend/.env file
from dotenv import load_dotenv
_script_dir = os.path.dirname(os.path.abspath(__file__))
_backend_dir = os.path.dirname(os.path.dirname(_script_dir))  # Go up 2 levels
_env_path = os.path.join(_backend_dir, '.env')
load_dotenv(_env_path)

# Debug screenshots directory
DEBUG_SCREENSHOT_DIR = os.path.join(os.path.dirname(__file__), '..', 'debug_screenshots')

# URL endpoints
AUTH_URL = "https://api.upstox.com/v2/login/authorization/dialog"
REDIRECT_URI = os.getenv("UPSTOX_REDIRECT_URI")
LOGIN_PIN = os.getenv("UPSTOX_PIN")
MOBILE_NUMBER = os.getenv("UPSTOX_MOBILE_NUMBER")
TOTP = os.getenv("UPSTOX_TOTP")


def build_authorization_url(client_id: str, redirect_uri: Optional[str] = None, multi_login: bool = False) -> Tuple[str, str]:
    """
    Construct the URL for user login and authorization
    
    Args:
        client_id: The API client ID
        redirect_uri: Override redirect URI (optional)
        multi_login: If True, add 'ML:' prefix to state for backend detection
    
    Returns:
        Tuple of (authorization_url, state)
    """
    effective_redirect_uri = redirect_uri if redirect_uri else REDIRECT_URI
    
    # Generate state token
    raw_state = secrets.token_urlsafe(16)
    
    # Add 'ML:' prefix for multi-login mode
    # Backend will detect this and return code in HTML without consuming it
    state = f"ML:{raw_state}" if multi_login else raw_state
    
    params = {
        "client_id": client_id,
        "redirect_uri": effective_redirect_uri,
        "response_type": "code",
        "state": state
    }
    full_url = f"{AUTH_URL}?{urllib.parse.urlencode(params)}"
    logger.info(f"Authorization URL constructed successfully for client: {client_id}")
    logger.info(f"Redirect URI: {effective_redirect_uri}")
    logger.info(f"Multi-login mode: {multi_login}")
    return full_url, raw_state  # Return raw_state for validation (without ML: prefix)


def automate_login_process(
    auth_url: str, 
    expected_state: str, 
    redirect_uri: Optional[str] = None,
    driver = None,
    keep_driver_open: bool = False
) -> Tuple[Optional[str], Optional[str]]:
    """
    Automate the login process using Selenium
    
    Args:
        auth_url: The authorization URL to navigate to
        expected_state: Expected state parameter for CSRF validation
        redirect_uri: Override redirect URI (optional)
        driver: Existing WebDriver instance to use (optional, for multi-login mode)
        keep_driver_open: If True, don't close the driver after login (for multi-login)
    
    Returns:
        Tuple of (authorization_code, error_type)
        error_type can be "RATE_LIMIT" if OTP limit exceeded
    """
    effective_redirect_uri = redirect_uri if redirect_uri else REDIRECT_URI
    
    if not LOGIN_PIN or not MOBILE_NUMBER or not TOTP:
        logger.error("LOGIN_PIN, MOBILE_NUMBER, or TOTP not found in environment variables")
        return None, None
    
    # Track if we created the driver locally
    driver_created_locally = driver is None
    
    try:
        if driver is None:
            logger.info("Setting up new web driver...")
            driver = setup_webdriver()
        else:
            logger.info("Using provided web driver instance...")
        
        logger.info("Opening authorization URL...")
        driver.get(auth_url)
        
        # Wait for page to be ready
        logger.info("Waiting for page to load...")
        time.sleep(2)
        
        # Define redirect domain for checking redirects
        redirect_domain = effective_redirect_uri.split('://')[1].split('/')[0]
        
        # Log current URL for debugging
        current_url = driver.current_url
        logger.info(f"Current URL after navigation: {current_url}")
        
        # Check if already redirected (already authorized)
        if redirect_domain in current_url:
            logger.info("Already redirected - session may still be valid")
            return _extract_auth_code(driver, current_url, expected_state)
        
        # Check for Cloudflare or bot protection
        page_source = driver.page_source.lower()
        if 'checking your browser' in page_source or 'cloudflare' in page_source:
            logger.warning("Cloudflare protection detected, waiting...")
            time.sleep(5)
        
        # DETECT PAGE STATE: Check if we're on PIN page (session remembered) or mobile input page
        # Use WebDriverWait since the page uses JavaScript rendering that takes time
        pin_input = None
        mobile_input = None
        
        # First, try to find PIN input (indicates remembered session - user was already logged in)
        # This is a quick check with short timeout
        try:
            logger.info("Checking if session is remembered (looking for PIN input)...")
            pin_input = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.ID, "pinCode"))
            )
            logger.info("✅ Detected PIN input page - session is remembered, skipping to PIN entry")
        except TimeoutException:
            logger.info("PIN input not found within 5s, looking for mobile input...")
        
        if pin_input is None:
            # Try to find mobile input field (fresh login required)
            logger.info("Looking for mobile number input field...")
            mobile_selectors = [
                (By.ID, "mobileNum"),
                (By.XPATH, '//*[@id="mobileNum"]'),
                (By.CSS_SELECTOR, "input[id='mobileNum']"),
                (By.CSS_SELECTOR, "input[type='tel']"),
                (By.CSS_SELECTOR, "input[placeholder*='mobile' i]"),
            ]
            
            for selector_type, selector_value in mobile_selectors:
                try:
                    mobile_input = WebDriverWait(driver, 5).until(
                        EC.presence_of_element_located((selector_type, selector_value))
                    )
                    logger.info(f"Found mobile input using: {selector_type} = {selector_value}")
                    break
                except TimeoutException:
                    logger.debug(f"Selector not found: {selector_type} = {selector_value}")
                    continue
            
            if mobile_input is None:
                # Take screenshot for debugging - neither PIN nor mobile input found
                _save_debug_screenshot(driver, "no_input_found")
                logger.error(f"Could not find mobile or PIN input. Page title: {driver.title}")
                logger.error(f"Current URL: {driver.current_url}")
                raise TimeoutException("Neither mobile nor PIN input found with any selector")
            
            # === MOBILE INPUT FLOW ===
            logger.info("Entering mobile number...")
            mobile_input.clear()
            mobile_input.send_keys(MOBILE_NUMBER)
            
            logger.info("Clicking Get OTP button...")
            get_otp_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, '//*[@id="getOtp"]'))
            )
            get_otp_button.click()
            
            logger.info("Waiting for OTP response...")
            time.sleep(3)
            
            # Check for OTP rate limit error
            try:
                error_msg = driver.find_element(By.CLASS_NAME, "error-msg")
                error_text = error_msg.text if error_msg else ""
                if "1017069" in error_text or "exceeded" in error_text.lower():
                    logger.warning(f"OTP rate limit hit: {error_text}")
                    return None, "RATE_LIMIT"
            except:
                pass  # No error element found, continue
            
            logger.info("Generating TOTP code...")
            totp_code = generate_totp_code(TOTP)
            if not totp_code:
                logger.error("Failed to generate TOTP code")
                return None, None
            
            logger.info(f"Generated TOTP code: {totp_code}")
            
            logger.info("Waiting for OTP input field...")
            otp_input = WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.XPATH, '//*[@id="otpNum"]'))
            )
            
            logger.info("Entering TOTP code...")
            otp_input.clear()
            otp_input.send_keys(totp_code)
            
            logger.info("Clicking continue button for OTP...")
            continue_otp_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, '//*[@id="continueBtn"]'))
            )
            continue_otp_button.click()
            
            logger.info("Waiting before PIN entry...")
            time.sleep(3)
            
            # Now wait for PIN input to appear
            logger.info("Waiting for PIN input field after OTP...")
            pin_input = WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.XPATH, '//*[@id="pinCode"]'))
            )
        
        # === PIN ENTRY FLOW (common for both remembered and fresh login) ===
        logger.info("Entering PIN...")
        pin_input.clear()
        pin_input.send_keys(LOGIN_PIN)
        
        logger.info("Clicking continue button for PIN...")
        continue_pin_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//*[@id="pinContinueBtn"]'))
        )
        continue_pin_button.click()
        
        logger.info("Waiting for redirect...")
        redirect_domain = effective_redirect_uri.split('://')[1].split('/')[0]
        logger.info(f"Waiting for redirect to domain: {redirect_domain}")
        
        def check_redirect(driver):
            current_url = driver.current_url
            logger.debug(f"Current URL: {current_url}")
            return redirect_domain in current_url
        
        WebDriverWait(driver, 60).until(check_redirect)
        
        redirected_url = driver.current_url
        return _extract_auth_code(driver, redirected_url, expected_state)
        
    except TimeoutException as e:
        logger.error(f"Timeout during login process: {e}")
        try:
            if driver:
                current_url = driver.current_url
                page_title = driver.title
                logger.error(f"Timeout occurred at URL: {current_url}")
                logger.error(f"Page title: {page_title}")
                _save_debug_screenshot(driver, "timeout_error")
        except Exception as debug_err:
            logger.debug(f"Could not capture debug info: {debug_err}")
        return None, None
    except NoSuchElementException as e:
        logger.error(f"Element not found during login: {e}")
        _save_debug_screenshot(driver, "element_not_found")
        return None, None
    except WebDriverException as e:
        logger.error(f"WebDriver error during login: {e}")
        return None, None
    except Exception as e:
        logger.error(f"Unexpected error during automation: {e}", exc_info=True)
        _save_debug_screenshot(driver, "unexpected_error")
        return None, None
    finally:
        # Only close driver if we created it locally and not asked to keep it open
        if driver_created_locally and not keep_driver_open and driver:
            try:
                driver.quit()
                logger.info("Web driver closed successfully")
            except Exception as e:
                logger.warning(f"Error closing driver: {e}")


def _extract_auth_code(driver, redirected_url: str, expected_state: str) -> Tuple[Optional[str], Optional[str]]:
    """
    Extract authorization code from redirect URL or HTML page element.
    
    For capture-code endpoint: Code is in HTML element with id="auth-code" and data-code attribute
    For callback endpoint: Code is in URL query parameters
    """
    logger.info(f"Captured redirect URL: {redirected_url}")
    
    # First, try to extract from HTML page element (capture-code endpoint)
    # This is used by multi-login to avoid code consumption by backend
    try:
        code_element = driver.find_element(By.ID, "auth-code")
        if code_element:
            returned_code = code_element.get_attribute("data-code")
            returned_state = code_element.get_attribute("data-state")
            
            if returned_code:
                logger.info("Extracted auth code from HTML page element (capture-code endpoint)")
                
                if returned_state and returned_state != expected_state:
                    logger.error("State parameter does not match! Possible CSRF attack.")
                    return None, None
                elif returned_state:
                    logger.info("State parameter validated successfully")
                
                logger.info("Automated login process completed successfully")
                return returned_code, None
    except NoSuchElementException:
        logger.debug("No auth-code HTML element found, falling back to URL extraction")
    except Exception as e:
        logger.debug(f"Error extracting from HTML element: {e}")
    
    # Fallback: Extract from URL query parameters (callback endpoint)
    parsed_url = urlparse(redirected_url)
    query_params = parse_qs(parsed_url.query)
    returned_code = query_params.get("code", [None])[0]
    returned_state = query_params.get("state", [None])[0]
    
    # Handle multi-login state prefix in fallback URL extraction
    if returned_state and returned_state.startswith("ML:"):
        logger.info(f"Removing ML prefix from captured state: {returned_state}")
        returned_state = returned_state[3:]
    
    if returned_state != expected_state:
        logger.error(f"State mismatch: expected {expected_state}, got {returned_state}")
        return None, None
    else:
        logger.info("State parameter validated successfully")
    
    logger.info("Automated login process completed successfully")
    return returned_code, None


def _save_debug_screenshot(driver, prefix: str):
    """Save a screenshot for debugging purposes"""
    try:
        if not os.path.exists(DEBUG_SCREENSHOT_DIR):
            os.makedirs(DEBUG_SCREENSHOT_DIR)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(DEBUG_SCREENSHOT_DIR, f"{prefix}_{timestamp}.png")
        driver.save_screenshot(filename)
        logger.info(f"Debug screenshot saved: {filename}")
        
        # Also save page source for analysis
        html_file = os.path.join(DEBUG_SCREENSHOT_DIR, f"{prefix}_{timestamp}.html")
        with open(html_file, 'w', encoding='utf-8') as f:
            f.write(driver.page_source)
        logger.info(f"Page source saved: {html_file}")
    except Exception as e:
        logger.warning(f"Could not save debug screenshot: {e}")
