"""
Token Manager - Handle storage and retrieval of Upstox tokens
Supports both database and JSON file storage
"""

import os
import sys
import json
import sqlite3
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional

# Add backend directory to path for centralized database access
_script_dir = Path(__file__).parent.parent.parent  # upstox -> upstox_auth -> backend
if str(_script_dir) not in sys.path:
    sys.path.insert(0, str(_script_dir))

from database.connection import get_db_path
from helpers import calculate_token_validity, Colors, print_colored

logger = logging.getLogger(__name__)

# JSON tokens file path
TOKENS_FILE = os.getenv("TOKEN_DIR_JSON")


def save_token_to_db(api_index: int, api_name: str, access_token: str, client_id: str, validity_at: datetime) -> bool:
    """Save a single token to the database"""
    conn = None
    try:
        # Use centralized database path
        db_path = get_db_path()
        
        if not os.path.exists(db_path):
            error_msg = f"Database not found at {db_path}"
            logger.error(error_msg)
            print_colored(f"❌ {error_msg}", Colors.BRIGHT_RED, bold=True)
            return False
        
        logger.info(f"Connecting to database: {db_path}")
        
        # Determine purpose based on api_index
        if api_index == 0:
            purpose = "primary"
        elif api_index in [1, 2, 3]:
            purpose = "websocket"
        else:
            purpose = "optionchain"
        
        # Connect to database
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        logger.info(f"Database connection established for {api_name}")
        
        # Check if upstox_tokens table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='upstox_tokens'")
        if not cursor.fetchone():
            logger.error("upstox_tokens table not found in database")
            print_colored("❌ upstox_tokens table not found!", Colors.BRIGHT_RED, bold=True)
            return False
        
        # Check if token already exists for this api_index
        cursor.execute("SELECT id FROM upstox_tokens WHERE api_index = ? AND user_id = 1", (api_index,))
        existing = cursor.fetchone()
        
        now_str = datetime.now().isoformat()
        validity_str = validity_at.isoformat()
        
        if existing:
            # Update existing token
            logger.info(f"Updating existing token for {api_name} (api_index={api_index})")
            cursor.execute("""
                UPDATE upstox_tokens 
                SET access_token = ?, client_id = ?, generated_at = ?, validity_at = ?, is_active = 1, updated_at = ?
                WHERE api_index = ? AND user_id = 1
            """, (access_token, client_id, now_str, validity_str, now_str, api_index))
            affected = cursor.rowcount
            logger.info(f"Updated {affected} row(s) for {api_name}")
            print_colored(f"💾 Updated token in database for {api_name}", Colors.BRIGHT_GREEN, bold=True)
        else:
            # Insert new token
            logger.info(f"Inserting new token for {api_name} (api_index={api_index})")
            cursor.execute("""
                INSERT INTO upstox_tokens (user_id, api_index, api_name, client_id, access_token, token_type, purpose, is_active, generated_at, validity_at, created_at, updated_at)
                VALUES (1, ?, ?, ?, ?, 'Bearer', ?, 1, ?, ?, ?, ?)
            """, (api_index, api_name, client_id, access_token, purpose, now_str, validity_str, now_str, now_str))
            logger.info(f"Inserted token for {api_name}, row ID: {cursor.lastrowid}")
            print_colored(f"💾 Saved token to database for {api_name}", Colors.BRIGHT_GREEN, bold=True)
        
        # Commit the transaction
        conn.commit()
        logger.info(f"Database transaction committed for {api_name}")
        
        return True
        
    except sqlite3.Error as e:
        logger.error(f"SQLite error saving token to database for {api_name}: {e}")
        print_colored(f"❌ Database error for {api_name}: {e}", Colors.BRIGHT_RED, bold=True)
        if conn:
            conn.rollback()
        return False
    except Exception as e:
        logger.error(f"Unexpected error saving token to database for {api_name}: {e}", exc_info=True)
        print_colored(f"❌ Failed to save {api_name} to database: {e}", Colors.BRIGHT_RED, bold=True)
        if conn:
            conn.rollback()
        return False
    finally:
        if conn:
            conn.close()
            logger.info(f"Database connection closed for {api_name}")


def save_tokens_to_json(tokens_dict: Dict[str, Any]):
    """Save tokens to JSON file"""
    if not TOKENS_FILE:
        logger.warning("TOKEN_DIR_JSON not set in environment")
        return
    
    try:
        output_data = {
            "status": "success",
            "data": tokens_dict,
            "metadata": {
                "generated_at": datetime.now().isoformat(),
                "total_tokens": len(tokens_dict)
            }
        }
        
        with open(TOKENS_FILE, 'w', encoding='utf-8') as file:
            json.dump(output_data, file, indent=2, ensure_ascii=False)
        
        logger.info(f"Saved {len(tokens_dict)} tokens to {TOKENS_FILE}")
        
    except Exception as e:
        logger.error(f"Error saving tokens to JSON: {e}")


def load_tokens() -> Dict[str, Any]:
    """Load tokens from JSON file"""
    if not TOKENS_FILE or not os.path.exists(TOKENS_FILE):
        return {}
    
    try:
        with open(TOKENS_FILE, 'r', encoding='utf-8') as file:
            data = json.load(file)
            if "status" in data and "data" in data:
                return data["data"]
            else:
                tokens = {k: v for k, v in data.items() if k != "metadata"}
                return tokens
    except FileNotFoundError:
        logger.warning(f"Tokens file {TOKENS_FILE} not found")
        return {}
    except Exception as e:
        logger.error(f"Error loading tokens: {e}")
        return {}


def display_token_file_location():
    """Display information about the tokens file location"""
    if TOKENS_FILE:
        print_colored(f"\n📁 Tokens file location: {TOKENS_FILE}", Colors.BRIGHT_CYAN, bold=True)
    else:
        print_colored("\n⚠️  TOKEN_DIR_JSON environment variable not set", Colors.BRIGHT_YELLOW, bold=True)
