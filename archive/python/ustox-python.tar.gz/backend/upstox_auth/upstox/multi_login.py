#!/usr/bin/env python3
"""
Upstox Multi-Login - Main Entry Point
Generates access tokens for multiple Upstox API configurations
Uses a shared Selenium driver for efficiency
"""

import logging
import time
import argparse
import os
import json
from datetime import datetime
from typing import Tuple, Optional
from dotenv import load_dotenv
from pathlib import Path

# Load environment variables from backend/.env file FIRST
# Find the .env file relative to this script's location
_script_dir = os.path.dirname(os.path.abspath(__file__))
_backend_dir = os.path.dirname(os.path.dirname(_script_dir))  # Go up 2 levels: upstox -> upstox_auth -> backend
_env_path = os.path.join(_backend_dir, '.env')
load_dotenv(_env_path)

from .config_validator import validate_environment_variables, API_CONFIGS
from .auth_flow import automate_login_process, build_authorization_url
from .selenium_driver import DriverManager
from .token_manager import save_token_to_db, save_tokens_to_json, display_token_file_location

# Import from helpers (sibling to upstox in upstox_auth)
from helpers import (
    Colors, print_colored, calculate_token_validity,
    get_access_token, get_profile_data, print_profile_card
)

logger = logging.getLogger(__name__)

# ============================================================================
# TOKEN GENERATION LOG FILE - For tracking each API's token generation
# ============================================================================
TOKEN_GEN_LOG_DIR = Path(_script_dir).parent / "token_generation_logs"
TOKEN_GEN_LOG_FILE = TOKEN_GEN_LOG_DIR / f"token_generation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

def setup_token_generation_logger():
    """Setup a dedicated logger for token generation details"""
    TOKEN_GEN_LOG_DIR.mkdir(exist_ok=True)
    
    # Create a dedicated file handler for token generation
    token_handler = logging.FileHandler(TOKEN_GEN_LOG_FILE, encoding='utf-8')
    token_handler.setLevel(logging.DEBUG)
    token_handler.setFormatter(logging.Formatter(
        '%(asctime)s | %(levelname)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    ))
    
    # Add to root logger to capture all relevant logs
    logging.getLogger().addHandler(token_handler)
    
    return TOKEN_GEN_LOG_FILE

def log_token_generation_details(
    api_index: int,
    api_name: str,
    client_id: str,
    redirect_uri: str,
    capture_code_uri: str,
    auth_code: str = None,
    access_token: str = None,
    db_saved: bool = False,
    error: str = None
):
    """Log detailed token generation info to both console and dedicated log file"""
    log_entry = {
        "timestamp": datetime.now().isoformat(),
        "api_index": api_index,
        "api_name": api_name,
        "client_id": client_id[:12] + "..." if client_id else None,  # Partial for security
        "redirect_uri": redirect_uri,
        "capture_code_uri": capture_code_uri,
        "auth_code_received": auth_code is not None,
        "auth_code_prefix": auth_code[:8] + "..." if auth_code else None,
        "access_token_generated": access_token is not None,
        "access_token_prefix": access_token[:20] + "..." if access_token else None,
        "database_saved": db_saved,
        "error": error
    }
    
    # Log to main logger
    logger.info(f"TOKEN_GEN_DETAIL | {api_name} | {json.dumps(log_entry, indent=2)}")
    
    # Also write to a separate JSON log for easy parsing
    json_log_file = TOKEN_GEN_LOG_DIR / "token_generation_summary.json"
    try:
        if json_log_file.exists():
            with open(json_log_file, 'r') as f:
                data = json.load(f)
        else:
            data = {"tokens": [], "last_updated": None}
        
        data["tokens"].append(log_entry)
        data["last_updated"] = datetime.now().isoformat()
        
        with open(json_log_file, 'w') as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        logger.warning(f"Could not write to JSON log: {e}")


def get_api_index(api_name: str) -> int:
    """Get the index of an API by name"""
    api_names = list(API_CONFIGS.keys())
    try:
        return api_names.index(api_name)
    except ValueError:
        return -1


def process_api_config(config_name: str, config: dict, driver=None, api_index: int = -1) -> Tuple[bool, Optional[str]]:
    """
    Process a single API configuration and return the access token
    
    Args:
        config_name: Name of the API configuration
        config: Configuration dictionary with api_key, api_secret, etc.
        driver: Optional shared Selenium driver instance
        api_index: The index of this API (0-5)
    
    Returns:
        Tuple of (success, token_or_error_code)
    """
    client_id = config.get('api_key', '')
    client_secret = config.get('api_secret', '')
    redirect_uri = config.get('redirect_uri', '')
    
    # Log start of processing
    logger.info(f"{'='*60}")
    logger.info(f"PROCESSING API: {config_name} (index={api_index})")
    logger.info(f"{'='*60}")
    logger.info(f"  Client ID: {client_id[:12]}..." if client_id else "  Client ID: MISSING")
    logger.info(f"  Redirect URI: {redirect_uri}")
    
    try:
        if not client_id or not client_secret:
            error_msg = f"{config_name} - Missing API key or secret"
            logger.error(error_msg)
            log_token_generation_details(
                api_index=api_index,
                api_name=config_name,
                client_id=client_id,
                redirect_uri=redirect_uri,
                capture_code_uri=redirect_uri,  # Same as redirect_uri now
                error="Missing API key or secret"
            )
            return False, None
        
        # Build auth URL with multi_login=True to add ML: prefix to state
        # This tells the backend to return code in HTML without consuming it
        auth_url, expected_state = build_authorization_url(client_id, redirect_uri, multi_login=True)
        logger.info(f"  Auth URL built with multi_login=True")
        logger.info(f"  State: {expected_state}")
        
        logger.info(f"Attempting automated login for {config_name}...")
        
        # Pass driver and keep_driver_open=True for multi-login mode
        returned_code, error_code = automate_login_process(
            auth_url, 
            expected_state, 
            redirect_uri,  # Use original registered redirect URI
            driver=driver,
            keep_driver_open=True  # Don't close - we're reusing it
        )
        
        # Check for rate limit error
        if error_code == "RATE_LIMIT":
            logger.warning(f"⚠️ {config_name} - OTP rate limit exceeded [1017069]")
            print_colored(f"⚠️ {config_name} - OTP rate limit hit. Try again in 10 minutes.", Colors.BRIGHT_YELLOW, bold=True)
            log_token_generation_details(
                api_index=api_index,
                api_name=config_name,
                client_id=client_id,
                redirect_uri=redirect_uri,
                capture_code_uri=redirect_uri,
                error="OTP Rate Limit [1017069]"
            )
            return False, "RATE_LIMIT"
        
        if returned_code:
            logger.info(f"✅ Auth code received for {config_name}: {returned_code[:8]}...")
            logger.info(f"Exchanging authorization code for access token ({config_name})...")
            logger.info(f"  Exchange params: client_id={client_id[:12]}..., redirect_uri={redirect_uri}")
            
            token, response_data = get_access_token(returned_code, client_id, client_secret, redirect_uri)
            
            if token:
                logger.info(f"✅ {config_name} - Access token generated successfully!")
                logger.info(f"  Token prefix: {token[:20]}...")
                print_colored(f"✅ {config_name} - Access token generated successfully!", Colors.BRIGHT_GREEN, bold=True)
                
                # Log the successful token generation
                log_token_generation_details(
                    api_index=api_index,
                    api_name=config_name,
                    client_id=client_id,
                    redirect_uri=redirect_uri,
                    capture_code_uri=redirect_uri,
                    auth_code=returned_code,
                    access_token=token,
                    db_saved=False  # Will be updated after DB save
                )
                
                return True, token
            else:
                error_msg = f"Token exchange failed: {response_data}"
                logger.error(f"❌ {config_name} - Failed to get access token")
                logger.error(f"  Response: {response_data}")
                print_colored(f"❌ {config_name} - Failed to get access token", Colors.BRIGHT_RED, bold=True)
                
                log_token_generation_details(
                    api_index=api_index,
                    api_name=config_name,
                    client_id=client_id,
                    redirect_uri=redirect_uri,
                    capture_code_uri=redirect_uri,
                    auth_code=returned_code,
                    error=f"Token exchange failed: {str(response_data)[:100]}"
                )
                return False, None
        else:
            logger.error(f"❌ {config_name} - Authorization code not found")
            print_colored(f"❌ {config_name} - Authorization code not found", Colors.BRIGHT_RED, bold=True)
            
            log_token_generation_details(
                api_index=api_index,
                api_name=config_name,
                client_id=client_id,
                redirect_uri=redirect_uri,
                capture_code_uri=redirect_uri,
                error="Auth code not found after login"
            )
            return False, None
            
    except Exception as e:
        logger.error(f"❌ {config_name} - Unexpected error: {e}", exc_info=True)
        print_colored(f"❌ {config_name} - Unexpected error: {e}", Colors.BRIGHT_RED, bold=True)
        return False, None


def display_all_profiles(successful_tokens: dict):
    """Display all user profiles in a stylized format"""
    if not successful_tokens:
        return
    
    print_colored(f"\n{'═' * 80}", Colors.BRIGHT_WHITE, bold=True)
    print_colored("🎯 USER PROFILE VERIFICATION", Colors.BRIGHT_WHITE, bold=True, underline=True)
    print_colored(f"{'═' * 80}", Colors.BRIGHT_WHITE, bold=True)
    
    for api_name, (token, color) in successful_tokens.items():
        profile_data = get_profile_data(token)
        if profile_data:
            print_profile_card(api_name, profile_data, color)
        else:
            print_colored(f"\n❌ Failed to fetch profile for {api_name}", Colors.BRIGHT_RED, bold=True)
    
    print_colored(f"\n{'═' * 80}", Colors.BRIGHT_WHITE, bold=True)


def main():
    """Main function for standalone execution - Auto generate tokens for all APIs"""
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Upstox Multi-API Token Generator')
    parser.add_argument('--start-index', type=int, default=0, help='Starting API index (0-5)')
    parser.add_argument('--headless', action='store_true', help='Run browser in headless mode')
    args = parser.parse_args()
    
    # Setup logging for standalone execution with UTF-8 encoding
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('multi_login.log', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    
    # Setup dedicated token generation logger
    token_log_file = setup_token_generation_logger()
    logger.info(f"📝 Token generation log file: {token_log_file}")
    print_colored(f"📝 Token generation log: {token_log_file}", Colors.BRIGHT_CYAN, bold=True)
    
    logger.info("Starting Multi-API Upstox authentication process...")
    print_colored("🚀 Starting Multi-API Upstox Authentication Process", Colors.BRIGHT_CYAN, bold=True, underline=True)
    
    shared_driver = None
    
    try:
        # Validate environment variables
        valid_configs = validate_environment_variables()
        if not valid_configs:
            logger.error("Environment validation failed")
            print_colored("❌ ERROR: Environment validation failed", Colors.BRIGHT_RED, bold=True)
            return 1
        
        # Filter by start_index if specified
        if args.start_index > 0:
            config_items = list(valid_configs.items())
            valid_configs = dict(config_items[args.start_index:])
            logger.info(f"Starting from index {args.start_index}, processing {len(valid_configs)} APIs")
        
        print_colored(f"\n✅ Found {len(valid_configs)} valid API configurations:", Colors.BRIGHT_GREEN, bold=True)
        for i, config_name in enumerate(valid_configs.keys(), 1):
            print_colored(f"  {i}. {config_name}", valid_configs[config_name]['color'], bold=True)
        
        print_colored(f"\n🔧 Initializing shared browser for all {len(valid_configs)} API configurations...", Colors.BRIGHT_YELLOW, bold=True)
        
        # Initialize shared driver ONCE for all APIs
        shared_driver = DriverManager.get_driver(headless=args.headless, shared=True)
        logger.info("Shared WebDriver initialized successfully")
        
        # Process each API configuration
        successful_configs = []
        failed_configs = []
        successful_tokens = {}
        tokens_to_save = {}
        
        for i, (config_name, config) in enumerate(valid_configs.items(), 1):
            actual_index = args.start_index + i - 1  # Calculate actual API index
            print_colored(f"\n[{i}/{len(valid_configs)}] Processing {config_name}...", Colors.BRIGHT_WHITE, bold=True)
            
            # Pass shared driver and api_index to each login
            success, token = process_api_config(config_name, config, driver=shared_driver, api_index=actual_index)
            
            if success and token:
                successful_configs.append(config_name)
                successful_tokens[config_name] = (token, config['color'])
                
                # Calculate token validity
                generation_time = datetime.now()
                validity_time = calculate_token_validity(generation_time)
                
                # Prepare token data for JSON file
                tokens_to_save[config_name] = {
                    "access_token": token,
                    "api_key": config['api_key'],
                    "generated_at": generation_time.isoformat(),
                    "validity_at": validity_time.isoformat(),
                    "status": "active"
                }
                
                # ===== SAVE TO DATABASE =====
                db_saved = save_token_to_db(
                    api_index=actual_index,
                    api_name=config_name,
                    access_token=token,
                    client_id=config['api_key'],
                    validity_at=validity_time
                )
                logger.info(f"💾 {config_name} - Database save: {'SUCCESS' if db_saved else 'FAILED'}")
                # ===========================
                
                # Display validity information
                print_colored(f"⏰ Token valid until: {validity_time.strftime('%Y-%m-%d %H:%M:%S')}", Colors.BRIGHT_CYAN, bold=True)
                
            else:
                failed_configs.append(config_name)
            
            # Add a small delay between API calls to avoid rate limiting
            if i < len(valid_configs):
                print_colored("⏳ Waiting 3 seconds before next API...", Colors.BRIGHT_BLACK)
                time.sleep(3)
        
        # Save all tokens to JSON file
        if tokens_to_save:
            save_tokens_to_json(tokens_to_save)
            display_token_file_location()
        
        # Display all profiles after token generation
        if successful_tokens:
            display_all_profiles(successful_tokens)
        
        # Summary
        print_colored(f"\n{'═' * 80}", Colors.BRIGHT_WHITE, bold=True)
        print_colored("📊 FINAL SUMMARY", Colors.BRIGHT_WHITE, bold=True, underline=True)
        print_colored(f"{'═' * 80}", Colors.BRIGHT_WHITE, bold=True)
        
        if successful_configs:
            print_colored(f"✅ Successfully processed ({len(successful_configs)}):", Colors.BRIGHT_GREEN, bold=True)
            for config_name in successful_configs:
                color = valid_configs[config_name]['color']
                print_colored(f"   • {config_name}", color, bold=True)
        
        if failed_configs:
            print_colored(f"❌ Failed to process ({len(failed_configs)}):", Colors.BRIGHT_RED, bold=True)
            for config_name in failed_configs:
                print_colored(f"   • {config_name}", Colors.BRIGHT_RED)
        
        if successful_configs and not failed_configs:
            logger.info("All API configurations processed successfully!")
            print_colored(f"\n🎉 All {len(successful_configs)} API configurations processed successfully!", Colors.BRIGHT_GREEN, bold=True)
            return 0
        elif successful_configs:
            logger.warning("Some API configurations failed to process")
            print_colored(f"\n⚠️  {len(successful_configs)}/{len(valid_configs)} configurations processed successfully", Colors.BRIGHT_YELLOW, bold=True)
            return 2
        else:
            logger.error("All API configurations failed to process")
            print_colored(f"\n💥 All API configurations failed to process", Colors.BRIGHT_RED, bold=True)
            return 1
            
    except KeyboardInterrupt:
        logger.info("Process interrupted by user")
        print_colored("\n\n⚠️ Process interrupted by user", Colors.BRIGHT_YELLOW, bold=True)
        return 130
    except Exception as e:
        logger.error(f"Unexpected error in main process: {e}", exc_info=True)
        print_colored(f"\n💥 Unexpected error: {e}", Colors.BRIGHT_RED, bold=True)
        return 1
    finally:
        # Always close the shared driver when done
        if shared_driver or DriverManager.is_shared_driver_active():
            print_colored("\n🔒 Closing shared browser...", Colors.BRIGHT_BLACK)
            DriverManager.close_driver()
            logger.info("Shared WebDriver closed after multi-login")


if __name__ == "__main__":
    import sys
    sys.exit(main())
