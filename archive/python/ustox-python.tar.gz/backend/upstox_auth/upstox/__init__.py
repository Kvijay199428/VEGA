"""
Upstox Authentication Module
Provides both single and multi-API login functionality
"""

from .selenium_driver import setup_webdriver, DriverManager, managed_driver
from .auth_flow import automate_login_process, build_authorization_url
from .config_validator import validate_environment_variables, API_CONFIGS
from .token_manager import save_token_to_db, save_tokens_to_json, load_tokens
from .single_login import single_api_login, list_available_apis
from .multi_login import main as multi_login_main

__all__ = [
    # Driver management
    'setup_webdriver',
    'DriverManager',
    'managed_driver',
    
    # Auth flow
    'automate_login_process',
    'build_authorization_url',
    
    # Config
    'validate_environment_variables',
    'API_CONFIGS',
    
    # Token management
    'save_token_to_db',
    'save_tokens_to_json',
    'load_tokens',
    
    # Login functions
    'single_api_login',
    'list_available_apis',
    'multi_login_main',
]
