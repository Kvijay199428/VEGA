"""
Config Validator - Validate environment variables for Upstox APIs
"""

import os
import logging
from typing import Dict, Any
from dotenv import load_dotenv

# Load environment variables from backend/.env file
_script_dir = os.path.dirname(os.path.abspath(__file__))
_backend_dir = os.path.dirname(os.path.dirname(_script_dir))  # Go up 2 levels
_env_path = os.path.join(_backend_dir, '.env')
load_dotenv(_env_path)

from helpers import Colors, print_colored, cleanup_old_tokens

logger = logging.getLogger(__name__)

# Default redirect URI (for popup login via backend callback)
DEFAULT_REDIRECT_URI = os.getenv("UPSTOX_REDIRECT_URI")

# Capture-code redirect URI (for multi-login - doesn't consume the code)
# This endpoint returns the auth code in HTML for the script to read and exchange
def get_capture_code_uri(callback_uri: str = None) -> str:
    """Convert a callback URI to capture-code URI for multi-login mode"""
    uri = callback_uri or DEFAULT_REDIRECT_URI
    if uri and "/callback" in uri:
        return uri.replace("/callback", "/capture-code")
    return uri

# API Configuration mapping
API_CONFIGS = {
    'PRIMARY': {
        'api_key': os.getenv("UPSTOX_CLIENT_ID_0"),
        'api_secret': os.getenv("UPSTOX_CLIENT_SECRET_0"),
        'redirect_uri': os.getenv("UPSTOX_REDIRECT_URI_0", DEFAULT_REDIRECT_URI),
        'color': Colors.BRIGHT_BLUE,
    },
    'WEBSOCKET1': {
        'api_key': os.getenv("UPSTOX_CLIENT_ID_1"),
        'api_secret': os.getenv("UPSTOX_CLIENT_SECRET_1"),
        'redirect_uri': os.getenv("UPSTOX_REDIRECT_URI_1", DEFAULT_REDIRECT_URI),
        'color': Colors.BRIGHT_MAGENTA,
    },
    'WEBSOCKET2': {
        'api_key': os.getenv("UPSTOX_CLIENT_ID_2"),
        'api_secret': os.getenv("UPSTOX_CLIENT_SECRET_2"),
        'redirect_uri': os.getenv("UPSTOX_REDIRECT_URI_2", DEFAULT_REDIRECT_URI),
        'color': Colors.BRIGHT_CYAN,
    },
    'WEBSOCKET3': {
        'api_key': os.getenv("UPSTOX_CLIENT_ID_3"),
        'api_secret': os.getenv("UPSTOX_CLIENT_SECRET_3"),
        'redirect_uri': os.getenv("UPSTOX_REDIRECT_URI_3", DEFAULT_REDIRECT_URI),
        'color': Colors.BRIGHT_CYAN,
    },
    'OPTIONCHAIN1': {
        'api_key': os.getenv("UPSTOX_CLIENT_ID_4"),
        'api_secret': os.getenv("UPSTOX_CLIENT_SECRET_4"),
        'redirect_uri': os.getenv("UPSTOX_REDIRECT_URI_4", DEFAULT_REDIRECT_URI),
        'color': Colors.BRIGHT_YELLOW,
    },
    'OPTIONCHAIN2': {
        'api_key': os.getenv("UPSTOX_CLIENT_ID_5"),
        'api_secret': os.getenv("UPSTOX_CLIENT_SECRET_5"),
        'redirect_uri': os.getenv("UPSTOX_REDIRECT_URI_5", DEFAULT_REDIRECT_URI),
        'color': Colors.BRIGHT_RED,
    }
}


def validate_environment_variables() -> Dict[str, Any]:
    """
    Validate that all required environment variables are present
    
    Returns:
        Dictionary of valid API configurations
    """
    # First cleanup old tokens
    cleanup_old_tokens()
    
    # Check common credentials
    mobile = os.getenv("UPSTOX_MOBILE_NUMBER")
    totp = os.getenv("UPSTOX_TOTP")
    pin = os.getenv("UPSTOX_PIN")
    
    if not all([mobile, totp, pin]):
        logger.error("Missing common credentials: MOBILE_NUMBER, TOTP, or PIN")
        print_colored("❌ Missing required environment variables", Colors.BRIGHT_RED, bold=True)
        return {}
    
    # Validate each API configuration
    valid_configs = {}
    
    for api_name, config in API_CONFIGS.items():
        api_key = config.get('api_key')
        api_secret = config.get('api_secret')
        
        if api_key and api_secret:
            valid_configs[api_name] = config
            logger.info(f"✅ {api_name} - Configuration valid")
        else:
            logger.warning(f"⚠️  {api_name} - Missing API key or secret, skipping")
    
    if not valid_configs:
        logger.error("No valid API configurations found")
        print_colored("❌ No valid API configurations", Colors.BRIGHT_RED, bold=True)
        return {}
    
    return valid_configs
