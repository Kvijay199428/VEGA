"""
Selenium WebDriver Setup for Upstox Login Automation
Supports both single-use and shared driver modes for efficient multi-login
"""

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from contextlib import contextmanager
import logging

logger = logging.getLogger(__name__)


class DriverManager:
    """
    Singleton driver manager for reusing Selenium driver across multiple logins.
    Use this for multi-login mode to avoid creating new browser instances for each API.
    """
    _driver = None
    _is_shared = False
    
    @classmethod
    def get_driver(cls, headless: bool = False, shared: bool = True):
        """
        Get or create a Chrome WebDriver instance.
        
        Args:
            headless: Whether to run in headless mode
            shared: If True, reuses the same driver instance (for multi-login)
        
        Returns:
            webdriver.Chrome: Configured Chrome WebDriver instance
        """
        if shared and cls._driver is not None:
            logger.info("Reusing existing shared WebDriver instance")
            return cls._driver
        
        driver = setup_webdriver(headless)
        
        if shared:
            cls._driver = driver
            cls._is_shared = True
            logger.info("Created new shared WebDriver instance")
        else:
            logger.info("Created new standalone WebDriver instance")
        
        return driver
    
    @classmethod
    def close_driver(cls):
        """Close the shared driver if it exists"""
        if cls._driver is not None:
            try:
                cls._driver.quit()
                logger.info("Shared WebDriver closed successfully")
            except Exception as e:
                logger.warning(f"Error closing shared WebDriver: {e}")
            finally:
                cls._driver = None
                cls._is_shared = False
    
    @classmethod
    def is_shared_driver_active(cls) -> bool:
        """Check if a shared driver is currently active"""
        return cls._driver is not None and cls._is_shared


def setup_webdriver(headless: bool = False):
    """
    Set up and return a Chrome WebDriver instance
    
    Args:
        headless: Whether to run in headless mode (default: False for visibility)
    
    Returns:
        webdriver.Chrome: Configured Chrome WebDriver instance
    """
    try:
        chrome_options = Options()
        
        if headless:
            chrome_options.add_argument('--headless')
        
        # Add common options for stability
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        # Set window size for consistency
        chrome_options.add_argument('--window-size=1024,768')
        
        logger.info(f"Initializing Chrome WebDriver (headless={headless})...")
        driver = webdriver.Chrome(options=chrome_options)
        
        # Hide webdriver property to avoid detection
        driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        
        # Set implicit wait
        driver.implicitly_wait(10)
        
        logger.info("WebDriver initialized successfully")
        return driver
        
    except Exception as e:
        logger.error(f"Failed to initialize WebDriver: {e}")
        raise


@contextmanager
def managed_driver(headless: bool = False, shared: bool = False):
    """
    Context manager for WebDriver that automatically cleans up.
    
    Usage:
        with managed_driver() as driver:
            driver.get("https://example.com")
    
    Args:
        headless: Whether to run in headless mode
        shared: Whether to use shared driver (won't close on exit if shared)
    """
    if shared:
        driver = DriverManager.get_driver(headless=headless, shared=True)
        try:
            yield driver
        except Exception:
            raise
        # Don't close shared driver - it will be closed explicitly later
    else:
        driver = setup_webdriver(headless)
        try:
            yield driver
        finally:
            try:
                driver.quit()
                logger.info("Managed driver closed successfully")
            except Exception as e:
                logger.warning(f"Error closing managed driver: {e}")
