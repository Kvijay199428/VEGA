"""
Upstox Auth Helpers Package
Centralized utilities for Upstox authentication and token management
"""

from .console import (
    Colors,
    print_colored,
    print_header,
    print_success,
    print_error,
    print_warning,
    print_info,
    print_profile_card
)

from .token_utils import (
    calculate_token_validity,
    is_token_valid,
    get_token_status_display,
    cleanup_old_tokens
)

from .api_client import (
    generate_totp_code,
    get_access_token,
    get_profile_data,
    build_authorization_url
)

__all__ = [
    # Console utilities
    "Colors",
    "print_colored",
    "print_header",
    "print_success",
    "print_error",
    "print_warning",
    "print_info",
    "print_profile_card",
    
    # Token utilities
    "calculate_token_validity",
    "is_token_valid",
    "get_token_status_display",
    "cleanup_old_tokens",
    
    # API client
    "generate_totp_code",
    "get_access_token",
    "get_profile_data",
    "build_authorization_url",
]
