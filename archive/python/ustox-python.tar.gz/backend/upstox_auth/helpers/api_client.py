"""
Upstox API Client Utilities
Functions for interacting with Upstox API endpoints
"""

import requests
import pyotp
import logging
from typing import Optional, Dict, Any, Tuple

logger = logging.getLogger("upstox_auth")

# Upstox API endpoints
TOKEN_URL = "https://api.upstox.com/v2/login/authorization/token"
PROFILE_URL = "https://api.upstox.com/v2/user/profile"


def generate_totp_code(totp_secret: str) -> Optional[str]:
    """
    Generate TOTP code from secret.
    
    Args:
        totp_secret: The TOTP secret key
        
    Returns:
        Generated TOTP code or None on error
    """
    try:
        totp = pyotp.TOTP(totp_secret)
        code = totp.now()
        return code
    except Exception as e:
        logger.error(f"Error generating TOTP code: {e}")
        return None


def get_access_token(
    code: str, 
    client_id: str, 
    client_secret: str, 
    redirect_uri: str
) -> Tuple[Optional[str], Any]:
    """
    Exchange authorization code for access token.
    
    Args:
        code: Authorization code from OAuth flow
        client_id: Upstox API client ID
        client_secret: Upstox API client secret
        redirect_uri: Redirect URI used in OAuth flow
    
    Returns:
        Tuple of (access_token, response_data)
    """
    try:
        payload = {
            "code": code,
            "client_id": client_id,
            "client_secret": client_secret,
            "redirect_uri": redirect_uri,
            "grant_type": "authorization_code"
        }
        
        headers = {
            "accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        
        response = requests.post(TOKEN_URL, data=payload, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            access_token = data.get("access_token")
            return access_token, data
        else:
            logger.error(f"Token exchange failed: {response.status_code} - {response.text}")
            return None, response.json() if response.text else None
            
    except Exception as e:
        logger.error(f"Exception during token exchange: {e}")
        return None, None


def get_profile_data(access_token: str) -> Optional[Dict[str, Any]]:
    """
    Fetch user profile data from Upstox API.
    
    Args:
        access_token: Valid Upstox access token
        
    Returns:
        User profile data or None on error
    """
    try:
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json"
        }
        
        response = requests.get(PROFILE_URL, headers=headers)
        
        if response.status_code == 200:
            return response.json().get("data")
        else:
            logger.error(f"Failed to fetch profile: {response.status_code}")
            return None
            
    except Exception as e:
        logger.error(f"Exception fetching profile: {e}")
        return None


def build_authorization_url(client_id: str, redirect_uri: str, state: str = None) -> str:
    """
    Build the Upstox OAuth authorization URL.
    
    Args:
        client_id: Upstox API client ID
        redirect_uri: Redirect URI for OAuth callback
        state: Optional state parameter for security
        
    Returns:
        Authorization URL string
    """
    import urllib.parse
    import secrets
    
    if state is None:
        state = secrets.token_urlsafe(16)
    
    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "state": state,
        "response_type": "code"
    }
    
    base_url = "https://api.upstox.com/v2/login/authorization/dialog"
    query_string = urllib.parse.urlencode(params)
    
    return f"{base_url}?{query_string}"
