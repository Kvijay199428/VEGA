"""
Upstox Console Utilities
ANSI color codes and console output helpers for styled terminal output
"""

import sys
import os


def safe_print(*args, **kwargs):
    """Print function that handles Unicode encoding errors on Windows"""
    try:
        print(*args, **kwargs)
    except UnicodeEncodeError:
        # Fallback: Remove emojis and special characters
        text = str(args[0]) if args else ""
        # Replace common emoji characters with ASCII equivalents
        replacements = {
            '✅': '[OK]', '❌': '[X]', '⚠️': '[!]', 'ℹ️': '[i]',
            '🚀': '>>', '💾': '[#]', '⏰': '[T]', '⏳': '...',
            '🔐': '[*]', '🔧': '[*]', '🎯': '[>]', '📊': '[=]',
            '💥': '[!]', '🎉': '[*]', '👤': '[U]', '📧': '[E]',
            '🆔': '[ID]', '📱': '[M]', '🏢': '[B]', '🔒': '[*]',
            '─': '-', '═': '=',
        }
        for emoji, ascii_char in replacements.items():
            text = text.replace(emoji, ascii_char)
        try:
            print(text, **kwargs)
        except UnicodeEncodeError:
            # Ultimate fallback: encode with errors replaced
            print(text.encode('ascii', errors='replace').decode('ascii'), **kwargs)


class Colors:
    """ANSI Color codes for console output"""
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    UNDERLINE = '\033[4m'
    
    # Text Colors
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    
    # Bright Colors
    BRIGHT_BLACK = '\033[90m'
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_MAGENTA = '\033[95m'
    BRIGHT_CYAN = '\033[96m'
    BRIGHT_WHITE = '\033[97m'
    
    # Background Colors
    BG_BLACK = '\033[40m'
    BG_RED = '\033[41m'
    BG_GREEN = '\033[42m'
    BG_YELLOW = '\033[43m'
    BG_BLUE = '\033[44m'
    BG_MAGENTA = '\033[45m'
    BG_CYAN = '\033[46m'
    BG_WHITE = '\033[47m'


def print_colored(text: str, color: str = Colors.WHITE, bold: bool = False, underline: bool = False) -> None:
    """Print colored text to console"""
    style = ""
    if bold:
        style += Colors.BOLD
    if underline:
        style += Colors.UNDERLINE
    safe_print(f"{style}{color}{text}{Colors.RESET}")


def print_header(text: str, color: str = Colors.BRIGHT_CYAN) -> None:
    """Print a header line with separators"""
    separator = "─" * 60
    print_colored(separator, Colors.BRIGHT_WHITE)
    print_colored(text, color, bold=True)
    print_colored(separator, Colors.BRIGHT_WHITE)


def print_success(text: str) -> None:
    """Print success message in green"""
    print_colored(f"✅ {text}", Colors.BRIGHT_GREEN)


def print_error(text: str) -> None:
    """Print error message in red"""
    print_colored(f"❌ {text}", Colors.BRIGHT_RED)


def print_warning(text: str) -> None:
    """Print warning message in yellow"""
    print_colored(f"⚠️ {text}", Colors.BRIGHT_YELLOW)


def print_info(text: str) -> None:
    """Print info message in cyan"""
    print_colored(f"ℹ️ {text}", Colors.BRIGHT_CYAN)


def print_profile_card(api_name: str, profile_data: dict, color: str) -> None:
    """Print a styled profile card"""
    print_colored(f"\n{'─' * 60}", Colors.BRIGHT_WHITE)
    print_colored(f"API: {api_name}", color, bold=True)
    print_colored(f"{'─' * 60}", Colors.BRIGHT_WHITE)
    
    if profile_data:
        print_colored(f"  👤 Name: {profile_data.get('user_name', 'N/A')}", Colors.BRIGHT_WHITE)
        print_colored(f"  📧 Email: {profile_data.get('email', 'N/A')}", Colors.BRIGHT_WHITE)
        print_colored(f"  🆔 User ID: {profile_data.get('user_id', 'N/A')}", Colors.BRIGHT_CYAN)
        print_colored(f"  📱 Mobile: {profile_data.get('mobile', 'N/A')}", Colors.BRIGHT_WHITE)
        print_colored(f"  🏢 Broker: {profile_data.get('broker', 'UPSTOX')}", Colors.BRIGHT_GREEN)
    
    print_colored(f"{'─' * 60}", Colors.BRIGHT_WHITE)
