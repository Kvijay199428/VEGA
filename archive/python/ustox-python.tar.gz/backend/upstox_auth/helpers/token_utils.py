"""
Upstox Token Utilities
Token validation and management helpers
"""

import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any

logger = logging.getLogger("upstox_auth")


def calculate_token_validity(generation_time: Optional[datetime] = None) -> datetime:
    """
    Calculate token validity based on the generation time.
    Token is valid until 3:00 AM of the next day after generation.
    
    Args:
        generation_time: When the token was generated. Defaults to now.
        
    Returns:
        datetime when the token expires
    """
    if generation_time is None:
        generation_time = datetime.now()
    
    three_am_today = generation_time.replace(hour=3, minute=0, second=0, microsecond=0)
    
    if generation_time < three_am_today:
        validity_time = three_am_today
    else:
        validity_time = three_am_today + timedelta(days=1)
    
    return validity_time


def is_token_valid(token_data: Dict[str, Any]) -> bool:
    """
    Check if a token is still valid based on its validity_at timestamp.
    
    Args:
        token_data: Token data dictionary with 'validity_at' field
        
    Returns:
        True if token is valid, False otherwise
    """
    try:
        if not isinstance(token_data, dict):
            return False
        
        validity_at = token_data.get('validity_at')
        if not validity_at:
            return False
        
        if isinstance(validity_at, str):
            validity_time = datetime.fromisoformat(validity_at)
        elif isinstance(validity_at, datetime):
            validity_time = validity_at
        else:
            return False
        
        return datetime.now() < validity_time
    except Exception as e:
        logger.error(f"Error checking token validity: {e}")
        return False


def get_token_status_display(token_data: Dict[str, Any]) -> str:
    """
    Get a human-readable status for a token.
    
    Args:
        token_data: Token data dictionary
        
    Returns:
        Status string (e.g., "VALID", "EXPIRED", "MISSING")
    """
    if not token_data:
        return "MISSING"
    
    if is_token_valid(token_data):
        validity_at = token_data.get('validity_at')
        if validity_at:
            if isinstance(validity_at, str):
                validity_time = datetime.fromisoformat(validity_at)
            else:
                validity_time = validity_at
            
            remaining = validity_time - datetime.now()
            hours = int(remaining.total_seconds() // 3600)
            return f"VALID ({hours}h remaining)"
        return "VALID"
    
    return "EXPIRED"


def cleanup_old_tokens() -> None:
    """
    Clean up old or expired tokens from the system.
    This is a placeholder function that can be implemented later.
    """
    logger.debug("cleanup_old_tokens called - no action taken (placeholder)")
    # This function can be implemented to clean up expired tokens
    # from the database or JSON files if needed
    pass

