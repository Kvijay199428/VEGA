"""
VEGA TRADER Server Runner
Entry point for starting the trading platform backend server
"""

import uvicorn

if __name__ == "__main__":
    uvicorn.run(
        "server.app:app",
        host="0.0.0.0",
        port=28020,
        reload=True,
        log_level="info"
    )
