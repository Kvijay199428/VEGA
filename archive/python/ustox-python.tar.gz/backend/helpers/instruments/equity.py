"""
Equity Instrument Helper - Extract equity instrument keys for WebSocket subscription
"""

from typing import List, Dict, Any, Optional, Tuple
from sqlalchemy.orm import Session
import logging

logger = logging.getLogger(__name__)


class EquityHelper:
    """
    Helper class for extracting equity instrument keys.
    
    Equity instruments are stored in equity_instruments table.
    Segments: NSE_EQ, BSE_EQ
    """
    
    # Known equity segments
    EQUITY_SEGMENTS = ['NSE_EQ', 'BSE_EQ']
    
    # Popular equity stocks for quick access (Nifty 50 constituents)
    POPULAR_STOCKS = [
        'NSE_EQ|INE009A01021',  # INFY
        'NSE_EQ|INE467B01029',  # TCS
        'NSE_EQ|INE040A01034',  # RELIANCE
        'NSE_EQ|INE090A01021',  # HDFCBANK
        'NSE_EQ|INE154A01025',  # ICICIBANK
    ]
    
    @staticmethod
    def get_all_keys(db: Session, exchange: Optional[str] = None) -> List[str]:
        """
        Get all equity instrument keys from the database.
        
        Args:
            exchange: Optional exchange filter (NSE, BSE)
            
        Returns:
            List of instrument keys for all equities
        """
        try:
            from models.instrument_models import EquityInstrument
            
            query = db.query(EquityInstrument.instrument_key)
            
            if exchange:
                query = query.filter(EquityInstrument.exchange == exchange.upper())
            
            instruments = query.all()
            
            keys = [i[0] for i in instruments if i[0]]
            logger.info(f"Found {len(keys)} equity instruments")
            return keys
            
        except Exception as e:
            logger.error(f"Error getting equity keys: {e}")
            return []
    
    @staticmethod
    def get_by_symbol(db: Session, symbol: str) -> Optional[str]:
        """
        Get instrument key for a specific symbol.
        
        Args:
            symbol: Trading symbol (e.g., 'INFY', 'TCS')
            
        Returns:
            Instrument key or None
        """
        try:
            from models.instrument_models import Instrument
            
            instrument = db.query(Instrument.instrument_key).filter(
                Instrument.trading_symbol == symbol.upper(),
                Instrument.instrument_type == 'EQ'
            ).first()
            
            return instrument[0] if instrument else None
            
        except Exception as e:
            logger.error(f"Error getting equity by symbol: {e}")
            return None
    
    @staticmethod
    def get_by_isin(db: Session, isin: str) -> Optional[str]:
        """
        Get instrument key for a specific ISIN.
        
        Args:
            isin: ISIN code (e.g., 'INE009A01021')
            
        Returns:
            Instrument key or None
        """
        try:
            from models.instrument_models import Instrument
            
            instrument = db.query(Instrument.instrument_key).filter(
                Instrument.isin == isin.upper(),
                Instrument.instrument_type == 'EQ'
            ).first()
            
            return instrument[0] if instrument else None
            
        except Exception as e:
            logger.error(f"Error getting equity by ISIN: {e}")
            return None
    
    @staticmethod
    def search(db: Session, query: str, limit: int = 50) -> List[Dict[str, Any]]:
        """
        Search equity instruments by symbol or name.
        
        Args:
            query: Search query
            limit: Maximum results
            
        Returns:
            List of matching instruments
        """
        try:
            from models.instrument_models import Instrument
            from sqlalchemy import or_
            
            instruments = db.query(Instrument).filter(
                Instrument.instrument_type == 'EQ',
                or_(
                    Instrument.trading_symbol.ilike(f"%{query}%"),
                    Instrument.name.ilike(f"%{query}%")
                )
            ).limit(limit).all()
            
            return [
                {
                    'instrument_key': i.instrument_key,
                    'trading_symbol': i.trading_symbol,
                    'name': i.name,
                    'isin': i.isin,
                    'exchange': i.exchange,
                    'segment': i.segment
                }
                for i in instruments
            ]
            
        except Exception as e:
            logger.error(f"Error searching equities: {e}")
            return []
    
    @staticmethod
    def get_instruments(db: Session, exchange: Optional[str] = None, limit: int = 1000) -> List[Dict[str, Any]]:
        """
        Get full equity instrument details.
        
        Args:
            exchange: Optional exchange filter
            limit: Maximum results
            
        Returns:
            List of instrument dictionaries
        """
        try:
            from models.instrument_models import EquityInstrument
            
            query = db.query(EquityInstrument)
            
            if exchange:
                query = query.filter(EquityInstrument.exchange == exchange.upper())
            
            instruments = query.limit(limit).all()
            
            return [
                {
                    'instrument_key': i.instrument_key,
                    'trading_symbol': i.trading_symbol,
                    'name': i.name,
                    'isin': i.isin,
                    'exchange': i.exchange,
                    'segment': i.segment,
                    'lot_size': i.lot_size,
                    'tick_size': i.tick_size
                }
                for i in instruments
            ]
            
        except Exception as e:
            logger.error(f"Error getting equity instruments: {e}")
            return []

    @staticmethod
    def get_instruments_paginated(
        db: Session, 
        exchange: Optional[str] = None, 
        limit: int = 50, 
        offset: int = 0,
        search_query: Optional[str] = None
    ) -> Tuple[List[Dict[str, Any]], int]:
        """
        Get full equity instrument details with pagination and optional search.
        
        Args:
            exchange: Optional exchange filter
            limit: Maximum results per page
            offset: Pagination offset
            search_query: Search by symbol, name, or sector
            
        Returns:
            Tuple containing (List of instrument dictionaries, total_count)
        """
        try:
            from models.instrument_models import EquityInstrument
            from sqlalchemy import or_
            from sector.sectoral_indices import sector_service
            
            query = db.query(EquityInstrument)
            
            if exchange:
                query = query.filter(EquityInstrument.exchange == exchange.upper())
            
            if search_query:
                # ... same search logic ...
                search_query = search_query.strip()
                filters = [
                    EquityInstrument.trading_symbol.ilike(f"%{search_query}%"),
                    EquityInstrument.name.ilike(f"%{search_query}%")
                ]
                
                # Check for sector match (fuzzy)
                matched_isins = set()
                sectors = sector_service.get_all_sectors()
                
                # If query is at least 3 chars, check sectors
                if len(search_query) >= 3:
                    for sector in sectors:
                        # Check name (e.g. "Nifty Bank") or key (e.g. "bank")
                        if (search_query.lower() in sector['name'].lower()) or \
                           (search_query.lower() == sector['key'].lower()):
                            # Get ISINs and add to filter
                            sector_isins = sector_service.get_sector_isin_codes(sector['key'])
                            matched_isins.update(sector_isins)
                
                if matched_isins:
                    filters.append(EquityInstrument.isin.in_(matched_isins))
                
                query = query.filter(or_(*filters))
            
            # Get total count of filtered results
            total_count = query.count()
            
            instrument_objs = query.offset(offset).limit(limit).all()
            
            results = [
                {
                    'instrument_key': i.instrument_key,
                    'trading_symbol': i.trading_symbol,
                    'name': i.name,
                    'isin': i.isin,
                    'exchange': i.exchange,
                    'segment': i.segment,
                    'lot_size': i.lot_size,
                    'tick_size': i.tick_size
                }
                for i in instrument_objs
            ]
            
            return results, total_count
            
        except Exception as e:
            logger.error(f"Error getting equity instruments paginated: {e}")
            return [], 0


# Singleton instance
equity_helper = EquityHelper()

