"""
Futures Instrument Helper - Extract futures instrument keys for WebSocket subscription
"""

from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class FuturesHelper:
    """
    Helper class for extracting futures instrument keys.
    
    Futures instruments are identified by:
    - segment: NSE_FO, BSE_FO, MCX_FO
    - instrument_type: FUT
    """
    
    # Known futures segments
    FUTURES_SEGMENTS = ['NSE_FO', 'BSE_FO', 'MCX_FO', 'NCD_FO', 'BCD_FO']
    
    @staticmethod
    def get_all_keys(db: Session, exchange: Optional[str] = None) -> List[str]:
        """
        Get all futures instrument keys from the database.
        
        Args:
            exchange: Optional exchange filter (NSE, BSE, MCX)
            
        Returns:
            List of instrument keys for all futures
        """
        try:
            from models.instrument_models import Instrument
            
            query = db.query(Instrument.instrument_key).filter(
                Instrument.instrument_type == 'FUT'
            )
            
            if exchange:
                segment = f"{exchange.upper()}_FO"
                query = query.filter(Instrument.segment == segment)
            
            instruments = query.all()
            
            keys = [i[0] for i in instruments if i[0]]
            logger.info(f"Found {len(keys)} futures instruments")
            return keys
            
        except Exception as e:
            logger.error(f"Error getting futures keys: {e}")
            return []
    
    @staticmethod
    def get_by_underlying(db: Session, underlying: str, exchange: str = 'NSE') -> List[str]:
        """
        Get futures instrument keys for a specific underlying.
        
        Args:
            underlying: Underlying symbol (e.g., 'NIFTY', 'BANKNIFTY', 'RELIANCE')
            exchange: Exchange code
            
        Returns:
            List of instrument keys
        """
        try:
            from models.instrument_models import Instrument
            
            segment = f"{exchange.upper()}_FO"
            
            instruments = db.query(Instrument.instrument_key).filter(
                Instrument.segment == segment,
                Instrument.instrument_type == 'FUT',
                Instrument.trading_symbol.ilike(f"{underlying}%")
            ).all()
            
            return [i[0] for i in instruments if i[0]]
            
        except Exception as e:
            logger.error(f"Error getting futures by underlying: {e}")
            return []
    
    @staticmethod
    def get_current_month(db: Session, underlying: str, exchange: str = 'NSE') -> Optional[str]:
        """
        Get current month futures for an underlying.
        
        Args:
            underlying: Underlying symbol
            exchange: Exchange code
            
        Returns:
            Instrument key or None
        """
        try:
            from models.instrument_models import Instrument, Derivative
            
            segment = f"{exchange.upper()}_FO"
            current_time = int(datetime.now().timestamp() * 1000)
            
            # Get nearest expiry future
            instrument = db.query(Instrument).join(
                Derivative, Instrument.instrument_key == Derivative.instrument_key
            ).filter(
                Instrument.segment == segment,
                Instrument.instrument_type == 'FUT',
                Instrument.trading_symbol.ilike(f"{underlying}%"),
                Derivative.expiry >= current_time
            ).order_by(Derivative.expiry.asc()).first()
            
            return instrument.instrument_key if instrument else None
            
        except Exception as e:
            logger.error(f"Error getting current month future: {e}")
            return None
    
    @staticmethod
    def get_instruments(
        db: Session, 
        underlying: Optional[str] = None,
        exchange: Optional[str] = None,
        limit: int = 1000
    ) -> List[Dict[str, Any]]:
        """
        Get full futures instrument details.
        
        Args:
            underlying: Optional underlying filter
            exchange: Optional exchange filter
            limit: Maximum results
            
        Returns:
            List of instrument dictionaries
        """
        try:
            from models.instrument_models import Instrument, Derivative
            
            query = db.query(Instrument, Derivative).outerjoin(
                Derivative, Instrument.instrument_key == Derivative.instrument_key
            ).filter(
                Instrument.instrument_type == 'FUT'
            )
            
            if exchange:
                segment = f"{exchange.upper()}_FO"
                query = query.filter(Instrument.segment == segment)
            
            if underlying:
                query = query.filter(Instrument.trading_symbol.ilike(f"{underlying}%"))
            
            results = query.limit(limit).all()
            
            return [
                {
                    'instrument_key': i.instrument_key,
                    'trading_symbol': i.trading_symbol,
                    'name': i.name,
                    'exchange': i.exchange,
                    'segment': i.segment,
                    'lot_size': i.lot_size,
                    'tick_size': i.tick_size,
                    'expiry': d.expiry if d else None,
                    'underlying_symbol': d.underlying_symbol if d else None
                }
                for i, d in results
            ]
            
        except Exception as e:
            logger.error(f"Error getting futures instruments: {e}")
            return []


# Singleton instance
futures_helper = FuturesHelper()
