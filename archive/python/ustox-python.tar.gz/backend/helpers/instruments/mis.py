"""
MIS (Intraday/Margin Intraday Square-off) Instrument Helper
Extract MIS-enabled instrument keys for WebSocket subscription
"""

from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
import logging

logger = logging.getLogger(__name__)


class MISHelper:
    """
    Helper class for extracting MIS-enabled instrument keys.
    
    MIS instruments are equities enabled for intraday trading with leverage.
    Identified by:
    - equity.intraday_margin IS NOT NULL
    """
    
    @staticmethod
    def get_all_keys(db: Session) -> List[str]:
        """
        Get all MIS-enabled instrument keys from the database.
        
        Returns:
            List of instrument keys for MIS-enabled instruments
        """
        try:
            from models.instrument_models import Instrument, Equity
            
            instruments = db.query(Instrument.instrument_key).join(
                Equity, Instrument.instrument_key == Equity.instrument_key
            ).filter(
                Equity.intraday_margin.isnot(None)
            ).all()
            
            keys = [i[0] for i in instruments if i[0]]
            logger.info(f"Found {len(keys)} MIS-enabled instruments")
            return keys
            
        except Exception as e:
            logger.error(f"Error getting MIS keys: {e}")
            return []
    
    @staticmethod
    def get_by_leverage(db: Session, min_leverage: float = None, max_leverage: float = None) -> List[str]:
        """
        Get MIS instruments filtered by leverage.
        
        Args:
            min_leverage: Minimum leverage factor
            max_leverage: Maximum leverage factor
            
        Returns:
            List of instrument keys
        """
        try:
            from models.instrument_models import Instrument, Equity
            
            query = db.query(Instrument.instrument_key).join(
                Equity, Instrument.instrument_key == Equity.instrument_key
            ).filter(
                Equity.intraday_leverage.isnot(None)
            )
            
            if min_leverage is not None:
                query = query.filter(Equity.intraday_leverage >= min_leverage)
            
            if max_leverage is not None:
                query = query.filter(Equity.intraday_leverage <= max_leverage)
            
            instruments = query.all()
            
            return [i[0] for i in instruments if i[0]]
            
        except Exception as e:
            logger.error(f"Error getting MIS by leverage: {e}")
            return []
    
    @staticmethod
    def get_by_margin(db: Session, max_margin: int = None) -> List[str]:
        """
        Get MIS instruments with margin requirement below threshold.
        
        Args:
            max_margin: Maximum margin requirement percentage
            
        Returns:
            List of instrument keys
        """
        try:
            from models.instrument_models import Instrument, Equity
            
            query = db.query(Instrument.instrument_key).join(
                Equity, Instrument.instrument_key == Equity.instrument_key
            ).filter(
                Equity.intraday_margin.isnot(None)
            )
            
            if max_margin is not None:
                query = query.filter(Equity.intraday_margin <= max_margin)
            
            instruments = query.all()
            
            return [i[0] for i in instruments if i[0]]
            
        except Exception as e:
            logger.error(f"Error getting MIS by margin: {e}")
            return []
    
    @staticmethod
    def search(db: Session, query: str, limit: int = 50) -> List[Dict[str, Any]]:
        """
        Search MIS-enabled instruments by symbol or name.
        
        Args:
            query: Search query
            limit: Maximum results
            
        Returns:
            List of matching instruments
        """
        try:
            from models.instrument_models import Instrument, Equity
            from sqlalchemy import or_
            
            instruments = db.query(Instrument, Equity).join(
                Equity, Instrument.instrument_key == Equity.instrument_key
            ).filter(
                Equity.intraday_margin.isnot(None),
                or_(
                    Instrument.trading_symbol.ilike(f"%{query}%"),
                    Instrument.name.ilike(f"%{query}%")
                )
            ).limit(limit).all()
            
            return [
                {
                    'instrument_key': i.instrument_key,
                    'trading_symbol': i.trading_symbol,
                    'name': i.name,
                    'exchange': i.exchange,
                    'intraday_margin': e.intraday_margin if e else None,
                    'intraday_leverage': e.intraday_leverage if e else None
                }
                for i, e in instruments
            ]
            
        except Exception as e:
            logger.error(f"Error searching MIS instruments: {e}")
            return []
    
    @staticmethod
    def get_instruments(db: Session, limit: int = 1000) -> List[Dict[str, Any]]:
        """
        Get full MIS instrument details.
        
        Returns:
            List of instrument dictionaries with MIS details
        """
        try:
            from models.instrument_models import Instrument, Equity
            
            results = db.query(Instrument, Equity).join(
                Equity, Instrument.instrument_key == Equity.instrument_key
            ).filter(
                Equity.intraday_margin.isnot(None)
            ).limit(limit).all()
            
            return [
                {
                    'instrument_key': i.instrument_key,
                    'trading_symbol': i.trading_symbol,
                    'name': i.name,
                    'isin': i.isin,
                    'exchange': i.exchange,
                    'segment': i.segment,
                    'lot_size': i.lot_size,
                    'intraday_margin': e.intraday_margin if e else None,
                    'intraday_leverage': e.intraday_leverage if e else None
                }
                for i, e in results
            ]
            
        except Exception as e:
            logger.error(f"Error getting MIS instruments: {e}")
            return []
    
    @staticmethod
    def is_mis_enabled(db: Session, instrument_key: str) -> bool:
        """
        Check if an instrument is MIS-enabled.
        
        Args:
            instrument_key: Instrument key to check
            
        Returns:
            True if MIS-enabled
        """
        try:
            from models.instrument_models import Equity
            
            equity = db.query(Equity).filter(
                Equity.instrument_key == instrument_key,
                Equity.intraday_margin.isnot(None)
            ).first()
            
            return equity is not None
            
        except Exception as e:
            logger.error(f"Error checking MIS status: {e}")
            return False
    
    @staticmethod
    def get_margin_info(db: Session, instrument_key: str) -> Optional[Dict[str, Any]]:
        """
        Get MIS margin info for an instrument.
        
        Returns:
            Dict with margin and leverage info
        """
        try:
            from models.instrument_models import Equity
            
            equity = db.query(Equity).filter(
                Equity.instrument_key == instrument_key
            ).first()
            
            if equity and equity.intraday_margin:
                return {
                    'intraday_margin': equity.intraday_margin,
                    'intraday_leverage': equity.intraday_leverage
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Error getting MIS margin info: {e}")
            return None


# Singleton instance
mis_helper = MISHelper()
