"""
Options Instrument Helper - Extract options instrument keys for WebSocket subscription
"""

from typing import List, Dict, Any, Optional, Literal
from sqlalchemy.orm import Session
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class OptionsHelper:
    """
    Helper class for extracting options instrument keys.
    
    Options instruments are identified by:
    - segment: NSE_FO, BSE_FO
    - instrument_type: CE (Call), PE (Put)
    """
    
    # Known options segments
    OPTIONS_SEGMENTS = ['NSE_FO', 'BSE_FO', 'NCD_FO', 'BCD_FO']
    
    @staticmethod
    def get_all_keys(
        db: Session, 
        option_type: Optional[Literal['CE', 'PE']] = None,
        exchange: Optional[str] = None
    ) -> List[str]:
        """
        Get all options instrument keys from the database.
        
        Args:
            option_type: CE (Call) or PE (Put), None for both
            exchange: Optional exchange filter
            
        Returns:
            List of instrument keys
        """
        try:
            from models.instrument_models import Instrument
            from sqlalchemy import or_
            
            if option_type:
                types = [option_type]
            else:
                types = ['CE', 'PE']
            
            query = db.query(Instrument.instrument_key).filter(
                Instrument.instrument_type.in_(types)
            )
            
            if exchange:
                segment = f"{exchange.upper()}_FO"
                query = query.filter(Instrument.segment == segment)
            
            instruments = query.all()
            
            keys = [i[0] for i in instruments if i[0]]
            logger.info(f"Found {len(keys)} options instruments")
            return keys
            
        except Exception as e:
            logger.error(f"Error getting options keys: {e}")
            return []
    
    @staticmethod
    def get_by_underlying(
        db: Session, 
        underlying: str, 
        option_type: Optional[Literal['CE', 'PE']] = None,
        exchange: str = 'NSE'
    ) -> List[str]:
        """
        Get options instrument keys for a specific underlying.
        
        Args:
            underlying: Underlying symbol (e.g., 'NIFTY', 'BANKNIFTY')
            option_type: CE or PE, None for both
            exchange: Exchange code
            
        Returns:
            List of instrument keys
        """
        try:
            from models.instrument_models import Instrument, Derivative
            
            segment = f"{exchange.upper()}_FO"
            types = [option_type] if option_type else ['CE', 'PE']
            
            instruments = db.query(Instrument.instrument_key).join(
                Derivative, Instrument.instrument_key == Derivative.instrument_key
            ).filter(
                Instrument.segment == segment,
                Instrument.instrument_type.in_(types),
                Derivative.underlying_symbol == underlying.upper()
            ).all()
            
            return [i[0] for i in instruments if i[0]]
            
        except Exception as e:
            logger.error(f"Error getting options by underlying: {e}")
            return []
    
    @staticmethod
    def get_by_strike(
        db: Session,
        underlying: str,
        strike_price: float,
        option_type: Optional[Literal['CE', 'PE']] = None,
        exchange: str = 'NSE'
    ) -> List[str]:
        """
        Get options by strike price.
        
        Args:
            underlying: Underlying symbol
            strike_price: Strike price
            option_type: CE or PE
            exchange: Exchange code
            
        Returns:
            List of instrument keys
        """
        try:
            from models.instrument_models import Instrument, Derivative
            
            segment = f"{exchange.upper()}_FO"
            types = [option_type] if option_type else ['CE', 'PE']
            
            instruments = db.query(Instrument.instrument_key).join(
                Derivative, Instrument.instrument_key == Derivative.instrument_key
            ).filter(
                Instrument.segment == segment,
                Instrument.instrument_type.in_(types),
                Derivative.underlying_symbol == underlying.upper(),
                Derivative.strike_price == strike_price
            ).all()
            
            return [i[0] for i in instruments if i[0]]
            
        except Exception as e:
            logger.error(f"Error getting options by strike: {e}")
            return []
    
    @staticmethod
    def get_option_chain(
        db: Session,
        underlying: str,
        expiry_date: Optional[str] = None,
        exchange: str = 'NSE'
    ) -> Dict[str, List[Dict]]:
        """
        Get option chain for an underlying.
        
        Args:
            underlying: Underlying symbol
            expiry_date: Optional expiry date filter (YYYY-MM-DD)
            exchange: Exchange code
            
        Returns:
            Dict with 'calls' and 'puts' lists
        """
        try:
            from models.instrument_models import Instrument, Derivative
            
            segment = f"{exchange.upper()}_FO"
            
            query = db.query(Instrument, Derivative).join(
                Derivative, Instrument.instrument_key == Derivative.instrument_key
            ).filter(
                Instrument.segment == segment,
                Instrument.instrument_type.in_(['CE', 'PE']),
                Derivative.underlying_symbol == underlying.upper()
            )
            
            # Add expiry filter if provided
            # Note: expiry is in milliseconds
            
            results = query.order_by(Derivative.strike_price).all()
            
            calls = []
            puts = []
            
            for i, d in results:
                option = {
                    'instrument_key': i.instrument_key,
                    'trading_symbol': i.trading_symbol,
                    'strike_price': d.strike_price if d else None,
                    'expiry': d.expiry if d else None,
                    'lot_size': i.lot_size
                }
                
                if i.instrument_type == 'CE':
                    calls.append(option)
                else:
                    puts.append(option)
            
            return {'calls': calls, 'puts': puts}
            
        except Exception as e:
            logger.error(f"Error getting option chain: {e}")
            return {'calls': [], 'puts': []}
    
    @staticmethod
    def get_instruments(
        db: Session,
        underlying: Optional[str] = None,
        option_type: Optional[Literal['CE', 'PE']] = None,
        exchange: Optional[str] = None,
        limit: int = 1000
    ) -> List[Dict[str, Any]]:
        """
        Get full options instrument details.
        """
        try:
            from models.instrument_models import Instrument, Derivative
            
            types = [option_type] if option_type else ['CE', 'PE']
            
            query = db.query(Instrument, Derivative).outerjoin(
                Derivative, Instrument.instrument_key == Derivative.instrument_key
            ).filter(
                Instrument.instrument_type.in_(types)
            )
            
            if exchange:
                segment = f"{exchange.upper()}_FO"
                query = query.filter(Instrument.segment == segment)
            
            if underlying:
                query = query.filter(Derivative.underlying_symbol == underlying.upper())
            
            results = query.limit(limit).all()
            
            return [
                {
                    'instrument_key': i.instrument_key,
                    'trading_symbol': i.trading_symbol,
                    'name': i.name,
                    'exchange': i.exchange,
                    'segment': i.segment,
                    'instrument_type': i.instrument_type,
                    'lot_size': i.lot_size,
                    'tick_size': i.tick_size,
                    'strike_price': d.strike_price if d else None,
                    'expiry': d.expiry if d else None,
                    'underlying_symbol': d.underlying_symbol if d else None
                }
                for i, d in results
            ]
            
        except Exception as e:
            logger.error(f"Error getting options instruments: {e}")
            return []


# Singleton instance
options_helper = OptionsHelper()
