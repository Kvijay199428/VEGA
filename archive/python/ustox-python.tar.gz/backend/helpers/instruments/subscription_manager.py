"""
Instrument Subscription Manager - Manages WebSocket subscriptions by instrument type

Coordinates between instrument helpers and the WebSocket service to subscribe
to different instrument types (equity, futures, options, index, mtf, mis).

This manager:
1. Collects instrument keys from all helpers
2. Combines them for WebSocket subscription
3. Tracks which keys belong to which type for filtering
4. Provides filtered access to cached prices by instrument type
"""

from typing import Dict, List, Set, Optional, Literal, Any
from sqlalchemy.orm import Session
import logging

logger = logging.getLogger(__name__)


class InstrumentSubscriptionManager:
    """
    Manages WebSocket subscriptions for different instrument types.
    
    Collects instrument keys from all helpers and provides them to the
    WebSocket service for subscription. Also tracks which keys belong
    to which type for endpoint filtering.
    """
    
    # Instrument type to segment mapping for filtering
    SEGMENT_MAPPING = {
        'index': ['NSE_INDEX', 'BSE_INDEX', 'MCX_INDEX'],
        'equity': ['NSE_EQ', 'BSE_EQ'],
        'futures': ['NSE_FO', 'BSE_FO', 'MCX_FO'],
        'options': ['NSE_FO', 'BSE_FO'],  # Options also in FO segment
    }
    
    def __init__(self):
        # Track subscriptions by type
        self.subscriptions: Dict[str, Set[str]] = {
            'index': set(),
            'equity': set(),
            'futures': set(),
            'options': set(),
            'mtf': set(),
            'mis': set()
        }
        
        # Cache for instrument key to type mapping
        self.key_to_type: Dict[str, str] = {}
        
        # Subscription modes for each type
        self.default_modes: Dict[str, str] = {
            'index': 'ltpc',
            'equity': 'ltpc',
            'futures': 'ltpc',
            'options': 'option_greeks',
            'mtf': 'ltpc',
            'mis': 'ltpc'
        }
        
        # Limits for each type (Upstox has limits)
        self.limits: Dict[str, int] = {
            'index': 100,      # All indices
            'equity': 500,     # Top equities
            'futures': 200,    # Active futures
            'options': 500,    # Active options
            'mtf': 100,
            'mis': 100
        }
    
    def get_all_instrument_keys(self, db: Session, types: List[str] = None) -> Dict[str, List[str]]:
        """
        Get all instrument keys from all helpers, organized by type.
        
        Args:
            db: Database session
            types: Optional list of types to include.
                   If None, fetches enabled types from SubscriptionSettings.
            
        Returns:
            Dict mapping instrument type to list of keys
        """
        from helpers.instruments.equity import EquityHelper
        from helpers.instruments.index import IndexHelper
        from helpers.instruments.futures import FuturesHelper
        from helpers.instruments.options import OptionsHelper
        from helpers.instruments.mtf import MTFHelper
        from helpers.instruments.mis import MISHelper
        from services.subscription_settings_service import subscription_settings_service
        
        # If types not provided, get enabled types from settings
        if types is None:
            settings = subscription_settings_service.get_settings(db)
            types = []
            if settings.equity_enabled: types.append('equity')
            if settings.index_enabled: types.append('index')
            if settings.futures_enabled: types.append('futures')
            if settings.options_enabled: types.append('options')
            if settings.mtf_enabled: types.append('mtf')
            if settings.mis_enabled: types.append('mis')
            
            logger.info(f"Using enabled subscription types: {types}")
        
        all_keys: Dict[str, List[str]] = {}
        
        try:
            # Index instruments
            if 'index' in types:
                index_keys = IndexHelper.get_all_keys(db)
                if not index_keys:
                    index_keys = IndexHelper.get_popular_keys()
                all_keys['index'] = index_keys[:self.limits['index']]
                logger.info(f"Collected {len(all_keys['index'])} index keys")
            
            # Equity instruments
            if 'equity' in types:
                equity_keys = EquityHelper.get_all_keys(db)
                all_keys['equity'] = equity_keys[:self.limits['equity']]
                logger.info(f"Collected {len(all_keys['equity'])} equity keys")
            
            # Futures instruments
            if 'futures' in types:
                futures_keys = FuturesHelper.get_all_keys(db)
                all_keys['futures'] = futures_keys[:self.limits['futures']]
                logger.info(f"Collected {len(all_keys['futures'])} futures keys")
            
            # Options instruments
            if 'options' in types:
                options_keys = OptionsHelper.get_all_keys(db)
                all_keys['options'] = options_keys[:self.limits['options']]
                logger.info(f"Collected {len(all_keys['options'])} options keys")
            
        except Exception as e:
            logger.error(f"Error collecting instrument keys: {e}")
        
        return all_keys
    
    def get_combined_keys(self, db: Session, types: List[str] = None) -> List[str]:
        """
        Get all instrument keys combined into a single list for WebSocket subscription.
        Also tracks which keys belong to which type.
        
        Args:
            db: Database session
            types: Optional list of types to include
            
        Returns:
            Combined list of all instrument keys
        """
        all_keys_by_type = self.get_all_instrument_keys(db, types)
        
        combined = []
        self.key_to_type.clear()
        
        for inst_type, keys in all_keys_by_type.items():
            self.subscriptions[inst_type] = set(keys)
            for key in keys:
                self.key_to_type[key] = inst_type
            combined.extend(keys)
        
        # Remove duplicates while preserving order
        seen = set()
        unique_keys = []
        for key in combined:
            if key not in seen:
                seen.add(key)
                unique_keys.append(key)
        
        logger.info(f"Combined {len(unique_keys)} unique instrument keys for subscription")
        return unique_keys
    
    def get_keys_by_type(self, instrument_type: str) -> List[str]:
        """Get subscribed keys for a specific instrument type"""
        return list(self.subscriptions.get(instrument_type, set()))
    
    def filter_prices_by_type(
        self, 
        all_prices: Dict[str, Any], 
        instrument_type: str
    ) -> Dict[str, Any]:
        """
        Filter cached prices to only include a specific instrument type.
        
        Args:
            all_prices: All cached prices from WebSocket
            instrument_type: Type to filter (index, equity, futures, options)
            
        Returns:
            Filtered dict with only the requested type
        """
        type_keys = self.subscriptions.get(instrument_type, set())
        
        filtered = {}
        for key, price in all_prices.items():
            if key in type_keys:
                filtered[key] = price
        
        return filtered
    
    def get_type_for_key(self, instrument_key: str) -> Optional[str]:
        """Get the instrument type for a specific key"""
        return self.key_to_type.get(instrument_key)
    
    def get_subscription_summary(self) -> Dict[str, int]:
        """Get summary of subscriptions by type"""
        return {k: len(v) for k, v in self.subscriptions.items()}
    
    def get_index_keys(self, db: Session, exchange: Optional[str] = None) -> List[str]:
        """Get index instrument keys"""
        from helpers.instruments.index import IndexHelper
        if exchange:
            return IndexHelper.get_by_exchange(db, exchange)
        return IndexHelper.get_all_keys(db)
    
    def get_equity_keys(self, db: Session, exchange: Optional[str] = None) -> List[str]:
        """Get equity instrument keys"""
        from helpers.instruments.equity import EquityHelper
        return EquityHelper.get_all_keys(db, exchange)
    
    def get_futures_keys(self, db: Session, underlying: Optional[str] = None, exchange: str = 'NSE') -> List[str]:
        """Get futures instrument keys"""
        from helpers.instruments.futures import FuturesHelper
        if underlying:
            return FuturesHelper.get_by_underlying(db, underlying, exchange)
        return FuturesHelper.get_all_keys(db, exchange)
    
    def get_options_keys(
        self, 
        db: Session, 
        underlying: Optional[str] = None,
        option_type: Optional[Literal['CE', 'PE']] = None,
        exchange: str = 'NSE'
    ) -> List[str]:
        """Get options instrument keys"""
        from helpers.instruments.options import OptionsHelper
        if underlying:
            return OptionsHelper.get_by_underlying(db, underlying, option_type, exchange)
        return OptionsHelper.get_all_keys(db, option_type, exchange)
    
    def clear_all(self):
        """Clear all tracked subscriptions"""
        for key in self.subscriptions:
            self.subscriptions[key].clear()
        self.key_to_type.clear()


# Singleton instance
subscription_manager = InstrumentSubscriptionManager()

