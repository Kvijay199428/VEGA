"""
Index Instrument Helper - Extract index instrument keys for WebSocket subscription
"""

from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
import logging

logger = logging.getLogger(__name__)


class IndexHelper:
    """
    Helper class for extracting index instrument keys.
    
    Index instruments are stored in index_instruments table.
    Segments: NSE_INDEX, BSE_INDEX, MCX_INDEX
    """
    
    # Known index segments
    INDEX_SEGMENTS = ['NSE_INDEX', 'BSE_INDEX', 'MCX_INDEX']
    
    # Popular index instrument keys for quick access
    POPULAR_INDICES = [
        'NSE_INDEX|Nifty 50',
        'NSE_INDEX|Nifty Bank',
        'NSE_INDEX|Nifty IT',
        'NSE_INDEX|Nifty Financial Services',
        'NSE_INDEX|Nifty Midcap 50',
        'NSE_INDEX|Nifty Next 50',
        'BSE_INDEX|SENSEX',
        'BSE_INDEX|SENSEX 50',
    ]
    
    @staticmethod
    def get_all_keys(db: Session) -> List[str]:
        """
        Get all index instrument keys from the database.
        
        Returns:
            List of instrument keys for all indices
        """
        try:
            from models.instrument_models import IndexInstrument
            
            instruments = db.query(IndexInstrument.instrument_key).all()
            
            keys = [i[0] for i in instruments if i[0]]
            logger.info(f"Found {len(keys)} index instruments")
            return keys
            
        except Exception as e:
            logger.error(f"Error getting index keys: {e}")
            return []
    
    @staticmethod
    def get_by_exchange(db: Session, exchange: str) -> List[str]:
        """
        Get index instrument keys for a specific exchange.
        
        Args:
            exchange: Exchange code (NSE, BSE, MCX)
            
        Returns:
            List of instrument keys
        """
        try:
            from models.instrument_models import IndexInstrument
            
            instruments = db.query(IndexInstrument.instrument_key).filter(
                IndexInstrument.exchange == exchange.upper()
            ).all()
            
            return [i[0] for i in instruments if i[0]]
            
        except Exception as e:
            logger.error(f"Error getting {exchange} index keys: {e}")
            return []
    
    @staticmethod
    def get_popular_keys() -> List[str]:
        """Get popular/major index instrument keys"""
        return IndexHelper.POPULAR_INDICES.copy()
    
    @staticmethod
    def get_instruments(db: Session, exchange: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get full index instrument details.
        
        Args:
            exchange: Optional exchange filter
            
        Returns:
            List of instrument dictionaries
        """
        try:
            from models.instrument_models import IndexInstrument
            
            query = db.query(IndexInstrument)
            
            if exchange:
                query = query.filter(IndexInstrument.exchange == exchange.upper())
            
            instruments = query.all()
            
            return [
                {
                    'instrument_key': i.instrument_key,
                    'trading_symbol': i.trading_symbol,
                    'name': i.name,
                    'exchange': i.exchange,
                    'segment': i.segment
                }
                for i in instruments
            ]
            
        except Exception as e:
            logger.error(f"Error getting index instruments: {e}")
            return []


# Singleton instance
index_helper = IndexHelper()
