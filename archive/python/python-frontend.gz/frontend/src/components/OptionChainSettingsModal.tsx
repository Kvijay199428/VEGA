import React, { useState, useEffect } from 'react';
import { X, Settings, Columns, LayoutGrid, Eye, EyeOff, RotateCcw } from 'lucide-react';
import type { OptionChainSettings, ColumnSettings } from '../hooks/useOptionChainSettings';

interface OptionChainSettingsModalProps {
    isOpen: boolean;
    onClose: () => void;
    settings: OptionChainSettings;
    onSave: (settings: OptionChainSettings) => void;
    onReset: () => void;
}

// Column display names
const columnLabels: Record<string, Record<string, string>> = {
    marketData: {
        volume: 'Volume',
        oi: 'Open Interest',
        closePrice: 'Close Price',
        prevOi: 'Previous OI',
        bid: 'Bid',
        bidQty: 'Bid Qty',
        ask: 'Ask',
        askQty: 'Ask Qty',
    },
    greeks: {
        vega: 'Vega',
        theta: 'Theta',
        gamma: 'Gamma',
        delta: 'Delta',
        iv: 'Implied Volatility',
        pop: 'Probability of Profit',
    },
    custom: {
        valuation: 'Valuation (Val)',
        bidAskChart: 'Bid/Ask Chart (B/A)',
    },
};

const categoryLabels: Record<string, string> = {
    marketData: 'Market Data',
    greeks: 'Greeks',
    custom: 'Custom',
};

const OptionChainSettingsModal: React.FC<OptionChainSettingsModalProps> = ({
    isOpen,
    onClose,
    settings,
    onSave,
    onReset,
}) => {
    const [localSettings, setLocalSettings] = useState<OptionChainSettings>(settings);
    const [activeTab, setActiveTab] = useState<'compare' | 'columns'>('columns');

    // Sync local state when modal opens
    useEffect(() => {
        if (isOpen) {
            setLocalSettings(settings);
        }
    }, [isOpen, settings]);

    if (!isOpen) return null;

    const handleColumnToggle = (category: keyof ColumnSettings, column: string) => {
        setLocalSettings(prev => ({
            ...prev,
            columns: {
                ...prev.columns,
                [category]: {
                    ...prev.columns[category],
                    [column]: !(prev.columns[category] as Record<string, boolean>)[column],
                },
            },
        }));
    };

    const handleToggleAllInCategory = (category: keyof ColumnSettings, visible: boolean) => {
        const updatedCategory = Object.fromEntries(
            Object.keys(localSettings.columns[category]).map(key => [key, visible])
        );
        setLocalSettings(prev => ({
            ...prev,
            columns: {
                ...prev.columns,
                [category]: updatedCategory,
            },
        }));
    };

    const handleCompareModeToggle = () => {
        setLocalSettings(prev => ({
            ...prev,
            compareMode: {
                ...prev.compareMode,
                enabled: !prev.compareMode.enabled,
            },
        }));
    };

    const handleLayoutChange = (layout: 'side-by-side' | 'stacked') => {
        setLocalSettings(prev => ({
            ...prev,
            compareMode: {
                ...prev.compareMode,
                layout,
            },
        }));
    };

    const handleSave = () => {
        onSave(localSettings);
        onClose();
    };

    const handleReset = () => {
        onReset();
        onClose();
    };

    const getCategoryVisibleCount = (category: keyof ColumnSettings) => {
        const cat = localSettings.columns[category] as Record<string, boolean>;
        const total = Object.keys(cat).length;
        const visible = Object.values(cat).filter(Boolean).length;
        return { visible, total };
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
            <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col animate-fade-in">
                {/* Header */}
                <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-700">
                    <div className="flex items-center gap-3">
                        <Settings size={20} className="text-primary-600" />
                        <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
                            Option Chain Settings
                        </h2>
                    </div>
                    <button
                        onClick={onClose}
                        className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                        <X size={18} className="text-slate-500" />
                    </button>
                </div>

                {/* Tabs */}
                <div className="flex border-b border-slate-200 dark:border-slate-700">
                    <button
                        onClick={() => setActiveTab('columns')}
                        className={`flex-1 px-4 py-3 text-sm font-medium transition-colors ${activeTab === 'columns'
                                ? 'text-primary-600 border-b-2 border-primary-600 bg-primary-50 dark:bg-primary-900/20'
                                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                            }`}
                    >
                        <Columns size={16} className="inline mr-2" />
                        Column Visibility
                    </button>
                    <button
                        onClick={() => setActiveTab('compare')}
                        className={`flex-1 px-4 py-3 text-sm font-medium transition-colors ${activeTab === 'compare'
                                ? 'text-primary-600 border-b-2 border-primary-600 bg-primary-50 dark:bg-primary-900/20'
                                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                            }`}
                    >
                        <LayoutGrid size={16} className="inline mr-2" />
                        Compare Mode
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-5">
                    {activeTab === 'columns' && (
                        <div className="space-y-5">
                            {(Object.keys(columnLabels) as Array<keyof ColumnSettings>).map((category) => {
                                const { visible, total } = getCategoryVisibleCount(category);
                                const allVisible = visible === total;

                                return (
                                    <div key={category} className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4">
                                        {/* Category Header */}
                                        <div className="flex items-center justify-between mb-3">
                                            <h3 className="font-medium text-slate-900 dark:text-white">
                                                {categoryLabels[category]}
                                            </h3>
                                            <div className="flex items-center gap-2">
                                                <span className="text-xs text-slate-500">
                                                    {visible}/{total} visible
                                                </span>
                                                <button
                                                    onClick={() => handleToggleAllInCategory(category, !allVisible)}
                                                    className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                                                    title={allVisible ? 'Hide all' : 'Show all'}
                                                >
                                                    {allVisible ? (
                                                        <EyeOff size={14} className="text-slate-500" />
                                                    ) : (
                                                        <Eye size={14} className="text-primary-600" />
                                                    )}
                                                </button>
                                            </div>
                                        </div>

                                        {/* Column Toggles */}
                                        <div className="grid grid-cols-2 gap-2">
                                            {Object.entries(columnLabels[category]).map(([key, label]) => {
                                                const isVisible = (localSettings.columns[category] as Record<string, boolean>)[key];
                                                return (
                                                    <label
                                                        key={key}
                                                        className={`flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-colors ${isVisible
                                                                ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300'
                                                                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400'
                                                            }`}
                                                    >
                                                        <input
                                                            type="checkbox"
                                                            checked={isVisible}
                                                            onChange={() => handleColumnToggle(category, key)}
                                                            className="sr-only"
                                                        />
                                                        <div className={`w-4 h-4 rounded border-2 flex items-center justify-center ${isVisible
                                                                ? 'bg-primary-600 border-primary-600'
                                                                : 'border-slate-300 dark:border-slate-600'
                                                            }`}>
                                                            {isVisible && (
                                                                <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                                                </svg>
                                                            )}
                                                        </div>
                                                        <span className="text-sm">{label}</span>
                                                    </label>
                                                );
                                            })}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    )}

                    {activeTab === 'compare' && (
                        <div className="space-y-5">
                            {/* Compare Mode Toggle */}
                            <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <h3 className="font-medium text-slate-900 dark:text-white">
                                            Enable Compare Mode
                                        </h3>
                                        <p className="text-sm text-slate-500 mt-1">
                                            View two option chains side by side
                                        </p>
                                    </div>
                                    <button
                                        onClick={handleCompareModeToggle}
                                        className={`relative w-12 h-6 rounded-full transition-colors ${localSettings.compareMode.enabled
                                                ? 'bg-primary-600'
                                                : 'bg-slate-300 dark:bg-slate-600'
                                            }`}
                                    >
                                        <div
                                            className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${localSettings.compareMode.enabled ? 'translate-x-7' : 'translate-x-1'
                                                }`}
                                        />
                                    </button>
                                </div>
                            </div>

                            {/* Layout Selection */}
                            {localSettings.compareMode.enabled && (
                                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4">
                                    <h3 className="font-medium text-slate-900 dark:text-white mb-3">
                                        Layout Style
                                    </h3>
                                    <div className="grid grid-cols-2 gap-3">
                                        <button
                                            onClick={() => handleLayoutChange('side-by-side')}
                                            className={`p-4 rounded-lg border-2 transition-colors ${localSettings.compareMode.layout === 'side-by-side'
                                                    ? 'border-primary-600 bg-primary-50 dark:bg-primary-900/30'
                                                    : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
                                                }`}
                                        >
                                            <div className="flex gap-1 justify-center mb-2">
                                                <div className="w-8 h-12 bg-slate-300 dark:bg-slate-600 rounded" />
                                                <div className="w-8 h-12 bg-slate-300 dark:bg-slate-600 rounded" />
                                            </div>
                                            <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                                                Side by Side
                                            </span>
                                            <p className="text-xs text-slate-500 mt-1">Best for wide screens</p>
                                        </button>
                                        <button
                                            onClick={() => handleLayoutChange('stacked')}
                                            className={`p-4 rounded-lg border-2 transition-colors ${localSettings.compareMode.layout === 'stacked'
                                                    ? 'border-primary-600 bg-primary-50 dark:bg-primary-900/30'
                                                    : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
                                                }`}
                                        >
                                            <div className="flex flex-col gap-1 items-center mb-2">
                                                <div className="w-14 h-5 bg-slate-300 dark:bg-slate-600 rounded" />
                                                <div className="w-14 h-5 bg-slate-300 dark:bg-slate-600 rounded" />
                                            </div>
                                            <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                                                Stacked
                                            </span>
                                            <p className="text-xs text-slate-500 mt-1">Best for small screens</p>
                                        </button>
                                    </div>
                                </div>
                            )}

                            {/* Info about secondary selection */}
                            {localSettings.compareMode.enabled && (
                                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                                    <p className="text-sm text-blue-700 dark:text-blue-300">
                                        <strong>Tip:</strong> When compare mode is enabled, you'll see a second set of
                                        underlying and expiry selectors to choose what to compare against.
                                    </p>
                                </div>
                            )}
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between px-5 py-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                    <button
                        onClick={handleReset}
                        className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"
                    >
                        <RotateCcw size={14} />
                        Reset to Defaults
                    </button>
                    <div className="flex gap-3">
                        <button
                            onClick={onClose}
                            className="px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={handleSave}
                            className="px-4 py-2 text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 rounded-lg transition-colors"
                        >
                            Save Changes
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default OptionChainSettingsModal;
