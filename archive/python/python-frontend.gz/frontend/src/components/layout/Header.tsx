import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
    Bell,
    Moon,
    Sun,
    Search,
    Wifi,
    WifiOff,
    ChevronDown,
    LogOut,
    Settings as SettingsIcon,
    Menu,
    X,
    LayoutDashboard,
    LineChart,
    ShoppingCart,
    Briefcase,
    Brain,
    Activity,
    Radio,
    GitCompareArrows,
    TrendingUp,
    Key
} from 'lucide-react';
import { useAppDispatch, useAppSelector } from '../../store/hooks';
import { setGlobalSearchQuery, addToast } from '../../store/slices/uiSlice';
import { logout } from '../../store/slices/authSlice';
import { useTheme } from '../../theme';
import api from '../../services/api';
import NotificationsPanel from '../NotificationsPanel';

const navItems = [
    { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/market', icon: LineChart, label: 'Market Data' },
    { path: '/equity-feed', icon: Radio, label: 'Equity Live' },
    { path: '/options', icon: GitCompareArrows, label: 'Options Chain' },
    { path: '/futures', icon: TrendingUp, label: 'Futures' },
    { path: '/trading', icon: ShoppingCart, label: 'Trading' },
];

const analyticsItems = [
    { path: '/strategies', icon: Brain, label: 'Strategies' },
    { path: '/indicators', icon: Activity, label: 'Indicators' },
];

const Header: React.FC = () => {
    const location = useLocation();
    const dispatch = useAppDispatch();
    const { globalSearchQuery, wsConnectionStatus } = useAppSelector(state => state.ui);
    const { theme, setTheme } = useTheme();
    const { user, sessionExpiry, token } = useAppSelector(state => state.auth);
    const [timeRemaining, setTimeRemaining] = useState('');
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const [userDropdownOpen, setUserDropdownOpen] = useState(false);
    const [analyticsDropdownOpen, setAnalyticsDropdownOpen] = useState(false);
    const [notificationsPanelOpen, setNotificationsPanelOpen] = useState(false);

    // Get notifications for unread count
    const notifications = useAppSelector(state => state.ui.notifications);
    const unreadCount = notifications.filter(n => !n.read).length;

    // Token status for remaining APIs button
    const [tokenStatus, setTokenStatus] = useState<{
        missing_count: number;
        all_valid: boolean;
        has_primary: boolean;
    } | null>(null);
    const [isLaunchingLogin, setIsLaunchingLogin] = useState(false);

    // Fetch token status on mount and when user changes
    useEffect(() => {
        if (token) {
            fetchTokenStatus();
        }
    }, [token]);

    const fetchTokenStatus = async () => {
        try {
            const response = await api.get('/v1/auth/upstox/tokens/db-status');
            if (response.data?.status === 'success') {
                setTokenStatus(response.data.data);
            }
        } catch (err) {
            console.error('Failed to fetch token status:', err);
        }
    };

    const handleLaunchRemainingLogin = async () => {
        try {
            setIsLaunchingLogin(true);
            // Start from index 1 to skip PRIMARY (already logged in)
            const response = await api.post('/v1/auth/upstox/launch-remaining-login', {
                start_index: 1
            });
            if (response.data?.status === 'success') {
                // Show success toast notification
                dispatch(addToast({
                    type: 'info',
                    message: '🚀 Login script launched! Please complete the login in the Chrome window that opens.',
                    duration: 8000
                }));
                // Refresh token status after a delay
                setTimeout(fetchTokenStatus, 5000);
            }
        } catch (err: any) {
            dispatch(addToast({
                type: 'error',
                message: err.response?.data?.detail || 'Failed to launch login script',
                duration: 5000
            }));
        } finally {
            setIsLaunchingLogin(false);
        }
    };

    // Calculate session time remaining
    useEffect(() => {
        if (!sessionExpiry) return;

        const updateTimer = () => {
            const now = new Date();
            const expiry = new Date(sessionExpiry);
            const diff = expiry.getTime() - now.getTime();

            if (diff <= 0) {
                setTimeRemaining('Session expired');
                return;
            }

            const hours = Math.floor(diff / (1000 * 60 * 60));
            const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            setTimeRemaining(`${hours}h ${minutes}m`);
        };

        updateTimer();
        const interval = setInterval(updateTimer, 60000);
        return () => clearInterval(interval);
    }, [sessionExpiry]);

    const toggleTheme = () => {
        setTheme(theme === 'dark' ? 'light' : 'dark');
    };

    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        dispatch(setGlobalSearchQuery(e.target.value));
    };

    const handleLogout = () => {
        dispatch(logout());
        setUserDropdownOpen(false);
    };

    return (
        <header className="fixed top-0 left-0 right-0 h-16 bg-surface-50 dark:bg-surface-800 border-b border-slate-200 dark:border-slate-700 z-50">
            <div className="h-full px-4 lg:px-6 flex items-center justify-between gap-4">
                {/* Logo */}
                <Link to="/" className="flex items-center gap-2 flex-shrink-0">
                    <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-primary-700 rounded-lg flex items-center justify-center">
                        <span className="text-white font-bold text-sm">VT</span>
                    </div>
                    <span className="hidden sm:block font-bold text-lg text-slate-900 dark:text-white">Vega Trader</span>
                </Link>

                {/* Desktop Navigation */}
                <nav className="hidden lg:flex items-center gap-1 flex-1 justify-center">
                    {navItems.map((item) => {
                        const isActive = location.pathname === item.path;
                        const Icon = item.icon;

                        return (
                            <Link
                                key={item.path}
                                to={item.path}
                                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${isActive
                                    ? 'bg-primary-600 text-white'
                                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                                    }`}
                                title={item.label}
                            >
                                <Icon size={18} />
                                <span className="hidden xl:inline">{item.label}</span>
                            </Link>
                        );
                    })}

                    {/* Analytics Dropdown */}
                    <div className="relative">
                        <button
                            onClick={() => setAnalyticsDropdownOpen(!analyticsDropdownOpen)}
                            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${analyticsItems.some(item => location.pathname === item.path)
                                ? 'bg-primary-600 text-white'
                                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                                }`}
                        >
                            <Brain size={18} />
                            <span className="hidden xl:inline">Analytics</span>
                            <ChevronDown size={14} className={`hidden xl:block transition-transform ${analyticsDropdownOpen ? 'rotate-180' : ''}`} />
                        </button>

                        {analyticsDropdownOpen && (
                            <>
                                <div
                                    className="fixed inset-0 z-40"
                                    onClick={() => setAnalyticsDropdownOpen(false)}
                                />
                                <div className="absolute left-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-lg shadow-lg border border-slate-200 dark:border-slate-700 py-1 z-50">
                                    {analyticsItems.map((item) => {
                                        const Icon = item.icon;
                                        const isActive = location.pathname === item.path;
                                        return (
                                            <Link
                                                key={item.path}
                                                to={item.path}
                                                onClick={() => setAnalyticsDropdownOpen(false)}
                                                className={`flex items-center gap-2 px-4 py-2 text-sm hover:bg-slate-100 dark:hover:bg-slate-700 ${isActive ? 'text-primary-600 dark:text-primary-400 font-medium' : 'text-slate-700 dark:text-slate-300'
                                                    }`}
                                            >
                                                <Icon size={16} />
                                                <span>{item.label}</span>
                                            </Link>
                                        );
                                    })}
                                </div>
                            </>
                        )}
                    </div>
                </nav>

                {/* Right section */}
                <div className="flex items-center gap-2 lg:gap-4">
                    {/* Search - Hidden on small screens */}
                    <div className="hidden md:flex items-center gap-2 bg-slate-100 dark:bg-slate-700 rounded-lg px-3 py-2 w-48">
                        <Search size={18} className="text-slate-400" />
                        <input
                            type="text"
                            value={globalSearchQuery}
                            onChange={handleSearchChange}
                            placeholder="Search..."
                            className="bg-transparent border-none outline-none text-sm w-full text-slate-700 dark:text-slate-200 placeholder:text-slate-400"
                        />
                    </div>

                    {/* WebSocket Connection Status */}
                    <div className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium ${wsConnectionStatus === 'connected'
                        ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
                        : wsConnectionStatus === 'connecting'
                            ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
                            : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
                        }`}>
                        {wsConnectionStatus === 'connected' ? (
                            <>
                                <Wifi size={14} />
                                <span>Live</span>
                            </>
                        ) : wsConnectionStatus === 'connecting' ? (
                            <>
                                <Wifi size={14} className="animate-pulse" />
                                <span>Connecting</span>
                            </>
                        ) : (
                            <>
                                <WifiOff size={14} />
                                <span>Offline</span>
                            </>
                        )}
                    </div>

                    {/* Session timer */}
                    {timeRemaining && (
                        <div className="hidden lg:flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                            <div className="w-2 h-2 rounded-full bg-profit-500 animate-pulse" />
                            <span>{timeRemaining}</span>
                        </div>
                    )}

                    {/* Login Remaining APIs Button - Shows when user has PRIMARY but not all tokens */}
                    {tokenStatus && tokenStatus.has_primary && !tokenStatus.all_valid && tokenStatus.missing_count > 0 && (
                        <button
                            onClick={handleLaunchRemainingLogin}
                            disabled={isLaunchingLogin}
                            className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 hover:bg-amber-200 dark:hover:bg-amber-900/50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            title="Login remaining API configurations"
                        >
                            <Key size={14} />
                            <span>
                                {isLaunchingLogin ? 'Launching...' : `Login ${tokenStatus.missing_count} APIs`}
                            </span>
                        </button>
                    )}

                    {/* Theme toggle */}
                    <button
                        onClick={toggleTheme}
                        className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400"
                    >
                        {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
                    </button>

                    {/* Notifications */}
                    <div className="relative hidden sm:block">
                        <button
                            onClick={() => setNotificationsPanelOpen(!notificationsPanelOpen)}
                            className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400 relative"
                        >
                            <Bell size={20} />
                            {unreadCount > 0 && (
                                <span className="absolute top-1 right-1 min-w-[8px] h-2 px-1 text-[10px] font-bold text-white bg-loss-500 rounded-full flex items-center justify-center">
                                    {unreadCount > 9 ? '9+' : ''}
                                </span>
                            )}
                        </button>
                        <NotificationsPanel
                            isOpen={notificationsPanelOpen}
                            onClose={() => setNotificationsPanelOpen(false)}
                        />
                    </div>

                    {/* User dropdown */}
                    <div className="relative">
                        <button
                            onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                            className="flex items-center gap-2 p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
                        >
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center">
                                <span className="text-white text-sm font-medium">
                                    {user?.name?.charAt(0) || 'U'}
                                </span>
                            </div>
                            <ChevronDown size={16} className="hidden sm:block text-slate-500" />
                        </button>

                        {/* User Dropdown Menu */}
                        {userDropdownOpen && (
                            <>
                                <div
                                    className="fixed inset-0 z-40"
                                    onClick={() => setUserDropdownOpen(false)}
                                />
                                <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-800 rounded-lg shadow-lg border border-slate-200 dark:border-slate-700 py-2 z-50">
                                    <div className="px-4 py-2 border-b border-slate-200 dark:border-slate-700">
                                        <p className="text-sm font-medium text-slate-900 dark:text-white">
                                            {user?.name || 'User'}
                                        </p>
                                        <p className="text-xs text-slate-500 dark:text-slate-400">
                                            {user?.email || 'user@example.com'}
                                        </p>
                                    </div>
                                    <Link
                                        to="/portfolio"
                                        className="flex items-center gap-2 px-4 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"
                                        onClick={() => setUserDropdownOpen(false)}
                                    >
                                        <Briefcase size={16} />
                                        <span>Portfolio</span>
                                    </Link>
                                    <Link
                                        to="/settings"
                                        className="flex items-center gap-2 px-4 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700"
                                        onClick={() => setUserDropdownOpen(false)}
                                    >
                                        <SettingsIcon size={16} />
                                        <span>Settings</span>
                                    </Link>
                                    <button
                                        onClick={handleLogout}
                                        className="w-full flex items-center gap-2 px-4 py-2 text-sm text-loss-600 dark:text-loss-400 hover:bg-loss-50 dark:hover:bg-loss-900/20"
                                    >
                                        <LogOut size={16} />
                                        <span>Logout</span>
                                    </button>
                                </div>
                            </>
                        )}
                    </div>

                    {/* Mobile menu toggle */}
                    <button
                        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                        className="lg:hidden p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400"
                    >
                        {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
                    </button>
                </div>
            </div>

            {/* Mobile Navigation Menu */}
            {mobileMenuOpen && (
                <div className="lg:hidden absolute top-16 left-0 right-0 bg-surface-50 dark:bg-surface-800 border-b border-slate-200 dark:border-slate-700 shadow-lg">
                    <nav className="p-4 space-y-1">
                        {navItems.map((item) => {
                            const isActive = location.pathname === item.path;
                            const Icon = item.icon;

                            return (
                                <Link
                                    key={item.path}
                                    to={item.path}
                                    onClick={() => setMobileMenuOpen(false)}
                                    className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${isActive
                                        ? 'bg-primary-600 text-white'
                                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                                        }`}
                                >
                                    <Icon size={20} />
                                    <span>{item.label}</span>
                                </Link>
                            );
                        })}
                    </nav>
                </div>
            )}
        </header>
    );
};

export default Header;
