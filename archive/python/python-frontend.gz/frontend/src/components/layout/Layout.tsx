import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from './Header';
import QuickActionsPanel from '../QuickActionsPanel';
import ToastContainer from '../ToastContainer';

const Layout: React.FC = () => {
    return (
        <div className="min-h-screen bg-background">
            <Header />

            <main className="pt-16 pb-16">
                <div className="h-[calc(100vh-8rem)] overflow-y-auto p-4">
                    <Outlet />
                </div>
            </main>

            <QuickActionsPanel />
            <ToastContainer />
        </div>
    );
};

export default Layout;
