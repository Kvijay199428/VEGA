/**
 * Charts Components Library
 * 
 * This directory contains all chart-related components for the VEGA TRADER application.
 * Components may use recharts (https://recharts.org/) or custom CSS-based visualizations.
 * 
 * Available Components:
 * - BidAskBar: Horizontal stacked bar chart for visualizing bid/ask quantities (CSS-based)
 */

export { default as BidAskBar } from './BidAskBar';
