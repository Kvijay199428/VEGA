import React from 'react';

interface BidAskBarProps {
    bidQty: number;
    askQty: number;
    /**
     * Color theme - 'call' for green/red (bullish context), 'put' for red/green (bearish context)
     */
    variant?: 'call' | 'put';
    /**
     * Width of the chart container
     */
    width?: number;
    /**
     * Height of the chart container
     */
    height?: number;
    /**
     * Show quantity labels
     */
    showLabels?: boolean;
}

/**
 * BidAskBar - A compact horizontal bar chart for visualizing bid/ask quantities
 * 
 * Used in options chain tables to show the relative strength of bid vs ask orders.
 * The bar shows bid quantity on the left and ask quantity on the right,
 * with proportional widths based on their relative sizes.
 */
const BidAskBar: React.FC<BidAskBarProps> = ({
    bidQty,
    askQty,
    variant = 'call',
    width = 80,
    height = 24,
    showLabels = false,
}) => {
    const total = bidQty + askQty;

    // Avoid division by zero
    if (total === 0) {
        return (
            <div
                className="flex items-center justify-center bg-slate-100 dark:bg-slate-800 rounded"
                style={{ width, height }}
            >
                <span className="text-[10px] text-slate-400">-</span>
            </div>
        );
    }

    const bidPercent = (bidQty / total) * 100;
    const askPercent = (askQty / total) * 100;

    // Determine colors based on variant
    const colors = variant === 'call'
        ? { bid: '#22c55e', ask: '#ef4444' }  // Green/Red for calls
        : { bid: '#ef4444', ask: '#22c55e' }; // Red/Green for puts

    // Format large numbers
    const formatQty = (qty: number): string => {
        if (qty >= 1000000) return `${(qty / 1000000).toFixed(1)}M`;
        if (qty >= 1000) return `${(qty / 1000).toFixed(1)}K`;
        return qty.toString();
    };

    // Determine which side is dominant
    const isDominantBid = bidQty > askQty;

    return (
        <div
            className="flex flex-col items-center gap-0.5"
            style={{ width }}
            title={`Bid: ${formatQty(bidQty)} (${bidPercent.toFixed(1)}%) | Ask: ${formatQty(askQty)} (${askPercent.toFixed(1)}%)`}
        >
            {/* Stacked bar representation */}
            <div
                className="flex w-full rounded overflow-hidden"
                style={{ height: showLabels ? height - 10 : height }}
            >
                {/* Bid bar */}
                <div
                    className="transition-all duration-300"
                    style={{
                        width: `${bidPercent}%`,
                        backgroundColor: colors.bid,
                        minWidth: bidQty > 0 ? '2px' : '0',
                        opacity: isDominantBid ? 1 : 0.6,
                    }}
                />
                {/* Ask bar */}
                <div
                    className="transition-all duration-300"
                    style={{
                        width: `${askPercent}%`,
                        backgroundColor: colors.ask,
                        minWidth: askQty > 0 ? '2px' : '0',
                        opacity: !isDominantBid ? 1 : 0.6,
                    }}
                />
            </div>

            {/* Optional labels */}
            {showLabels && (
                <div className="flex justify-between w-full text-[8px]">
                    <span style={{ color: colors.bid }}>{formatQty(bidQty)}</span>
                    <span style={{ color: colors.ask }}>{formatQty(askQty)}</span>
                </div>
            )}
        </div>
    );
};

export default BidAskBar;
