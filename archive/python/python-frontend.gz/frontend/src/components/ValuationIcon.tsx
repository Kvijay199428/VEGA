/**
 * ValuationIcon Component
 * 
 * Displays animated icon indicating if an option is overvalued, undervalued, or fairly valued
 * based on Black-Scholes theoretical pricing.
 * 
 * Features:
 * - Animated icons: ▲ (Overvalued), ▼ (Undervalued), — (Fair)
 * - Pulse glow + blink animations for mispriced options
 * - Detailed tooltip on hover (fixed positioning to avoid clipping)
 * - Confidence level indicator
 */

import React, { useState, useRef, useCallback } from 'react';
import './ValuationIcon.css';

interface TooltipDetails {
    fair_price_formatted: string;
    market_price_formatted: string;
    mispricing_pct_formatted: string;
    confidence_level: 'High' | 'Medium' | 'Low';
}

interface ValuationIconProps {
    status: 'Overvalued' | 'Undervalued' | 'Fair';
    fairPrice: number;
    marketPrice: number;
    mispricing_pct: number;
    action: 'SELL' | 'BUY' | 'HOLD';
    blinking: boolean;
    strikePrice?: number;  // Optional, not used internally but passed from parent
    confidence: 'High' | 'Medium' | 'Low';
    tooltipDetails?: TooltipDetails;
}

interface TooltipPosition {
    top: number;
    left: number;
    showBelow: boolean;
}

const ValuationIcon: React.FC<ValuationIconProps> = ({
    status,
    fairPrice,
    marketPrice,
    mispricing_pct,
    action,
    blinking,
    confidence,
    tooltipDetails
}) => {
    const [isHovering, setIsHovering] = useState(false);
    const [tooltipPos, setTooltipPos] = useState<TooltipPosition>({ top: 0, left: 0, showBelow: false });
    const cellRef = useRef<HTMLDivElement>(null);

    // Icon mapping
    const iconMap = {
        Overvalued: '▲',
        Undervalued: '▼',
        Fair: '—'
    };

    const iconClassName = `val-icon ${status.toLowerCase()} ${blinking ? 'blinking' : ''}`;

    // Format numbers for display (fallback if tooltipDetails not provided)
    const formatPrice = (price: number) => `₹${price.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
    const formatPct = (pct: number) => `${pct > 0 ? '+' : ''}${pct.toFixed(1)}%`;

    // Calculate tooltip position using fixed positioning
    const handleMouseEnter = useCallback(() => {
        if (cellRef.current) {
            const rect = cellRef.current.getBoundingClientRect();
            const tooltipHeight = 120; // Approximate tooltip height
            const spaceAbove = rect.top;
            const showBelow = spaceAbove < tooltipHeight + 10;

            setTooltipPos({
                top: showBelow ? rect.bottom + 8 : rect.top - tooltipHeight - 8,
                left: rect.left + rect.width / 2,
                showBelow
            });
        }
        setIsHovering(true);
    }, []);

    const handleMouseLeave = useCallback(() => {
        setIsHovering(false);
    }, []);

    return (
        <div
            ref={cellRef}
            className="valuation-cell"
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
        >
            <div className={iconClassName} data-status={status.toLowerCase()}>
                <span className="icon-content">{iconMap[status]}</span>
            </div>

            {isHovering && (
                <div
                    className={`tooltip ${tooltipPos.showBelow ? 'tooltip-below' : ''}`}
                    style={{
                        top: `${tooltipPos.top}px`,
                        left: `${tooltipPos.left}px`,
                        transform: 'translateX(-50%)'
                    }}
                >
                    <div className="tooltip-status">{status.toUpperCase()}</div>
                    <div className="tooltip-details">
                        <strong>Fair Price:</strong> {tooltipDetails?.fair_price_formatted || formatPrice(fairPrice)}<br />
                        <strong>Market Price:</strong> {tooltipDetails?.market_price_formatted || formatPrice(marketPrice)}<br />
                        <strong>Mispricing:</strong> {formatPct(mispricing_pct)}<br />
                        <div className="tooltip-action">Action: {action}</div>
                        <small className="tooltip-confidence">Confidence: {confidence}</small>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ValuationIcon;
