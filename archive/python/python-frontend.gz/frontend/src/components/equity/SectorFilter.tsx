/**
 * Sector Filter Component
 * Horizontal scrollable sector pills with scroll buttons
 */

import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import type { Sector } from '../../types/equity';

interface SectorFilterProps {
    sectors: Sector[];
    selectedSector: string | null;
    onSectorClick: (sectorKey: string) => void;
    onClearFilter: () => void;
    isLoading: boolean;
}

const SectorFilter: React.FC<SectorFilterProps> = ({
    sectors,
    selectedSector,
    onSectorClick,
    onClearFilter,
    isLoading
}) => {
    const scrollRef = useRef<HTMLDivElement>(null);

    const scrollLeft = () => {
        if (scrollRef.current) {
            scrollRef.current.scrollBy({ left: -200, behavior: 'smooth' });
        }
    };

    const scrollRight = () => {
        if (scrollRef.current) {
            scrollRef.current.scrollBy({ left: 200, behavior: 'smooth' });
        }
    };

    const handleWheel = (e: React.WheelEvent) => {
        if (scrollRef.current && e.deltaY !== 0) {
            scrollRef.current.scrollBy({ left: e.deltaY, behavior: 'auto' });
        }
    };

    return (
        <div className="flex-1 min-w-0">
            <div className="relative group">
                {/* Left Scroll Button */}
                <div className="absolute left-0 top-0 bottom-2 z-10 flex items-center bg-gradient-to-r from-slate-50 via-slate-50/80 to-transparent dark:from-surface-950 dark:via-surface-950/80 dark:to-transparent pr-6 pl-0">
                    <button
                        onClick={scrollLeft}
                        className="p-1 hover:text-primary-400 text-slate-500 dark:text-slate-400 transition-colors bg-slate-100/50 dark:bg-surface-900/50 rounded-full hover:bg-slate-200 dark:hover:bg-surface-800"
                        title="Scroll Left"
                    >
                        <ChevronLeft size={16} />
                    </button>
                </div>

                <div
                    ref={scrollRef}
                    onWheel={handleWheel}
                    className="flex items-center gap-2 overflow-x-auto pb-2 px-8 scrollbar-hide select-none"
                    style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                >
                    {/* All button */}
                    <button
                        onClick={onClearFilter}
                        className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${!selectedSector
                            ? 'bg-primary-600 text-white shadow-lg shadow-primary-600/30'
                            : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600'
                            }`}
                    >
                        All
                    </button>

                    {/* Sector pills */}
                    {isLoading ? (
                        <div className="flex items-center gap-2 px-3">
                            <Loader2 size={14} className="animate-spin text-slate-400" />
                            <span className="text-xs text-slate-400">Loading sectors...</span>
                        </div>
                    ) : (
                        sectors.map(sector => (
                            <button
                                key={sector.key}
                                onClick={() => onSectorClick(sector.key)}
                                className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-all whitespace-nowrap ${selectedSector === sector.key
                                    ? 'bg-primary-600 text-white shadow-lg shadow-primary-600/30'
                                    : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600'
                                    }`}
                            >
                                {sector.name.replace('Nifty ', '')}
                            </button>
                        ))
                    )}
                </div>

                {/* Right Scroll Button */}
                <div className="absolute right-0 top-0 bottom-2 z-10 flex items-center bg-gradient-to-l from-slate-50 via-slate-50/80 to-transparent dark:from-surface-950 dark:via-surface-950/80 dark:to-transparent pl-6 pr-0 justify-end">
                    <button
                        onClick={scrollRight}
                        className="p-1 hover:text-primary-400 text-slate-500 dark:text-slate-400 transition-colors bg-slate-100/50 dark:bg-surface-900/50 rounded-full hover:bg-slate-200 dark:hover:bg-surface-800"
                        title="Scroll Right"
                    >
                        <ChevronRight size={16} />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default SectorFilter;
