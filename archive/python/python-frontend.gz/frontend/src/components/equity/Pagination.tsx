/**
 * Pagination Component
 * Reusable pagination footer for data tables
 */

import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface PaginationProps {
    currentPage: number;
    totalPages: number;
    totalCount: number;
    pageSize: number;
    onPrevPage: () => void;
    onNextPage: () => void;
    isConnected?: boolean;
}

const Pagination: React.FC<PaginationProps> = ({
    currentPage,
    totalPages,
    totalCount,
    pageSize,
    onPrevPage,
    onNextPage,
    isConnected = false
}) => {
    const startItem = currentPage * pageSize + 1;
    const endItem = Math.min((currentPage + 1) * pageSize, totalCount);

    return (
        <div className="px-4 py-2.5 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-surface-900 flex justify-between items-center flex-shrink-0">
            <span className="text-xs text-slate-600 dark:text-slate-500">
                {startItem} - {endItem} of {totalCount}
            </span>

            <div className="flex items-center gap-2">
                <button
                    onClick={onPrevPage}
                    disabled={currentPage === 0}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-colors ${currentPage === 0
                            ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed'
                            : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600'
                        }`}
                >
                    <ChevronLeft size={14} />
                    Prev
                </button>

                <span className="text-xs text-slate-500 dark:text-slate-400 px-2">
                    {currentPage + 1} / {totalPages || 1}
                </span>

                <button
                    onClick={onNextPage}
                    disabled={currentPage >= totalPages - 1}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-colors ${currentPage >= totalPages - 1
                            ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed'
                            : 'bg-primary-600 text-white hover:bg-primary-700'
                        }`}
                >
                    Next
                    <ChevronRight size={14} />
                </button>
            </div>

            {isConnected && (
                <span className="text-xs text-green-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                    Live
                </span>
            )}
        </div>
    );
};

export default Pagination;
