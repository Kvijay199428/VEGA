/**
 * Equity Table Row Component
 * Individual row for equity instrument with live price data
 */

import React from 'react';
import { TrendingUp, TrendingDown, Star } from 'lucide-react';
import type { EquityInstrument, LivePrice } from '../../types/equity';
import { formatPrice, formatChange } from '../../utils/formatters';

interface EquityTableRowProps {
    instrument: EquityInstrument;
    price?: LivePrice;
    index: number;
}

const EquityTableRow: React.FC<EquityTableRowProps> = ({
    instrument,
    price,
    index
}) => {
    const hasPrice = !!price;
    const change = price?.change || 0;

    return (
        <tr
            key={instrument.instrument_key || index}
            className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
        >
            <td className="px-2 py-2">
                <button className="text-slate-400 dark:text-slate-500 hover:text-amber-400 transition-colors">
                    <Star size={14} />
                </button>
            </td>
            <td className="px-2 py-2 font-semibold text-slate-900 dark:text-white text-sm truncate">
                {instrument.trading_symbol}
            </td>
            <td className="px-2 py-2 text-slate-500 dark:text-slate-400 text-xs truncate" title={instrument.name}>
                {instrument.name}
            </td>
            <td className={`px-2 py-2 text-right font-medium text-sm tabular-nums ${hasPrice ? (change >= 0 ? 'text-green-400' : 'text-red-400') : 'text-slate-400'
                }`}>
                {hasPrice ? formatPrice(price.ltp) : '-'}
            </td>
            <td className="px-2 py-2 text-right text-slate-500 dark:text-slate-400 text-sm tabular-nums">
                {hasPrice ? formatPrice(price.cp) : '-'}
            </td>
            <td className={`px-2 py-2 text-right font-medium text-sm ${change >= 0 ? 'text-green-400' : 'text-red-400'
                }`}>
                {hasPrice ? (
                    <span className="inline-flex items-center justify-end gap-1">
                        {change >= 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                        <span className="tabular-nums">{formatChange(change)}</span>
                    </span>
                ) : '-'}
            </td>
            <td className="px-2 py-2 text-center">
                {hasPrice ? (
                    <span className="inline-flex items-center gap-1 text-xs text-green-400">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                        Live
                    </span>
                ) : (
                    <span className="text-slate-500 text-xs">-</span>
                )}
            </td>
        </tr>
    );
};

export default EquityTableRow;
