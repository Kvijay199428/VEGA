import React from 'react';
import { TrendingUp, Brain, LayoutGrid, Activity } from 'lucide-react';

const QuickActionsPanel: React.FC = () => {
    // Open option chain in a new browser popup window (maximized)
    const openOptionChainPopup = () => {
        const popup = window.open(
            '/options-popup',
            'OptionChainPopup',
            'popup=yes,menubar=no,toolbar=no,location=no,status=no,resizable=yes,scrollbars=no'
        );
        // Maximize the popup window
        if (popup) {
            popup.moveTo(0, 0);
            popup.resizeTo(window.screen.availWidth, window.screen.availHeight);
        }
    };

    // Open equity feed in a new browser popup window (maximized)
    const openEquityPopup = () => {
        const popup = window.open(
            '/equity-popup',
            'EquityFeedPopup',
            'popup=yes,menubar=no,toolbar=no,location=no,status=no,resizable=yes,scrollbars=no'
        );
        // Maximize the popup window
        if (popup) {
            popup.moveTo(0, 0);
            popup.resizeTo(window.screen.availWidth, window.screen.availHeight);
        }
    };

    return (
        <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 shadow-lg z-40">
            <div className="max-w-7xl mx-auto px-4 py-3">
                <div className="flex items-center justify-center gap-4">
                    <button className="btn btn-primary flex items-center gap-2 px-6 py-3">
                        <TrendingUp size={20} />
                        <span>New Order</span>
                    </button>
                    <button className="btn btn-secondary flex items-center gap-2 px-6 py-3">
                        <Brain size={20} />
                        <span>AI Strategy</span>
                    </button>
                    <button
                        onClick={openEquityPopup}
                        className="btn flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 text-white hover:from-emerald-700 hover:to-teal-700 transition-all"
                    >
                        <Activity size={20} />
                        <span>Equity Feed</span>
                    </button>
                    <button
                        onClick={openOptionChainPopup}
                        className="btn flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:from-purple-700 hover:to-indigo-700 transition-all"
                    >
                        <LayoutGrid size={20} />
                        <span>Option Chain</span>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default QuickActionsPanel;
