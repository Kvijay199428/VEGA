/**
 * HoverDropdown - Reusable hover dropdown component
 * Opens on hover with smooth animations
 */

import React, { useState, useRef } from 'react';
import { ChevronDown, Check } from 'lucide-react';

export interface HoverDropdownOption<T> {
    label: string;
    value: T;
    icon?: React.ReactNode;
}

export interface HoverDropdownProps<T> {
    label: string | React.ReactNode;
    options: HoverDropdownOption<T>[];
    selectedValue: T;
    onSelect: (value: T) => void;
    className?: string;
    buttonClass?: string;
    dropdownClass?: string;
    align?: 'left' | 'right';
}

function HoverDropdown<T>({
    label,
    options,
    selectedValue,
    onSelect,
    className = '',
    buttonClass = '',
    dropdownClass = '',
    align = 'left'
}: HoverDropdownProps<T>) {
    const [isOpen, setIsOpen] = useState(false);
    const timeoutRef = useRef<NodeJS.Timeout | null>(null);

    const handleMouseEnter = () => {
        if (timeoutRef.current) clearTimeout(timeoutRef.current);
        setIsOpen(true);
    };

    const handleMouseLeave = () => {
        timeoutRef.current = setTimeout(() => {
            setIsOpen(false);
        }, 150);
    };

    return (
        <div
            className={`relative ${className}`}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
        >
            <button
                className={`flex items-center gap-1.5 transition-colors ${buttonClass}`}
            >
                {label}
                <ChevronDown size={14} className={`transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
            </button>

            {isOpen && (
                <div className={`absolute top-full ${align === 'right' ? 'right-0' : 'left-0'} mt-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xl z-50 overflow-hidden min-w-[140px] animate-in fade-in zoom-in-95 duration-100 ${dropdownClass}`}>
                    <div className="py-1">
                        {options.map((option) => (
                            <button
                                key={String(option.value)}
                                onClick={() => {
                                    onSelect(option.value);
                                    setIsOpen(false);
                                }}
                                className={`w-full text-left px-3 py-2 text-sm flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors ${selectedValue === option.value
                                    ? 'text-primary-600 dark:text-primary-400 font-medium bg-primary-50 dark:bg-primary-900/10'
                                    : 'text-slate-700 dark:text-slate-300'
                                    }`}
                            >
                                <span className="flex items-center gap-2">
                                    {option.icon}
                                    {option.label}
                                </span>
                                {selectedValue === option.value && <Check size={14} />}
                            </button>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

export default HoverDropdown;
