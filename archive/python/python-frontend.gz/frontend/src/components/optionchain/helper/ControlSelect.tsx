/**
 * ControlSelect - Reusable styled select component
 * For underlying and expiry selections with consistent styling
 */

import React from 'react';
import { ChevronDown } from 'lucide-react';

export interface ControlSelectOption {
    value: string;
    label: string;
}

export interface ControlSelectProps {
    value: string;
    onChange: (value: string) => void;
    options: ControlSelectOption[];
    className?: string;
    isPopup?: boolean;
    compact?: boolean;
    title?: string;
}

const ControlSelect: React.FC<ControlSelectProps> = ({
    value,
    onChange,
    options,
    className = '',
    isPopup = false,
    compact = false,
    title
}) => {
    const baseClass = `appearance-none cursor-pointer border-none outline-none font-medium rounded-md`;

    const sizeClass = compact
        ? '!py-1 !px-2 !pr-6 w-28'
        : isPopup
            ? 'bg-slate-800 text-white text-xs px-2 py-1.5 pr-6'
            : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-200 text-xs px-3 py-1.5 pr-7';

    const bgClass = compact
        ? isPopup
            ? 'bg-slate-800 text-white text-xs'
            : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-200 text-xs'
        : '';

    const selectClass = `${baseClass} ${sizeClass} ${bgClass} ${className}`;
    const iconSize = compact ? 12 : 14;
    const iconPosition = compact ? 'right-1.5' : 'right-2';

    return (
        <div className="relative">
            <select
                value={value}
                onChange={(e) => onChange(e.target.value)}
                className={selectClass}
                title={title}
            >
                {options.map((option) => (
                    <option key={option.value} value={option.value}>
                        {option.label}
                    </option>
                ))}
            </select>
            <ChevronDown
                size={iconSize}
                className={`absolute ${iconPosition} top-1/2 -translate-y-1/2 pointer-events-none text-slate-400`}
            />
        </div>
    );
};

export default ControlSelect;
