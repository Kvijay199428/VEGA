import React from 'react';
import type { ColumnSettings } from '../../hooks/useOptionChainSettings';

interface OptionChainSkeletonRowProps {
    columns: ColumnSettings;
    isPopup?: boolean;
    isCompact?: boolean;
}

const OptionChainSkeletonRow: React.FC<OptionChainSkeletonRowProps> = ({
    columns,
    isPopup = false,
    isCompact = false
}) => {
    const { marketData, greeks, custom } = columns;
    const px = isCompact || isPopup ? 'px-1 py-1' : 'px-2 py-2';

    // Skeleton cell style
    const skeletonCell = `${px} text-center`;
    const skeletonContent = "h-4 bg-slate-200 dark:bg-slate-800 rounded animate-pulse w-full";
    const skeletonSmall = "h-4 bg-slate-200 dark:bg-slate-800 rounded animate-pulse w-2/3 ml-auto";
    const skeletonChart = "h-3 bg-slate-200 dark:bg-slate-800 rounded animate-pulse w-full";

    return (
        <tr className="border-b border-slate-100 dark:border-slate-800">
            {greeks.delta && <td className={skeletonCell}><div className={skeletonSmall}></div></td>}
            {greeks.gamma && <td className={skeletonCell}><div className={skeletonSmall}></div></td>}
            {greeks.theta && <td className={skeletonCell}><div className={skeletonSmall}></div></td>}
            {greeks.vega && <td className={skeletonCell}><div className={skeletonSmall}></div></td>}
            {marketData.bid && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            {marketData.bidQty && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            {custom.bidAskChart && <td className={skeletonCell}><div className={skeletonChart}></div></td>}
            {marketData.ask && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            {marketData.askQty && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            {greeks.iv && <td className={skeletonCell}><div className={skeletonSmall}></div></td>}
            {greeks.pop && <td className={skeletonCell}><div className={skeletonSmall}></div></td>}
            {custom.valuation && <td className={skeletonCell}><div className="h-4 w-4 rounded-full bg-slate-200 dark:bg-slate-800 animate-pulse mx-auto"></div></td>}
            {marketData.oi && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            {marketData.prevOi && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            <td className={skeletonCell}><div className={skeletonSmall}></div></td>
            {marketData.closePrice && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            <td className={skeletonCell}><div className={skeletonContent}></div></td>
            {marketData.volume && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            <td className={`${isPopup ? 'px-2 py-1' : 'px-4 py-2'} text-center`} style={{ minWidth: '220px' }}>
                <div className="h-5 w-12 bg-slate-300 dark:bg-slate-700 rounded animate-pulse mx-auto"></div>
            </td>
            {marketData.volume && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            <td className={skeletonCell}><div className={skeletonContent}></div></td>
            {marketData.closePrice && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            <td className={skeletonCell}><div className={skeletonSmall}></div></td>
            {marketData.prevOi && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            {marketData.oi && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            {custom.valuation && <td className={skeletonCell}><div className="h-4 w-4 rounded-full bg-slate-200 dark:bg-slate-800 animate-pulse mx-auto"></div></td>}
            {greeks.pop && <td className={skeletonCell}><div className={skeletonSmall}></div></td>}
            {greeks.iv && <td className={skeletonCell}><div className={skeletonSmall}></div></td>}
            {marketData.askQty && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            {marketData.ask && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            {custom.bidAskChart && <td className={skeletonCell}><div className={skeletonChart}></div></td>}
            {marketData.bid && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            {marketData.bidQty && <td className={skeletonCell}><div className={skeletonContent}></div></td>}
            {greeks.vega && <td className={skeletonCell}><div className={skeletonSmall}></div></td>}
            {greeks.theta && <td className={skeletonCell}><div className={skeletonSmall}></div></td>}
            {greeks.gamma && <td className={skeletonCell}><div className={skeletonSmall}></div></td>}
            {greeks.delta && <td className={skeletonCell}><div className={skeletonSmall}></div></td>}
        </tr>
    );
};

export default OptionChainSkeletonRow;
