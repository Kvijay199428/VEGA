/**
 * Option Chain Row
 * Individual table row component for call/put option data
 */

import React from 'react';
import type { OptionChainRow as OptionChainRowData, StrikeInfo } from '../../types/optionChain';
import type { ColumnSettings } from '../../hooks/useOptionChainSettings';
import { formatNumber, formatLargeNumber } from '../../utils/formatters';
import { getCallSideClass, getPutSideClass, calculateChange } from '../../utils/optionChainHelpers';
import ValuationIcon from '../ValuationIcon';
import { BidAskBar } from '../charts';

interface OptionChainRowProps {
    row: OptionChainRowData;
    index: number;
    spotPrice: number;
    atmStrike: number;
    getStrikeInfo: (strike: number) => StrikeInfo;
    columns: ColumnSettings;
    isPopup?: boolean;
    idPrefix?: string;
    isCompact?: boolean;
}

const OptionChainRow: React.FC<OptionChainRowProps> = ({
    row,
    index,
    spotPrice,
    atmStrike,
    getStrikeInfo,
    columns,
    isPopup = false,
    idPrefix = 'strike-row',
    isCompact = false
}) => {
    const callLtp = row.call?.ltp || 0;
    const callClose = row.call?.close_price || 0;
    const callChange = calculateChange(callLtp, callClose);

    const putLtp = row.put?.ltp || 0;
    const putClose = row.put?.close_price || 0;
    const putChange = calculateChange(putLtp, putClose);

    const { marketData, greeks, custom } = columns;

    const callClass = getCallSideClass(row.strike_price, spotPrice, atmStrike);
    const putClass = getPutSideClass(row.strike_price, spotPrice, atmStrike);
    const strikeInfo = getStrikeInfo(row.strike_price);

    const getChangeColor = (val: number): string => {
        if (val > 0) return 'text-green-600 dark:text-green-400';
        if (val < 0) return 'text-red-600 dark:text-red-400';
        return '';
    };
    // Compact mode adjustments
    const px = isCompact || isPopup ? 'px-1 py-1' : 'px-2 py-2';
    const barSize = isCompact || isPopup ? { width: 40, height: 12 } : { width: 60, height: 16 };
    const greekDecimals = isCompact || isPopup ? [2, 2, 1, 2] : [4, 5, 2, 4]; // Reduced decimals for compact mode


    return (
        <tr
            id={`${idPrefix}-${index}`}
            className={`border-b ${isPopup ? 'border-slate-800 hover:bg-slate-800/50' : 'border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/30'}`}
        >
            {/* Call Side - Greeks first */}
            {greeks.delta && (
                <td className={`${px} text-right text-slate-600 dark:text-slate-400 ${callClass}`}>
                    {formatNumber(row.call?.delta || 0, greekDecimals[0])}
                </td>
            )}
            {greeks.gamma && (
                <td className={`${px} text-right text-slate-600 dark:text-slate-400 ${callClass}`}>
                    {formatNumber(row.call?.gamma || 0, greekDecimals[1])}
                </td>
            )}
            {greeks.theta && (
                <td className={`${px} text-right text-slate-600 dark:text-slate-400 ${callClass}`}>
                    {formatNumber(row.call?.theta || 0, greekDecimals[2])}
                </td>
            )}
            {greeks.vega && (
                <td className={`${px} text-right text-slate-600 dark:text-slate-400 ${callClass}`}>
                    {formatNumber(row.call?.vega || 0, greekDecimals[3])}
                </td>
            )}

            {/* Call Side - Bid/Ask */}
            {marketData.bid && (
                <td className={`${px} text-right text-green-600 dark:text-green-500 ${callClass}`}>
                    {formatNumber(row.call?.bid_price || 0)}
                </td>
            )}
            {marketData.bidQty && (
                <td className={`${px} text-right text-green-500 dark:text-green-400 ${callClass}`}>
                    {formatLargeNumber(row.call?.bid_qty || 0)}
                </td>
            )}
            {custom.bidAskChart && (
                <td className={`${isPopup ? 'px-0.5 py-1' : 'px-1 py-2'} ${callClass}`}>
                    <BidAskBar
                        bidQty={row.call?.bid_qty || 0}
                        askQty={row.call?.ask_qty || 0}
                        variant="call"
                        width={barSize.width}
                        height={barSize.height}
                    />
                </td>
            )}
            {marketData.ask && (
                <td className={`${px} text-right text-red-600 dark:text-red-500 ${callClass}`}>
                    {formatNumber(row.call?.ask_price || 0)}
                </td>
            )}
            {marketData.askQty && (
                <td className={`${px} text-right text-red-500 dark:text-red-400 ${callClass}`}>
                    {formatLargeNumber(row.call?.ask_qty || 0)}
                </td>
            )}

            {/* Call Side - Market Data */}
            {greeks.iv && (
                <td className={`${px} text-right text-slate-600 dark:text-slate-400 ${callClass}`}>
                    {formatNumber(row.call?.iv || 0, 1)}%
                </td>
            )}
            {greeks.pop && (
                <td className={`${px} text-right text-slate-600 dark:text-slate-400 ${callClass}`}>
                    {formatNumber(row.call?.pop || 0, 1)}%
                </td>
            )}
            {/* Call Valuation Icon */}
            {custom.valuation && (
                <td className={`${px} text-center valuation-td ${callClass}`}>
                    {row.call?.valuation && (
                        <ValuationIcon
                            status={row.call.valuation.status}
                            fairPrice={row.call.valuation.fair_price}
                            marketPrice={row.call.valuation.market_price}
                            mispricing_pct={row.call.valuation.mispricing_pct}
                            action={row.call.valuation.action}
                            blinking={row.call.valuation.blinking}
                            strikePrice={row.strike_price}
                            confidence={row.call.valuation.tooltip_details.confidence_level}
                            tooltipDetails={row.call.valuation.tooltip_details}
                        />
                    )}
                </td>
            )}
            {marketData.oi && (
                <td className={`${px} text-right text-green-600 dark:text-green-400 ${callClass}`}>
                    {formatLargeNumber(row.call?.oi || 0)}
                </td>
            )}
            {marketData.prevOi && (
                <td className={`${px} text-right text-slate-500 ${callClass}`}>
                    {formatLargeNumber(row.call?.prev_oi || 0)}
                </td>
            )}
            <td className={`${px} text-right font-medium ${getChangeColor(callChange)} ${callClass}`}>
                {callChange >= 0 ? '+' : ''}{formatNumber(callChange, 1)}%
            </td>
            {marketData.closePrice && (
                <td className={`${px} text-right text-slate-500 ${callClass}`}>
                    {formatNumber(callClose)}
                </td>
            )}
            <td className={`${px} text-right font-semibold text-green-600 dark:text-green-400 ${callClass}`}>
                {formatNumber(callLtp)}
            </td>
            {marketData.volume && (
                <td className={`${px} text-right text-slate-500 ${callClass}`}>
                    {formatLargeNumber(row.call?.volume || 0)}
                </td>
            )}

            {/* Strike Price */}
            <td className={`${isPopup ? 'px-2 py-1' : 'px-4 py-2'} text-center font-bold ${strikeInfo.isATM
                ? 'bg-amber-200 dark:bg-amber-800/50'
                : isPopup ? 'bg-slate-900' : 'bg-slate-100 dark:bg-slate-900'
                } text-slate-900 dark:text-white`} style={{ minWidth: '220px' }}>
                <div className="flex flex-col items-center">
                    {row.strike_price}
                    {strikeInfo.isATM && (
                        <span className={`${isPopup ? 'text-[9px] ml-1' : 'text-[10px] px-2 rounded mt-0.5'} font-semibold text-amber-700 dark:text-amber-300 ${!isPopup && 'bg-amber-100 dark:bg-amber-900/50'}`}>
                            ATM
                        </span>
                    )}
                </div>
            </td>

            {/* Put Side - Market Data (mirror order) */}
            {marketData.volume && (
                <td className={`${px} text-left text-slate-500 ${putClass}`}>
                    {formatLargeNumber(row.put?.volume || 0)}
                </td>
            )}
            <td className={`${px} text-left font-semibold text-red-600 dark:text-red-400 ${putClass}`}>
                {formatNumber(putLtp)}
            </td>
            {marketData.closePrice && (
                <td className={`${px} text-left text-slate-500 ${putClass}`}>
                    {formatNumber(putClose)}
                </td>
            )}
            <td className={`${px} text-left font-medium ${getChangeColor(putChange)} ${putClass}`}>
                {putChange >= 0 ? '+' : ''}{formatNumber(putChange, 1)}%
            </td>
            {marketData.prevOi && (
                <td className={`${px} text-left text-slate-500 ${putClass}`}>
                    {formatLargeNumber(row.put?.prev_oi || 0)}
                </td>
            )}
            {marketData.oi && (
                <td className={`${px} text-left text-red-600 dark:text-red-400 ${putClass}`}>
                    {formatLargeNumber(row.put?.oi || 0)}
                </td>
            )}
            {/* Put Valuation Icon */}
            {custom.valuation && (
                <td className={`${px} text-center valuation-td ${putClass}`}>
                    {row.put?.valuation && (
                        <ValuationIcon
                            status={row.put.valuation.status}
                            fairPrice={row.put.valuation.fair_price}
                            marketPrice={row.put.valuation.market_price}
                            mispricing_pct={row.put.valuation.mispricing_pct}
                            action={row.put.valuation.action}
                            blinking={row.put.valuation.blinking}
                            strikePrice={row.strike_price}
                            confidence={row.put.valuation.tooltip_details.confidence_level}
                            tooltipDetails={row.put.valuation.tooltip_details}
                        />
                    )}
                </td>
            )}
            {greeks.pop && (
                <td className={`${px} text-left text-slate-600 dark:text-slate-400 ${putClass}`}>
                    {formatNumber(row.put?.pop || 0, 1)}%
                </td>
            )}
            {greeks.iv && (
                <td className={`${px} text-left text-slate-600 dark:text-slate-400 ${putClass}`}>
                    {formatNumber(row.put?.iv || 0, 1)}%
                </td>
            )}

            {/* Put Side - Bid/Ask */}
            {marketData.askQty && (
                <td className={`${px} text-left text-red-500 dark:text-red-400 ${putClass}`}>
                    {formatLargeNumber(row.put?.ask_qty || 0)}
                </td>
            )}
            {marketData.ask && (
                <td className={`${px} text-left text-red-600 dark:text-red-500 ${putClass}`}>
                    {formatNumber(row.put?.ask_price || 0)}
                </td>
            )}
            {custom.bidAskChart && (
                <td className={`${isPopup ? 'px-0.5 py-1' : 'px-1 py-2'} ${putClass}`}>
                    <BidAskBar
                        bidQty={row.put?.bid_qty || 0}
                        askQty={row.put?.ask_qty || 0}
                        variant="put"
                        width={barSize.width}
                        height={barSize.height}
                    />
                </td>
            )}
            {marketData.bid && (
                <td className={`${px} text-left text-green-600 dark:text-green-500 ${putClass}`}>
                    {formatNumber(row.put?.bid_price || 0)}
                </td>
            )}
            {marketData.bidQty && (
                <td className={`${px} text-left text-green-500 dark:text-green-400 ${putClass}`}>
                    {formatLargeNumber(row.put?.bid_qty || 0)}
                </td>
            )}

            {/* Put Side - Greeks */}
            {greeks.vega && (
                <td className={`${px} text-left text-slate-600 dark:text-slate-400 ${putClass}`}>
                    {formatNumber(row.put?.vega || 0, greekDecimals[3])}
                </td>
            )}
            {greeks.theta && (
                <td className={`${px} text-left text-slate-600 dark:text-slate-400 ${putClass}`}>
                    {formatNumber(row.put?.theta || 0, greekDecimals[2])}
                </td>
            )}
            {greeks.gamma && (
                <td className={`${px} text-left text-slate-600 dark:text-slate-400 ${putClass}`}>
                    {formatNumber(row.put?.gamma || 0, greekDecimals[1])}
                </td>
            )}
            {greeks.delta && (
                <td className={`${px} text-left text-slate-600 dark:text-slate-400 ${putClass}`}>
                    {formatNumber(row.put?.delta || 0, greekDecimals[0])}
                </td>
            )}
        </tr>
    );
};

// Memoize the row component to prevent unnecessary re-renders
export default React.memo(OptionChainRow);
