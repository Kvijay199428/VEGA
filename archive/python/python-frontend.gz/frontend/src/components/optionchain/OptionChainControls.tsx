/**
 * Option Chain Controls
 * Header component with compact controls using hover dropdowns
 */

import React from 'react';
import {
    Wifi,
    WifiOff,
    Settings,
    LayoutGrid,
    RefreshCw,
    ExternalLink
} from 'lucide-react';
import type { Underlying, OptionSegment, Exchange } from '../../types/optionChain';
import { HoverDropdown, ControlSelect } from './helper';

interface OptionChainControlsProps {
    // Segment & Exchange
    segment: OptionSegment;
    exchange: Exchange;
    onSegmentChange: (segment: OptionSegment) => void;
    onExchangeChange: (exchange: Exchange) => void;

    // Underlying selection
    underlyings: Underlying[];
    selectedUnderlying: string;
    onUnderlyingChange: (underlying: string) => void;

    // Expiry selection
    expiries: string[];
    selectedExpiry: string;
    onExpiryChange: (expiry: string) => void;

    // Connection status
    isConnected: boolean;
    isLive: boolean;

    // Compare mode
    compareMode: boolean;
    compareLayout?: 'side-by-side' | 'stacked';
    onLayoutChange?: (layout: 'side-by-side' | 'stacked') => void;

    // Actions
    onOpenSettings: () => void;
    onRefresh: () => void;
    isLoading: boolean;

    // Popup mode (optional)
    isPopup?: boolean;
    onOpenPopup?: () => void;

    // Secondary Chain Props (for Compare Mode)
    secondarySegment?: OptionSegment;
    secondaryExchange?: Exchange;
    onSecondarySegmentChange?: (segment: OptionSegment) => void;
    onSecondaryExchangeChange?: (exchange: Exchange) => void;
    secondaryUnderlyings?: Underlying[];
    secondarySelectedUnderlying?: string;
    onSecondaryUnderlyingChange?: (underlying: string) => void;
    secondaryExpiries?: string[];
    secondarySelectedExpiry?: string;
    onSecondaryExpiryChange?: (expiry: string) => void;
}


const OptionChainControls: React.FC<OptionChainControlsProps> = ({
    segment,
    exchange,
    onSegmentChange,
    onExchangeChange,
    underlyings,
    selectedUnderlying,
    onUnderlyingChange,
    expiries,
    selectedExpiry,
    onExpiryChange,
    isConnected,
    isLive,
    compareMode,
    compareLayout = 'side-by-side',
    onLayoutChange,
    onOpenSettings,
    onRefresh,
    isLoading,
    isPopup = false,
    onOpenPopup,
    // Secondary props
    secondarySegment = 'index' as OptionSegment,
    secondaryExchange = 'NSE' as Exchange,
    onSecondarySegmentChange,
    onSecondaryExchangeChange,
    secondaryUnderlyings = [],
    secondarySelectedUnderlying = '',
    onSecondaryUnderlyingChange,
    secondaryExpiries = [],
    secondarySelectedExpiry = '',
    onSecondaryExpiryChange,
}) => {
    // Styles
    const containerClass = isPopup
        ? 'flex items-center justify-between px-3 py-1.5 bg-slate-900 border-b border-slate-700 flex-shrink-0'
        : 'card flex-shrink-0 !p-2 !py-2.5'; // More compact card padding

    // Common drop-down button style
    const dropdownBtnClass = `px-3 py-1.5 text-xs rounded-md font-medium ${isPopup
        ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
        }`;

    return (
        <div className={containerClass}>
            <div className="flex items-center gap-3 w-full">

                {/* --- LEFT SECTION: Status & Info --- */}
                <div className="flex items-center gap-2 pr-3 border-r border-slate-200 dark:border-slate-700 mr-1">
                    {/* Live Status */}
                    <div className={`flex items-center gap-1.5 px-2 py-1 rounded-md ${isLive
                        ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400'
                        : isConnected
                            ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                        }`}>
                        {isConnected ? (
                            <Wifi size={14} className={isLive ? 'animate-pulse' : ''} />
                        ) : (
                            <WifiOff size={14} />
                        )}
                        {!isPopup && (
                            <span className="text-xs font-bold tracking-wide">
                                {isLive ? 'LIVE' : isConnected ? 'CONN' : 'OFF'}
                            </span>
                        )}
                    </div>
                </div>


                {/* --- MIDDLE SECTION: Selectors --- */}
                <div className="flex items-center gap-2 flex-wrap flex-1">

                    {/* Segment Dropdown */}
                    <HoverDropdown<OptionSegment>
                        label={segment === 'index' ? 'Index Options' : 'Equity Options'}
                        selectedValue={segment}
                        onSelect={onSegmentChange}
                        buttonClass={dropdownBtnClass}
                        options={[
                            { label: 'Index Options', value: 'index' },
                            { label: 'Equity Options', value: 'equity' }
                        ]}
                    />

                    {/* Exchange Dropdown */}
                    <HoverDropdown<Exchange>
                        label={exchange}
                        selectedValue={exchange}
                        onSelect={onExchangeChange}
                        buttonClass={dropdownBtnClass}
                        options={[
                            { label: 'NSE', value: 'NSE' },
                            { label: 'BSE', value: 'BSE' }
                        ]}
                    />

                    {/* Primary Underlying */}
                    <ControlSelect
                        value={selectedUnderlying}
                        onChange={onUnderlyingChange}
                        options={underlyings.map((u) => ({
                            value: u.instrument_key,
                            label: u.name
                        }))}
                        isPopup={isPopup}
                        title="Primary Underlying"
                    />

                    {/* Primary Expiry */}
                    <ControlSelect
                        value={selectedExpiry}
                        onChange={onExpiryChange}
                        options={expiries.map((exp) => ({
                            value: exp,
                            label: new Date(exp).toLocaleDateString('en-IN', {
                                day: '2-digit',
                                month: 'short',
                                year: 'numeric'
                            })
                        }))}
                        isPopup={isPopup}
                        title="Primary Expiry"
                    />
                </div>


                {/* --- RIGHT SECTION: Compare & Tools --- */}
                <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-700">

                    <div className="flex items-center gap-2">
                        {/* Compare Mode Dropdown */}
                        {/* Compare Mode Control (Only visible when enabled) */}
                        {compareMode && (
                            <HoverDropdown<string>
                                label={
                                    <span className="flex items-center gap-1.5 text-primary-600 dark:text-primary-400">
                                        <LayoutGrid size={16} />
                                        <span className="hidden xl:inline">Compare</span>
                                    </span>
                                }
                                selectedValue={compareLayout || 'side-by-side'}
                                onSelect={(val) => {
                                    // Only switch layouts, never disable compare mode
                                    if (onLayoutChange && (val === 'side-by-side' || val === 'stacked')) {
                                        onLayoutChange(val as 'side-by-side' | 'stacked');
                                    }
                                }}
                                buttonClass={`${dropdownBtnClass} !bg-primary-50 dark:!bg-primary-900/20 ring-1 ring-primary-500/20`}
                                align="right"
                                options={[
                                    { label: 'Side-by-Side', value: 'side-by-side', icon: <LayoutGrid size={14} className="text-primary-500" /> },
                                    { label: 'Stacked View', value: 'stacked', icon: <LayoutGrid size={14} className="text-primary-500" /> }
                                ]}
                            />
                        )}

                        {/* Secondary Controls (Visible if Compare Mode is ON) */}
                        {compareMode && (
                            <div className="flex items-center gap-2 animate-in slide-in-from-right-4 fade-in duration-200">
                                {/* Secondary Segment - Using HoverDropdown like primary */}
                                <HoverDropdown<OptionSegment>
                                    label={secondarySegment === 'index' ? 'Index Options' : 'Equity Options'}
                                    selectedValue={secondarySegment}
                                    onSelect={(val) => onSecondarySegmentChange?.(val)}
                                    buttonClass={dropdownBtnClass}
                                    options={[
                                        { label: 'Index Options', value: 'index' },
                                        { label: 'Equity Options', value: 'equity' }
                                    ]}
                                />

                                {/* Secondary Exchange - Using HoverDropdown like primary */}
                                <HoverDropdown<Exchange>
                                    label={secondaryExchange}
                                    selectedValue={secondaryExchange}
                                    onSelect={(val) => onSecondaryExchangeChange?.(val)}
                                    buttonClass={dropdownBtnClass}
                                    options={[
                                        { label: 'NSE', value: 'NSE' },
                                        { label: 'BSE', value: 'BSE' }
                                    ]}
                                />

                                {/* Secondary Underlying - Using ControlSelect */}
                                <ControlSelect
                                    value={secondarySelectedUnderlying}
                                    onChange={(val) => onSecondaryUnderlyingChange?.(val)}
                                    options={secondaryUnderlyings.map((u) => ({
                                        value: u.instrument_key,
                                        label: u.name
                                    }))}
                                    isPopup={isPopup}
                                    title="Secondary Underlying"
                                />

                                {/* Secondary Expiry - Using ControlSelect */}
                                <ControlSelect
                                    value={secondarySelectedExpiry}
                                    onChange={(val) => onSecondaryExpiryChange?.(val)}
                                    options={secondaryExpiries.map((exp) => ({
                                        value: exp,
                                        label: new Date(exp).toLocaleDateString('en-IN', {
                                            day: '2-digit',
                                            month: 'short',
                                            year: 'numeric'
                                        })
                                    }))}
                                    isPopup={isPopup}
                                    title="Secondary Expiry"
                                />
                            </div>
                        )}
                    </div>

                    <div className="w-px h-6 bg-slate-200 dark:bg-slate-700 mx-1"></div>

                    {/* Settings */}
                    <button
                        onClick={onOpenSettings}
                        className={`${isPopup ? 'p-1.5' : 'p-1.5'} text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors`}
                        title="Settings"
                    >
                        <Settings size={18} />
                    </button>

                    {/* Refresh */}
                    <button
                        onClick={onRefresh}
                        disabled={isLoading}
                        className={`${isPopup ? 'p-1.5' : 'p-1.5'} text-slate-500 hover:text-primary-600 dark:hover:text-primary-400 rounded-md hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-colors pointer-events-auto`}
                        title="Refresh Data"
                    >
                        <RefreshCw size={18} className={isLoading ? 'animate-spin' : ''} />
                    </button>

                    {/* Popup Toggle (Only on main page) */}
                    {!isPopup && onOpenPopup && (
                        <button
                            onClick={onOpenPopup}
                            className="p-1.5 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                            title="Open in Popup"
                        >
                            <ExternalLink size={18} />
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default OptionChainControls;
