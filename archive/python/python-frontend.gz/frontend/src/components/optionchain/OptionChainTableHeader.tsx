/**
 * Option Chain Table Header
 * Reusable table header component with CALLS/PUTS labels, totals row, and column headers
 */

import React from 'react';
import type { BidAskTotals } from '../../types/optionChain';
import type { ColumnSettings } from '../../hooks/useOptionChainSettings';
import { formatLargeNumber } from '../../utils/formatters';

interface OptionChainTableHeaderProps {
    callTotals: BidAskTotals;
    putTotals: BidAskTotals;
    columns: ColumnSettings;
    isPopup?: boolean;
    isCompact?: boolean;
    spotPrice?: number;
    pcr?: number;
    instrument?: string;
    expiry?: string;
}

const OptionChainTableHeader: React.FC<OptionChainTableHeaderProps> = ({
    callTotals,
    putTotals,
    columns,
    isPopup = false,
    isCompact = false,
    spotPrice,
    pcr,
    instrument,
    expiry
}) => {
    const bgClass = isPopup ? 'bg-slate-800' : 'bg-slate-100 dark:bg-slate-800';
    const strikeBgClass = isPopup ? 'bg-slate-900' : 'bg-slate-200 dark:bg-slate-900';
    const borderClass = isPopup ? 'border-slate-700' : 'border-slate-200 dark:border-slate-700';
    const textClass = isPopup ? 'text-slate-400' : 'text-slate-600 dark:text-slate-400';

    // Compact mode adjustments
    const cellPx = isCompact || isPopup ? 'px-1' : 'px-2';
    const cellPy = isCompact || isPopup ? 'py-1' : 'py-2';
    // Font sizes - totals row is larger than column headers
    const totalsRowFontSize = isCompact || isPopup ? 'text-[14px]' : 'text-xs';
    const columnHeadersFontSize = isCompact || isPopup ? 'text-[11px]' : 'text-xs';

    // Destructure visibility settings
    const { marketData, greeks, custom } = columns;

    // Calculate visibility counts for spans
    const greeksCount = [
        greeks.delta,
        greeks.gamma,
        greeks.theta,
        greeks.vega
    ].filter(Boolean).length;

    const bidAskCount = [
        marketData.bid,
        marketData.bidQty,
        custom.bidAskChart,
        marketData.ask,
        marketData.askQty
    ].filter(Boolean).length;

    const marketDataCount = [
        greeks.iv,
        greeks.pop,
        custom.valuation,
        marketData.oi,
        marketData.prevOi,
        true, // Chg% (always visible)
        marketData.closePrice,
        true, // LTP (always visible)
        marketData.volume
    ].filter(Boolean).length;

    const callColSpan = greeksCount + bidAskCount + marketDataCount;
    const putColSpan = callColSpan;

    // Spacers for the totals row
    const emptyBeforeBidAsk = greeksCount;
    const bidAskColSpan = bidAskCount;
    const emptyAfterBidAsk = marketDataCount;

    return (
        <thead className="sticky top-0 z-20">
            {/* Main Header Row */}
            <tr className={bgClass}>
                {/* CALLS Header with Spot Price on right */}
                <th colSpan={callColSpan} className={`px-4 py-2 border-b ${borderClass} ${bgClass}`}>
                    <div className="flex items-center justify-between">
                        <div className="flex-1"></div>
                        <span className="text-green-600 dark:text-green-400 font-semibold">CALLS</span>
                        <div className="flex-1 flex justify-end">
                            {spotPrice !== undefined && spotPrice > 0 && (
                                <div className="flex items-center gap-1.5 whitespace-nowrap">
                                    <span className="text-xs text-slate-400 dark:text-slate-500 uppercase font-semibold">Spot:</span>
                                    <span className={`text-sm font-bold ${isPopup ? 'text-primary-400' : 'text-primary-600 dark:text-primary-400'}`}>
                                        {spotPrice.toLocaleString('en-IN')}
                                    </span>
                                </div>
                            )}
                        </div>
                    </div>
                </th>
                <th className={`px-4 py-1 ${strikeBgClass} border-b ${borderClass}`}>
                    {/* Strike column header is empty */}
                </th>
                {/* PUTS Header with PCR on left */}
                <th colSpan={putColSpan} className={`px-4 py-2 border-b ${borderClass} ${bgClass}`}>
                    <div className="flex items-center justify-between">
                        <div className="flex-1 flex justify-start">
                            {pcr !== undefined && pcr > 0 && (
                                <div className="flex items-center gap-1.5 whitespace-nowrap">
                                    <span className="text-xs text-slate-400 dark:text-slate-500 uppercase font-semibold">PCR:</span>
                                    <span className={`text-sm font-bold ${pcr > 1 ? 'text-green-600 dark:text-green-400' :
                                        pcr < 0.7 ? 'text-red-500 dark:text-red-400' :
                                            'text-slate-700 dark:text-slate-300'
                                        }`}>
                                        {pcr.toFixed(2)}
                                    </span>
                                </div>
                            )}
                        </div>
                        <span className="text-red-600 dark:text-red-400 font-semibold">PUTS</span>
                        <div className="flex-1"></div>
                    </div>
                </th>
            </tr>

            {/* Totals Row - positioned above Bid/Ask columns */}
            <tr className={`${bgClass} ${totalsRowFontSize}`}>
                {isCompact ? (
                    // Compact Mode: Span entire Call side
                    <th colSpan={callColSpan} className={`${cellPx} ${cellPy} border-b ${borderClass} ${bgClass}`}>
                        <div className="flex items-center justify-between whitespace-nowrap">
                            {/* Bid/Ask on left */}
                            <div className="flex justify-center gap-2">
                                <span className="text-green-600 dark:text-green-400" title="Total Bid Value (Total Bid Quantity)">Bid: {formatLargeNumber(callTotals.bid)} ({formatLargeNumber(callTotals.bid_qty)})</span>
                                <span className="text-slate-400">|</span>
                                <span className="text-red-600 dark:text-red-400" title="Total Ask Value (Total Ask Quantity)">Ask: {formatLargeNumber(callTotals.ask)} ({formatLargeNumber(callTotals.ask_qty)})</span>
                            </div>
                            {/* Instrument on right */}
                            {instrument && (
                                <span className={`font-semibold ${isPopup ? 'text-slate-300' : 'text-slate-700 dark:text-slate-300'}`}>
                                    {instrument}
                                </span>
                            )}
                        </div>
                    </th>
                ) : (
                    // Normal Mode: Split into sections
                    <>
                        {emptyBeforeBidAsk > 0 && <th colSpan={emptyBeforeBidAsk} className={`border-b ${borderClass} ${bgClass}`}></th>}
                        {bidAskColSpan > 0 && (
                            <th colSpan={bidAskColSpan} className={`${cellPx} ${cellPy} text-center border-b ${borderClass} ${bgClass}`}>
                                <div className="flex justify-center gap-2 whitespace-nowrap">
                                    <span className="text-green-600 dark:text-green-400" title="Total Bid Value (Total Bid Quantity)">Bid: {formatLargeNumber(callTotals.bid)} ({formatLargeNumber(callTotals.bid_qty)})</span>
                                    <span className="text-slate-400">|</span>
                                    <span className="text-red-600 dark:text-red-400" title="Total Ask Value (Total Ask Quantity)">Ask: {formatLargeNumber(callTotals.ask)} ({formatLargeNumber(callTotals.ask_qty)})</span>
                                </div>
                            </th>
                        )}
                        {emptyAfterBidAsk > 0 && (
                            <th colSpan={emptyAfterBidAsk} className={`${cellPx} ${cellPy} border-b ${borderClass} ${bgClass}`}>
                                {/* Instrument only on right of Bid/Ask */}
                                {instrument && (
                                    <div className="flex items-center justify-end whitespace-nowrap">
                                        <span className={`font-semibold ${isPopup ? 'text-slate-300' : 'text-slate-700 dark:text-slate-300'}`}>
                                            {instrument}
                                        </span>
                                    </div>
                                )}
                            </th>
                        )}
                    </>
                )}

                {/* Strike */}
                <th className={`px-4 py-1 ${strikeBgClass} border-b ${borderClass}`}></th>

                {isCompact ? (
                    // Compact Mode: Span entire Put side
                    <th colSpan={putColSpan} className={`${cellPx} ${cellPy} border-b ${borderClass} ${bgClass}`}>
                        <div className="flex items-center justify-between whitespace-nowrap">
                            {/* Expiry on left */}
                            {expiry && (
                                <span className={`${isPopup ? 'text-slate-400' : 'text-slate-500 dark:text-slate-400'}`}>
                                    {expiry}
                                </span>
                            )}
                            {/* Bid/Ask on right */}
                            <div className="flex justify-center gap-2">
                                <span className="text-red-600 dark:text-red-400" title="Total Ask Value (Total Ask Quantity)">Ask: {formatLargeNumber(putTotals.ask)} ({formatLargeNumber(putTotals.ask_qty)})</span>
                                <span className="text-slate-400">|</span>
                                <span className="text-green-600 dark:text-green-400" title="Total Bid Value (Total Bid Quantity)">Bid: {formatLargeNumber(putTotals.bid)} ({formatLargeNumber(putTotals.bid_qty)})</span>
                            </div>
                        </div>
                    </th>
                ) : (
                    // Normal Mode: Split into sections
                    <>
                        {emptyAfterBidAsk > 0 && (
                            <th colSpan={emptyAfterBidAsk} className={`${cellPx} ${cellPy} border-b ${borderClass} ${bgClass}`}>
                                {/* Expiry only on left of Bid/Ask */}
                                {expiry && (
                                    <div className="flex items-center justify-start whitespace-nowrap">
                                        <span className={`${isPopup ? 'text-slate-400' : 'text-slate-500 dark:text-slate-400'}`}>
                                            {expiry}
                                        </span>
                                    </div>
                                )}
                            </th>
                        )}
                        {bidAskColSpan > 0 && (
                            <th colSpan={bidAskColSpan} className={`${cellPx} ${cellPy} text-center border-b ${borderClass} ${bgClass}`}>
                                <div className="flex justify-center gap-2 whitespace-nowrap">
                                    <span className="text-red-600 dark:text-red-400" title="Total Ask Value (Total Ask Quantity)">Ask: {formatLargeNumber(putTotals.ask)} ({formatLargeNumber(putTotals.ask_qty)})</span>
                                    <span className="text-slate-400">|</span>
                                    <span className="text-green-600 dark:text-green-400" title="Total Bid Value (Total Bid Quantity)">Bid: {formatLargeNumber(putTotals.bid)} ({formatLargeNumber(putTotals.bid_qty)})</span>
                                </div>
                            </th>
                        )}
                        {emptyBeforeBidAsk > 0 && <th colSpan={emptyBeforeBidAsk} className={`border-b ${borderClass} ${bgClass}`}></th>}
                    </>
                )}
            </tr>

            {/* Column Headers Row */}
            <tr className={`${bgClass} ${columnHeadersFontSize} ${textClass}`}>
                {/* Call Headers - Greeks first */}
                {greeks.delta && <th className={`${cellPx} ${cellPy} text-right ${bgClass}`}>Delta</th>}
                {greeks.gamma && <th className={`${cellPx} ${cellPy} text-right ${bgClass}`}>Gamma</th>}
                {greeks.theta && <th className={`${cellPx} ${cellPy} text-right ${bgClass}`}>Theta</th>}
                {greeks.vega && <th className={`${cellPx} ${cellPy} text-right ${bgClass}`}>Vega</th>}
                {/* Call Headers - Bid/Ask */}
                {marketData.bid && <th className={`${cellPx} ${cellPy} text-right font-semibold text-green-600 dark:text-green-400 ${bgClass}`}>Bid</th>}
                {marketData.bidQty && <th className={`${cellPx} ${cellPy} text-right font-semibold text-green-600 dark:text-green-400 ${bgClass}`}>Bid Qty</th>}
                {custom.bidAskChart && <th className={`${cellPx} ${cellPy} text-center font-semibold ${bgClass}`} title="Bid/Ask Chart">B/A</th>}
                {marketData.ask && <th className={`${cellPx} ${cellPy} text-right font-semibold text-red-600 dark:text-red-400 ${bgClass}`}>Ask</th>}
                {marketData.askQty && <th className={`${cellPx} ${cellPy} text-right font-semibold text-red-600 dark:text-red-400 ${bgClass}`}>Ask Qty</th>}
                {/* Call Headers - Market Data */}
                {greeks.iv && <th className={`${cellPx} ${cellPy} text-right ${bgClass}`}>IV</th>}
                {greeks.pop && <th className={`${cellPx} ${cellPy} text-right ${bgClass}`} title="Probability of Profit">PoP</th>}
                {custom.valuation && <th className={`${cellPx} ${cellPy} text-center ${bgClass}`} title="Valuation">Val</th>}
                {marketData.oi && <th className={`${cellPx} ${cellPy} text-right ${bgClass}`}>OI</th>}
                {marketData.prevOi && <th className={`${cellPx} ${cellPy} text-right ${bgClass}`}>Prev OI</th>}
                <th className={`${cellPx} ${cellPy} text-right ${bgClass}`}>Chg%</th>
                {marketData.closePrice && <th className={`${cellPx} ${cellPy} text-right ${bgClass}`}>Close</th>}
                <th className={`${cellPx} ${cellPy} text-right font-semibold ${bgClass}`}>LTP</th>
                {marketData.volume && <th className={`${cellPx} ${cellPy} text-right ${bgClass}`}>Vol</th>}
                {/* Strike */}
                <th className={`px-4 ${cellPy} text-center font-bold ${strikeBgClass}`}>STRIKE</th>
                {/* Put Headers - Market Data (mirror) */}
                {marketData.volume && <th className={`${cellPx} ${cellPy} text-left ${bgClass}`}>Vol</th>}
                <th className={`${cellPx} ${cellPy} text-left font-semibold ${bgClass}`}>LTP</th>
                {marketData.closePrice && <th className={`${cellPx} ${cellPy} text-left ${bgClass}`}>Close</th>}
                <th className={`${cellPx} ${cellPy} text-left ${bgClass}`}>Chg%</th>
                {marketData.prevOi && <th className={`${cellPx} ${cellPy} text-left ${bgClass}`}>Prev OI</th>}
                {marketData.oi && <th className={`${cellPx} ${cellPy} text-left ${bgClass}`}>OI</th>}
                {custom.valuation && <th className={`${cellPx} ${cellPy} text-center ${bgClass}`} title="Valuation">Val</th>}
                {greeks.pop && <th className={`${cellPx} ${cellPy} text-left ${bgClass}`} title="Probability of Profit">PoP</th>}
                {greeks.iv && <th className={`${cellPx} ${cellPy} text-left ${bgClass}`}>IV</th>}
                {/* Put Headers - Bid/Ask */}
                {marketData.askQty && <th className={`${cellPx} ${cellPy} text-left font-semibold text-red-600 dark:text-red-400 ${bgClass}`}>Ask Qty</th>}
                {marketData.ask && <th className={`${cellPx} ${cellPy} text-left font-semibold text-red-600 dark:text-red-400 ${bgClass}`}>Ask</th>}
                {custom.bidAskChart && <th className={`${cellPx} ${cellPy} text-center font-semibold ${bgClass}`} title="Bid/Ask Chart">B/A</th>}
                {marketData.bid && <th className={`${cellPx} ${cellPy} text-left font-semibold text-green-600 dark:text-green-400 ${bgClass}`}>Bid</th>}
                {marketData.bidQty && <th className={`${cellPx} ${cellPy} text-left font-semibold text-green-600 dark:text-green-400 ${bgClass}`}>Bid Qty</th>}
                {/* Put Headers - Greeks */}
                {greeks.vega && <th className={`${cellPx} ${cellPy} text-left ${bgClass}`}>Vega</th>}
                {greeks.theta && <th className={`${cellPx} ${cellPy} text-left ${bgClass}`}>Theta</th>}
                {greeks.gamma && <th className={`${cellPx} ${cellPy} text-left ${bgClass}`}>Gamma</th>}
                {greeks.delta && <th className={`${cellPx} ${cellPy} text-left ${bgClass}`}>Delta</th>}
            </tr>
        </thead>
    );
};

export default OptionChainTableHeader;
