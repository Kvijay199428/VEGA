import React, { useEffect } from 'react';
import { X, AlertCircle, CheckCircle, Info, AlertTriangle } from 'lucide-react';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { removeToast } from '../store/slices/uiSlice';

const ToastContainer: React.FC = () => {
    const dispatch = useAppDispatch();
    const toasts = useAppSelector(state => state.ui.toasts);

    const getIcon = (type: 'info' | 'success' | 'warning' | 'error') => {
        switch (type) {
            case 'success':
                return <CheckCircle size={20} />;
            case 'warning':
                return <AlertTriangle size={20} />;
            case 'error':
                return <AlertCircle size={20} />;
            default:
                return <Info size={20} />;
        }
    };

    const getStyles = (type: 'info' | 'success' | 'warning' | 'error') => {
        switch (type) {
            case 'success':
                return 'bg-profit-50 dark:bg-profit-900/20 text-profit-700 dark:text-profit-400 border-profit-200 dark:border-profit-800';
            case 'warning':
                return 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-800';
            case 'error':
                return 'bg-loss-50 dark:bg-loss-900/20 text-loss-700 dark:text-loss-400 border-loss-200 dark:border-loss-800';
            default:
                return 'bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-400 border-primary-200 dark:border-primary-800';
        }
    };

    return (
        <div className="fixed bottom-4 right-4 z-50 space-y-2 max-w-sm w-full">
            {toasts.map((toast) => (
                <Toast
                    key={toast.id}
                    id={toast.id}
                    type={toast.type}
                    message={toast.message}
                    duration={toast.duration}
                    onClose={() => dispatch(removeToast(toast.id))}
                    getIcon={getIcon}
                    getStyles={getStyles}
                />
            ))}
        </div>
    );
};

interface ToastProps {
    id: string;
    type: 'info' | 'success' | 'warning' | 'error';
    message: string;
    duration?: number;
    onClose: () => void;
    getIcon: (type: 'info' | 'success' | 'warning' | 'error') => React.ReactElement;
    getStyles: (type: 'info' | 'success' | 'warning' | 'error') => string;
}

const Toast: React.FC<ToastProps> = ({ type, message, duration = 5000, onClose, getIcon, getStyles }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onClose();
        }, duration);

        return () => clearTimeout(timer);
    }, [duration, onClose]);

    return (
        <div
            className={`flex items-start gap-3 p-4 rounded-lg border shadow-lg animate-slide-in-right ${getStyles(type)}`}
        >
            <div className="flex-shrink-0 mt-0.5">
                {getIcon(type)}
            </div>
            <p className="flex-1 text-sm font-medium">{message}</p>
            <button
                onClick={onClose}
                className="flex-shrink-0 hover:opacity-70 transition-opacity"
            >
                <X size={18} />
            </button>
        </div>
    );
};

export default ToastContainer;
