import React from 'react';
import { X, AlertCircle, CheckCircle, Info, AlertTriangle, Trash2, CheckCheck } from 'lucide-react';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { markNotificationRead, markAllNotificationsRead, clearNotifications } from '../store/slices/uiSlice';

interface NotificationsPanelProps {
    isOpen: boolean;
    onClose: () => void;
}

const NotificationsPanel: React.FC<NotificationsPanelProps> = ({ isOpen, onClose }) => {
    const dispatch = useAppDispatch();
    const notifications = useAppSelector(state => state.ui.notifications);
    const unreadCount = notifications.filter(n => !n.read).length;

    const getIcon = (type: 'info' | 'success' | 'warning' | 'error') => {
        switch (type) {
            case 'success':
                return <CheckCircle size={16} className="text-green-500" />;
            case 'warning':
                return <AlertTriangle size={16} className="text-amber-500" />;
            case 'error':
                return <AlertCircle size={16} className="text-red-500" />;
            default:
                return <Info size={16} className="text-blue-500" />;
        }
    };

    const getBgColor = (type: 'info' | 'success' | 'warning' | 'error', read: boolean) => {
        if (read) return 'bg-slate-50 dark:bg-slate-800/50';

        switch (type) {
            case 'success':
                return 'bg-green-50 dark:bg-green-900/20';
            case 'warning':
                return 'bg-amber-50 dark:bg-amber-900/20';
            case 'error':
                return 'bg-red-50 dark:bg-red-900/20';
            default:
                return 'bg-blue-50 dark:bg-blue-900/20';
        }
    };

    const formatTimestamp = (timestamp: string) => {
        const date = new Date(timestamp);
        const now = new Date();
        const diffMs = now.getTime() - date.getTime();
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return `${diffMins}m ago`;
        if (diffHours < 24) return `${diffHours}h ago`;
        if (diffDays < 7) return `${diffDays}d ago`;
        return date.toLocaleDateString();
    };

    if (!isOpen) return null;

    return (
        <>
            {/* Backdrop */}
            <div
                className="fixed inset-0 z-40"
                onClick={onClose}
            />

            {/* Panel */}
            <div className="absolute right-0 mt-2 w-96 max-h-[70vh] bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-700 z-50 overflow-hidden flex flex-col">
                {/* Header */}
                <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900">
                    <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-slate-900 dark:text-white">Notifications</h3>
                        {unreadCount > 0 && (
                            <span className="px-2 py-0.5 text-xs font-medium bg-red-500 text-white rounded-full">
                                {unreadCount}
                            </span>
                        )}
                    </div>
                    <div className="flex items-center gap-1">
                        {notifications.length > 0 && (
                            <>
                                <button
                                    onClick={() => dispatch(markAllNotificationsRead())}
                                    className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400"
                                    title="Mark all as read"
                                >
                                    <CheckCheck size={16} />
                                </button>
                                <button
                                    onClick={() => dispatch(clearNotifications())}
                                    className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400"
                                    title="Clear all"
                                >
                                    <Trash2 size={16} />
                                </button>
                            </>
                        )}
                        <button
                            onClick={onClose}
                            className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400"
                        >
                            <X size={16} />
                        </button>
                    </div>
                </div>

                {/* Notifications List */}
                <div className="flex-1 overflow-y-auto">
                    {notifications.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-12 text-slate-400 dark:text-slate-500">
                            <Info size={32} className="mb-2 opacity-50" />
                            <p className="text-sm">No notifications</p>
                        </div>
                    ) : (
                        <div className="divide-y divide-slate-100 dark:divide-slate-700">
                            {notifications.map((notification) => (
                                <div
                                    key={notification.id}
                                    onClick={() => !notification.read && dispatch(markNotificationRead(notification.id))}
                                    className={`px-4 py-3 cursor-pointer transition-colors hover:bg-slate-100 dark:hover:bg-slate-700/50 ${getBgColor(notification.type, notification.read)}`}
                                >
                                    <div className="flex items-start gap-3">
                                        <div className="flex-shrink-0 mt-0.5">
                                            {getIcon(notification.type)}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <div className="flex items-center gap-2">
                                                <p className={`text-sm font-medium ${notification.read ? 'text-slate-600 dark:text-slate-400' : 'text-slate-900 dark:text-white'}`}>
                                                    {notification.title}
                                                </p>
                                                {!notification.read && (
                                                    <span className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0" />
                                                )}
                                            </div>
                                            <p className={`text-xs mt-0.5 line-clamp-2 ${notification.read ? 'text-slate-400 dark:text-slate-500' : 'text-slate-600 dark:text-slate-300'}`}>
                                                {notification.message}
                                            </p>
                                            <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                                                {formatTimestamp(notification.timestamp)}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </>
    );
};

export default NotificationsPanel;
