import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { useAppDispatch } from '../../store/hooks';
import { setToken } from '../../store/slices/authSlice';
import './TokenExpiryPopup.css';

interface TokenExpiryPopupProps {
    isAuthenticated: boolean;
}

export const TokenExpiryPopup: React.FC<TokenExpiryPopupProps> = ({ isAuthenticated }) => {
    const dispatch = useAppDispatch();
    const [showPopup, setShowPopup] = useState(false);
    const [primaryExpiry, setPrimaryExpiry] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [statusMessage, setStatusMessage] = useState('');

    // Check token status every minute
    useEffect(() => {
        if (!isAuthenticated) {
            setShowPopup(false);
            return;
        }

        const checkTokenStatus = async () => {
            try {
                const response = await api.get('/v1/auth/upstox/tokens/db-status');

                if (response.data?.status === 'success') {
                    const { primary_expired, primary_expiry } = response.data.data;

                    if (primary_expired) {
                        setShowPopup(true);
                        setPrimaryExpiry(primary_expiry);
                    } else {
                        setShowPopup(false);
                    }
                }
            } catch (error) {
                console.error('Error checking token status:', error);
            }
        };

        // Check immediately
        checkTokenStatus();

        // Then check every 60 seconds
        const interval = setInterval(checkTokenStatus, 60000);

        return () => clearInterval(interval);
    }, [isAuthenticated]);

    const handleSingleLogin = async () => {
        try {
            setIsLoading(true);
            setStatusMessage('🚀 Launching automated login...');

            const response = await api.post('/v1/auth/upstox/automated-single-login');

            if (response.data?.status === 'success') {
                setStatusMessage('✅ Chrome window opened. Complete the login and wait...');

                // Poll for token update
                let pollCount = 0;
                const maxPolls = 60; // 3 minutes

                const pollInterval = setInterval(async () => {
                    try {
                        pollCount++;
                        const statusResponse = await api.get('/v1/auth/upstox/tokens/db-status');

                        if (statusResponse.data?.status === 'success') {
                            const { primary_expired } = statusResponse.data.data;

                            if (!primary_expired) {
                                clearInterval(pollInterval);
                                setStatusMessage('✅ Token refreshed successfully!');

                                // Fetch and update the new token before reloading
                                try {
                                    const tokenResponse = await api.get('/v1/auth/upstox/token');
                                    if (tokenResponse.data?.status === 'success' && tokenResponse.data?.access_token) {
                                        dispatch(setToken(tokenResponse.data.access_token));
                                        console.log('Token updated in store, reloading...');
                                    }
                                } catch (err) {
                                    console.error('Failed to update token in store:', err);
                                }

                                // Token is already updated in Redux store
                                // No reload needed - React will re-render with new auth state
                                setTimeout(() => {
                                    setShowPopup(false);
                                    setIsLoading(false);
                                    setStatusMessage('');
                                }, 1000);
                            }
                        }

                        if (pollCount >= maxPolls) {
                            clearInterval(pollInterval);
                            setStatusMessage('⏱️ Timeout. Please try again.');
                            setIsLoading(false);
                        }
                    } catch (error) {
                        console.error('Polling error:', error);
                    }
                }, 3000);
            }
        } catch (error: any) {
            console.error('Single login error:', error);
            setStatusMessage('❌ Failed to launch login. Please try again.');
            setIsLoading(false);
        }
    };

    const handleMultiLogin = async () => {
        try {
            setIsLoading(true);
            setStatusMessage('🚀 Launching multi-login for all APIs...');

            const response = await api.post('/v1/auth/upstox/launch-remaining-login', {
                start_index: 0
            });

            if (response.data?.status === 'success') {
                setStatusMessage('✅ Chrome window opened. Complete the login and wait...');

                // Poll for token update
                let pollCount = 0;
                const maxPolls = 120; // 6 minutes for multi

                const pollInterval = setInterval(async () => {
                    try {
                        pollCount++;
                        const statusResponse = await api.get('/v1/auth/upstox/tokens/db-status');

                        if (statusResponse.data?.status === 'success') {
                            const { primary_expired, valid_count } = statusResponse.data.data;

                            setStatusMessage(`⚡ Progress: ${valid_count}/6 tokens generated...`);

                            if (!primary_expired && valid_count > 0) {
                                clearInterval(pollInterval);
                                setStatusMessage(`✅ ${valid_count} token(s) refreshed successfully!`);

                                // Fetch and update the new token before reloading
                                try {
                                    const tokenResponse = await api.get('/v1/auth/upstox/token');
                                    if (tokenResponse.data?.status === 'success' && tokenResponse.data?.access_token) {
                                        dispatch(setToken(tokenResponse.data.access_token));
                                        console.log('Token updated in store, reloading...');
                                    }
                                } catch (err) {
                                    console.error('Failed to update token in store:', err);
                                }

                                // Token is already updated in Redux store
                                // No reload needed - React will re-render with new auth state
                                setTimeout(() => {
                                    setShowPopup(false);
                                    setIsLoading(false);
                                    setStatusMessage('');
                                }, 1000);
                            }
                        }

                        if (pollCount >= maxPolls) {
                            clearInterval(pollInterval);
                            setStatusMessage('⏱️ Timeout. Please try again.');
                            setIsLoading(false);
                        }
                    } catch (error) {
                        console.error('Polling error:', error);
                    }
                }, 3000);
            }
        } catch (error: any) {
            console.error('Multi-login error:', error);
            setStatusMessage('❌ Failed to launch login. Please try again.');
            setIsLoading(false);
        }
    };

    if (!showPopup) return null;

    const expiryDisplay = primaryExpiry
        ? new Date(primaryExpiry).toLocaleString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        })
        : '3:00 AM';

    return (
        <div className="token-expiry-overlay">
            <div className="token-expiry-popup">
                <div className="popup-icon">⚠️</div>
                <h2 className="popup-title">Access Token Expired</h2>

                <p className="popup-message">
                    Your Upstox token expired at <strong>{expiryDisplay}</strong>
                </p>

                <p className="popup-submessage">
                    Please login again to continue using the application
                </p>

                {statusMessage && (
                    <div className="status-message">{statusMessage}</div>
                )}

                <div className="popup-buttons">
                    <button
                        className="btn-single-login"
                        onClick={handleSingleLogin}
                        disabled={isLoading}
                    >
                        {isLoading ? '⏳ Processing...' : '🔑 Login Single Token'}
                    </button>

                    <button
                        className="btn-multi-login"
                        onClick={handleMultiLogin}
                        disabled={isLoading}
                    >
                        {isLoading ? '⏳ Processing...' : '🔐 Login All Tokens (6)'}
                    </button>
                </div>
            </div>
        </div>
    );
};
