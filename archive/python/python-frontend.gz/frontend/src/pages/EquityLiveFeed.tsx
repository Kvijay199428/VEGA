/**
 * Equity Live Feed Page
 * Show live equity prices from WebSocket with sector filtering and search
 */

import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, X, Loader2 } from 'lucide-react';
import { useAppSelector } from '../store/hooks';
import api from '../services/api';
import { handleUpstoxError } from '../utils/upstoxErrors';
import { SectorFilter, EquityTableRow, Pagination } from '../components/equity';
import type { EquityInstrument, LivePrice, Sector } from '../types/equity';

const PAGE_SIZE = 50;

const EquityLiveFeed: React.FC = () => {
    const [instruments, setInstruments] = useState<EquityInstrument[]>([]);
    const [totalCount, setTotalCount] = useState(0);
    const [livePrices, setLivePrices] = useState<Record<string, LivePrice>>({});
    const [isLoading, setIsLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(0);
    const [retryCount, setRetryCount] = useState(0);

    // Sector filter state
    const [sectors, setSectors] = useState<Sector[]>([]);
    const [selectedSector, setSelectedSector] = useState<string | null>(null);
    const [sectorsLoading, setSectorsLoading] = useState(true);

    // Search state
    const [searchQuery, setSearchQuery] = useState('');
    const [debouncedQuery, setDebouncedQuery] = useState('');

    // Get global state from Redux
    const { globalSearchQuery, selectedExchange, wsConnectionStatus } = useAppSelector(state => state.ui);
    const isConnected = wsConnectionStatus === 'connected';

    // URL params sync
    const [searchParams, setSearchParams] = useSearchParams();
    const searchInputRef = useRef<HTMLInputElement>(null);

    // Debounce search query
    useEffect(() => {
        const timer = setTimeout(() => {
            setDebouncedQuery(searchQuery);
            setCurrentPage(0);
        }, 500);
        return () => clearTimeout(timer);
    }, [searchQuery]);

    // Sync URL -> State
    useEffect(() => {
        if (sectors.length === 0 && sectorsLoading) return;

        const sectorParam = searchParams.get('sector');
        const q = searchParams.get('q');

        let targetSector: string | null = null;

        if (sectorParam) {
            const matched = sectors.find(s =>
                s.name.toLowerCase() === sectorParam.toLowerCase() ||
                s.key.toLowerCase() === sectorParam.toLowerCase()
            );
            if (matched) targetSector = matched.key;
        }

        if (targetSector) {
            if (targetSector !== selectedSector) setSelectedSector(targetSector);
            if (searchQuery) { setSearchQuery(''); setDebouncedQuery(''); }
        } else if (q) {
            if (q !== searchQuery) { setSearchQuery(q); setDebouncedQuery(q); }
            if (selectedSector) setSelectedSector(null);
        } else {
            if (searchQuery) { setSearchQuery(''); setDebouncedQuery(''); }
            if (selectedSector) setSelectedSector(null);
        }
    }, [searchParams, sectors, sectorsLoading]);

    // Sync State -> URL
    useEffect(() => {
        setSearchParams(prev => {
            const newParams = new URLSearchParams(prev);

            if (selectedSector) {
                const sectorObj = sectors.find(s => s.key === selectedSector);
                newParams.set('sector', sectorObj?.name || selectedSector);
            } else {
                newParams.delete('sector');
            }

            if (debouncedQuery) {
                newParams.set('q', debouncedQuery);
            } else {
                newParams.delete('q');
            }

            return newParams;
        }, { replace: true });
    }, [selectedSector, debouncedQuery, sectors]);

    // Fetch available sectors
    useEffect(() => {
        const fetchSectors = async () => {
            try {
                setSectorsLoading(true);
                const response = await api.get('/v1/sectors');
                if (response.data?.status === 'success') {
                    const availableSectors = response.data.sectors.filter((s: Sector) => s.available);
                    setSectors(availableSectors);
                }
            } catch (err) {
                console.error('Error fetching sectors:', err);
            } finally {
                setSectorsLoading(false);
            }
        };
        fetchSectors();
    }, []);

    // Fetch equity instruments
    const fetchInstruments = useCallback(async () => {
        try {
            setIsLoading(true);
            const offset = currentPage * PAGE_SIZE;

            let url: string;
            if (selectedSector) {
                url = `/v1/instruments/equity/sector/${selectedSector}?exchange=${selectedExchange}&limit=${PAGE_SIZE}&offset=${offset}`;
            } else if (debouncedQuery.trim()) {
                url = `/v1/instruments/equity?q=${encodeURIComponent(debouncedQuery)}&exchange=${selectedExchange}&limit=${PAGE_SIZE}&offset=${offset}`;
            } else {
                url = `/v1/instruments/equity?exchange=${selectedExchange}&limit=${PAGE_SIZE}&offset=${offset}`;
            }

            const response = await api.get(url);

            if (response.data?.status === 'success') {
                const instrumentList = response.data.instruments || [];
                setInstruments(instrumentList);
                setTotalCount(response.data.total || response.data.count || instrumentList.length);
            }
        } catch (err: any) {
            console.error('Error fetching instruments:', err);
            handleUpstoxError(err, 'Equity Instruments');
        } finally {
            setIsLoading(false);
        }
    }, [selectedExchange, currentPage, debouncedQuery, selectedSector]);

    // Fetch live prices
    const fetchPrices = useCallback(async () => {
        try {
            const response = await api.get('/v1/market/market-feed/equity/prices');
            if (response.data?.status === 'success') {
                setLivePrices(response.data.data || {});
            }
        } catch (err) {
            console.error('Error fetching prices:', err);
        }
    }, []);

    // Reset page on filter changes
    useEffect(() => {
        setCurrentPage(0);
    }, [selectedExchange, debouncedQuery, selectedSector]);

    // Fetch instruments when deps change
    useEffect(() => {
        fetchInstruments();
    }, [fetchInstruments]);

    // Auto-retry if empty
    useEffect(() => {
        if (instruments.length === 0 && retryCount < 30 && !debouncedQuery && !selectedSector) {
            const timer = setTimeout(() => {
                setRetryCount(prev => prev + 1);
                fetchInstruments();
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [instruments.length, retryCount, fetchInstruments, debouncedQuery, selectedSector]);

    // Poll for prices
    useEffect(() => {
        if (!isConnected) return;
        fetchPrices();
        const interval = setInterval(fetchPrices, 1000);
        return () => clearInterval(interval);
    }, [isConnected, fetchPrices]);

    // Global type-to-search
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (
                document.activeElement instanceof HTMLInputElement ||
                document.activeElement instanceof HTMLTextAreaElement
            ) return;

            if (
                e.key.length === 1 &&
                !e.ctrlKey && !e.altKey && !e.metaKey && !e.isComposing &&
                /[a-zA-Z0-9\s]/.test(e.key)
            ) {
                e.preventDefault();
                searchInputRef.current?.focus();
                setSearchQuery(prev => prev + e.key);
                setSelectedSector(null);
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, []);

    const totalPages = Math.ceil(totalCount / PAGE_SIZE);

    const handleSectorClick = (sectorKey: string) => {
        if (selectedSector === sectorKey) {
            setSelectedSector(null);
        } else {
            setSelectedSector(sectorKey);
            setSearchQuery('');
            setDebouncedQuery('');
        }
    };

    return (
        <div className="h-full flex flex-col animate-fade-in">
            {/* Top Bar: Search and Sector Filter */}
            <div className="mb-3 flex-shrink-0 flex items-center gap-3">
                {/* Search Box */}
                <div className="relative w-64 flex-shrink-0">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search size={14} className="text-slate-400" />
                    </div>
                    <input
                        ref={searchInputRef}
                        type="text"
                        value={searchQuery}
                        onChange={(e) => {
                            setSearchQuery(e.target.value);
                            if (e.target.value) setSelectedSector(null);
                        }}
                        placeholder="Search Symbol, Name, Sector..."
                        className="block w-full pl-9 pr-3 py-1.5 bg-slate-100 dark:bg-surface-800 border border-slate-300 dark:border-slate-700 rounded-full text-xs text-slate-900 dark:text-slate-200 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-colors"
                    />
                    {searchQuery && (
                        <button
                            onClick={() => setSearchQuery('')}
                            className="absolute inset-y-0 right-0 pr-2 flex items-center text-slate-500 hover:text-slate-300"
                        >
                            <X size={12} />
                        </button>
                    )}
                </div>

                {/* Sector Filter */}
                <SectorFilter
                    sectors={sectors}
                    selectedSector={selectedSector}
                    onSectorClick={handleSectorClick}
                    onClearFilter={() => setSelectedSector(null)}
                    isLoading={sectorsLoading}
                />
            </div>

            {/* Main Table Container */}
            <div className="flex-1 bg-white dark:bg-surface-800 rounded-lg border border-slate-200 dark:border-slate-700 overflow-hidden flex flex-col">
                {isLoading ? (
                    <div className="flex-1 flex items-center justify-center">
                        <Loader2 className="animate-spin h-8 w-8 text-primary-600" />
                    </div>
                ) : (
                    <>
                        {/* Table */}
                        <div className="flex-1 overflow-auto">
                            <table className="w-full text-sm" style={{ tableLayout: 'fixed' }}>
                                <colgroup>
                                    <col style={{ width: '40px' }} />
                                    <col style={{ width: '12%' }} />
                                    <col style={{ width: '28%' }} />
                                    <col style={{ width: '12%' }} />
                                    <col style={{ width: '12%' }} />
                                    <col style={{ width: '14%' }} />
                                    <col style={{ width: '10%' }} />
                                </colgroup>
                                <thead className="sticky top-0 bg-slate-100 dark:bg-surface-900 z-10">
                                    <tr className="border-b border-slate-200 dark:border-slate-700">
                                        <th className="px-2 py-2.5 text-left text-xs font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-surface-900"></th>
                                        <th className="px-2 py-2.5 text-left text-xs font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-surface-900">Symbol</th>
                                        <th className="px-2 py-2.5 text-left text-xs font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-surface-900">Name</th>
                                        <th className="px-2 py-2.5 text-right text-xs font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-surface-900">LTP</th>
                                        <th className="px-2 py-2.5 text-right text-xs font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-surface-900">Close</th>
                                        <th className="px-2 py-2.5 text-right text-xs font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-surface-900">Change%</th>
                                        <th className="px-2 py-2.5 text-center text-xs font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-surface-900">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {instruments.length === 0 ? (
                                        <tr>
                                            <td colSpan={7} className="text-center py-12 text-slate-500">
                                                {globalSearchQuery ? 'No instruments found matching your search' :
                                                    selectedSector ? (
                                                        <div className="flex flex-col items-center gap-2">
                                                            <span>No instruments found for this sector</span>
                                                            <span className="text-xs text-slate-500">
                                                                Sector CSV may not be synced yet. Try syncing sectors.
                                                            </span>
                                                        </div>
                                                    ) : (
                                                        <div className="flex flex-col items-center gap-4">
                                                            <Loader2 size={32} className="animate-spin text-primary-600" />
                                                            <span>Loading instruments... (auto-syncing from Upstox)</span>
                                                            <span className="text-sm text-slate-400">
                                                                {retryCount > 0 && `Attempt ${retryCount}/30`}
                                                            </span>
                                                        </div>
                                                    )
                                                }
                                            </td>
                                        </tr>
                                    ) : (
                                        instruments.map((inst, i) => (
                                            <EquityTableRow
                                                key={inst.instrument_key || i}
                                                instrument={inst}
                                                price={livePrices[inst.instrument_key]}
                                                index={i}
                                            />
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>

                        {/* Pagination Footer */}
                        {instruments.length > 0 && (
                            <Pagination
                                currentPage={currentPage}
                                totalPages={totalPages}
                                totalCount={totalCount}
                                pageSize={PAGE_SIZE}
                                onPrevPage={() => setCurrentPage(prev => Math.max(0, prev - 1))}
                                onNextPage={() => setCurrentPage(prev => Math.min(totalPages - 1, prev + 1))}
                                isConnected={isConnected}
                            />
                        )}
                    </>
                )}
            </div>
        </div>
    );
};

export default EquityLiveFeed;
