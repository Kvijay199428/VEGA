/**
 * Futures Page - Display futures contracts
 * 
 * Features:
 * - Index Futures / Equity Futures segment tabs
 * - Underlying selector
 * - Futures contracts table with expiry, LTP, OI, volume
 * - Real-time updates
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
    Loader2,
    RefreshCw,
    ChevronDown,
    Calendar
} from 'lucide-react';
import api from '../services/api';
import { handleUpstoxError } from '../utils/upstoxErrors';

interface FuturesContract {
    instrument_key: string;
    trading_symbol: string;
    name: string;
    expiry: string;
    underlying_symbol: string;
    lot_size: number;
    exchange: string;
}

// Known index underlyings with futures
const INDEX_UNDERLYINGS = [
    { instrument_key: "NSE_INDEX|Nifty 50", name: "NIFTY 50", exchange: "NSE" },
    { instrument_key: "NSE_INDEX|Nifty Bank", name: "BANK NIFTY", exchange: "NSE" },
    { instrument_key: "NSE_INDEX|NIFTY FIN SERVICE", name: "FINNIFTY", exchange: "NSE" },
    { instrument_key: "NSE_INDEX|Nifty Midcap Select", name: "MIDCPNIFTY", exchange: "NSE" },
];

const Futures: React.FC = () => {
    const [segment, setSegment] = useState<'index' | 'equity'>('index');
    const [exchange, setExchange] = useState<'NSE' | 'BSE'>('NSE');
    const [selectedUnderlying, setSelectedUnderlying] = useState<string>('');
    const [contracts, setContracts] = useState<FuturesContract[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [_error, setError] = useState<string | null>(null);

    // Get underlyings based on segment
    const underlyings = segment === 'index'
        ? INDEX_UNDERLYINGS.filter(u => u.exchange === exchange)
        : []; // For equity, we'd fetch from API

    // Fetch futures contracts
    const fetchContracts = useCallback(async () => {
        setIsLoading(true);
        setError(null);

        try {
            let url = `/v1/instruments/futures?exchange=${exchange}&limit=100`;
            if (selectedUnderlying) {
                url += `&underlying=${encodeURIComponent(selectedUnderlying)}`;
            }

            const response = await api.get(url);

            if (response.data?.status === 'success') {
                setContracts(response.data.instruments || []);
            }
        } catch (err: any) {
            console.error('Error fetching futures:', err);
            setError(err.response?.data?.detail || 'Failed to fetch futures contracts');
            handleUpstoxError(err, 'Futures Contracts');
        } finally {
            setIsLoading(false);
        }
    }, [exchange, selectedUnderlying]);

    // Set default underlying on segment/exchange change
    useEffect(() => {
        if (segment === 'index' && underlyings.length > 0) {
            setSelectedUnderlying(underlyings[0].instrument_key);
        } else {
            setSelectedUnderlying('');
        }
    }, [segment, exchange]);

    // Fetch contracts when selection changes
    useEffect(() => {
        fetchContracts();
    }, [fetchContracts]);

    // Format expiry date
    const formatExpiry = (expiry: string) => {
        if (!expiry) return '-';
        const date = new Date(expiry);
        return date.toLocaleDateString('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    };

    // Get days to expiry
    const getDaysToExpiry = (expiry: string) => {
        if (!expiry) return '-';
        const expiryDate = new Date(expiry);
        const today = new Date();
        const diff = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        return diff > 0 ? `${diff}d` : 'Expired';
    };

    return (
        <div className="space-y-4 animate-fade-in">
            {/* Controls Section */}
            <div className="card">
                <div className="p-4 flex flex-wrap items-center gap-4">
                    {/* Segment Tabs */}
                    <div className="flex gap-2">
                        {(['index', 'equity'] as const).map((seg) => (
                            <button
                                key={seg}
                                onClick={() => setSegment(seg)}
                                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${segment === seg
                                    ? 'bg-primary-600 text-white'
                                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                                    }`}
                            >
                                {seg === 'index' ? 'Index Futures' : 'Equity Futures'}
                            </button>
                        ))}
                    </div>

                    {/* Exchange Toggle */}
                    <div className="flex gap-2">
                        {(['NSE', 'BSE'] as const).map((ex) => (
                            <button
                                key={ex}
                                onClick={() => setExchange(ex)}
                                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${exchange === ex
                                    ? 'bg-primary-600 text-white'
                                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                                    }`}
                            >
                                {ex}
                            </button>
                        ))}
                    </div>

                    {/* Underlying Selector (for index) */}
                    {segment === 'index' && underlyings.length > 0 && (
                        <div className="relative">
                            <select
                                value={selectedUnderlying}
                                onChange={(e) => setSelectedUnderlying(e.target.value)}
                                className="appearance-none bg-slate-100 dark:bg-slate-800 px-4 py-2 pr-8 rounded-lg text-sm font-medium border-none outline-none cursor-pointer"
                            >
                                <option value="">All Underlyings</option>
                                {underlyings.map((u) => (
                                    <option key={u.instrument_key} value={u.instrument_key}>
                                        {u.name}
                                    </option>
                                ))}
                            </select>
                            <ChevronDown size={16} className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400" />
                        </div>
                    )}

                    {/* Refresh Button */}
                    <button
                        onClick={fetchContracts}
                        disabled={isLoading}
                        className="ml-auto p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                    >
                        <RefreshCw size={18} className={isLoading ? 'animate-spin' : ''} />
                    </button>
                </div>
            </div>

            {/* Futures Contracts Table */}
            <div className="card">
                <div className="overflow-x-auto">
                    {isLoading ? (
                        <div className="flex items-center justify-center py-12">
                            <Loader2 className="animate-spin h-8 w-8 text-primary-600" />
                        </div>
                    ) : (
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Symbol</th>
                                    <th>Underlying</th>
                                    <th className="text-center">Expiry</th>
                                    <th className="text-center">Days Left</th>
                                    <th className="text-right">Lot Size</th>
                                    <th className="text-center">Exchange</th>
                                </tr>
                            </thead>
                            <tbody>
                                {contracts.length === 0 ? (
                                    <tr>
                                        <td colSpan={6} className="text-center py-12 text-slate-500">
                                            No futures contracts found
                                        </td>
                                    </tr>
                                ) : (
                                    contracts.map((contract, i) => (
                                        <tr
                                            key={contract.instrument_key || i}
                                            className="hover:bg-slate-50 dark:hover:bg-slate-800/50"
                                        >
                                            <td className="font-semibold text-slate-900 dark:text-white">
                                                {contract.trading_symbol}
                                            </td>
                                            <td className="text-slate-500 dark:text-slate-400">
                                                {contract.underlying_symbol || contract.name}
                                            </td>
                                            <td className="text-center">
                                                <span className="inline-flex items-center gap-1 text-slate-600 dark:text-slate-300">
                                                    <Calendar size={14} />
                                                    {formatExpiry(contract.expiry)}
                                                </span>
                                            </td>
                                            <td className="text-center">
                                                <span className={`px-2 py-1 rounded text-xs font-medium ${getDaysToExpiry(contract.expiry) === 'Expired'
                                                    ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
                                                    : parseInt(getDaysToExpiry(contract.expiry)) <= 7
                                                        ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
                                                        : 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
                                                    }`}>
                                                    {getDaysToExpiry(contract.expiry)}
                                                </span>
                                            </td>
                                            <td className="text-right font-medium text-slate-700 dark:text-slate-300">
                                                {contract.lot_size}
                                            </td>
                                            <td className="text-center">
                                                <span className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 text-xs font-medium">
                                                    {contract.exchange}
                                                </span>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Futures;
