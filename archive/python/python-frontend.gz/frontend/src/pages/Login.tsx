/**
 * Login Page
 * Authentication page for Upstox API login
 */

import React from 'react';
import { useAppSelector } from '../store/hooks';
import useUpstoxAuth from '../hooks/useUpstoxAuth';

const Login: React.FC = () => {
    const { isLoading, error } = useAppSelector((state) => state.auth);

    const {
        isCheckingToken,
        isGenerating,
        generationStatus,
        loginError,
        tokenInput,
        showManualInput,
        setTokenInput,
        setShowManualInput,
        openUpstoxPopup,
        handleMultiLogin,
        handleManualLogin,
    } = useUpstoxAuth();

    // Loading state while checking for existing token
    if (isCheckingToken) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-900 via-primary-900 to-slate-900 flex items-center justify-center p-4">
                <div className="absolute inset-0 overflow-hidden">
                    <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary-500/20 rounded-full blur-3xl" />
                    <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-profit-500/20 rounded-full blur-3xl" />
                </div>
                <div className="relative text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-primary-500 to-primary-700 rounded-2xl mb-4">
                        <span className="text-white font-bold text-2xl">VT</span>
                    </div>
                    <div className="flex items-center justify-center gap-3 mt-4">
                        <div className="w-6 h-6 border-2 border-primary-400 border-t-transparent rounded-full animate-spin" />
                        <p className="text-slate-300">Checking session...</p>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-primary-900 to-slate-900 flex items-center justify-center p-4">
            {/* Background effects */}
            <div className="absolute inset-0 overflow-hidden">
                <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary-500/20 rounded-full blur-3xl" />
                <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-profit-500/20 rounded-full blur-3xl" />
            </div>

            {/* Login card */}
            <div className="relative w-full max-w-md">
                <div className="bg-white/10 backdrop-blur-xl rounded-2xl border border-white/20 p-8 shadow-2xl">
                    {/* Logo */}
                    <div className="text-center mb-8">
                        <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-primary-500 to-primary-700 rounded-2xl mb-4">
                            <span className="text-white font-bold text-2xl">VT</span>
                        </div>
                        <h1 className="text-3xl font-bold text-white mb-2">Vega Trader</h1>
                        <p className="text-slate-300">AI-Powered Trading Platform</p>
                    </div>

                    {/* Session info */}
                    <div className="bg-primary-500/20 rounded-lg p-4 mb-6">
                        <div className="flex items-center gap-3 text-sm">
                            <div className="w-3 h-3 bg-profit-500 rounded-full animate-pulse" />
                            <div className="text-slate-200">
                                <p className="font-medium">Session Window</p>
                                <p className="text-slate-400">3:15 AM - 2:30 AM IST (23 hours)</p>
                            </div>
                        </div>
                    </div>

                    {/* Automation Info */}
                    {!isGenerating && (
                        <div className="mb-4 p-3 bg-amber-500/10 rounded-lg border border-amber-500/30">
                            <div className="flex items-start gap-2 text-xs">
                                <span className="text-amber-400 mt-0.5">💡</span>
                                <p className="text-amber-200/80">
                                    <strong>Auto-Login:</strong> A Chrome browser will open on your desktop to complete the Upstox authentication automatically.
                                </p>
                            </div>
                        </div>
                    )}

                    {/* Generation Status */}
                    {isGenerating && (
                        <div className="mb-4 p-4 bg-gradient-to-r from-primary-500/30 to-primary-600/30 rounded-lg border border-primary-500/50">
                            <div className="flex items-center gap-3">
                                <div className="relative">
                                    <div className="w-6 h-6 border-2 border-primary-300 border-t-transparent rounded-full animate-spin" />
                                    <div className="absolute inset-0 w-6 h-6 border-2 border-primary-200/30 rounded-full" />
                                </div>
                                <div className="flex-1">
                                    <p className="text-primary-100 font-medium">Automated Login In Progress</p>
                                    <p className="text-primary-200 text-sm mt-0.5">{generationStatus}</p>
                                </div>
                            </div>
                            <p className="text-primary-300/70 text-xs mt-3 pl-9">Please wait and don't close the Chrome browser that opens...</p>
                        </div>
                    )}

                    {/* Multi-API Login Button */}
                    <button
                        onClick={handleMultiLogin}
                        disabled={isLoading || isGenerating}
                        className="w-full py-3 px-4 bg-gradient-to-r from-primary-600 to-primary-500 hover:from-primary-500 hover:to-primary-400 text-white font-semibold rounded-lg transition-all duration-200 flex items-center justify-center gap-2 mb-3 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                            <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                            <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                        {isGenerating ? 'Generating Tokens...' : 'Login with All APIs (6 Tokens)'}
                    </button>

                    {/* Quick Single Login */}
                    <button
                        onClick={openUpstoxPopup}
                        disabled={isLoading || isGenerating}
                        className="w-full py-2 px-4 bg-white/10 hover:bg-white/20 text-slate-300 font-medium rounded-lg transition-all duration-200 border border-white/20 flex items-center justify-center gap-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        📝 Manual Login (Single Token)
                    </button>

                    {/* Divider */}
                    <div className="relative my-6">
                        <div className="absolute inset-0 flex items-center">
                            <div className="w-full border-t border-white/20" />
                        </div>
                        <div className="relative flex justify-center text-sm">
                            <button
                                onClick={() => setShowManualInput(!showManualInput)}
                                className="px-4 bg-transparent text-slate-400 hover:text-white transition-colors"
                            >
                                {showManualInput ? 'Hide' : 'Or use access token'}
                            </button>
                        </div>
                    </div>

                    {/* Manual token input */}
                    {showManualInput && (
                        <form onSubmit={handleManualLogin} className="space-y-4 animate-fade-in">
                            <div>
                                <label className="block text-sm font-medium text-slate-300 mb-2">
                                    Access Token
                                </label>
                                <input
                                    type="password"
                                    value={tokenInput}
                                    onChange={(e) => setTokenInput(e.target.value)}
                                    placeholder="Paste your Upstox access token"
                                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-primary-500"
                                />
                            </div>
                            <button
                                type="submit"
                                disabled={!tokenInput.trim() || isLoading}
                                className="w-full py-3 px-4 bg-white/10 hover:bg-white/20 text-white font-medium rounded-lg transition-all duration-200 border border-white/20 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                Continue with Token
                            </button>
                        </form>
                    )}

                    {/* Error message */}
                    {(error || loginError) && (
                        <div className="mt-4 p-3 bg-loss-500/20 border border-loss-500/50 rounded-lg text-loss-400 text-sm">
                            {loginError || error}
                        </div>
                    )}

                    {/* Footer */}
                    <p className="mt-6 text-center text-xs text-slate-500">
                        By logging in, you agree to our Terms of Service and Privacy Policy
                    </p>
                </div>

                {/* Features */}
                <div className="mt-8 grid grid-cols-3 gap-4 text-center">
                    <div className="text-slate-400">
                        <div className="text-2xl mb-1">🤖</div>
                        <p className="text-xs">AI Strategies</p>
                    </div>
                    <div className="text-slate-400">
                        <div className="text-2xl mb-1">📊</div>
                        <p className="text-xs">Real-time Data</p>
                    </div>
                    <div className="text-slate-400">
                        <div className="text-2xl mb-1">⚡</div>
                        <p className="text-xs">Fast Execution</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;
