import React from 'react';
import { Activity, Plus, Settings as SettingsIcon } from 'lucide-react';

const Indicators: React.FC = () => {
    const builtinIndicators = [
        { id: '1', name: 'RSI', fullName: 'Relative Strength Index', category: 'Momentum', params: 'Period: 14' },
        { id: '2', name: 'MACD', fullName: 'Moving Average Convergence Divergence', category: 'Trend', params: '12, 26, 9' },
        { id: '3', name: 'BB', fullName: 'Bollinger Bands', category: 'Volatility', params: 'Period: 20, SD: 2' },
        { id: '4', name: 'EMA', fullName: 'Exponential Moving Average', category: 'Trend', params: 'Period: 20' },
        { id: '5', name: 'SMA', fullName: 'Simple Moving Average', category: 'Trend', params: 'Period: 50' },
        { id: '6', name: 'ATR', fullName: 'Average True Range', category: 'Volatility', params: 'Period: 14' },
        { id: '7', name: 'VWAP', fullName: 'Volume Weighted Average Price', category: 'Volume', params: 'Anchor: Session' },
        { id: '8', name: 'Stochastic', fullName: 'Stochastic Oscillator', category: 'Momentum', params: '%K: 14, %D: 3' },
    ];

    const userIndicators = [
        { id: '1', name: 'My RSI Alert', basedOn: 'RSI', condition: 'RSI < 30 or RSI > 70', status: 'Active' },
        { id: '2', name: 'MACD Cross', basedOn: 'MACD', condition: 'Line crosses Signal', status: 'Active' },
    ];

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Indicators</h1>
                    <p className="text-slate-500 dark:text-slate-400">Technical indicators for analysis</p>
                </div>
                <button className="btn btn-primary">
                    <Plus size={18} className="mr-2" />
                    Create Custom
                </button>
            </div>

            {/* Built-in Indicators */}
            <div className="card">
                <div className="card-header">
                    <h2 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                        <Activity size={20} className="text-primary-500" />
                        Built-in Indicators
                    </h2>
                </div>
                <div className="overflow-x-auto">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Short</th>
                                <th>Full Name</th>
                                <th>Category</th>
                                <th>Default Params</th>
                                <th className="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {builtinIndicators.map((ind) => (
                                <tr key={ind.id}>
                                    <td className="font-semibold text-slate-900 dark:text-white">{ind.name}</td>
                                    <td className="text-slate-600 dark:text-slate-400">{ind.fullName}</td>
                                    <td><span className="badge badge-info">{ind.category}</span></td>
                                    <td className="text-slate-500 text-sm">{ind.params}</td>
                                    <td className="text-center">
                                        <div className="flex justify-center gap-2">
                                            <button className="btn btn-secondary py-1 px-3 text-xs">Calculate</button>
                                            <button className="btn btn-ghost py-1 px-2">
                                                <SettingsIcon size={14} />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Custom Indicators */}
            <div className="card">
                <div className="card-header">
                    <h2 className="font-semibold text-slate-900 dark:text-white">Custom Indicators</h2>
                </div>
                <div className="overflow-x-auto">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Based On</th>
                                <th>Condition</th>
                                <th>Status</th>
                                <th className="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {userIndicators.map((ind) => (
                                <tr key={ind.id}>
                                    <td className="font-semibold text-slate-900 dark:text-white">{ind.name}</td>
                                    <td>{ind.basedOn}</td>
                                    <td className="text-slate-500 text-sm">{ind.condition}</td>
                                    <td><span className="badge badge-success">{ind.status}</span></td>
                                    <td className="text-center">
                                        <button className="btn btn-secondary py-1 px-3 text-xs">Edit</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Indicators;
