import React, { useEffect, useState } from 'react';
import { TrendingUp, TrendingDown, PieChart, BarChart2 } from 'lucide-react';
import { useAppDispatch } from '../store/hooks';
import { fetchAllPortfolioData } from '../store/slices/portfolioSlice';

const Portfolio: React.FC = () => {
    const dispatch = useAppDispatch();
    // const { holdings, positions, isLoading } = useAppSelector(state => state.portfolio);
    const [activeTab, setActiveTab] = useState<'holdings' | 'positions'>('holdings');

    useEffect(() => {
        dispatch(fetchAllPortfolioData());
    }, [dispatch]);

    // Mock data
    const mockHoldings = [
        { symbol: 'RELIANCE', name: 'Reliance Industries', qty: 50, avg: 2450, ltp: 2512.50, pnl: 3125, pnl_percent: 2.55, invested: 122500, current: 125625 },
        { symbol: 'TCS', name: 'Tata Consultancy', qty: 25, avg: 3850, ltp: 3920.00, pnl: 1750, pnl_percent: 1.82, invested: 96250, current: 98000 },
        { symbol: 'INFY', name: 'Infosys Limited', qty: 100, avg: 1520, ltp: 1485.00, pnl: -3500, pnl_percent: -2.30, invested: 152000, current: 148500 },
        { symbol: 'HDFCBANK', name: 'HDFC Bank', qty: 40, avg: 1680, ltp: 1715.50, pnl: 1420, pnl_percent: 2.11, invested: 67200, current: 68620 },
        { symbol: 'ICICIBANK', name: 'ICICI Bank', qty: 75, avg: 1050, ltp: 1082.25, pnl: 2418.75, pnl_percent: 3.07, invested: 78750, current: 81168.75 },
    ];

    const mockPositions = [
        { symbol: 'NIFTY25D19500CE', type: 'OPT', qty: 50, avg: 82.50, ltp: 89.25, pnl: 337.50, pnl_percent: 8.18, product: 'INTRADAY' },
        { symbol: 'BANKNIFTY25D44000PE', type: 'OPT', qty: -25, avg: 125.00, ltp: 118.50, pnl: 162.50, pnl_percent: 5.20, product: 'INTRADAY' },
        { symbol: 'RELIANCE', type: 'EQ', qty: 100, avg: 2505.00, ltp: 2512.50, pnl: 750, pnl_percent: 0.30, product: 'INTRADAY' },
    ];

    const totalInvested = mockHoldings.reduce((acc, h) => acc + h.invested, 0);
    const totalCurrent = mockHoldings.reduce((acc, h) => acc + h.current, 0);
    const totalPnl = totalCurrent - totalInvested;
    const totalPnlPercent = (totalPnl / totalInvested) * 100;

    const dayPnl = mockPositions.reduce((acc, p) => acc + p.pnl * (p.type === 'OPT' ? 50 : 1), 0);

    return (
        <div className="space-y-6 animate-fade-in">
            <div>
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Portfolio</h1>
                <p className="text-slate-500 dark:text-slate-400">Your holdings and open positions</p>
            </div>

            {/* Summary cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="stat-card">
                    <div className="flex items-center justify-between">
                        <span className="stat-label">Total Invested</span>
                        <PieChart size={20} className="text-primary-500" />
                    </div>
                    <p className="stat-value">₹{totalInvested.toLocaleString('en-IN')}</p>
                </div>

                <div className="stat-card">
                    <div className="flex items-center justify-between">
                        <span className="stat-label">Current Value</span>
                        <BarChart2 size={20} className="text-primary-500" />
                    </div>
                    <p className="stat-value">₹{totalCurrent.toLocaleString('en-IN')}</p>
                </div>

                <div className="stat-card">
                    <div className="flex items-center justify-between">
                        <span className="stat-label">Overall P&L</span>
                        {totalPnl >= 0 ? (
                            <TrendingUp size={20} className="text-profit-500" />
                        ) : (
                            <TrendingDown size={20} className="text-loss-500" />
                        )}
                    </div>
                    <p className={`stat-value ${totalPnl >= 0 ? 'price-up' : 'price-down'}`}>
                        {totalPnl >= 0 ? '+' : ''}₹{totalPnl.toLocaleString('en-IN')}
                    </p>
                    <p className={`stat-change ${totalPnlPercent >= 0 ? 'price-up' : 'price-down'}`}>
                        {totalPnlPercent >= 0 ? '+' : ''}{totalPnlPercent.toFixed(2)}%
                    </p>
                </div>

                <div className="stat-card">
                    <div className="flex items-center justify-between">
                        <span className="stat-label">Day P&L</span>
                        {dayPnl >= 0 ? (
                            <TrendingUp size={20} className="text-profit-500" />
                        ) : (
                            <TrendingDown size={20} className="text-loss-500" />
                        )}
                    </div>
                    <p className={`stat-value ${dayPnl >= 0 ? 'price-up' : 'price-down'}`}>
                        {dayPnl >= 0 ? '+' : ''}₹{dayPnl.toLocaleString('en-IN')}
                    </p>
                    <p className="stat-change text-slate-500">Today's unrealized</p>
                </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-4 border-b border-slate-200 dark:border-slate-700">
                <button
                    onClick={() => setActiveTab('holdings')}
                    className={`px-4 py-2 font-medium border-b-2 -mb-px transition-colors ${activeTab === 'holdings'
                        ? 'text-primary-600 border-primary-600'
                        : 'text-slate-500 border-transparent hover:text-slate-700'
                        }`}
                >
                    Holdings ({mockHoldings.length})
                </button>
                <button
                    onClick={() => setActiveTab('positions')}
                    className={`px-4 py-2 font-medium border-b-2 -mb-px transition-colors ${activeTab === 'positions'
                        ? 'text-primary-600 border-primary-600'
                        : 'text-slate-500 border-transparent hover:text-slate-700'
                        }`}
                >
                    Positions ({mockPositions.length})
                </button>
            </div>

            {/* Content */}
            <div className="card">
                <div className="overflow-x-auto">
                    {activeTab === 'holdings' ? (
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Symbol</th>
                                    <th>Name</th>
                                    <th className="text-right">Qty</th>
                                    <th className="text-right">Avg Price</th>
                                    <th className="text-right">LTP</th>
                                    <th className="text-right">Invested</th>
                                    <th className="text-right">Current</th>
                                    <th className="text-right">P&L</th>
                                    <th className="text-right">%</th>
                                </tr>
                            </thead>
                            <tbody>
                                {mockHoldings.map((h, i) => (
                                    <tr key={i}>
                                        <td className="font-semibold text-slate-900 dark:text-white">{h.symbol}</td>
                                        <td className="text-slate-500">{h.name}</td>
                                        <td className="text-right">{h.qty}</td>
                                        <td className="text-right">₹{h.avg.toFixed(2)}</td>
                                        <td className="text-right">₹{h.ltp.toFixed(2)}</td>
                                        <td className="text-right">₹{h.invested.toLocaleString('en-IN')}</td>
                                        <td className="text-right">₹{h.current.toLocaleString('en-IN')}</td>
                                        <td className={`text-right font-medium ${h.pnl >= 0 ? 'price-up' : 'price-down'}`}>
                                            {h.pnl >= 0 ? '+' : ''}₹{h.pnl.toFixed(2)}
                                        </td>
                                        <td className={`text-right ${h.pnl_percent >= 0 ? 'price-up' : 'price-down'}`}>
                                            {h.pnl_percent >= 0 ? '+' : ''}{h.pnl_percent.toFixed(2)}%
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Symbol</th>
                                    <th>Type</th>
                                    <th>Product</th>
                                    <th className="text-right">Qty</th>
                                    <th className="text-right">Avg Price</th>
                                    <th className="text-right">LTP</th>
                                    <th className="text-right">P&L</th>
                                    <th className="text-right">%</th>
                                    <th className="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {mockPositions.map((p, i) => (
                                    <tr key={i}>
                                        <td className="font-semibold text-slate-900 dark:text-white">{p.symbol}</td>
                                        <td><span className="badge badge-info">{p.type}</span></td>
                                        <td className="text-slate-500">{p.product}</td>
                                        <td className={`text-right ${p.qty < 0 ? 'text-loss-600' : ''}`}>{p.qty}</td>
                                        <td className="text-right">₹{p.avg.toFixed(2)}</td>
                                        <td className="text-right">₹{p.ltp.toFixed(2)}</td>
                                        <td className={`text-right font-medium ${p.pnl >= 0 ? 'price-up' : 'price-down'}`}>
                                            {p.pnl >= 0 ? '+' : ''}₹{p.pnl.toFixed(2)}
                                        </td>
                                        <td className={`text-right ${p.pnl_percent >= 0 ? 'price-up' : 'price-down'}`}>
                                            {p.pnl_percent >= 0 ? '+' : ''}{p.pnl_percent.toFixed(2)}%
                                        </td>
                                        <td className="text-center">
                                            <button className="btn btn-danger py-1 px-3 text-xs">Exit</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Portfolio;
