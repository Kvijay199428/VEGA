import React, { useEffect } from 'react';
import EquityLiveFeed from './EquityLiveFeed';

const EquityPopupPage: React.FC = () => {
    // Set formatted title
    useEffect(() => {
        document.title = "Equity Live Feed - VEGA TRADER";
    }, []);

    return (
        <div className="h-screen w-screen bg-background text-foreground overflow-hidden">
            {/* 
                EquityLiveFeed relies on 'h-full' to fill parent. 
                We provide a full-screen container. 
                Added p-4 to match Layout padding. 
            */}
            <div className="h-full p-4">
                <EquityLiveFeed />
            </div>
        </div>
    );
};

export default EquityPopupPage;
