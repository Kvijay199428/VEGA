import React, { useState } from 'react';
import { Brain, Play, Plus, Sparkles, BarChart2, Edit, Trash2 } from 'lucide-react';

const Strategies: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'predefined' | 'user' | 'ai'>('predefined');
    const [aiPrompt, setAiPrompt] = useState('');

    const predefinedStrategies = [
        { id: '1', name: 'Iron Condor', category: 'Options', risk: 'Low', winRate: 72, description: 'Profit from low volatility with limited risk' },
        { id: '2', name: 'Bull Call Spread', category: 'Options', risk: 'Medium', winRate: 65, description: 'Bullish on underlying with capped profit/loss' },
        { id: '3', name: 'Short Straddle', category: 'Options', risk: 'High', winRate: 58, description: 'Bet on low volatility, unlimited risk' },
        { id: '4', name: 'Covered Call', category: 'Options', risk: 'Low', winRate: 78, description: 'Generate income from holdings' },
        { id: '5', name: 'RSI Reversal', category: 'Equity', risk: 'Medium', winRate: 62, description: 'Mean reversion based on RSI levels' },
        { id: '6', name: 'MACD Crossover', category: 'Equity', risk: 'Medium', winRate: 55, description: 'Trend following with MACD signals' },
    ];

    const userStrategies = [
        { id: '1', name: 'My NIFTY Strategy', status: 'Active', trades: 24, pnl: 15420, winRate: 71 },
        { id: '2', name: 'Bank Nifty Scalper', status: 'Paused', trades: 156, pnl: -2340, winRate: 45 },
        { id: '3', name: 'Intraday Momentum', status: 'Active', trades: 89, pnl: 8750, winRate: 58 },
    ];

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Strategies</h1>
                    <p className="text-slate-500 dark:text-slate-400">Create, backtest, and execute trading strategies</p>
                </div>
                <button className="btn btn-primary">
                    <Plus size={18} className="mr-2" />
                    New Strategy
                </button>
            </div>

            {/* Tabs */}
            <div className="flex gap-4 border-b border-slate-200 dark:border-slate-700">
                {[
                    { key: 'predefined', icon: BarChart2, label: 'Predefined' },
                    { key: 'user', icon: Edit, label: 'My Strategies' },
                    { key: 'ai', icon: Sparkles, label: 'AI Generator' },
                ].map(({ key, icon: Icon, label }) => (
                    <button
                        key={key}
                        onClick={() => setActiveTab(key as typeof activeTab)}
                        className={`px-4 py-2 font-medium border-b-2 -mb-px transition-colors flex items-center gap-2 ${activeTab === key
                                ? 'text-primary-600 border-primary-600'
                                : 'text-slate-500 border-transparent hover:text-slate-700'
                            }`}
                    >
                        <Icon size={16} />
                        {label}
                    </button>
                ))}
            </div>

            {/* Content */}
            {activeTab === 'predefined' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {predefinedStrategies.map((strategy) => (
                        <div key={strategy.id} className="card p-5 hover:shadow-md transition-shadow">
                            <div className="flex items-start justify-between mb-3">
                                <div>
                                    <h3 className="font-semibold text-slate-900 dark:text-white">{strategy.name}</h3>
                                    <span className="badge badge-info text-xs">{strategy.category}</span>
                                </div>
                                <span className={`badge ${strategy.risk === 'Low' ? 'badge-success' :
                                        strategy.risk === 'Medium' ? 'badge-info' : 'badge-danger'
                                    }`}>
                                    {strategy.risk} Risk
                                </span>
                            </div>
                            <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">{strategy.description}</p>
                            <div className="flex items-center justify-between text-sm mb-4">
                                <span className="text-slate-500">Win Rate</span>
                                <span className="font-medium price-up">{strategy.winRate}%</span>
                            </div>
                            <div className="flex gap-2">
                                <button className="btn btn-secondary flex-1 py-2 text-sm">Details</button>
                                <button className="btn btn-primary flex-1 py-2 text-sm">
                                    <Play size={14} className="mr-1" /> Execute
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {activeTab === 'user' && (
                <div className="card">
                    <div className="overflow-x-auto">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Strategy Name</th>
                                    <th>Status</th>
                                    <th className="text-right">Total Trades</th>
                                    <th className="text-right">P&L</th>
                                    <th className="text-right">Win Rate</th>
                                    <th className="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {userStrategies.map((strategy) => (
                                    <tr key={strategy.id}>
                                        <td className="font-semibold text-slate-900 dark:text-white">{strategy.name}</td>
                                        <td>
                                            <span className={`badge ${strategy.status === 'Active' ? 'badge-success' : 'badge-info'}`}>
                                                {strategy.status}
                                            </span>
                                        </td>
                                        <td className="text-right">{strategy.trades}</td>
                                        <td className={`text-right font-medium ${strategy.pnl >= 0 ? 'price-up' : 'price-down'}`}>
                                            {strategy.pnl >= 0 ? '+' : ''}₹{strategy.pnl.toLocaleString('en-IN')}
                                        </td>
                                        <td className={`text-right ${strategy.winRate >= 50 ? 'price-up' : 'price-down'}`}>
                                            {strategy.winRate}%
                                        </td>
                                        <td className="text-center">
                                            <div className="flex justify-center gap-2">
                                                <button className="btn btn-ghost p-1.5"><Edit size={16} /></button>
                                                <button className="btn btn-ghost p-1.5 text-loss-500"><Trash2 size={16} /></button>
                                                <button className="btn btn-primary py-1 px-3 text-xs">
                                                    {strategy.status === 'Active' ? 'Pause' : 'Resume'}
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {activeTab === 'ai' && (
                <div className="max-w-3xl">
                    <div className="card p-6">
                        <div className="flex items-center gap-3 mb-6">
                            <div className="w-12 h-12 bg-gradient-to-br from-primary-500 to-profit-500 rounded-xl flex items-center justify-center">
                                <Brain size={24} className="text-white" />
                            </div>
                            <div>
                                <h2 className="font-semibold text-slate-900 dark:text-white">AI Strategy Generator</h2>
                                <p className="text-sm text-slate-500">Describe your trading idea and let AI create the strategy</p>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <div>
                                <label className="label">Describe your strategy</label>
                                <textarea
                                    value={aiPrompt}
                                    onChange={(e) => setAiPrompt(e.target.value)}
                                    rows={4}
                                    className="input resize-none"
                                    placeholder="E.g., I want a strategy that buys NIFTY calls when RSI is below 30 and sells when RSI crosses above 70. Maximum risk should be ₹5000 per trade..."
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="label">Risk Level</label>
                                    <select className="input">
                                        <option>Low</option>
                                        <option>Medium</option>
                                        <option>High</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="label">Max Capital</label>
                                    <input type="number" className="input" placeholder="₹100,000" />
                                </div>
                            </div>

                            <button className="btn btn-primary w-full py-3">
                                <Sparkles size={18} className="mr-2" />
                                Generate Strategy
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Strategies;
