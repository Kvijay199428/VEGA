/**
 * Options Chain Page
 * Main option chain view with full controls and table
 */

import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import useOptionChainData from '../hooks/useOptionChainData';
import useOptionChainSettings from '../hooks/useOptionChainSettings';
import { OptionChainControls, OptionChainTableHeader, OptionChainRow } from '../components/optionchain';
import OptionChainSettingsModal from '../components/OptionChainSettingsModal';
import useAutoScrollToATM from '../hooks/useAutoScrollToATM';
import OptionChainSkeletonRow from '../components/optionchain/OptionChainSkeletonRow';

const COMPACT_COLUMNS = {
    marketData: {
        volume: true,
        oi: true,
        closePrice: false, // Hidden in compact mode to save space
        prevOi: false,
        bid: false,
        bidQty: false,
        ask: false,
        askQty: false,
    },
    greeks: {
        vega: false,
        theta: true,
        gamma: false,
        delta: true,
        iv: false,
        pop: true,
    },
    custom: {
        valuation: true,
        bidAskChart: true,
    },
};

const OptionsChain: React.FC = () => {
    const [showSettings, setShowSettings] = useState(false);

    // Primary Data hook
    const primaryChain = useOptionChainData();

    // Secondary Data hook - completely independent state
    const secondaryChain = useOptionChainData();

    // Settings hook
    const {
        settings,
        saveSettings,
        updateCompareMode,
        resetToDefaults,
    } = useOptionChainSettings();

    // Synchronize secondary chain defaults when compare mode is enabled
    useEffect(() => {
        if (settings.compareMode.enabled && !secondaryChain.selectedUnderlying) {
            // Set same segment/exchange
            secondaryChain.setSegment(primaryChain.segment);
            secondaryChain.setExchange(primaryChain.exchange);

            // Set same underlying
            if (primaryChain.selectedUnderlying) {
                secondaryChain.setSelectedUnderlying(primaryChain.selectedUnderlying);
            }
        }
    }, [settings.compareMode.enabled, primaryChain.segment, primaryChain.exchange, primaryChain.selectedUnderlying]);

    // Select smart expiry for secondary chain:
    // 1. If Primary is on Current Expiry (index 0), Secondary gets Next Expiry (index 1).
    // 2. If Primary is on Future Expiry (index > 0), Secondary gets Current Expiry (index 0).
    // This auto-detects based on the Primary chain's selection.
    useEffect(() => {
        if (settings.compareMode.enabled && secondaryChain.expiries.length > 0) {

            // Find index of currently selected expiry in primary chain
            // Note: We use primaryChain.expiries to find the index of primaryChain.selectedExpiry
            const primaryExpiryIndex = primaryChain.expiries.indexOf(primaryChain.selectedExpiry);

            let targetExpiry = '';

            if (primaryExpiryIndex === 0) {
                // Primary is on Current Expiry -> Secondary should be Next Expiry (index 1) if available
                targetExpiry = secondaryChain.expiries.length > 1 ? secondaryChain.expiries[1] : secondaryChain.expiries[0];
            } else {
                // Primary is on Future Expiry -> Secondary should be Current Expiry (index 0)
                targetExpiry = secondaryChain.expiries[0];
            }

            // Only update if it's different to avoid loops (though check is cheap)
            // And only if secondary hasn't been manually set to something else? 
            // actually user requirement implies auto-switching logic is dominant when compare mode IS enabled or primary changes.
            if (secondaryChain.selectedExpiry !== targetExpiry) {
                secondaryChain.setSelectedExpiry(targetExpiry);
            }
        }
    }, [
        settings.compareMode.enabled,
        primaryChain.selectedExpiry,
        primaryChain.expiries,      // Dependency for index lookup
        secondaryChain.expiries     // Dependency for available secondary expiries
    ]);

    // Sync URL with selection state
    useEffect(() => {
        if (!primaryChain.selectedUnderlying || !primaryChain.selectedExpiry) return;

        // Helper to format: "Underlying+Expiry"
        const formatParam = (underlying: string, expiry: string) => {
            // Ensure we use a consistent format. 
            // If expiry is a date string, we might want to keep it as is or format it.
            // User requested "instrument+expiry", assuming raw value or simple format.
            // Using raw values for now as they are likely readable.
            return `${underlying}+${expiry}`;
        };

        const primaryStr = formatParam(primaryChain.selectedUnderlying, primaryChain.selectedExpiry);

        let urlQuery = `?${primaryStr}`;

        if (settings.compareMode.enabled && secondaryChain.selectedUnderlying && secondaryChain.selectedExpiry) {
            const secondaryStr = formatParam(secondaryChain.selectedUnderlying, secondaryChain.selectedExpiry);
            urlQuery += `&${secondaryStr}`;
        }

        // Update URL without reloading or adding to history stack (replace)
        // We use window.history to strictly control the format as requested
        const newUrl = `${window.location.pathname}${urlQuery}`;
        window.history.replaceState(null, '', newUrl);

    }, [
        primaryChain.selectedUnderlying,
        primaryChain.selectedExpiry,
        settings.compareMode.enabled,
        secondaryChain.selectedUnderlying,
        secondaryChain.selectedExpiry
    ]);



    // Auto-scroll to ATM strike for Primary Chain
    // Triggers on data load, ATM change, or layout changes (compare mode/layout)
    useAutoScrollToATM({
        dataLength: primaryChain.optionChain.length,
        atmIndex: primaryChain.atmIndex,
        rowIdPrefix: 'strike-row',
        containerId: 'strike-row-container',
        isEnabled: true,
        dependencies: [
            settings.compareMode.enabled,
            settings.compareMode.layout
        ]
    });

    // Auto-scroll to ATM strike for Secondary Chain
    // Triggers only when compare mode is enabled
    useAutoScrollToATM({
        dataLength: secondaryChain.optionChain.length,
        atmIndex: secondaryChain.atmIndex,
        rowIdPrefix: 'compare-strike-row',
        containerId: 'compare-strike-row-container',
        isEnabled: settings.compareMode.enabled,
        dependencies: [
            settings.compareMode.enabled,
            settings.compareMode.layout
        ]
    });

    const handleOpenPopup = () => {
        const popup = window.open(
            '/options-popup',
            'OptionChainPopup',
            'popup=yes,menubar=no,toolbar=no,location=no,status=no,resizable=yes,scrollbars=no'
        );
        if (popup) {
            popup.moveTo(0, 0);
            popup.resizeTo(window.screen.availWidth, window.screen.availHeight);
        }
    };

    // Helper to render a table instance
    const renderTable = (data: typeof primaryChain, columns: typeof settings.columns, idPrefix: string, isCompact: boolean) => (
        <div className="flex-1 flex flex-col overflow-hidden h-full">
            <div id={`${idPrefix}-container`} className="overflow-auto flex-1 scrollbar-hide relative">
                <table className="w-full option-chain-table">
                    <OptionChainTableHeader
                        callTotals={data.callTotals}
                        putTotals={data.putTotals}
                        columns={columns}
                        isCompact={isCompact}
                        spotPrice={data.spotPrice}
                        pcr={data.pcr}
                        instrument={data.selectedUnderlying}
                        expiry={data.selectedExpiry}
                    />
                    <tbody>
                        {data.isLoading && data.optionChain.length === 0 ? (
                            // Render Skeleton Rows for initial load
                            Array.from({ length: 20 }).map((_, i) => (
                                <OptionChainSkeletonRow
                                    key={`skeleton-${i}`}
                                    columns={columns}
                                    isCompact={isCompact}
                                />
                            ))
                        ) : data.optionChain.length === 0 ? (
                            <tr>
                                <td colSpan={37} className="text-center py-12 text-slate-500">
                                    {data.selectedUnderlying && data.selectedExpiry
                                        ? 'No option chain data available'
                                        : 'Select an underlying and expiry to view option chain'}
                                </td>
                            </tr>
                        ) : (
                            <>
                                {data.optionChain.map((row, i) => (
                                    <OptionChainRow
                                        key={i}
                                        row={row}
                                        index={i}
                                        spotPrice={data.spotPrice}
                                        atmStrike={data.atmStrike}
                                        getStrikeInfo={data.getStrikeInfo}
                                        columns={columns}
                                        idPrefix={idPrefix}
                                        isCompact={isCompact}
                                    />
                                ))}
                                {/* Show small spinner at bottom if background refreshing */}
                                {data.isLoading && (
                                    <tr>
                                        <td colSpan={37} className="text-center py-2 bg-slate-50/50 dark:bg-slate-900/50">
                                            <div className="flex items-center justify-center">
                                                <Loader2 className="animate-spin h-4 w-4 text-primary-400" />
                                            </div>
                                        </td>
                                    </tr>
                                )}
                            </>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );

    const isSideBySide = settings.compareMode.layout === 'side-by-side';

    // Determine props for rendering
    // Side by side uses compact columns for BOTH. Stacked uses full settings columns for BOTH.
    const effectiveColumns = settings.compareMode.enabled && isSideBySide ? COMPACT_COLUMNS : settings.columns;

    // DEBUG: Log effective columns to trace why full columns are showing
    useEffect(() => {
        if (settings.compareMode.enabled) {
            console.log('[OptionsChain] Compare Mode Enabled');
            console.log('[OptionsChain] Layout:', settings.compareMode.layout);
            console.log('[OptionsChain] isSideBySide:', isSideBySide);
            console.log('[OptionsChain] Effective Columns:', effectiveColumns);
        }
    }, [settings.compareMode.enabled, settings.compareMode.layout, isSideBySide, effectiveColumns]);

    return (
        <div className="flex flex-col h-full animate-fade-in" style={{ height: 'calc(100vh - 160px)' }}>
            {/* Primary Controls - Always Visible */}
            <div className="-mx-4 mb-4">
                <OptionChainControls
                    segment={primaryChain.segment}
                    exchange={primaryChain.exchange}
                    onSegmentChange={primaryChain.setSegment}
                    onExchangeChange={primaryChain.setExchange}
                    underlyings={primaryChain.underlyings}
                    selectedUnderlying={primaryChain.selectedUnderlying}
                    onUnderlyingChange={primaryChain.setSelectedUnderlying}
                    expiries={primaryChain.expiries}
                    selectedExpiry={primaryChain.selectedExpiry}
                    onExpiryChange={primaryChain.setSelectedExpiry}
                    isConnected={primaryChain.isConnected}
                    isLive={primaryChain.isLive}
                    compareMode={settings.compareMode.enabled}
                    compareLayout={settings.compareMode.layout}
                    onLayoutChange={(layout) => updateCompareMode({ layout })}
                    onOpenSettings={() => setShowSettings(true)}
                    onRefresh={() => primaryChain.refreshOptionChain(true)}
                    isLoading={primaryChain.isLoading}
                    onOpenPopup={handleOpenPopup}
                    // Secondary Props
                    secondarySegment={secondaryChain.segment}
                    secondaryExchange={secondaryChain.exchange}
                    onSecondarySegmentChange={secondaryChain.setSegment}
                    onSecondaryExchangeChange={secondaryChain.setExchange}
                    secondaryUnderlyings={secondaryChain.underlyings}
                    secondarySelectedUnderlying={secondaryChain.selectedUnderlying}
                    onSecondaryUnderlyingChange={secondaryChain.setSelectedUnderlying}
                    secondaryExpiries={secondaryChain.expiries}
                    secondarySelectedExpiry={secondaryChain.selectedExpiry}
                    onSecondaryExpiryChange={secondaryChain.setSelectedExpiry}
                />
            </div>

            {/* Content Area */}
            <div className={`card px-0 -mx-4 overflow-hidden flex-1 flex ${settings.compareMode.enabled && isSideBySide ? 'flex-row gap-4' : 'flex-col gap-4'}`}>

                {/* Primary Table Container */}
                <div className="flex-1 overflow-hidden flex flex-col">
                    {/* For stacked mode, we might want a label or header for primary, but controls are above so it's clear */}
                    {renderTable(primaryChain, effectiveColumns, 'strike-row', settings.compareMode.enabled && isSideBySide)}
                </div>

                {/* Secondary Option Chain */}
                {settings.compareMode.enabled && (
                    <div className={`flex-1 overflow-hidden flex flex-col ${isSideBySide ? 'border-l border-slate-200 dark:border-slate-700 pl-4' : 'border-t border-slate-200 dark:border-slate-700 pt-4'}`}>
                        {renderTable(secondaryChain, effectiveColumns, 'compare-strike-row', settings.compareMode.enabled && isSideBySide)}
                    </div>
                )}
            </div>

            {/* Settings Modal */}
            <OptionChainSettingsModal
                isOpen={showSettings}
                onClose={() => setShowSettings(false)}
                settings={settings}
                onSave={saveSettings}
                onReset={resetToDefaults}
            />
        </div>
    );
};

export default OptionsChain;
