import React, { useState, useEffect } from 'react';
import { Bell, Shield, Palette, Brain, Key, Save, Wifi, Loader2 } from 'lucide-react';
import { useTheme } from '../theme';
import api from '../services/api';
import { toast } from 'react-hot-toast';

interface SubscriptionSettings {
    equity_enabled: boolean;
    index_enabled: boolean;
    futures_enabled: boolean;
    options_enabled: boolean;
    mtf_enabled: boolean;
    mis_enabled: boolean;
}

const Settings: React.FC = () => {
    const { theme, setTheme } = useTheme();
    const [activeTab, setActiveTab] = useState<'general' | 'notifications' | 'risk' | 'ai' | 'api' | 'subscriptions'>('general');

    // Subscription Settings State
    const [subSettings, setSubSettings] = useState<SubscriptionSettings>({
        equity_enabled: true,
        index_enabled: true,
        futures_enabled: false,
        options_enabled: false,
        mtf_enabled: false,
        mis_enabled: false
    });
    const [isLoadingSubs, setIsLoadingSubs] = useState(false);
    const [isSavingSubs, setIsSavingSubs] = useState(false);

    const tabs = [
        { key: 'general', icon: Palette, label: 'General' },
        { key: 'notifications', icon: Bell, label: 'Notifications' },
        { key: 'subscriptions', icon: Wifi, label: 'Subscriptions' },
        { key: 'risk', icon: Shield, label: 'Risk Management' },
        { key: 'ai', icon: Brain, label: 'AI Preferences' },
        { key: 'api', icon: Key, label: 'API Keys' },
    ];

    // Fetch subscription settings
    useEffect(() => {
        if (activeTab === 'subscriptions') {
            fetchSubscriptionSettings();
        }
    }, [activeTab]);

    const fetchSubscriptionSettings = async () => {
        try {
            setIsLoadingSubs(true);
            const response = await api.get('/v1/settings/subscriptions');
            if (response.data?.status === 'success') {
                setSubSettings(response.data.data);
            }
        } catch (error) {
            console.error('Failed to fetch subscription settings:', error);
            toast.error('Failed to load subscription settings');
        } finally {
            setIsLoadingSubs(false);
        }
    };

    const handleSubToggle = (key: keyof SubscriptionSettings) => {
        setSubSettings(prev => ({
            ...prev,
            [key]: !prev[key]
        }));
    };

    const saveSubscriptionSettings = async () => {
        try {
            setIsSavingSubs(true);
            await api.put('/v1/settings/subscriptions', subSettings);
            toast.success('Subscription settings saved');
        } catch (error) {
            console.error('Failed to update subscription settings:', error);
            toast.error('Failed to save settings');
        } finally {
            setIsSavingSubs(false);
        }
    };

    return (
        <div className="space-y-6 animate-fade-in">
            <div>
                <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Settings</h1>
                <p className="text-slate-500 dark:text-slate-400">Manage your account and preferences</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {/* Sidebar */}
                <div className="card p-2">
                    <nav className="space-y-1">
                        {tabs.map(({ key, icon: Icon, label }) => (
                            <button
                                key={key}
                                onClick={() => setActiveTab(key as typeof activeTab)}
                                className={`w-full sidebar-item ${activeTab === key ? 'active' : ''}`}
                            >
                                <Icon size={18} />
                                <span>{label}</span>
                            </button>
                        ))}
                    </nav>
                </div>

                {/* Content */}
                <div className="lg:col-span-3 card">
                    <div className="card-header">
                        <h2 className="font-semibold text-slate-900 dark:text-white">
                            {tabs.find(t => t.key === activeTab)?.label}
                        </h2>
                    </div>
                    <div className="card-body">
                        {activeTab === 'general' && (
                            <div className="space-y-6 max-w-xl">
                                <div>
                                    <label className="label">Theme</label>
                                    <div className="grid grid-cols-3 gap-3">
                                        {(['light', 'dark', 'system'] as const).map((t) => (
                                            <button
                                                key={t}
                                                onClick={() => setTheme(t)}
                                                className={`py-3 px-4 rounded-lg border-2 transition-all ${theme === t
                                                    ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20'
                                                    : 'border-slate-200 dark:border-slate-700'
                                                    }`}
                                            >
                                                <span className="capitalize text-sm font-medium">{t}</span>
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                <div>
                                    <label className="label">Default Segment</label>
                                    <select className="input">
                                        <option>NSE - Equity</option>
                                        <option>NFO - Derivatives</option>
                                        <option>BSE - Equity</option>
                                    </select>
                                </div>

                                <div>
                                    <label className="label">Default Product Type</label>
                                    <select className="input">
                                        <option>INTRADAY</option>
                                        <option>CNC (Delivery)</option>
                                    </select>
                                </div>

                                <button className="btn btn-primary">
                                    <Save size={18} className="mr-2" />
                                    Save Changes
                                </button>
                            </div>
                        )}

                        {activeTab === 'notifications' && (
                            <div className="space-y-4 max-w-xl">
                                {[
                                    { label: 'Order Executed', desc: 'When an order is filled' },
                                    { label: 'Order Cancelled', desc: 'When an order is cancelled' },
                                    { label: 'Price Alerts', desc: 'When price targets are hit' },
                                    { label: 'Strategy Signals', desc: 'AI strategy recommendations' },
                                    { label: 'Market News', desc: 'Important market updates' },
                                ].map((item, i) => (
                                    <div key={i} className="flex items-center justify-between py-3 border-b border-slate-100 dark:border-slate-800">
                                        <div>
                                            <p className="font-medium text-slate-900 dark:text-white">{item.label}</p>
                                            <p className="text-sm text-slate-500">{item.desc}</p>
                                        </div>
                                        <label className="relative inline-flex items-center cursor-pointer">
                                            <input type="checkbox" defaultChecked className="sr-only peer" />
                                            <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-primary-500 rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                                        </label>
                                    </div>
                                ))}
                            </div>
                        )}

                        {activeTab === 'subscriptions' && (
                            <div className="space-y-6 max-w-xl">
                                {isLoadingSubs ? (
                                    <div className="flex justify-center py-12">
                                        <Loader2 className="animate-spin text-primary-600" size={32} />
                                    </div>
                                ) : (
                                    <>
                                        <div className="bg-blue-50 dark:bg-blue-900/20 text-blue-800 dark:text-blue-200 p-4 rounded-lg text-sm">
                                            Select which instrument types to subscribe to via WebSocket.
                                            Disabling unused types improves performance.
                                        </div>

                                        <div className="space-y-4">
                                            {[
                                                { key: 'equity_enabled', label: 'Equity', desc: 'NSE/BSE Stocks (Reliance, TCS, etc.)' },
                                                { key: 'index_enabled', label: 'Indices', desc: 'Market Indices (Nifty 50, Bank Nifty)' },
                                                { key: 'futures_enabled', label: 'Futures', desc: 'Equity & Index Futures' },
                                                { key: 'options_enabled', label: 'Options', desc: 'Call/Put Options (active contracts)' },
                                                { key: 'mtf_enabled', label: 'MTF Instruments', desc: 'Stocks eligible for Margin Trading Facility' },
                                                { key: 'mis_enabled', label: 'Intraday (MIS)', desc: 'Stocks eligible for Intraday trading' },
                                            ].map((item) => (
                                                <div key={item.key} className="flex items-center justify-between py-3 border-b border-slate-100 dark:border-slate-800">
                                                    <div>
                                                        <p className="font-medium text-slate-900 dark:text-white">{item.label}</p>
                                                        <p className="text-sm text-slate-500">{item.desc}</p>
                                                    </div>
                                                    <label className="relative inline-flex items-center cursor-pointer">
                                                        <input
                                                            type="checkbox"
                                                            checked={subSettings[item.key as keyof SubscriptionSettings]}
                                                            onChange={() => handleSubToggle(item.key as keyof SubscriptionSettings)}
                                                            className="sr-only peer"
                                                        />
                                                        <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-primary-500 rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                                                    </label>
                                                </div>
                                            ))}
                                        </div>

                                        <button
                                            className="btn btn-primary"
                                            onClick={saveSubscriptionSettings}
                                            disabled={isSavingSubs}
                                        >
                                            {isSavingSubs ? (
                                                <>
                                                    <Loader2 size={18} className="animate-spin mr-2" />
                                                    Saving...
                                                </>
                                            ) : (
                                                <>
                                                    <Save size={18} className="mr-2" />
                                                    Save Preferences
                                                </>
                                            )}
                                        </button>
                                    </>
                                )}
                            </div>
                        )}

                        {activeTab === 'risk' && (
                            <div className="space-y-6 max-w-xl">
                                <div>
                                    <label className="label">Max Risk Per Trade (%)</label>
                                    <input type="number" className="input" defaultValue="2" />
                                    <p className="text-xs text-slate-500 mt-1">Maximum % of capital to risk on a single trade</p>
                                </div>

                                <div>
                                    <label className="label">Max Daily Loss (₹)</label>
                                    <input type="number" className="input" defaultValue="10000" />
                                    <p className="text-xs text-slate-500 mt-1">Stop trading when daily loss exceeds this amount</p>
                                </div>

                                <div>
                                    <label className="label">Max Open Positions</label>
                                    <input type="number" className="input" defaultValue="5" />
                                </div>

                                <div>
                                    <label className="label">Default Stop Loss (%)</label>
                                    <input type="number" className="input" defaultValue="1.5" />
                                </div>

                                <button className="btn btn-primary">
                                    <Save size={18} className="mr-2" />
                                    Save Risk Settings
                                </button>
                            </div>
                        )}

                        {activeTab === 'ai' && (
                            <div className="space-y-6 max-w-xl">
                                <div>
                                    <label className="label">AI Confidence Threshold</label>
                                    <input type="range" min="50" max="95" defaultValue="70" className="w-full" />
                                    <div className="flex justify-between text-xs text-slate-500 mt-1">
                                        <span>50%</span><span>70%</span><span>95%</span>
                                    </div>
                                    <p className="text-xs text-slate-500 mt-2">Only show AI signals with confidence above this threshold</p>
                                </div>

                                <div>
                                    <label className="label">Preferred Strategy Types</label>
                                    <div className="space-y-2">
                                        {['Iron Condor', 'Bull Call Spread', 'Straddle', 'Momentum', 'Mean Reversion'].map((s) => (
                                            <label key={s} className="flex items-center gap-2">
                                                <input type="checkbox" defaultChecked className="rounded border-slate-300" />
                                                <span className="text-sm text-slate-700 dark:text-slate-300">{s}</span>
                                            </label>
                                        ))}
                                    </div>
                                </div>

                                <button className="btn btn-primary">
                                    <Save size={18} className="mr-2" />
                                    Save AI Preferences
                                </button>
                            </div>
                        )}

                        {activeTab === 'api' && (
                            <div className="space-y-6 max-w-xl">
                                <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
                                    <p className="text-sm text-amber-800 dark:text-amber-200">
                                        API credentials are stored securely. Never share your API keys.
                                    </p>
                                </div>

                                <div>
                                    <label className="label">Upstox API Key</label>
                                    <input type="password" className="input" placeholder="Enter API Key" />
                                </div>

                                <div>
                                    <label className="label">Upstox API Secret</label>
                                    <input type="password" className="input" placeholder="Enter API Secret" />
                                </div>

                                <div>
                                    <label className="label">Redirect URI</label>
                                    <input type="text" className="input" defaultValue="http://localhost:28020/api/v1/auth/upstox/callback" readOnly />
                                </div>

                                <button className="btn btn-primary">
                                    <Save size={18} className="mr-2" />
                                    Save API Settings
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Settings;