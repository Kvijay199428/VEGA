import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import useOptionChainData from '../hooks/useOptionChainData';
import useOptionChainSettings from '../hooks/useOptionChainSettings';
import { OptionChainControls, OptionChainTableHeader, OptionChainRow } from '../components/optionchain';
import OptionChainSettingsModal from '../components/OptionChainSettingsModal';
import useAutoScrollToATM from '../hooks/useAutoScrollToATM';
import OptionChainSkeletonRow from '../components/optionchain/OptionChainSkeletonRow';

const COMPACT_COLUMNS = {
    marketData: {
        volume: true,
        oi: true,
        closePrice: false,
        prevOi: false,
        bid: false,
        bidQty: false,
        ask: false,
        askQty: false,
    },
    greeks: {
        vega: false,
        theta: true,
        gamma: false,
        delta: true,
        iv: false,
        pop: true,
    },
    custom: {
        valuation: true,
        bidAskChart: true,
    },
};

const OptionChainPopupPage: React.FC = () => {
    const [showSettings, setShowSettings] = useState(false);

    // Primary Data hook
    const primaryChain = useOptionChainData();

    // Secondary Data hook - completely independent state
    const secondaryChain = useOptionChainData();

    // Settings hook
    const {
        settings,
        saveSettings,
        resetToDefaults,
    } = useOptionChainSettings();

    // Synchronize secondary chain defaults when compare mode is enabled
    useEffect(() => {
        if (settings.compareMode.enabled && !secondaryChain.selectedUnderlying) {
            // Set same segment/exchange
            secondaryChain.setSegment(primaryChain.segment);
            secondaryChain.setExchange(primaryChain.exchange);

            // Set same underlying
            if (primaryChain.selectedUnderlying) {
                secondaryChain.setSelectedUnderlying(primaryChain.selectedUnderlying);
            }
        }
    }, [settings.compareMode.enabled, primaryChain.segment, primaryChain.exchange, primaryChain.selectedUnderlying]);

    // Select smart expiry for secondary chain:
    // 1. If Primary is on Current Expiry (index 0), Secondary gets Next Expiry (index 1).
    // 2. If Primary is on Future Expiry (index > 0), Secondary gets Current Expiry (index 0).
    useEffect(() => {
        if (settings.compareMode.enabled && secondaryChain.expiries.length > 0) {

            // Find index of currently selected expiry in primary chain
            const primaryExpiryIndex = primaryChain.expiries.indexOf(primaryChain.selectedExpiry);

            let targetExpiry = '';

            if (primaryExpiryIndex === 0) {
                // Primary is on Current Expiry -> Secondary should be Next Expiry (index 1) if available
                targetExpiry = secondaryChain.expiries.length > 1 ? secondaryChain.expiries[1] : secondaryChain.expiries[0];
            } else {
                // Primary is on Future Expiry -> Secondary should be Current Expiry (index 0)
                targetExpiry = secondaryChain.expiries[0];
            }

            if (secondaryChain.selectedExpiry !== targetExpiry) {
                secondaryChain.setSelectedExpiry(targetExpiry);
            }
        }
    }, [
        settings.compareMode.enabled,
        primaryChain.selectedExpiry,
        primaryChain.expiries,
        secondaryChain.expiries
    ]);

    // Sync URL with selection state (same format as main page)
    useEffect(() => {
        if (!primaryChain.selectedUnderlying || !primaryChain.selectedExpiry) return;

        // Helper to format: "Underlying+Expiry"
        const formatParam = (underlying: string, expiry: string) => {
            return `${underlying}+${expiry}`;
        };

        const primaryStr = formatParam(primaryChain.selectedUnderlying, primaryChain.selectedExpiry);

        let urlQuery = `?${primaryStr}`;

        if (settings.compareMode.enabled && secondaryChain.selectedUnderlying && secondaryChain.selectedExpiry) {
            const secondaryStr = formatParam(secondaryChain.selectedUnderlying, secondaryChain.selectedExpiry);
            urlQuery += `&${secondaryStr}`;
        }

        // Update URL without reloading or adding to history stack (replace)
        const newUrl = `${window.location.pathname}${urlQuery}`;
        window.history.replaceState(null, '', newUrl);

    }, [
        primaryChain.selectedUnderlying,
        primaryChain.selectedExpiry,
        settings.compareMode.enabled,
        secondaryChain.selectedUnderlying,
        secondaryChain.selectedExpiry
    ]);

    // Auto-scroll to ATM strike when option chain loads (Primary)
    useAutoScrollToATM({
        dataLength: primaryChain.optionChain.length,
        atmIndex: primaryChain.atmIndex,
        rowIdPrefix: 'popup-strike-row',
        containerId: 'popup-strike-row-container',
        isEnabled: true
    });

    // Auto-scroll to ATM strike when option chain loads (Secondary)
    useAutoScrollToATM({
        dataLength: secondaryChain.optionChain.length,
        atmIndex: secondaryChain.atmIndex,
        rowIdPrefix: 'popup-compare-strike-row',
        containerId: 'popup-compare-strike-row-container',
        isEnabled: settings.compareMode.enabled,
        dependencies: [
            settings.compareMode.enabled,
            settings.compareMode.layout
        ]
    });

    // Set window title
    useEffect(() => {
        const underlying = primaryChain.underlyings.find(u => u.instrument_key === primaryChain.selectedUnderlying);
        const name = underlying?.name || 'Option Chain';
        document.title = `${name} - Option Chain | VEGA TRADER`;
    }, [primaryChain.selectedUnderlying, primaryChain.underlyings]);

    const isSideBySide = settings.compareMode.layout === 'side-by-side';
    const effectiveColumns = settings.compareMode.enabled && isSideBySide ? COMPACT_COLUMNS : settings.columns;

    // Helper to render a table instance
    const renderTable = (data: typeof primaryChain, columns: typeof settings.columns, idPrefix: string, isCompact: boolean) => (
        <div className="flex-1 flex flex-col overflow-hidden h-full">
            <div id={`${idPrefix}-container`} className="overflow-auto flex-1 scrollbar-hide relative">
                <table className="w-full option-chain-table text-xs">
                    <OptionChainTableHeader
                        callTotals={data.callTotals}
                        putTotals={data.putTotals}
                        columns={columns}
                        isCompact={isCompact}
                        isPopup={true}
                        spotPrice={data.spotPrice}
                        pcr={data.pcr}
                        instrument={data.selectedUnderlying}
                        expiry={data.selectedExpiry}
                    />
                    <tbody>
                        {data.isLoading && data.optionChain.length === 0 ? (
                            // Render Skeleton Rows for initial load
                            Array.from({ length: 20 }).map((_, i) => (
                                <OptionChainSkeletonRow
                                    key={`skeleton-${i}`}
                                    columns={columns}
                                    isCompact={isCompact}
                                    isPopup={true}
                                />
                            ))
                        ) : data.optionChain.length === 0 ? (
                            <tr>
                                <td colSpan={37} className="text-center py-12 text-slate-500">
                                    {data.selectedUnderlying && data.selectedExpiry
                                        ? 'No option chain data available'
                                        : 'Select an underlying and expiry to view option chain'}
                                </td>
                            </tr>
                        ) : (
                            <>
                                {data.optionChain.map((row, i) => (
                                    <OptionChainRow
                                        key={i}
                                        row={row}
                                        index={i}
                                        spotPrice={data.spotPrice}
                                        atmStrike={data.atmStrike}
                                        getStrikeInfo={data.getStrikeInfo}
                                        columns={columns}
                                        idPrefix={idPrefix}
                                        isCompact={isCompact}
                                        isPopup={true}
                                    />
                                ))}
                                {/* Show small spinner at bottom if background refreshing */}
                                {data.isLoading && (
                                    <tr>
                                        <td colSpan={37} className="text-center py-2 bg-slate-50/50 dark:bg-slate-900/50">
                                            <div className="flex items-center justify-center">
                                                <Loader2 className="animate-spin h-4 w-4 text-primary-400" />
                                            </div>
                                        </td>
                                    </tr>
                                )}
                            </>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );

    return (
        <div className="h-screen bg-slate-950 text-white flex flex-col overflow-hidden">
            {/* Header - Fixed, never scrolls */}
            <OptionChainControls
                segment={primaryChain.segment}
                exchange={primaryChain.exchange}
                onSegmentChange={primaryChain.setSegment}
                onExchangeChange={primaryChain.setExchange}
                underlyings={primaryChain.underlyings}
                selectedUnderlying={primaryChain.selectedUnderlying}
                onUnderlyingChange={primaryChain.setSelectedUnderlying}
                expiries={primaryChain.expiries}
                selectedExpiry={primaryChain.selectedExpiry}
                onExpiryChange={primaryChain.setSelectedExpiry}
                isConnected={primaryChain.isConnected}
                isLive={primaryChain.isLive}
                compareMode={settings.compareMode.enabled}
                onOpenSettings={() => setShowSettings(true)}
                onRefresh={() => primaryChain.refreshOptionChain(true)}
                isLoading={primaryChain.isLoading}
                isPopup={true}
                // Secondary Props
                secondarySegment={secondaryChain.segment}
                secondaryExchange={secondaryChain.exchange}
                onSecondarySegmentChange={secondaryChain.setSegment}
                onSecondaryExchangeChange={secondaryChain.setExchange}
                secondaryUnderlyings={secondaryChain.underlyings}
                secondarySelectedUnderlying={secondaryChain.selectedUnderlying}
                onSecondaryUnderlyingChange={secondaryChain.setSelectedUnderlying}
                secondaryExpiries={secondaryChain.expiries}
                secondarySelectedExpiry={secondaryChain.selectedExpiry}
                onSecondaryExpiryChange={secondaryChain.setSelectedExpiry}
            />

            {/* Content Area */}
            <div className={`flex-1 overflow-hidden flex ${settings.compareMode.enabled && isSideBySide ? 'flex-row gap-4' : 'flex-col gap-4'}`}>

                {/* Primary Table Container */}
                <div className="flex-1 overflow-hidden flex flex-col">
                    {renderTable(primaryChain, effectiveColumns, 'popup-strike-row', settings.compareMode.enabled && isSideBySide)}
                </div>

                {/* Secondary Option Chain */}
                {settings.compareMode.enabled && (
                    <div className={`flex-1 overflow-hidden flex flex-col ${isSideBySide ? 'border-l border-slate-200 dark:border-slate-700 pl-4' : 'border-t border-slate-200 dark:border-slate-700 pt-4'}`}>
                        {renderTable(secondaryChain, effectiveColumns, 'popup-compare-strike-row', settings.compareMode.enabled && isSideBySide)}
                    </div>
                )}
            </div>

            {/* Settings Modal */}
            <OptionChainSettingsModal
                isOpen={showSettings}
                onClose={() => setShowSettings(false)}
                settings={settings}
                onSave={saveSettings}
                onReset={resetToDefaults}
            />
        </div>
    );
};

export default OptionChainPopupPage;
