import React, { useEffect } from 'react';
import { TrendingUp, TrendingDown, DollarSign, PieChart, Activity, Brain, Wifi, WifiOff } from 'lucide-react';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { fetchAllPortfolioData } from '../store/slices/portfolioSlice';
import useIndexSpotPrices from '../hooks/useIndexSpotPrices';

const Dashboard: React.FC = () => {
    const dispatch = useAppDispatch();
    const { summary, holdings } = useAppSelector(state => state.portfolio);
    const { indices: liveIndices, isLive } = useIndexSpotPrices();

    useEffect(() => {
        dispatch(fetchAllPortfolioData());
    }, [dispatch]);

    // Portfolio data with safe defaults
    const portfolioData = {
        net_worth: summary?.net_worth ?? 0,
        pnl_day: summary?.pnl_day ?? 0,
        pnl_total: summary?.pnl_total ?? 0,
        margin_used: summary?.margin_used ?? 0,
        margin_available: summary?.margin_available ?? 0,
        buying_power: summary?.buying_power ?? 0,
    };

    const pnlPercent = portfolioData.net_worth > 0
        ? (portfolioData.pnl_day / (portfolioData.net_worth - portfolioData.pnl_day)) * 100
        : 0;

    const mockHoldings = holdings.length > 0 ? holdings : [
        { trading_symbol: 'RELIANCE', quantity: 50, average_price: 2450, last_price: 2512.50, pnl: 3125, pnl_percent: 2.55 },
        { trading_symbol: 'TCS', quantity: 25, average_price: 3850, last_price: 3920.00, pnl: 1750, pnl_percent: 1.82 },
        { trading_symbol: 'INFY', quantity: 100, average_price: 1520, last_price: 1485.00, pnl: -3500, pnl_percent: -2.30 },
        { trading_symbol: 'HDFCBANK', quantity: 40, average_price: 1680, last_price: 1715.50, pnl: 1420, pnl_percent: 2.11 },
        { trading_symbol: 'ICICIBANK', quantity: 75, average_price: 1050, last_price: 1082.25, pnl: 2418.75, pnl_percent: 3.07 },
    ];

    // Use live indices directly from WebSocket (showing all that are available)

    return (
        <div className="space-y-4 animate-fade-in pb-24">

            {/* Market Indices - Compact Scrollable View */}
            <div className="flex items-center gap-2 mb-1">
                <h3 className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
                    Market Indices
                </h3>
                {isLive ? (
                    <span className="flex items-center gap-1 text-xs text-green-500">
                        <Wifi size={12} />
                        <span className="animate-pulse">LIVE</span>
                    </span>
                ) : (
                    <span className="flex items-center gap-1 text-xs text-slate-400">
                        <WifiOff size={12} />
                        <span>Offline</span>
                    </span>
                )}
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                {liveIndices.length === 0 ? (
                    // Loading placeholders
                    Array.from({ length: 4 }).map((_, i) => (
                        <div
                            key={i}
                            className="flex-shrink-0 bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 min-w-[140px] animate-pulse"
                        >
                            <div className="h-3 bg-slate-200 dark:bg-slate-700 rounded w-16 mb-2"></div>
                            <div className="h-5 bg-slate-200 dark:bg-slate-700 rounded w-20"></div>
                        </div>
                    ))
                ) : (
                    liveIndices.map((index) => (
                        <div
                            key={index.instrument_key}
                            className="flex-shrink-0 bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 min-w-[140px] hover:shadow-md transition-shadow"
                        >
                            <div className="flex items-center justify-between gap-2">
                                <span className="text-xs font-semibold text-slate-600 dark:text-slate-300 truncate">
                                    {index.name}
                                </span>
                                {index.spot_price > 0 && (
                                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${index.change >= 0
                                        ? 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400'
                                        : 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400'
                                        }`}>
                                        {index.change >= 0 ? '+' : ''}{index.change_percent.toFixed(2)}%
                                    </span>
                                )}
                            </div>
                            <p className={`text-base font-bold mt-0.5 ${index.spot_price === 0
                                ? 'text-slate-400'
                                : 'text-slate-900 dark:text-white'
                                }`}>
                                {index.spot_price > 0
                                    ? `₹${index.spot_price.toLocaleString('en-IN', { maximumFractionDigits: 1 })}`
                                    : '---'
                                }
                            </p>
                            {index.spot_price > 0 && (
                                <p className={`text-[11px] font-medium ${index.change >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                                    }`}>
                                    {index.change >= 0 ? '+' : ''}₹{index.change.toFixed(1)}
                                </p>
                            )}
                        </div>
                    ))
                )}
            </div>

            {/* Portfolio summary cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Net Worth */}
                <div className="stat-card">
                    <div className="flex items-center justify-between">
                        <span className="stat-label">Net Worth</span>
                        <DollarSign size={20} className="text-primary-500" />
                    </div>
                    <p className="stat-value">₹{portfolioData.net_worth.toLocaleString('en-IN')}</p>
                    <p className={`stat-change ${portfolioData.pnl_total >= 0 ? 'price-up' : 'price-down'}`}>
                        {portfolioData.pnl_total >= 0 ? '+' : ''}₹{portfolioData.pnl_total.toLocaleString('en-IN')} overall
                    </p>
                </div>

                {/* Daily P&L */}
                <div className="stat-card">
                    <div className="flex items-center justify-between">
                        <span className="stat-label">Today's P&L</span>
                        {portfolioData.pnl_day >= 0 ? (
                            <TrendingUp size={20} className="text-profit-500" />
                        ) : (
                            <TrendingDown size={20} className="text-loss-500" />
                        )}
                    </div>
                    <p className={`stat-value ${portfolioData.pnl_day >= 0 ? 'price-up' : 'price-down'}`}>
                        {portfolioData.pnl_day >= 0 ? '+' : ''}₹{portfolioData.pnl_day.toLocaleString('en-IN')}
                    </p>
                    <p className={`stat-change ${pnlPercent >= 0 ? 'price-up' : 'price-down'}`}>
                        {pnlPercent >= 0 ? '+' : ''}{pnlPercent.toFixed(2)}%
                    </p>
                </div>

                {/* Margin Used */}
                <div className="stat-card">
                    <div className="flex items-center justify-between">
                        <span className="stat-label">Margin Used</span>
                        <PieChart size={20} className="text-amber-500" />
                    </div>
                    <p className="stat-value">
                        {((portfolioData.margin_used / (portfolioData.margin_used + portfolioData.margin_available)) * 100).toFixed(1)}%
                    </p>
                    <p className="stat-change text-slate-500">
                        ₹{portfolioData.margin_used.toLocaleString('en-IN')} / ₹{(portfolioData.margin_used + portfolioData.margin_available).toLocaleString('en-IN')}
                    </p>
                </div>

                {/* Buying Power */}
                <div className="stat-card">
                    <div className="flex items-center justify-between">
                        <span className="stat-label">Buying Power</span>
                        <Activity size={20} className="text-profit-500" />
                    </div>
                    <p className="stat-value">₹{portfolioData.buying_power.toLocaleString('en-IN')}</p>
                    <p className="stat-change text-slate-500">Available for trading</p>
                </div>
            </div>

            {/* Holdings and AI section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Holdings table */}
                <div className="lg:col-span-2 card">
                    <div className="card-header flex items-center justify-between">
                        <h2 className="text-lg font-semibold text-slate-900 dark:text-white">Top Holdings</h2>
                        <button className="text-sm text-primary-600 hover:text-primary-500">View All</button>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Symbol</th>
                                    <th className="text-right">Qty</th>
                                    <th className="text-right">Avg Price</th>
                                    <th className="text-right">LTP</th>
                                    <th className="text-right">P&L</th>
                                    <th className="text-right">%</th>
                                </tr>
                            </thead>
                            <tbody>
                                {mockHoldings.map((holding, i) => (
                                    <tr key={i}>
                                        <td className="font-medium text-slate-900 dark:text-white">{holding.trading_symbol}</td>
                                        <td className="text-right">{holding.quantity}</td>
                                        <td className="text-right">₹{holding.average_price.toFixed(2)}</td>
                                        <td className="text-right">₹{holding.last_price.toFixed(2)}</td>
                                        <td className={`text-right font-medium ${holding.pnl >= 0 ? 'price-up' : 'price-down'}`}>
                                            {holding.pnl >= 0 ? '+' : ''}₹{holding.pnl.toFixed(2)}
                                        </td>
                                        <td className={`text-right ${holding.pnl_percent >= 0 ? 'price-up' : 'price-down'}`}>
                                            {holding.pnl_percent >= 0 ? '+' : ''}{holding.pnl_percent.toFixed(2)}%
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* AI Recommendations */}
                <div className="card">
                    <div className="card-header">
                        <h2 className="text-lg font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                            <Brain size={20} className="text-primary-500" />
                            AI Insights
                        </h2>
                    </div>
                    <div className="card-body space-y-4">
                        {/* AI recommendation card */}
                        <div className="bg-gradient-to-br from-primary-500/10 to-profit-500/10 border border-primary-500/20 rounded-lg p-4">
                            <div className="flex items-center gap-2 mb-2">
                                <span className="badge badge-info">High Confidence</span>
                                <span className="text-xs text-slate-500">78%</span>
                            </div>
                            <h3 className="font-semibold text-slate-900 dark:text-white mb-1">NIFTY Call Spread</h3>
                            <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
                                Sell 19500 CE, Buy 19600 CE - Expiry Dec 26
                            </p>
                            <div className="flex items-center justify-between text-sm mb-3">
                                <span className="text-slate-500">Est. Profit</span>
                                <span className="price-up font-medium">+₹2,500</span>
                            </div>
                            <button className="btn btn-primary w-full text-sm">
                                Execute Strategy
                            </button>
                        </div>

                        {/* Quick stats */}
                        <div className="space-y-3">
                            <div className="flex items-center justify-between text-sm">
                                <span className="text-slate-500">Strategies Active</span>
                                <span className="font-medium text-slate-900 dark:text-white">3</span>
                            </div>
                            <div className="flex items-center justify-between text-sm">
                                <span className="text-slate-500">Win Rate (30d)</span>
                                <span className="font-medium price-up">72%</span>
                            </div>
                            <div className="flex items-center justify-between text-sm">
                                <span className="text-slate-500">AI Signals Today</span>
                                <span className="font-medium text-slate-900 dark:text-white">5</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
