import React, { useState } from 'react';
import { Search, X, RefreshCw, Filter } from 'lucide-react';

const Trading: React.FC = () => {
    const [orderType, setOrderType] = useState<'MARKET' | 'LIMIT' | 'SL' | 'SL-M'>('MARKET');
    const [transactionType, setTransactionType] = useState<'BUY' | 'SELL'>('BUY');
    const [product, setProduct] = useState<'CNC' | 'INTRADAY'>('INTRADAY');
    const [quantity, setQuantity] = useState('');
    const [price, setPrice] = useState('');
    const [symbol, setSymbol] = useState('RELIANCE');

    // Mock open orders
    const mockOrders = [
        { id: '1', symbol: 'NIFTY25D19500CE', type: 'LIMIT', side: 'BUY', qty: 50, price: 85.50, status: 'OPEN', time: '10:30:25' },
        { id: '2', symbol: 'RELIANCE', type: 'MARKET', side: 'SELL', qty: 25, price: 2510.00, status: 'PENDING', time: '10:28:15' },
        { id: '3', symbol: 'TCS', type: 'SL', side: 'SELL', qty: 10, price: 3900.00, status: 'OPEN', time: '10:15:00' },
    ];

    const mockTrades = [
        { id: '1', symbol: 'INFY', side: 'BUY', qty: 100, price: 1482.50, value: 148250, time: '09:45:30', status: 'COMPLETE' },
        { id: '2', symbol: 'HDFCBANK', side: 'SELL', qty: 50, price: 1710.00, value: 85500, time: '09:30:15', status: 'COMPLETE' },
        { id: '3', symbol: 'SBIN', side: 'BUY', qty: 200, price: 618.25, value: 123650, time: '09:20:00', status: 'COMPLETE' },
    ];

    const handlePlaceOrder = () => {
        console.log('Placing order:', { symbol, orderType, transactionType, product, quantity, price });
    };

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Trading</h1>
                    <p className="text-slate-500 dark:text-slate-400">Place and manage your orders</p>
                </div>
                <button className="btn btn-ghost">
                    <RefreshCw size={18} className="mr-2" />
                    Refresh
                </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Order form */}
                <div className="card">
                    <div className="card-header">
                        <h2 className="font-semibold text-slate-900 dark:text-white">Place Order</h2>
                    </div>
                    <div className="card-body space-y-4">
                        {/* Symbol search */}
                        <div>
                            <label className="label">Symbol</label>
                            <div className="relative">
                                <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                                <input
                                    type="text"
                                    value={symbol}
                                    onChange={(e) => setSymbol(e.target.value.toUpperCase())}
                                    className="input pl-10"
                                    placeholder="Search symbol..."
                                />
                            </div>
                            <p className="text-xs text-slate-500 mt-1">LTP: ₹2,512.50 | Change: +1.02%</p>
                        </div>

                        {/* Transaction type */}
                        <div className="grid grid-cols-2 gap-2">
                            <button
                                onClick={() => setTransactionType('BUY')}
                                className={`py-2 px-4 rounded-lg font-medium transition-all ${transactionType === 'BUY'
                                    ? 'bg-profit-600 text-white'
                                    : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                                    }`}
                            >
                                BUY
                            </button>
                            <button
                                onClick={() => setTransactionType('SELL')}
                                className={`py-2 px-4 rounded-lg font-medium transition-all ${transactionType === 'SELL'
                                    ? 'bg-loss-600 text-white'
                                    : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                                    }`}
                            >
                                SELL
                            </button>
                        </div>

                        {/* Product type */}
                        <div>
                            <label className="label">Product</label>
                            <div className="grid grid-cols-2 gap-2">
                                {(['INTRADAY', 'CNC'] as const).map((p) => (
                                    <button
                                        key={p}
                                        onClick={() => setProduct(p)}
                                        className={`py-2 px-3 rounded-lg text-sm font-medium transition-all ${product === p
                                            ? 'bg-primary-600 text-white'
                                            : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                                            }`}
                                    >
                                        {p}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Order type */}
                        <div>
                            <label className="label">Order Type</label>
                            <div className="grid grid-cols-4 gap-1">
                                {(['MARKET', 'LIMIT', 'SL', 'SL-M'] as const).map((type) => (
                                    <button
                                        key={type}
                                        onClick={() => setOrderType(type)}
                                        className={`py-1.5 px-2 rounded text-xs font-medium transition-all ${orderType === type
                                            ? 'bg-primary-600 text-white'
                                            : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                                            }`}
                                    >
                                        {type}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Quantity and Price */}
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="label">Quantity</label>
                                <input
                                    type="number"
                                    value={quantity}
                                    onChange={(e) => setQuantity(e.target.value)}
                                    className="input"
                                    placeholder="0"
                                />
                            </div>
                            {orderType !== 'MARKET' && (
                                <div>
                                    <label className="label">Price</label>
                                    <input
                                        type="number"
                                        value={price}
                                        onChange={(e) => setPrice(e.target.value)}
                                        className="input"
                                        placeholder="0.00"
                                    />
                                </div>
                            )}
                        </div>

                        {/* Order summary */}
                        <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-3">
                            <div className="flex justify-between text-sm mb-1">
                                <span className="text-slate-500">Est. Value</span>
                                <span className="font-medium text-slate-900 dark:text-white">
                                    ₹{((parseInt(quantity) || 0) * 2512.50).toLocaleString('en-IN')}
                                </span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-500">Margin Required</span>
                                <span className="font-medium text-slate-900 dark:text-white">
                                    ₹{(((parseInt(quantity) || 0) * 2512.50) * 0.2).toLocaleString('en-IN')}
                                </span>
                            </div>
                        </div>

                        {/* Place order button */}
                        <button
                            onClick={handlePlaceOrder}
                            className={`w-full py-3 rounded-lg font-semibold text-white transition-all ${transactionType === 'BUY'
                                ? 'bg-profit-600 hover:bg-profit-700'
                                : 'bg-loss-600 hover:bg-loss-700'
                                }`}
                        >
                            {transactionType === 'BUY' ? 'Place Buy Order' : 'Place Sell Order'}
                        </button>
                    </div>
                </div>

                {/* Open Orders */}
                <div className="lg:col-span-2 space-y-6">
                    {/* Open orders */}
                    <div className="card">
                        <div className="card-header flex items-center justify-between">
                            <h2 className="font-semibold text-slate-900 dark:text-white">Open Orders ({mockOrders.length})</h2>
                            <button className="btn btn-ghost text-sm py-1">
                                <Filter size={16} className="mr-1" /> Filter
                            </button>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th>Symbol</th>
                                        <th>Type</th>
                                        <th>Side</th>
                                        <th className="text-right">Qty</th>
                                        <th className="text-right">Price</th>
                                        <th>Status</th>
                                        <th>Time</th>
                                        <th className="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {mockOrders.map((order) => (
                                        <tr key={order.id}>
                                            <td className="font-medium text-slate-900 dark:text-white">{order.symbol}</td>
                                            <td><span className="badge badge-info">{order.type}</span></td>
                                            <td className={order.side === 'BUY' ? 'price-up' : 'price-down'}>{order.side}</td>
                                            <td className="text-right">{order.qty}</td>
                                            <td className="text-right">₹{order.price.toFixed(2)}</td>
                                            <td><span className={`badge ${order.status === 'OPEN' ? 'badge-success' : 'badge-info'}`}>{order.status}</span></td>
                                            <td className="text-slate-500">{order.time}</td>
                                            <td className="text-center">
                                                <button className="text-loss-500 hover:text-loss-600">
                                                    <X size={18} />
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    {/* Trade history */}
                    <div className="card">
                        <div className="card-header">
                            <h2 className="font-semibold text-slate-900 dark:text-white">Recent Trades</h2>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th>Symbol</th>
                                        <th>Side</th>
                                        <th className="text-right">Qty</th>
                                        <th className="text-right">Price</th>
                                        <th className="text-right">Value</th>
                                        <th>Time</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {mockTrades.map((trade) => (
                                        <tr key={trade.id}>
                                            <td className="font-medium text-slate-900 dark:text-white">{trade.symbol}</td>
                                            <td className={trade.side === 'BUY' ? 'price-up' : 'price-down'}>{trade.side}</td>
                                            <td className="text-right">{trade.qty}</td>
                                            <td className="text-right">₹{trade.price.toFixed(2)}</td>
                                            <td className="text-right font-medium">₹{trade.value.toLocaleString('en-IN')}</td>
                                            <td className="text-slate-500">{trade.time}</td>
                                            <td><span className="badge badge-success">{trade.status}</span></td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Trading;
