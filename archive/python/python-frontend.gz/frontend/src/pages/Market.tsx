import React, { useEffect, useState } from 'react';
import { Search, TrendingUp, TrendingDown, Star, BarChart2 } from 'lucide-react';
import { useAppDispatch, useAppSelector } from '../store/hooks';
import { fetchInstruments, addToWatchlist, removeFromWatchlist } from '../store/slices/marketSlice';

const Market: React.FC = () => {
    const dispatch = useAppDispatch();
    const { watchlist } = useAppSelector(state => state.market);
    const [searchQuery, setSearchQuery] = useState('');
    const [activeTab, setActiveTab] = useState<'watchlist' | 'indices' | 'gainers' | 'losers'>('watchlist');

    useEffect(() => {
        dispatch(fetchInstruments({ exchange: 'NSE' }));
    }, [dispatch]);

    // Mock watchlist data
    const mockWatchlistData = [
        { symbol: 'RELIANCE', name: 'Reliance Industries', price: 2512.50, change: 25.30, change_percent: 1.02, volume: '12.5M' },
        { symbol: 'TCS', name: 'Tata Consultancy', price: 3920.00, change: -15.20, change_percent: -0.39, volume: '8.2M' },
        { symbol: 'INFY', name: 'Infosys Limited', price: 1485.00, change: 12.75, change_percent: 0.87, volume: '15.1M' },
        { symbol: 'HDFCBANK', name: 'HDFC Bank', price: 1715.50, change: 8.90, change_percent: 0.52, volume: '9.8M' },
        { symbol: 'ICICIBANK', name: 'ICICI Bank', price: 1082.25, change: -5.40, change_percent: -0.50, volume: '11.2M' },
        { symbol: 'SBIN', name: 'State Bank of India', price: 625.80, change: 7.25, change_percent: 1.17, volume: '22.5M' },
        { symbol: 'BHARTIARTL', name: 'Bharti Airtel', price: 1245.00, change: 18.50, change_percent: 1.51, volume: '6.8M' },
        { symbol: 'WIPRO', name: 'Wipro Limited', price: 465.30, change: -3.20, change_percent: -0.68, volume: '7.5M' },
    ];

    const mockGainers = [...mockWatchlistData].sort((a, b) => b.change_percent - a.change_percent).slice(0, 5);
    const mockLosers = [...mockWatchlistData].sort((a, b) => a.change_percent - b.change_percent).slice(0, 5);

    const filteredData = mockWatchlistData.filter(item =>
        item.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className="space-y-6 animate-fade-in">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Market Data</h1>
                    <p className="text-slate-500 dark:text-slate-400">Live quotes and market overview</p>
                </div>

                {/* Search */}
                <div className="relative w-full md:w-80">
                    <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search symbols..."
                        className="input pl-10"
                    />
                </div>
            </div>

            {/* Tabs */}
            <div className="flex gap-2 border-b border-slate-200 dark:border-slate-700">
                {(['watchlist', 'indices', 'gainers', 'losers'] as const).map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition-colors ${activeTab === tab
                            ? 'text-primary-600 border-primary-600'
                            : 'text-slate-500 border-transparent hover:text-slate-700'
                            }`}
                    >
                        {tab === 'watchlist' && <Star size={16} className="inline mr-1" />}
                        {tab === 'gainers' && <TrendingUp size={16} className="inline mr-1" />}
                        {tab === 'losers' && <TrendingDown size={16} className="inline mr-1" />}
                        {tab === 'indices' && <BarChart2 size={16} className="inline mr-1" />}
                        {tab.charAt(0).toUpperCase() + tab.slice(1)}
                    </button>
                ))}
            </div>

            {/* Content */}
            <div className="card">
                <div className="overflow-x-auto">
                    <table className="table">
                        <thead>
                            <tr>
                                <th className="w-12"></th>
                                <th>Symbol</th>
                                <th>Name</th>
                                <th className="text-right">LTP</th>
                                <th className="text-right">Change</th>
                                <th className="text-right">%</th>
                                <th className="text-right">Volume</th>
                                <th className="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(activeTab === 'gainers' ? mockGainers : activeTab === 'losers' ? mockLosers : filteredData).map((item, i) => (
                                <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer">
                                    <td>
                                        <button
                                            className="text-amber-400 hover:text-amber-500"
                                            onClick={() => watchlist.includes(item.symbol)
                                                ? dispatch(removeFromWatchlist(item.symbol))
                                                : dispatch(addToWatchlist(item.symbol))
                                            }
                                        >
                                            <Star size={18} fill={watchlist.includes(item.symbol) ? 'currentColor' : 'none'} />
                                        </button>
                                    </td>
                                    <td className="font-semibold text-slate-900 dark:text-white">{item.symbol}</td>
                                    <td className="text-slate-500 dark:text-slate-400">{item.name}</td>
                                    <td className="text-right font-medium text-slate-900 dark:text-white">
                                        ₹{item.price.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                                    </td>
                                    <td className={`text-right ${item.change >= 0 ? 'price-up' : 'price-down'}`}>
                                        {item.change >= 0 ? '+' : ''}₹{item.change.toFixed(2)}
                                    </td>
                                    <td className={`text-right font-medium ${item.change_percent >= 0 ? 'price-up' : 'price-down'}`}>
                                        {item.change_percent >= 0 ? '+' : ''}{item.change_percent.toFixed(2)}%
                                    </td>
                                    <td className="text-right text-slate-500">{item.volume}</td>
                                    <td className="text-center">
                                        <div className="flex justify-center gap-2">
                                            <button className="btn btn-success py-1 px-3 text-xs">Buy</button>
                                            <button className="btn btn-danger py-1 px-3 text-xs">Sell</button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Market;
