import { addToast, addNotification } from '../store/slices/uiSlice';
import { store } from '../store';

/**
 * Upstox API error codes and their user-friendly messages
 */
export const UPSTOX_ERROR_MESSAGES: Record<string, { message: string; severity: 'error' | 'warning' | 'info' }> = {
    // Common API errors
    'UDAPI10000': {
        message: 'Invalid API request. Please try again.',
        severity: 'error'
    },
    'UDAPI100016': {
        message: 'Invalid credentials. Please check your login details.',
        severity: 'error'
    },
    'UDAPI10005': {
        message: 'Too many requests. Please wait and try again.',
        severity: 'warning'
    },
    'UDAPI100015': {
        message: 'API version error. Please contact support.',
        severity: 'error'
    },
    'UDAPI100050': {
        message: 'Invalid authentication token. Please login again.',
        severity: 'error'
    },
    'UDAPI100067': {
        message: 'This operation is not permitted with extended token.',
        severity: 'warning'
    },
    'UDAPI100036': {
        message: 'Invalid input provided. Please check your request.',
        severity: 'error'
    },
    'UDAPI100038': {
        message: 'Invalid input provided. Please check your request.',
        severity: 'error'
    },
    'UDAPI100073': {
        message: 'Your account is inactive. Please contact support.',
        severity: 'error'
    },
    'UDAPI100500': {
        message: 'An unexpected error occurred. Please contact support.',
        severity: 'error'
    },

    // Service-specific errors
    'UDAPI100072': {
        message: 'This service is only available during market hours (5:30 AM - 12:00 AM IST).',
        severity: 'info'
    },
    'UDAPI100060': {
        message: 'Resource not found. Please check your request.',
        severity: 'warning'
    },
    'UDAPI100068': {
        message: 'Incorrect client credentials. Please verify your API keys.',
        severity: 'error'
    },
};

/**
 * Extract error information from API response
 */
function parseApiError(error: any): { code: string; message: string; severity: 'error' | 'warning' | 'info' } {
    // Check if it's an Upstox error response
    if (error?.response?.data?.error) {
        const errorData = error.response.data.error;
        return {
            code: errorData.code || 'UNKNOWN',
            message: errorData.message || 'An error occurred',
            severity: errorData.severity || 'error'
        };
    }

    // Check for detail message (FastAPI format)
    if (error?.response?.data?.detail) {
        const detail = error.response.data.detail;
        // Try to extract error code from detail message
        const codeMatch = detail.match(/UDAPI\d+/);
        if (codeMatch) {
            const code = codeMatch[0];
            const errorInfo = UPSTOX_ERROR_MESSAGES[code];
            if (errorInfo) {
                return {
                    code,
                    message: errorInfo.message,
                    severity: errorInfo.severity
                };
            }
        }
        return {
            code: 'UNKNOWN',
            message: detail,
            severity: 'error'
        };
    }

    // Generic error
    return {
        code: 'UNKNOWN',
        message: error?.message || 'An unexpected error occurred',
        severity: 'error'
    };
}

/**
 * Handle Upstox API errors and show toast notifications
 */
export function handleUpstoxError(error: any, context?: string): void {
    const errorInfo = parseApiError(error);

    // Map severity to toast type
    const toastType = errorInfo.severity === 'info' ? 'info' :
        errorInfo.severity === 'warning' ? 'warning' : 'error';

    // Determine duration based on severity
    const duration = errorInfo.severity === 'error' ? 6000 :
        errorInfo.severity === 'warning' ? 5000 : 4000;

    const fullMessage = context ? `${context}: ${errorInfo.message}` : errorInfo.message;

    // Show toast notification (temporary)
    store.dispatch(addToast({
        type: toastType,
        message: fullMessage,
        duration
    }));

    // Also add to persistent notification panel
    store.dispatch(addNotification({
        type: toastType,
        title: context || 'API Error',
        message: `${errorInfo.code !== 'UNKNOWN' ? `[${errorInfo.code}] ` : ''}${errorInfo.message}`
    }));

    // Log to console in development
    if (process.env.NODE_ENV === 'development') {
        console.error('[Upstox Error]', {
            code: errorInfo.code,
            message: errorInfo.message,
            severity: errorInfo.severity,
            context,
            originalError: error
        });
    }
}

/**
 * Check if error is due to service hours
 */
export function isServiceHoursError(error: any): boolean {
    const errorInfo = parseApiError(error);
    return errorInfo.code === 'UDAPI100072';
}

/**
 * Check if error is authentication related
 */
export function isAuthError(error: any): boolean {
    const errorInfo = parseApiError(error);
    const authErrors = ['UDAPI100016', 'UDAPI100050', 'UDAPI100068', 'UDAPI100073'];
    return authErrors.includes(errorInfo.code);
}

/**
 * Check if error should trigger a retry
 */
export function shouldRetry(error: any): boolean {
    const errorInfo = parseApiError(error);
    const retryableErrors = ['UDAPI10005', 'UDAPI100500', 'UDAPI100072'];
    return retryableErrors.includes(errorInfo.code);
}
