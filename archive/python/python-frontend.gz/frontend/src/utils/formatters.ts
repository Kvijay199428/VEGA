/**
 * Formatting Utilities
 * Shared number and string formatting functions
 */

/**
 * Format a number with specified decimal places
 */
export const formatNumber = (num: number, decimals: number = 2): string => {
    return num?.toFixed(decimals) || '-';
};

/**
 * Format large numbers with K/L/Cr notation (Indian numbering system)
 * K = Thousands (1,000)
 * L = Lakhs (100,000)
 * Cr = Crores (10,000,000)
 */
export const formatLargeNumber = (num: number): string => {
    if (num >= 10000000) return (num / 10000000).toFixed(2) + ' Cr';
    if (num >= 100000) return (num / 100000).toFixed(2) + ' L';
    if (num >= 1000) return (num / 1000).toFixed(2) + ' K';
    return num?.toString() || '-';
};

/**
 * Format price for display with Indian locale formatting
 */
export const formatPrice = (price: number): string => {
    return price.toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
};

/**
 * Format percentage change with sign
 */
export const formatChange = (change: number): string => {
    const sign = change >= 0 ? '+' : '';
    return `${sign}${change.toFixed(2)}%`;
};

/**
 * Get CSS class for color based on positive/negative value
 */
export const getChangeColor = (val: number): string => {
    if (val > 0) return 'text-green-600 dark:text-green-400';
    if (val < 0) return 'text-red-600 dark:text-red-400';
    return '';
};
