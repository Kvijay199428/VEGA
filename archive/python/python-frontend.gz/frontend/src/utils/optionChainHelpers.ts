/**
 * Option Chain Helper Functions
 * Shared logic for Option Chain components
 */

import type { StrikeInfo, BidAskTotals, OptionChainRow } from '../types/optionChain';

/**
 * Determine if a strike is ATM, ITM, or OTM relative to spot price
 */
export const getStrikeInfo = (
    strike: number,
    spotPrice: number,
    atmStrike: number
): StrikeInfo => {
    if (!spotPrice) return { isATM: false, isITM: false, isOTM: false };

    const isATM = strike === atmStrike;
    const isITM = strike < spotPrice;  // For Calls: ITM when strike < spot
    const isOTM = strike > spotPrice;  // For Calls: OTM when strike > spot

    return { isATM, isITM, isOTM };
};

/**
 * Get background CSS class for Call side based on strike position
 * ATM = Amber, ITM = Green, OTM = Red
 */
export const getCallSideClass = (
    strike: number,
    spotPrice: number,
    atmStrike: number
): string => {
    if (!spotPrice) return '';

    const { isATM, isITM, isOTM } = getStrikeInfo(strike, spotPrice, atmStrike);

    if (isATM) return 'bg-amber-200 dark:bg-amber-800/50';
    if (isITM) return 'bg-green-50 dark:bg-green-900/20';
    if (isOTM) return 'bg-red-50 dark:bg-red-900/20';
    return '';
};

/**
 * Get background CSS class for Put side based on strike position
 * ATM = Amber, ITM = Green (inverted from Call), OTM = Red (inverted from Call)
 */
export const getPutSideClass = (
    strike: number,
    spotPrice: number,
    atmStrike: number
): string => {
    if (!spotPrice) return '';

    const { isATM, isITM, isOTM } = getStrikeInfo(strike, spotPrice, atmStrike);

    if (isATM) return 'bg-amber-200 dark:bg-amber-800/50';
    // For Puts: ITM is Strike > Spot, OTM is Strike < Spot (inverted from Call)
    if (isITM) return 'bg-red-50 dark:bg-red-900/20';     // Puts OTM (Strike < Spot)
    if (isOTM) return 'bg-green-50 dark:bg-green-900/20'; // Puts ITM (Strike > Spot)
    return '';
};

/**
 * Calculate the ATM index (closest strike to spot price)
 */
export const findAtmIndex = (optionChain: OptionChainRow[], spotPrice: number): number => {
    if (!spotPrice || optionChain.length === 0) return -1;

    let closestIndex = 0;
    let closestDiff = Math.abs(optionChain[0].strike_price - spotPrice);

    optionChain.forEach((row, index) => {
        const diff = Math.abs(row.strike_price - spotPrice);
        if (diff < closestDiff) {
            closestDiff = diff;
            closestIndex = index;
        }
    });

    return closestIndex;
};

/**
 * Calculate Bid/Ask totals for Call side
 */
export const calculateCallTotals = (optionChain: OptionChainRow[]): BidAskTotals => {
    return optionChain.reduce((acc, row) => ({
        bid: acc.bid + (row.call?.bid_price || 0),
        bid_qty: acc.bid_qty + (row.call?.bid_qty || 0),
        ask: acc.ask + (row.call?.ask_price || 0),
        ask_qty: acc.ask_qty + (row.call?.ask_qty || 0),
    }), { bid: 0, bid_qty: 0, ask: 0, ask_qty: 0 });
};

/**
 * Calculate Bid/Ask totals for Put side
 */
export const calculatePutTotals = (optionChain: OptionChainRow[]): BidAskTotals => {
    return optionChain.reduce((acc, row) => ({
        bid: acc.bid + (row.put?.bid_price || 0),
        bid_qty: acc.bid_qty + (row.put?.bid_qty || 0),
        ask: acc.ask + (row.put?.ask_price || 0),
        ask_qty: acc.ask_qty + (row.put?.ask_qty || 0),
    }), { bid: 0, bid_qty: 0, ask: 0, ask_qty: 0 });
};

/**
 * Calculate percentage change
 */
export const calculateChange = (ltp: number, closePrice: number): number => {
    if (!closePrice) return 0;
    return ((ltp - closePrice) / closePrice) * 100;
};
