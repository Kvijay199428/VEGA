/**
 * Option Chain Types
 * Shared interfaces for Option Chain components and pages
 */

// Underlying instrument for option chain
export interface Underlying {
    instrument_key: string;
    name: string;
    trading_symbol?: string;
    exchange: string;
}

// Valuation tooltip details
export interface ValuationTooltipDetails {
    fair_price_formatted: string;
    market_price_formatted: string;
    mispricing_pct_formatted: string;
    confidence_level: 'High' | 'Medium' | 'Low';
}

// Valuation data for an option
export interface ValuationData {
    status: 'Overvalued' | 'Undervalued' | 'Fair';
    fair_price: number;
    market_price: number;
    mispricing_pct: number;
    action: 'SELL' | 'BUY' | 'HOLD';
    blinking: boolean;
    tooltip_details: ValuationTooltipDetails;
}

// Option side (Call or Put) with market data and greeks
export interface OptionSide {
    instrument_key: string;
    // Market Data
    ltp: number;
    close_price: number;
    volume: number;
    oi: number;
    bid_price: number;
    bid_qty: number;
    ask_price: number;
    ask_qty: number;
    prev_oi: number;
    // Option Greeks
    vega: number;
    theta: number;
    gamma: number;
    delta: number;
    iv: number;
    pop: number;
    // Valuation (optional, added by backend)
    valuation?: ValuationData;
}

// Single row in option chain table
export interface OptionChainRow {
    expiry: string;
    pcr: number;
    strike_price: number;
    underlying_key: string;
    underlying_spot_price: number;
    call: OptionSide;
    put: OptionSide;
}

// Strike information for ATM/ITM/OTM determination
export interface StrikeInfo {
    isATM: boolean;
    isITM: boolean;
    isOTM: boolean;
}

// Bid/Ask totals for summary row
export interface BidAskTotals {
    bid: number;
    bid_qty: number;
    ask: number;
    ask_qty: number;
}

// Segment type
export type OptionSegment = 'index' | 'equity';

// Exchange type
export type Exchange = 'NSE' | 'BSE';
