// API Types for VEGA TRADER

// Re-export domain types
export * from './optionChain';
export * from './equity';

// Auth Types
export interface User {
    id: string;
    email: string;
    name: string;
    upstox_user_id?: string;
    is_verified: boolean;
    created_at: string;
}

export interface AuthState {
    user: User | null;
    token: string | null;
    isAuthenticated: boolean;
    isLoading: boolean;
    error: string | null;
    sessionExpiry: string | null;
}

export interface LoginCredentials {
    email: string;
    password: string;
}

export interface SessionStatus {
    session_status: string;
    valid_until: string;
    hours_remaining: number;
    minutes_remaining: number;
}

// Portfolio Types
export interface PortfolioSummary {
    net_worth: number;
    pnl_day: number;
    pnl_total: number;
    margin_used: number;
    margin_available: number;
    buying_power: number;
}

export interface Holding {
    id: string;
    trading_symbol: string;
    exchange: string;
    quantity: number;
    average_price: number;
    last_price: number;
    pnl: number;
    pnl_percent: number;
    day_change: number;
    day_change_percent: number;
    instrument_token: string;
}

export interface Position {
    id: string;
    trading_symbol: string;
    exchange: string;
    product: string;
    quantity: number;
    average_price: number;
    last_price: number;
    pnl: number;
    pnl_percent: number;
    buy_quantity: number;
    sell_quantity: number;
    day_buy_value: number;
    day_sell_value: number;
}

// Order Types
export type OrderType = 'MARKET' | 'LIMIT' | 'SL' | 'SL-M';
export type TransactionType = 'BUY' | 'SELL';
export type ProductType = 'CNC' | 'INTRADAY' | 'MARGIN';
export type OrderStatus = 'PENDING' | 'OPEN' | 'COMPLETE' | 'CANCELLED' | 'REJECTED';

export interface Order {
    id: string;
    order_id: string;
    trading_symbol: string;
    exchange: string;
    transaction_type: TransactionType;
    order_type: OrderType;
    product: ProductType;
    quantity: number;
    price?: number;
    trigger_price?: number;
    status: OrderStatus;
    filled_quantity: number;
    average_price: number;
    placed_at: string;
    updated_at: string;
}

export interface OrderRequest {
    instrument_token: string;
    transaction_type: TransactionType;
    quantity: number;
    order_type: OrderType;
    product: ProductType;
    price?: number;
    trigger_price?: number;
    validity?: 'DAY' | 'IOC' | 'GTC';
    tag?: string;
}

// Market Types
export interface Quote {
    symbol: string;
    last_price: number;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
    change: number;
    change_percent: number;
    bid: number;
    ask: number;
    timestamp: string;
}

export interface Instrument {
    instrument_token: string;
    trading_symbol: string;
    name: string;
    exchange: string;
    segment: string;
    instrument_type: string;
    lot_size: number;
    tick_size: number;
    expiry?: string;
    strike?: number;
    option_type?: 'CE' | 'PE';
}

export interface OHLC {
    timestamp: string;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
}

export interface MarketIndex {
    name: string;
    symbol: string;
    value: number;
    change: number;
    change_percent: number;
    timestamp: string;
}

// Strategy Types
export interface Strategy {
    id: string;
    name: string;
    description: string;
    strategy_type: string;
    category: string;
    status: 'DRAFT' | 'ACTIVE' | 'PAUSED' | 'ARCHIVED';
    is_active: boolean;
    parameters: Record<string, any>;
    rules: StrategyRule[];
    instruments: string[];
    risk_management: RiskManagement;
    created_at: string;
    updated_at: string;
}

export interface StrategyRule {
    name: string;
    condition: string;
    action: 'BUY' | 'SELL' | 'HOLD';
}

export interface RiskManagement {
    stop_loss: number;
    take_profit: number;
    max_positions: number;
    max_position_size?: number;
    trailing_stop?: number;
}

export interface BacktestResult {
    start_date: string;
    end_date: string;
    initial_capital: number;
    final_capital: number;
    total_return: number;
    annualized_return: number;
    total_trades: number;
    win_rate: number;
    max_drawdown: number;
    sharpe_ratio: number;
    profit_factor: number;
}

// Settings Types
export interface UserSettings {
    theme: 'light' | 'dark' | 'system';
    default_segment: string;
    default_product: ProductType;
    risk_per_trade: number;
    max_daily_loss: number;
    notifications_enabled: boolean;
    sound_enabled: boolean;
}

// API Response wrapper
export interface ApiResponse<T> {
    status: 'success' | 'error';
    data?: T;
    message?: string;
    error?: string;
}
