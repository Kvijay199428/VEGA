/**
 * Equity Types
 * Shared interfaces for Equity Live Feed components and pages
 */

// Equity instrument from database
export interface EquityInstrument {
    instrument_key: string;
    trading_symbol: string;
    name: string;
    exchange: string;
    isin?: string;
}

// Live price data from WebSocket
export interface LivePrice {
    ltp: number;
    ltt: string;
    ltq: string;
    cp: number;
    change: number;
    updated_at: string;
}

// Sector for filtering
export interface Sector {
    key: string;
    name: string;
    available: boolean;
}

// Pagination constants
export const PAGE_SIZE = 50;
