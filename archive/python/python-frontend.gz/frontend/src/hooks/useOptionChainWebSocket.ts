/**
 * Option Chain WebSocket Hook - Real-time option chain data subscription
 * 
 * Connects to backend WebSocket and subscribes to option chain updates
 * for the selected instrument and expiry.
 */

import { useEffect, useCallback, useState, useRef } from 'react';
import { useAppSelector } from '../store/hooks';

export interface OptionChainData {
    strike_price: number;
    expiry: string;
    pcr: number;
    underlying_key: string;
    underlying_spot_price: number;
    call: OptionSide;
    put: OptionSide;
}

export interface OptionSide {
    instrument_key: string;
    ltp: number;
    close_price: number;
    volume: number;
    oi: number;
    bid_price: number;
    bid_qty: number;
    ask_price: number;
    ask_qty: number;
    prev_oi: number;
    vega: number;
    theta: number;
    gamma: number;
    delta: number;
    iv: number;
    pop: number;
    valuation?: {
        status: 'Overvalued' | 'Undervalued' | 'Fair';
        fair_price: number;
        market_price: number;
        mispricing_pct: number;
        action: 'SELL' | 'BUY' | 'HOLD';
        blinking: boolean;
        tooltip_details: {
            fair_price_formatted: string;
            market_price_formatted: string;
            mispricing_pct_formatted: string;
            confidence_level: 'High' | 'Medium' | 'Low';
        };
    };
}

export interface OptionChainState {
    isConnected: boolean;
    isConnecting: boolean;
    error: string | null;
    data: OptionChainData[];
    spotPrice: number;
    updatedAt: string | null;
    isLive: boolean;
}

const WS_URL = `ws://127.0.0.1:28020/api/ws`;

export function useOptionChainWebSocket(
    instrumentKey: string | null,
    expiryDate: string | null
) {
    const { isAuthenticated, token: _token } = useAppSelector(state => state.auth);
    const wsRef = useRef<WebSocket | null>(null);
    const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const reconnectAttemptsRef = useRef(0);
    const maxReconnectAttempts = 5;
    const currentChannelRef = useRef<string | null>(null);

    const [state, setState] = useState<OptionChainState>({
        isConnected: false,
        isConnecting: false,
        error: null,
        data: [],
        spotPrice: 0,
        updatedAt: null,
        isLive: false
    });

    // Connect to WebSocket
    const connect = useCallback(() => {
        if (!isAuthenticated || wsRef.current?.readyState === WebSocket.OPEN) {
            return;
        }

        setState(prev => ({ ...prev, isConnecting: true, error: null }));

        try {
            const ws = new WebSocket(WS_URL);
            wsRef.current = ws;

            ws.onopen = () => {
                console.log('✅ Option Chain WebSocket connected');
                setState(prev => ({
                    ...prev,
                    isConnected: true,
                    isConnecting: false,
                    error: null
                }));
                reconnectAttemptsRef.current = 0;

                // Subscribe to current channel if we have one
                if (instrumentKey && expiryDate) {
                    subscribe(instrumentKey, expiryDate);
                }
            };

            ws.onmessage = (event) => {
                try {
                    const message = JSON.parse(event.data);
                    handleMessage(message);
                } catch (e) {
                    console.error('Error parsing WebSocket message:', e);
                }
            };

            ws.onerror = (error) => {
                console.error('Option Chain WebSocket error:', error);
                setState(prev => ({
                    ...prev,
                    error: 'WebSocket connection error',
                    isLive: false
                }));
            };

            ws.onclose = (event) => {
                console.log(`Option Chain WebSocket closed (code: ${event.code})`);
                setState(prev => ({
                    ...prev,
                    isConnected: false,
                    isConnecting: false,
                    isLive: false
                }));

                // Attempt reconnection
                if (isAuthenticated && reconnectAttemptsRef.current < maxReconnectAttempts) {
                    const delay = Math.min(1000 * Math.pow(2, reconnectAttemptsRef.current), 30000);
                    reconnectTimeoutRef.current = setTimeout(() => {
                        reconnectAttemptsRef.current++;
                        console.log(`Reconnecting... (attempt ${reconnectAttemptsRef.current})`);
                        connect();
                    }, delay);
                }
            };
        } catch (error: any) {
            console.error('Failed to create WebSocket:', error);
            setState(prev => ({
                ...prev,
                isConnecting: false,
                error: error.message || 'Failed to connect'
            }));
        }
    }, [isAuthenticated]);

    // Handle incoming WebSocket messages
    const handleMessage = useCallback((message: any) => {
        const type = message.type;

        switch (type) {
            case 'option_chain_subscription_ack':
                console.log(`📊 Subscribed to: ${message.channel}`);
                // If initial data is included, use it
                if (message.initial_data?.data) {
                    const data = message.initial_data.data;
                    setState(prev => ({
                        ...prev,
                        data,
                        spotPrice: data[0]?.underlying_spot_price || 0,
                        updatedAt: message.initial_data.updated_at,
                        isLive: true
                    }));
                }
                break;

            case 'option_chain_update':
                // Check if this is for our current subscription
                const expectedChannel = `option_chain:${instrumentKey}:${expiryDate}`;
                if (message.channel === expectedChannel && message.data?.data) {
                    const newData = message.data.data;
                    setState(prev => ({
                        ...prev,
                        data: newData,
                        spotPrice: newData[0]?.underlying_spot_price || prev.spotPrice,
                        updatedAt: message.data.updated_at,
                        isLive: true
                    }));
                }
                break;

            case 'option_chain_unsubscribe_ack':
                console.log(`📊 Unsubscribed from: ${message.channel}`);
                break;

            case 'error':
                console.error('WebSocket error message:', message.message);
                break;

            default:
                // Ignore other message types
                break;
        }
    }, [instrumentKey, expiryDate]);

    // Subscribe to option chain channel
    const subscribe = useCallback((instKey: string, expiry: string) => {
        if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
            return;
        }

        const channel = `option_chain:${instKey}:${expiry}`;

        // Unsubscribe from previous channel if different
        if (currentChannelRef.current && currentChannelRef.current !== channel) {
            const [, prevInst, prevExp] = currentChannelRef.current.split(':');
            wsRef.current.send(JSON.stringify({
                type: 'unsubscribe_option_chain',
                instrument_key: prevInst,
                expiry_date: prevExp
            }));
        }

        // Subscribe to new channel
        wsRef.current.send(JSON.stringify({
            type: 'subscribe_option_chain',
            instrument_key: instKey,
            expiry_date: expiry
        }));

        currentChannelRef.current = channel;
    }, []);

    // Disconnect WebSocket
    const disconnect = useCallback(() => {
        if (reconnectTimeoutRef.current) {
            clearTimeout(reconnectTimeoutRef.current);
            reconnectTimeoutRef.current = null;
        }

        if (wsRef.current) {
            wsRef.current.close();
            wsRef.current = null;
        }

        currentChannelRef.current = null;
        setState(prev => ({
            ...prev,
            isConnected: false,
            isLive: false
        }));
    }, []);

    // Connect on mount when authenticated
    useEffect(() => {
        if (isAuthenticated) {
            connect();
        }

        return () => {
            disconnect();
        };
    }, [isAuthenticated, connect, disconnect]);

    // Subscribe when instrument/expiry changes
    useEffect(() => {
        if (state.isConnected && instrumentKey && expiryDate) {
            subscribe(instrumentKey, expiryDate);
        }
    }, [state.isConnected, instrumentKey, expiryDate, subscribe]);

    // Update data from HTTP response (fallback/initial load)
    const setDataFromHttp = useCallback((data: OptionChainData[], updatedAt?: string) => {
        setState(prev => ({
            ...prev,
            data,
            spotPrice: data[0]?.underlying_spot_price || prev.spotPrice,
            updatedAt: updatedAt || new Date().toISOString(),
            isLive: state.isConnected
        }));
    }, [state.isConnected]);

    return {
        ...state,
        connect,
        disconnect,
        setDataFromHttp
    };
}

export default useOptionChainWebSocket;
