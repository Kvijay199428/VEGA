import { useEffect, useRef } from 'react';

interface AutoScrollParams {
    /**
     * Number of items in the list. used to detect data changes.
     */
    dataLength: number;
    /**
     * The index of the ATM strike to scroll to.
     */
    atmIndex: number;
    /**
     * The ID prefix of the rows (e.g., 'strike-row').
     */
    rowIdPrefix: string;
    /**
     * Whether scrolling is enabled.
     */
    isEnabled?: boolean;
    /**
     * The ID of the scrollable container. 
     * If provided, manual scrollTop calculation is used for precise centering.
     * If omitted, falls back to element.scrollIntoView().
     */
    containerId?: string;
    /**
     * Additional dependencies that should trigger a scroll check.
     * Use this for layout changes (e.g., compare mode toggle).
     */
    dependencies?: any[];
}

/**
 * Hook to auto-scroll an element into view when data changes or layout updates.
 * Designed for centering the ATM strike in the Option Chain.
 */
const useAutoScrollToATM = ({
    dataLength,
    atmIndex,
    rowIdPrefix,
    containerId,
    isEnabled = true,
    dependencies = []
}: AutoScrollParams) => {
    // We use a timeout ref to clear potential pending scrolls on unmount/update
    const timeoutRef = useRef<NodeJS.Timeout | null>(null);

    useEffect(() => {
        if (isEnabled && dataLength > 0 && atmIndex >= 0) {
            // Clear any existing timeout
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }

            // Small delay to ensure DOM is fully rendered/layout is updated
            // Increased to 200ms to handle layout shifts in stacked mode better
            timeoutRef.current = setTimeout(() => {
                const elementId = `${rowIdPrefix}-${atmIndex}`;
                const element = document.getElementById(elementId);
                const container = containerId ? document.getElementById(containerId) : null;

                if (element) {
                    if (container) {
                        // Precise centering calculation
                        // We subtract the sticky header height (approx 32px-40px) if not accounted for, 
                        // but usually offsetTop is relative to the offsetParent (the table or relative container).
                        // If the container is the scrollable div, relative positioning usually works.
                        const containerHeight = container.clientHeight;
                        const elementHeight = element.clientHeight;
                        const elementTop = element.offsetTop;

                        // Calculate desired scroll position
                        const scrollTop = elementTop - (containerHeight / 2) + (elementHeight / 2);

                        container.scrollTo({
                            top: scrollTop,
                            behavior: 'smooth'
                        });
                    } else {
                        // Fallback to native scrollIntoView
                        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                } else {
                    // Optional: Debug log if element not found, but kept silent for production
                    // console.warn(`[useAutoScrollToATM] Element not found: ${elementId}`);
                }
            }, 300);
        }

        return () => {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }
        };
    }, [
        dataLength,
        atmIndex,
        rowIdPrefix,
        containerId,
        isEnabled,
        ...dependencies
    ]);
};

export default useAutoScrollToATM;
