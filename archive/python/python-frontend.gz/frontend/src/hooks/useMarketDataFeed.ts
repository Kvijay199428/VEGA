/**
 * Market Data Hook - Auto-connect and subscribe to market feed on login
 * 
 * Uses backend WebSocket service to connect to Upstox and fetch index prices.
 */

import { useEffect, useCallback, useState, useRef } from 'react';
import { useAppSelector, useAppDispatch } from '../store/hooks';
import { setWsConnectionStatus, setWsSubscribedCount } from '../store/slices/uiSlice';
import api from '../services/api';

export interface IndexPrice {
    ltp: number;
    ltt: string;
    ltq: string;
    cp: number;
    change: number;
    updated_at: string;
}

export interface MarketDataState {
    isConnected: boolean;
    isConnecting: boolean;
    error: string | null;
    indices: Record<string, IndexPrice>;
    marketStatus: Record<string, string>;
    subscriptionCount: number;
}

export function useMarketDataFeed() {
    // IMPORTANT: Keep hooks in consistent order to avoid React warnings
    const dispatch = useAppDispatch();
    const { isAuthenticated, token } = useAppSelector(state => state.auth);
    const pollingRef = useRef<NodeJS.Timeout | null>(null);

    const [state, setState] = useState<MarketDataState>({
        isConnected: false,
        isConnecting: false,
        error: null,
        indices: {},
        marketStatus: {},
        subscriptionCount: 0
    });

    // Connect to market feed via backend
    const connect = useCallback(async () => {
        if (!isAuthenticated || !token) {
            console.log('Not authenticated, skipping market feed connection');
            return;
        }

        if (state.isConnected || state.isConnecting) {
            console.log('Already connected or connecting');
            return;
        }

        setState(prev => ({ ...prev, isConnecting: true, error: null }));
        dispatch(setWsConnectionStatus('connecting'));

        try {
            // Call backend to connect and subscribe
            const response = await api.post('/v1/market/market-feed/connect');

            if (response.data?.status === 'success') {
                console.log(`✅ Connected to market feed with ${response.data.subscribed_instruments} indices`);
                setState(prev => ({
                    ...prev,
                    isConnected: true,
                    isConnecting: false,
                    subscriptionCount: response.data.subscribed_instruments || response.data.total_subscribed || 0
                }));
                dispatch(setWsConnectionStatus('connected'));
                dispatch(setWsSubscribedCount(response.data.total_subscribed || response.data.subscribed_instruments || 0));

                // Start polling for prices
                startPolling();
            } else {
                throw new Error(response.data?.message || 'Connection failed');
            }
        } catch (error: any) {
            console.error('Failed to connect to market feed:', error);
            setState(prev => ({
                ...prev,
                isConnecting: false,
                error: error.response?.data?.detail || error.message || 'Connection failed'
            }));
            dispatch(setWsConnectionStatus('disconnected'));
        }
    }, [isAuthenticated, token, state.isConnected, state.isConnecting, dispatch]);

    // Disconnect from market feed
    const disconnect = useCallback(async () => {
        try {
            await api.post('/v1/market/market-feed/disconnect');
            stopPolling();
            setState(prev => ({
                ...prev,
                isConnected: false,
                indices: {},
                marketStatus: {},
                subscriptionCount: 0
            }));
            dispatch(setWsConnectionStatus('disconnected'));
            dispatch(setWsSubscribedCount(0));
        } catch (error) {
            console.error('Error disconnecting:', error);
        }
    }, [dispatch]);

    // Poll for live index prices
    const fetchIndexPrices = useCallback(async () => {
        try {
            const response = await api.get('/v1/market/market-feed/indices');

            if (response.data?.status === 'success') {
                setState(prev => ({
                    ...prev,
                    indices: response.data.data || {},
                    marketStatus: response.data.market_status || {},
                    isConnected: true
                }));
            } else if (response.data?.status === 'error') {
                setState(prev => ({
                    ...prev,
                    isConnected: false
                }));
            }
        } catch (error) {
            console.error('Error fetching index prices:', error);
        }
    }, []);

    // Start polling for prices (every 1 second)
    const startPolling = useCallback(() => {
        if (pollingRef.current) {
            clearInterval(pollingRef.current);
        }

        // Fetch immediately
        fetchIndexPrices();

        // Then poll every second
        pollingRef.current = setInterval(fetchIndexPrices, 1000);
    }, [fetchIndexPrices]);

    // Stop polling
    const stopPolling = useCallback(() => {
        if (pollingRef.current) {
            clearInterval(pollingRef.current);
            pollingRef.current = null;
        }
    }, []);

    // Check connection status
    const checkStatus = useCallback(async () => {
        try {
            const response = await api.get('/v1/market/market-feed/status');

            if (response.data?.status === 'success') {
                const data = response.data.data;
                setState(prev => ({
                    ...prev,
                    isConnected: data.connected,
                    subscriptionCount: data.subscriptions,
                    marketStatus: data.market_status || {}
                }));

                // Start polling if connected
                if (data.connected && !pollingRef.current) {
                    startPolling();
                }
            }
        } catch (error) {
            console.error('Error checking status:', error);
        }
    }, [startPolling]);

    // Auto-connect when authenticated
    useEffect(() => {
        if (isAuthenticated && !state.isConnected && !state.isConnecting) {
            // Small delay to ensure token is ready
            const timer = setTimeout(() => {
                connect();
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [isAuthenticated, connect, state.isConnected, state.isConnecting]);

    // Disconnect when logged out
    useEffect(() => {
        if (!isAuthenticated && state.isConnected) {
            disconnect();
        }
    }, [isAuthenticated, disconnect, state.isConnected]);

    // Cleanup on unmount
    useEffect(() => {
        return () => {
            stopPolling();
        };
    }, [stopPolling]);

    return {
        ...state,
        connect,
        disconnect,
        checkStatus,
        refetch: fetchIndexPrices
    };
}

export default useMarketDataFeed;

