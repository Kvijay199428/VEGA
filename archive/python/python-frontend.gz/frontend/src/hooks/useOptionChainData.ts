/**
 * Option Chain Data Hook
 * Consolidated hook for fetching and managing option chain data
 */

import { useState, useCallback, useEffect, useMemo } from 'react';
import api from '../services/api';
import { handleUpstoxError } from '../utils/upstoxErrors';
import { findAtmIndex, calculateCallTotals, calculatePutTotals } from '../utils/optionChainHelpers';
import useOptionChainWebSocket from './useOptionChainWebSocket';
import type { Underlying, OptionChainRow, OptionSegment, Exchange, BidAskTotals, StrikeInfo } from '../types/optionChain';

interface UseOptionChainDataReturn {
    // State
    segment: OptionSegment;
    exchange: Exchange;
    underlyings: Underlying[];
    selectedUnderlying: string;
    expiries: string[];
    selectedExpiry: string;
    optionChain: OptionChainRow[];
    spotPrice: number;
    pcr: number;
    isLoading: boolean;

    // Computed
    atmIndex: number;
    atmStrike: number;
    callTotals: BidAskTotals;
    putTotals: BidAskTotals;

    // WebSocket state
    isConnected: boolean;
    isLive: boolean;

    // Actions
    setSegment: (segment: OptionSegment) => void;
    setExchange: (exchange: Exchange) => void;
    setSelectedUnderlying: (underlying: string) => void;
    setSelectedExpiry: (expiry: string) => void;
    refreshOptionChain: (forceRefresh?: boolean) => Promise<void>;
    getStrikeInfo: (strike: number) => StrikeInfo;
}

const useOptionChainData = (): UseOptionChainDataReturn => {
    // Selection state
    const [segment, setSegment] = useState<OptionSegment>('index');
    const [exchange, setExchange] = useState<Exchange>('NSE');
    const [underlyings, setUnderlyings] = useState<Underlying[]>([]);
    const [selectedUnderlying, setSelectedUnderlying] = useState<string>('');
    const [expiries, setExpiries] = useState<string[]>([]);
    const [selectedExpiry, setSelectedExpiry] = useState<string>('');

    // Data state
    const [optionChain, setOptionChain] = useState<OptionChainRow[]>([]);
    const [spotPrice, setSpotPrice] = useState<number>(0);
    const [pcr, setPcr] = useState<number>(0);
    const [isLoading, setIsLoading] = useState(false);

    // WebSocket hook for real-time updates
    const {
        isConnected,
        isLive,
        data: wsData,
        spotPrice: wsSpotPrice,
        setDataFromHttp
    } = useOptionChainWebSocket(selectedUnderlying || null, selectedExpiry || null);

    // Calculate ATM index
    const atmIndex = useMemo(() => findAtmIndex(optionChain, spotPrice), [optionChain, spotPrice]);

    // Get ATM strike value
    const atmStrike = useMemo(() => {
        return atmIndex >= 0 ? optionChain[atmIndex]?.strike_price : 0;
    }, [atmIndex, optionChain]);

    // Calculate totals
    const callTotals = useMemo(() => calculateCallTotals(optionChain), [optionChain]);
    const putTotals = useMemo(() => calculatePutTotals(optionChain), [optionChain]);

    // Strike info helper
    const getStrikeInfo = useCallback((strike: number): StrikeInfo => {
        if (!spotPrice) return { isATM: false, isITM: false, isOTM: false };
        const isATM = strike === atmStrike;
        const isITM = strike < spotPrice;
        const isOTM = strike > spotPrice;
        return { isATM, isITM, isOTM };
    }, [spotPrice, atmStrike]);

    // Fetch underlyings
    const fetchUnderlyings = useCallback(async () => {
        try {
            const response = await api.get(`/v1/options/underlyings?segment=${segment}&exchange=${exchange}`);
            if (response.data?.status === 'success') {
                const data = response.data.data || [];
                setUnderlyings(data);
                if (data.length > 0) {
                    // Default to NIFTY 50 if available, otherwise first item
                    const nifty = data.find((u: any) => u.name === 'NIFTY 50' || u.instrument_key?.includes('Nifty 50'));
                    setSelectedUnderlying(nifty ? nifty.instrument_key : data[0].instrument_key);
                }
            }
        } catch (err) {
            console.error('Error fetching underlyings:', err);
            handleUpstoxError(err, 'Options Underlyings');
        }
    }, [segment, exchange]);

    // Fetch expiry dates
    const fetchExpiries = useCallback(async () => {
        if (!selectedUnderlying) return;
        try {
            const response = await api.get(`/v1/options/expiries/${encodeURIComponent(selectedUnderlying)}`);
            if (response.data?.status === 'success') {
                setExpiries(response.data.data || []);
                if (response.data.data?.length > 0) {
                    setSelectedExpiry(response.data.data[0]);
                }
            }
        } catch (err) {
            console.error('Error fetching expiries:', err);
            handleUpstoxError(err, 'Options Expiries');
        }
    }, [selectedUnderlying]);

    // Fetch option chain
    const refreshOptionChain = useCallback(async (forceRefresh = false) => {
        if (!selectedUnderlying || !selectedExpiry) return;
        setIsLoading(true);
        try {
            const response = await api.get('/v1/options/chain', {
                params: {
                    instrument_key: selectedUnderlying,
                    expiry_date: selectedExpiry,
                    force_refresh: forceRefresh
                }
            });
            if (response.data?.status === 'success') {
                const data = response.data.data || [];
                setOptionChain(data);
                setDataFromHttp(data, response.data.updated_at);
                if (data.length > 0) {
                    // Find first non-zero spot price
                    const validRow = data.find((row: any) => row.underlying_spot_price > 0);
                    const validSpot = validRow ? validRow.underlying_spot_price : (data[0].underlying_spot_price || 0);

                    setSpotPrice(validSpot);
                    setPcr(data[0].pcr || 0);
                }
            }
        } catch (err: any) {
            console.error('Error fetching option chain:', err);
            handleUpstoxError(err, 'Option Chain');
        } finally {
            setIsLoading(false);
        }
    }, [selectedUnderlying, selectedExpiry, setDataFromHttp]);

    // Effects
    useEffect(() => {
        fetchUnderlyings();
    }, [fetchUnderlyings]);

    useEffect(() => {
        if (selectedUnderlying) {
            fetchExpiries();
        }
    }, [selectedUnderlying, fetchExpiries]);

    useEffect(() => {
        if (selectedUnderlying && selectedExpiry) {
            refreshOptionChain();
        }
    }, [selectedUnderlying, selectedExpiry, refreshOptionChain]);

    // Update from WebSocket data
    useEffect(() => {
        if (wsData && wsData.length > 0 && isLive) {
            setOptionChain(wsData);
            if (wsSpotPrice) setSpotPrice(wsSpotPrice);
            setPcr(wsData[0]?.pcr || 0);
        }
    }, [wsData, wsSpotPrice, isLive]);

    return {
        // State
        segment,
        exchange,
        underlyings,
        selectedUnderlying,
        expiries,
        selectedExpiry,
        optionChain,
        spotPrice,
        pcr,
        isLoading,

        // Computed
        atmIndex,
        atmStrike,
        callTotals,
        putTotals,

        // WebSocket state
        isConnected,
        isLive,

        // Actions
        setSegment,
        setExchange,
        setSelectedUnderlying,
        setSelectedExpiry,
        refreshOptionChain,
        getStrikeInfo,
    };
};

export default useOptionChainData;
