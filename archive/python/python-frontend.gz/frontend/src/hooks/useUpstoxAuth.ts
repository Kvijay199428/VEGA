import { useState, useEffect } from 'react';
import { useAppDispatch } from '../store/hooks';
import { setToken } from '../store/slices/authSlice';
import api from '../services/api';

interface UseUpstoxAuthReturn {
    isCheckingToken: boolean;
    isGenerating: boolean;
    generationStatus: string;
    loginError: string | null;
    tokenInput: string;
    showManualInput: boolean;
    setTokenInput: (value: string) => void;
    setShowManualInput: (value: boolean) => void;
    openUpstoxPopup: () => Promise<void>;
    handleMultiLogin: () => Promise<void>;
    handleManualLogin: (e: React.FormEvent) => void;
}

const useUpstoxAuth = (): UseUpstoxAuthReturn => {
    const dispatch = useAppDispatch();

    // UI States
    const [isCheckingToken, setIsCheckingToken] = useState(true);
    const [isGenerating, setIsGenerating] = useState(false);
    const [generationStatus, setGenerationStatus] = useState('');
    const [loginError, setLoginError] = useState<string | null>(null);
    const [showManualInput, setShowManualInput] = useState(false);
    const [tokenInput, setTokenInput] = useState('');

    // Check for existing session on mount
    useEffect(() => {
        const checkExistingSession = async () => {
            try {
                // Simulate a quick check or validate token if exists
                // For Login page specific "checking" animation
                await new Promise(resolve => setTimeout(resolve, 800));

                // Real implementation would check authSlice or local storage validity
                // But Login.tsx handles redirect if authenticated, so we just finish loading
                setIsCheckingToken(false);
            } catch (error) {
                console.error('Session check failed:', error);
                setIsCheckingToken(false);
            }
        };

        checkExistingSession();
    }, []);

    // Manual Token Login
    const handleManualLogin = (e: React.FormEvent) => {
        e.preventDefault();
        if (!tokenInput.trim()) return;

        try {
            dispatch(setToken(tokenInput.trim()));
            // Navigation handled by App.tsx/routes based on auth state
        } catch (err) {
            setLoginError('Invalid token format');
        }
    };

    // Single Login Automation
    const openUpstoxPopup = async () => {
        try {
            setIsGenerating(true);
            setLoginError(null);
            setGenerationStatus('🚀 Launching automated login...');

            const response = await api.post('/v1/auth/upstox/automated-single-login');

            if (response.data?.status === 'success') {
                setGenerationStatus('✅ Chrome window opened. Complete the login and wait...');

                // Poll for token update
                startTokenPolling(60); // 3 minutes max
            } else {
                setLoginError(response.data?.message || 'Failed to start login automation');
                setIsGenerating(false);
            }
        } catch (error: any) {
            console.error('Single login error:', error);
            setLoginError(error.response?.data?.message || 'Failed to launch login automation');
            setIsGenerating(false);
        }
    };

    // Multi-Login Automation
    const handleMultiLogin = async () => {
        try {
            setIsGenerating(true);
            setLoginError(null);
            setGenerationStatus('🚀 Launching multi-login for all APIs...');

            const response = await api.post('/v1/auth/upstox/launch-remaining-login', {
                start_index: 0
            });

            if (response.data?.status === 'success') {
                setGenerationStatus('✅ Chrome window opened. Complete the login and wait...');
                // Poll for token update (longer timeout for multi)
                startTokenPolling(120); // 6 minutes max
            } else {
                setLoginError(response.data?.message || 'Failed to start multi-login');
                setIsGenerating(false);
            }
        } catch (error: any) {
            console.error('Multi-login error:', error);
            setLoginError(error.response?.data?.message || 'Failed to launch multi-login');
            setIsGenerating(false);
        }
    };

    // Helper: Poll for token success
    const startTokenPolling = (maxPolls: number) => {
        let pollCount = 0;

        const pollInterval = setInterval(async () => {
            try {
                pollCount++;
                const statusResponse = await api.get('/v1/auth/upstox/tokens/db-status');

                if (statusResponse.data?.status === 'success') {
                    const { primary_expired, valid_count } = statusResponse.data.data;

                    if (valid_count > 0 && !primary_expired) {
                        clearInterval(pollInterval);
                        setGenerationStatus('✅ Tokens generated! Logging you in...');

                        // Fetch the actual token and update store
                        try {
                            const tokenResponse = await api.get('/v1/auth/upstox/token');
                            if (tokenResponse.data?.status === 'success' && tokenResponse.data?.access_token) {
                                dispatch(setToken(tokenResponse.data.access_token));
                                // Success!
                            }
                        } catch (err) {
                            console.error('Failed to fetch new token:', err);
                            setLoginError('Tokens generated but failed to retrieve session.');
                            setIsGenerating(false);
                        }
                    } else if (valid_count > 0) {
                        setGenerationStatus(`⚡ Progress: ${valid_count} tokens generated...`);
                    }
                }

                if (pollCount >= maxPolls) {
                    clearInterval(pollInterval);
                    setLoginError('⏱️ Login timed out. Please try again.');
                    setIsGenerating(false);
                }
            } catch (error) {
                console.error('Polling error:', error);
            }
        }, 3000);
    };

    return {
        isCheckingToken,
        isGenerating,
        generationStatus,
        loginError,
        tokenInput,
        showManualInput,
        setTokenInput,
        setShowManualInput,
        openUpstoxPopup,
        handleMultiLogin,
        handleManualLogin,
    };
};

export default useUpstoxAuth;
