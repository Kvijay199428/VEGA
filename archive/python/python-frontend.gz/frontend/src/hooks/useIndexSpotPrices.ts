/**
 * Index Spot Prices Hook
 * Subscribes to all index underlying spot prices from the option chain WebSocket
 */

import { useEffect, useCallback, useState, useRef } from 'react';
import { useAppSelector } from '../store/hooks';

export interface IndexSpotData {
    instrument_key: string;
    name: string;
    spot_price: number;
    prev_close: number;
    change: number;
    change_percent: number;
    updatedAt: string | null;
}

// All tradeable index instruments with options
export const INDEX_INSTRUMENTS = [
    { instrument_key: "NSE_INDEX|Nifty 50", name: "NIFTY 50" },
    { instrument_key: "NSE_INDEX|Nifty Bank", name: "BANK NIFTY" },
    { instrument_key: "NSE_INDEX|NIFTY FIN SERVICE", name: "FINNIFTY" },
    { instrument_key: "NSE_INDEX|NIFTY MID SELECT", name: "MIDCPNIFTY" },
    { instrument_key: "BSE_INDEX|SENSEX", name: "SENSEX" },
    { instrument_key: "BSE_INDEX|BANKEX", name: "BANKEX" },
];

interface IndexSpotPricesState {
    isConnected: boolean;
    indices: Map<string, IndexSpotData>;
    isLive: boolean;
}

const WS_URL = `ws://127.0.0.1:28020/api/ws`;

export function useIndexSpotPrices() {
    console.log('Using WebSocket URL:', WS_URL);
    const { isAuthenticated } = useAppSelector(state => state.auth);
    const wsRef = useRef<WebSocket | null>(null);
    const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const reconnectAttemptsRef = useRef(0);
    const maxReconnectAttempts = 5;
    const prevPricesRef = useRef<Map<string, number>>(new Map());

    const [state, setState] = useState<IndexSpotPricesState>({
        isConnected: false,
        indices: new Map(),
        isLive: false
    });

    // Handle incoming WebSocket messages
    const handleMessage = useCallback((message: any) => {
        const type = message.type;

        // Listen for the global index_spot_prices broadcast
        if (type === 'index_spot_prices') {
            const indices = message.data?.indices;

            if (!indices || indices.length === 0) return;

            setState(prev => {
                const newIndices = new Map(prev.indices);

                for (const indexData of indices) {
                    const key = indexData.instrument_key;
                    const prevData = newIndices.get(key);
                    const prevClose = prevData?.prev_close || prevPricesRef.current.get(key) || indexData.spot_price;

                    // Store the first price as prev_close reference
                    if (!prevPricesRef.current.has(key)) {
                        prevPricesRef.current.set(key, indexData.spot_price);
                    }

                    const change = indexData.spot_price - prevClose;
                    const changePercent = prevClose > 0
                        ? (change / prevClose) * 100
                        : 0;

                    newIndices.set(key, {
                        instrument_key: key,
                        name: indexData.name,
                        spot_price: indexData.spot_price,
                        prev_close: prevClose,
                        change: change,
                        change_percent: changePercent,
                        updatedAt: indexData.updated_at || new Date().toISOString()
                    });
                }

                return {
                    ...prev,
                    indices: newIndices,
                    isLive: true
                };
            });
        }
    }, []);

    // Connect to WebSocket
    const connect = useCallback(() => {
        if (!isAuthenticated || wsRef.current?.readyState === WebSocket.OPEN) {
            return;
        }

        try {
            const ws = new WebSocket(WS_URL);
            wsRef.current = ws;

            ws.onopen = () => {
                console.log('✅ Index Spot Prices WebSocket connected');
                setState(prev => ({
                    ...prev,
                    isConnected: true
                }));
                reconnectAttemptsRef.current = 0;
            };

            ws.onmessage = (event) => {
                try {
                    const message = JSON.parse(event.data);
                    handleMessage(message);
                } catch (e) {
                    console.error('Error parsing WebSocket message:', e);
                }
            };

            ws.onerror = (error) => {
                console.error('Index Spot Prices WebSocket error:', error);
                setState(prev => ({
                    ...prev,
                    isLive: false
                }));
            };

            ws.onclose = (event) => {
                console.log(`Index Spot Prices WebSocket closed (code: ${event.code})`);
                setState(prev => ({
                    ...prev,
                    isConnected: false,
                    isLive: false
                }));

                // Attempt reconnection
                if (isAuthenticated && reconnectAttemptsRef.current < maxReconnectAttempts) {
                    const delay = Math.min(1000 * Math.pow(2, reconnectAttemptsRef.current), 30000);
                    reconnectTimeoutRef.current = setTimeout(() => {
                        reconnectAttemptsRef.current++;
                        console.log(`Reconnecting... (attempt ${reconnectAttemptsRef.current})`);
                        connect();
                    }, delay);
                }
            };
        } catch (error: any) {
            console.error('Failed to create WebSocket:', error);
        }
    }, [isAuthenticated, handleMessage]);

    // Disconnect WebSocket
    const disconnect = useCallback(() => {
        if (reconnectTimeoutRef.current) {
            clearTimeout(reconnectTimeoutRef.current);
            reconnectTimeoutRef.current = null;
        }

        if (wsRef.current) {
            wsRef.current.close();
            wsRef.current = null;
        }

        setState(prev => ({
            ...prev,
            isConnected: false,
            isLive: false
        }));
    }, []);

    // Connect on mount when authenticated
    useEffect(() => {
        if (isAuthenticated) {
            connect();
        }

        return () => {
            disconnect();
        };
    }, [isAuthenticated, connect, disconnect]);

    // Convert Map to array for easier consumption
    const indicesArray = Array.from(state.indices.values());

    return {
        ...state,
        indices: indicesArray,
        connect,
        disconnect
    };
}

export default useIndexSpotPrices;
