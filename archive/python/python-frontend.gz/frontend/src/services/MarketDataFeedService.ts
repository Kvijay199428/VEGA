/**
 * Market Data Feed V3 Service
 * WebSocket client for real-time market data from Upstox
 */

import api from './api';

// Subscription modes and their limits
export const SUBSCRIPTION_MODES = {
    LTPC: 'ltpc',           // Last Trade Price & Close (5000 max)
    FULL: 'full',           // Full with 5 depth levels (2000 max)
    OPTION_GREEKS: 'option_greeks', // Option Greeks (3000 max)
    FULL_D30: 'full_d30'    // Full with 30 depth levels (50 max, Plus only)
} as const;

export const MODE_LIMITS = {
    [SUBSCRIPTION_MODES.LTPC]: 5000,
    [SUBSCRIPTION_MODES.FULL]: 2000,
    [SUBSCRIPTION_MODES.OPTION_GREEKS]: 3000,
    [SUBSCRIPTION_MODES.FULL_D30]: 50
};

// Message types
export type MessageType = 'initial_feed' | 'live_feed' | 'market_info';

// LTPC data structure
export interface LTPCData {
    ltp: number;    // Last Traded Price
    ltt: string;    // Last Traded Time (ms)
    ltq: string;    // Last Traded Quantity
    cp: number;     // Close Price
}

// Market depth quote
export interface DepthQuote {
    price: number;
    quantity: string;
    orders: string;
}

// Full feed data
export interface FullFeedData {
    ltpc: LTPCData;
    depth?: {
        buy: DepthQuote[];
        sell: DepthQuote[];
    };
    metadata?: {
        atp: number;   // Average Traded Price
        vtt: string;   // Volume Traded Today
        oi: number;    // Open Interest
        iv: number;    // Implied Volatility
        tbq: number;   // Total Buy Quantity
        tsq: number;   // Total Sell Quantity
    };
    optionGreeks?: {
        delta: number;
        gamma: number;
        theta: number;
        vega: number;
        rho: number;
    };
}

// Feed response
export interface FeedResponse {
    type: MessageType;
    feeds: Record<string, FullFeedData>;
    currentTs: string;
}

// Market status response
export interface MarketInfoResponse {
    type: 'market_info';
    segmentStatus: Record<string, string>;
    currentTs: string;
}

// Callbacks
type OnFeedCallback = (data: FeedResponse) => void;
type OnMarketInfoCallback = (data: MarketInfoResponse) => void;
type OnErrorCallback = (error: Error) => void;
type OnConnectCallback = () => void;
type OnDisconnectCallback = () => void;

/**
 * Market Data Feed V3 WebSocket Client
 */
class MarketDataFeedService {
    private ws: WebSocket | null = null;
    private wsUrl: string | null = null;
    private reconnectAttempts = 0;
    private maxReconnectAttempts = 5;
    private reconnectDelay = 1000;
    private messageQueue: any[] = [];
    private subscriptions: Map<string, string> = new Map(); // instrumentKey -> mode

    // Callbacks
    private onFeed: OnFeedCallback | null = null;
    private onMarketInfo: OnMarketInfoCallback | null = null;
    private onError: OnErrorCallback | null = null;
    private onConnect: OnConnectCallback | null = null;
    private onDisconnect: OnDisconnectCallback | null = null;

    /**
     * Initialize and connect to WebSocket
     */
    async connect(): Promise<void> {
        try {
            // Get WebSocket URL from backend
            const response = await api.get('/v1/market/market-feed/auth');

            if (response.data?.status !== 'success') {
                throw new Error('Failed to get WebSocket auth');
            }

            this.wsUrl = response.data.data.websocket_url;

            if (!this.wsUrl) {
                throw new Error('No WebSocket URL received');
            }

            this.createConnection();

        } catch (error) {
            console.error('Failed to connect to market feed:', error);
            this.onError?.(error as Error);
            throw error;
        }
    }

    /**
     * Create WebSocket connection
     */
    private createConnection(): void {
        if (!this.wsUrl) return;

        this.ws = new WebSocket(this.wsUrl);
        this.ws.binaryType = 'arraybuffer'; // Important for Protobuf

        this.ws.onopen = () => {
            console.log('✅ Connected to Market Data Feed V3');
            this.reconnectAttempts = 0;
            this.onConnect?.();
            this.processQueue();

            // Resubscribe to previously subscribed instruments
            this.resubscribe();
        };

        this.ws.onmessage = (event) => {
            this.handleMessage(event.data);
        };

        this.ws.onerror = (error) => {
            console.error('❌ WebSocket error:', error);
            this.onError?.(new Error('WebSocket error'));
        };

        this.ws.onclose = () => {
            console.log('⚠️ WebSocket disconnected');
            this.onDisconnect?.();
            this.attemptReconnect();
        };
    }

    /**
     * Handle incoming message (binary Protobuf)
     */
    private handleMessage(data: ArrayBuffer): void {
        try {
            // Decode binary data
            const decoded = this.decodeMessage(data);

            if (!decoded) {
                console.warn('Failed to decode message');
                return;
            }

            // Route message based on type
            if (decoded.type === 'market_info') {
                this.onMarketInfo?.(decoded as MarketInfoResponse);
            } else {
                this.onFeed?.(decoded as FeedResponse);
            }

        } catch (error) {
            console.error('Error handling message:', error);
        }
    }

    /**
     * Decode binary Protobuf message
     * For now, try JSON parsing as fallback
     */
    private decodeMessage(data: ArrayBuffer): any {
        try {
            // Try JSON first (some messages may be JSON)
            const text = new TextDecoder().decode(data);
            return JSON.parse(text);
        } catch {
            // Binary Protobuf - would need protobufjs for full decoding
            console.warn('Binary message received - Protobuf decoding needed');
            return null;
        }
    }

    /**
     * Subscribe to instruments
     */
    subscribe(instrumentKeys: string[], mode: keyof typeof SUBSCRIPTION_MODES = 'LTPC'): void {
        const modeValue = SUBSCRIPTION_MODES[mode];

        // Check limits
        const limit = MODE_LIMITS[modeValue];
        if (instrumentKeys.length > limit) {
            console.warn(`Subscription exceeds limit for ${mode} mode. Max: ${limit}`);
            instrumentKeys = instrumentKeys.slice(0, limit);
        }

        const request = {
            guid: this.generateGuid(),
            method: 'sub',
            data: {
                mode: modeValue,
                instrumentKeys: instrumentKeys
            }
        };

        this.sendMessage(request);

        // Track subscriptions
        instrumentKeys.forEach(key => {
            this.subscriptions.set(key, modeValue);
        });
    }

    /**
     * Unsubscribe from instruments
     */
    unsubscribe(instrumentKeys: string[]): void {
        const request = {
            guid: this.generateGuid(),
            method: 'unsub',
            data: {
                instrumentKeys: instrumentKeys
            }
        };

        this.sendMessage(request);

        // Remove from tracking
        instrumentKeys.forEach(key => {
            this.subscriptions.delete(key);
        });
    }

    /**
     * Change subscription mode for instruments
     */
    changeMode(instrumentKeys: string[], newMode: keyof typeof SUBSCRIPTION_MODES): void {
        const modeValue = SUBSCRIPTION_MODES[newMode];

        const request = {
            guid: this.generateGuid(),
            method: 'change_mode',
            data: {
                mode: modeValue,
                instrumentKeys: instrumentKeys
            }
        };

        this.sendMessage(request);

        // Update tracking
        instrumentKeys.forEach(key => {
            if (this.subscriptions.has(key)) {
                this.subscriptions.set(key, modeValue);
            }
        });
    }

    /**
     * Send message via WebSocket
     */
    private sendMessage(message: any): void {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            const data = JSON.stringify(message);
            this.ws.send(data);
        } else {
            this.messageQueue.push(message);
        }
    }

    /**
     * Process queued messages after connection
     */
    private processQueue(): void {
        while (this.messageQueue.length > 0) {
            const message = this.messageQueue.shift();
            this.sendMessage(message);
        }
    }

    /**
     * Resubscribe after reconnection
     */
    private resubscribe(): void {
        // Group by mode
        const byMode: Record<string, string[]> = {};

        this.subscriptions.forEach((mode, key) => {
            if (!byMode[mode]) {
                byMode[mode] = [];
            }
            byMode[mode].push(key);
        });

        // Resubscribe each group
        Object.entries(byMode).forEach(([mode, keys]) => {
            const request = {
                guid: this.generateGuid(),
                method: 'sub',
                data: {
                    mode: mode,
                    instrumentKeys: keys
                }
            };
            this.sendMessage(request);
        });
    }

    /**
     * Attempt reconnection with exponential backoff
     */
    private attemptReconnect(): void {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            console.error('Max reconnection attempts reached');
            return;
        }

        this.reconnectAttempts++;
        const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);

        console.log(`Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts})`);

        setTimeout(() => {
            this.createConnection();
        }, delay);
    }

    /**
     * Disconnect WebSocket
     */
    disconnect(): void {
        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }
        this.subscriptions.clear();
        this.messageQueue = [];
    }

    /**
     * Get current subscriptions
     */
    getSubscriptions(): Map<string, string> {
        return new Map(this.subscriptions);
    }

    /**
     * Check if connected
     */
    isConnected(): boolean {
        return this.ws !== null && this.ws.readyState === WebSocket.OPEN;
    }

    /**
     * Set callbacks
     */
    setOnFeed(callback: OnFeedCallback): void {
        this.onFeed = callback;
    }

    setOnMarketInfo(callback: OnMarketInfoCallback): void {
        this.onMarketInfo = callback;
    }

    setOnError(callback: OnErrorCallback): void {
        this.onError = callback;
    }

    setOnConnect(callback: OnConnectCallback): void {
        this.onConnect = callback;
    }

    setOnDisconnect(callback: OnDisconnectCallback): void {
        this.onDisconnect = callback;
    }

    /**
     * Generate unique GUID for requests
     */
    private generateGuid(): string {
        return 'xxxxxxxxxxxxxxxxxxxx'.replace(/x/g, () => {
            return Math.floor(Math.random() * 16).toString(16);
        });
    }
}

// Export singleton instance
export const marketDataFeed = new MarketDataFeedService();
export default MarketDataFeedService;
