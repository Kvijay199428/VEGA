import axios from 'axios';
import type { AxiosInstance, AxiosError, InternalAxiosRequestConfig } from 'axios';
import { handleUpstoxError } from '../utils/upstoxErrors';

// Create axios instance with defaults
const api: AxiosInstance = axios.create({
    baseURL: import.meta.env.VITE_API_URL || '/api',
    timeout: 180000, // 3 minutes for Selenium auto-login
    headers: {
        'Content-Type': 'application/json',
    },
});

// Request interceptor - add auth token
api.interceptors.request.use(
    (config: InternalAxiosRequestConfig) => {
        const token = localStorage.getItem('access_token');
        if (token && config.headers) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error: AxiosError) => {
        return Promise.reject(error);
    }
);

// Response interceptor - handle errors globally
api.interceptors.response.use(
    (response) => response,
    (error: AxiosError) => {
        // Check if this is an Upstox API error (contains UDAPI error code)
        const detail = (error.response?.data as any)?.detail || '';
        const isUpstoxError = typeof detail === 'string' && detail.includes('UDAPI');

        if (isUpstoxError && error.response?.status !== 401) {
            // Extract context from URL
            const url = error.config?.url || '';
            let context = 'API Error';
            if (url.includes('/options')) context = 'Options Chain';
            else if (url.includes('/market')) context = 'Market Data';
            else if (url.includes('/portfolio')) context = 'Portfolio';
            else if (url.includes('/orders')) context = 'Orders';
            else if (url.includes('/auth')) context = 'Authentication';

            // Show toast and add to notification panel
            handleUpstoxError(error, context);
        }

        if (error.response?.status === 401) {
            // Only auto-logout if it's a session/auth endpoint that fails
            // Don't logout for regular API calls - the Upstox token might still be valid
            const url = error.config?.url || '';
            // Only auto-logout for critical auth session endpoints
            // /user/profile should NOT auto-logout since backend falls back to PRIMARY token from DB
            const isAuthEndpoint = url.includes('/auth/session') ||
                url.includes('/auth/refresh');

            if (isAuthEndpoint) {
                localStorage.removeItem('access_token');
                window.location.href = '/login';
            }
            // For other endpoints, just let the error bubble up without logging out
        }
        return Promise.reject(error);
    }
);

export default api;

// API endpoints
export const endpoints = {
    // Auth
    auth: {
        login: '/v1/auth/login',
        logout: '/v1/auth/logout',
        refresh: '/v1/auth/refresh-token',
        sessionStatus: '/v1/auth/session-status',
        upstoxCallback: '/v1/auth/upstox/callback',
    },

    // User
    user: {
        profile: '/v1/user/profile',
        accountInfo: '/v1/user/account-info',
        accountSettings: '/v1/user/account-settings',
        riskPreferences: '/v1/user/risk-preferences',
        aiPreferences: '/v1/user/ai-preferences',
    },

    // Market
    market: {
        instruments: '/v1/market/instruments',
        quote: (symbol: string) => `/v1/market/quote/${symbol}`,
        quotes: '/v1/market/quotes',
        ohlc: (symbol: string) => `/v1/market/ohlc/${symbol}`,
        depth: (symbol: string) => `/v1/market/depth/${symbol}`,
        heatmap: '/v1/market/heatmap',
        indices: '/v1/market/indices',
        historical: (symbol: string) => `/v1/market/historical/${symbol}`,
    },

    // Orders
    orders: {
        list: '/v1/orders',
        place: '/v1/orders/place',
        get: (id: string) => `/v1/orders/${id}`,
        modify: (id: string) => `/v1/orders/${id}`,
        cancel: (id: string) => `/v1/orders/${id}/cancel`,
        trades: '/v1/orders/trades',
        batch: '/v1/orders/batch',
    },

    // Portfolio
    portfolio: {
        summary: '/v1/portfolio/summary',
        positions: '/v1/portfolio/positions',
        holdings: '/v1/portfolio/holdings',
        performance: '/v1/portfolio/performance',
        allocation: '/v1/portfolio/allocation',
        snapshots: '/v1/portfolio/snapshots',
    },

    // Strategies
    strategies: {
        predefined: '/v1/strategies/predefined',
        user: '/v1/strategies/user',
        get: (id: string) => `/v1/strategies/user/${id}`,
        aiGenerate: '/v1/strategies/ai/generate',
        execute: '/v1/strategies/execute',
        backtest: (id: string) => `/v1/strategies/${id}/backtest`,
        performance: (id: string) => `/v1/strategies/${id}/performance`,
    },

    // Indicators
    indicators: {
        list: '/v1/indicators',
        calculate: (id: string) => `/v1/indicators/${id}`,
        user: '/v1/indicators/user',
    },

    // Settings
    settings: {
        general: '/v1/settings/general',
        notifications: '/v1/settings/notifications',
    },
};
