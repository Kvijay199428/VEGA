import { createSlice } from '@reduxjs/toolkit';
import type { PayloadAction } from '@reduxjs/toolkit';

interface UiState {
    activeModal: string | null;
    notifications: Notification[];
    toasts: Toast[];
    // Global search and market feed state
    globalSearchQuery: string;
    selectedExchange: 'NSE' | 'BSE';
    wsConnectionStatus: 'connected' | 'disconnected' | 'connecting';
    wsSubscribedCount: number;
}

interface Notification {
    id: string;
    type: 'info' | 'success' | 'warning' | 'error';
    title: string;
    message: string;
    read: boolean;
    timestamp: string;
}

interface Toast {
    id: string;
    type: 'info' | 'success' | 'warning' | 'error';
    message: string;
    duration?: number;
}



const initialState: UiState = {
    activeModal: null,
    notifications: [],
    toasts: [],
    // Global search and market feed state
    globalSearchQuery: '',
    selectedExchange: 'NSE',
    wsConnectionStatus: 'disconnected',
    wsSubscribedCount: 0,
};

const uiSlice = createSlice({
    name: 'ui',
    initialState,
    reducers: {


        openModal: (state, action: PayloadAction<string>) => {
            state.activeModal = action.payload;
        },
        closeModal: (state) => {
            state.activeModal = null;
        },
        addNotification: (state, action: PayloadAction<Omit<Notification, 'id' | 'read' | 'timestamp'>>) => {
            state.notifications.unshift({
                ...action.payload,
                id: Date.now().toString(),
                read: false,
                timestamp: new Date().toISOString(),
            });
        },
        markNotificationRead: (state, action: PayloadAction<string>) => {
            const notification = state.notifications.find(n => n.id === action.payload);
            if (notification) {
                notification.read = true;
            }
        },
        clearNotifications: (state) => {
            state.notifications = [];
        },
        markAllNotificationsRead: (state) => {
            state.notifications.forEach(n => n.read = true);
        },
        addToast: (state, action: PayloadAction<Omit<Toast, 'id'>>) => {
            state.toasts.push({
                ...action.payload,
                id: Date.now().toString(),
            });
        },
        removeToast: (state, action: PayloadAction<string>) => {
            state.toasts = state.toasts.filter(t => t.id !== action.payload);
        },
        // Global search and market feed actions
        setGlobalSearchQuery: (state, action: PayloadAction<string>) => {
            state.globalSearchQuery = action.payload;
        },
        setSelectedExchange: (state, action: PayloadAction<'NSE' | 'BSE'>) => {
            state.selectedExchange = action.payload;
        },
        setWsConnectionStatus: (state, action: PayloadAction<'connected' | 'disconnected' | 'connecting'>) => {
            state.wsConnectionStatus = action.payload;
        },
        setWsSubscribedCount: (state, action: PayloadAction<number>) => {
            state.wsSubscribedCount = action.payload;
        },
    },
});

export const {
    openModal,
    closeModal,
    addNotification,
    markNotificationRead,
    markAllNotificationsRead,
    clearNotifications,
    addToast,
    removeToast,
    setGlobalSearchQuery,
    setSelectedExchange,
    setWsConnectionStatus,
    setWsSubscribedCount,
} = uiSlice.actions;
export default uiSlice.reducer;
