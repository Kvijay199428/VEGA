import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import type { PayloadAction } from '@reduxjs/toolkit';
import api, { endpoints } from '../../services/api';
import type { PortfolioSummary, Holding, Position } from '../../types';
import { handleUpstoxError, isServiceHoursError } from '../../utils/upstoxErrors';

interface PortfolioState {
    summary: PortfolioSummary | null;
    holdings: Holding[];
    positions: Position[];
    isLoading: boolean;
    error: string | null;
    lastUpdated: string | null;
}

const initialState: PortfolioState = {
    summary: null,
    holdings: [],
    positions: [],
    isLoading: false,
    error: null,
    lastUpdated: null,
};

// Async thunks
export const fetchPortfolioSummary = createAsyncThunk(
    'portfolio/fetchSummary',
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get<{ data: PortfolioSummary }>(endpoints.portfolio.summary);
            return response.data.data;
        } catch (error: any) {
            // Handle Upstox-specific errors
            handleUpstoxError(error, 'Portfolio Summary');

            // Don't throw error if it's just service hours (silent fail)
            if (isServiceHoursError(error)) {
                return rejectWithValue('Service unavailable');
            }

            return rejectWithValue(error.response?.data?.message || 'Failed to fetch portfolio');
        }
    }
);

export const fetchHoldings = createAsyncThunk(
    'portfolio/fetchHoldings',
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get<{ data: Holding[] }>(endpoints.portfolio.holdings);
            return response.data.data;
        } catch (error: any) {
            handleUpstoxError(error, 'Holdings');
            return rejectWithValue(error.response?.data?.message || 'Failed to fetch holdings');
        }
    }
);

export const fetchPositions = createAsyncThunk(
    'portfolio/fetchPositions',
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get<{ data: Position[] }>(endpoints.portfolio.positions);
            return response.data.data;
        } catch (error: any) {
            handleUpstoxError(error, 'Positions');
            return rejectWithValue(error.response?.data?.message || 'Failed to fetch positions');
        }
    }
);

export const fetchAllPortfolioData = createAsyncThunk(
    'portfolio/fetchAll',
    async (_, { dispatch }) => {
        await Promise.all([
            dispatch(fetchPortfolioSummary()),
            dispatch(fetchHoldings()),
            dispatch(fetchPositions()),
        ]);
    }
);

const portfolioSlice = createSlice({
    name: 'portfolio',
    initialState,
    reducers: {
        updateHoldingPrice: (state, action: PayloadAction<{ symbol: string; price: number }>) => {
            const holding = state.holdings.find(h => h.trading_symbol === action.payload.symbol);
            if (holding) {
                holding.last_price = action.payload.price;
                holding.pnl = (action.payload.price - holding.average_price) * holding.quantity;
                holding.pnl_percent = ((action.payload.price - holding.average_price) / holding.average_price) * 100;
            }
        },
        updatePositionPrice: (state, action: PayloadAction<{ symbol: string; price: number }>) => {
            const position = state.positions.find(p => p.trading_symbol === action.payload.symbol);
            if (position) {
                position.last_price = action.payload.price;
                position.pnl = (action.payload.price - position.average_price) * position.quantity;
                position.pnl_percent = ((action.payload.price - position.average_price) / position.average_price) * 100;
            }
        },
        clearError: (state) => {
            state.error = null;
        },
    },
    extraReducers: (builder) => {
        builder
            // Summary
            .addCase(fetchPortfolioSummary.pending, (state) => {
                state.isLoading = true;
            })
            .addCase(fetchPortfolioSummary.fulfilled, (state, action) => {
                state.isLoading = false;
                state.summary = action.payload;
                state.lastUpdated = new Date().toISOString();
            })
            .addCase(fetchPortfolioSummary.rejected, (state, action) => {
                state.isLoading = false;
                state.error = action.payload as string;
            })
            // Holdings
            .addCase(fetchHoldings.pending, (state) => {
                state.isLoading = true;
            })
            .addCase(fetchHoldings.fulfilled, (state, action) => {
                state.isLoading = false;
                state.holdings = action.payload || [];
            })
            .addCase(fetchHoldings.rejected, (state, action) => {
                state.isLoading = false;
                state.error = action.payload as string;
            })
            // Positions
            .addCase(fetchPositions.pending, (state) => {
                state.isLoading = true;
            })
            .addCase(fetchPositions.fulfilled, (state, action) => {
                state.isLoading = false;
                state.positions = action.payload || [];
            })
            .addCase(fetchPositions.rejected, (state, action) => {
                state.isLoading = false;
                state.error = action.payload as string;
            });
    },
});

export const { updateHoldingPrice, updatePositionPrice, clearError } = portfolioSlice.actions;
export default portfolioSlice.reducer;
