import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import type { PayloadAction } from '@reduxjs/toolkit';
import api, { endpoints } from '../../services/api';
import type { Quote, Instrument, MarketIndex } from '../../types';

interface MarketState {
    instruments: Instrument[];
    watchlist: string[];
    quotes: Record<string, Quote>;
    indices: MarketIndex[];
    selectedSymbol: string | null;
    isLoading: boolean;
    error: string | null;
}

const initialState: MarketState = {
    instruments: [],
    watchlist: ['RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'ICICIBANK'],
    quotes: {},
    indices: [],
    selectedSymbol: null,
    isLoading: false,
    error: null,
};

// Async thunks
export const fetchInstruments = createAsyncThunk(
    'market/fetchInstruments',
    async (params: { exchange?: string; segment?: string } = {}, { rejectWithValue }) => {
        try {
            const response = await api.get<{ data: Instrument[] }>(endpoints.market.instruments, { params });
            return response.data.data;
        } catch (error: any) {
            return rejectWithValue(error.response?.data?.message || 'Failed to fetch instruments');
        }
    }
);

export const fetchQuote = createAsyncThunk(
    'market/fetchQuote',
    async (symbol: string, { rejectWithValue }) => {
        try {
            const response = await api.get<{ data: Quote }>(endpoints.market.quote(symbol));
            return { symbol, quote: response.data.data };
        } catch (error: any) {
            return rejectWithValue(error.response?.data?.message || 'Failed to fetch quote');
        }
    }
);

export const fetchMultipleQuotes = createAsyncThunk(
    'market/fetchMultipleQuotes',
    async (symbols: string[], { rejectWithValue }) => {
        try {
            const response = await api.post<{ data: Record<string, Quote> }>(endpoints.market.quotes, { symbols });
            return response.data.data;
        } catch (error: any) {
            return rejectWithValue(error.response?.data?.message || 'Failed to fetch quotes');
        }
    }
);

export const fetchIndices = createAsyncThunk(
    'market/fetchIndices',
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get<{ data: MarketIndex[] }>(endpoints.market.indices);
            return response.data.data;
        } catch (error: any) {
            return rejectWithValue(error.response?.data?.message || 'Failed to fetch indices');
        }
    }
);

const marketSlice = createSlice({
    name: 'market',
    initialState,
    reducers: {
        setSelectedSymbol: (state, action: PayloadAction<string>) => {
            state.selectedSymbol = action.payload;
        },
        addToWatchlist: (state, action: PayloadAction<string>) => {
            if (!state.watchlist.includes(action.payload)) {
                state.watchlist.push(action.payload);
            }
        },
        removeFromWatchlist: (state, action: PayloadAction<string>) => {
            state.watchlist = state.watchlist.filter(s => s !== action.payload);
        },
        updateQuote: (state, action: PayloadAction<{ symbol: string; quote: Partial<Quote> }>) => {
            const { symbol, quote } = action.payload;
            if (state.quotes[symbol]) {
                state.quotes[symbol] = { ...state.quotes[symbol], ...quote };
            } else {
                state.quotes[symbol] = quote as Quote;
            }
        },
        clearError: (state) => {
            state.error = null;
        },
    },
    extraReducers: (builder) => {
        builder
            // Instruments
            .addCase(fetchInstruments.pending, (state) => {
                state.isLoading = true;
            })
            .addCase(fetchInstruments.fulfilled, (state, action) => {
                state.isLoading = false;
                state.instruments = action.payload || [];
            })
            .addCase(fetchInstruments.rejected, (state, action) => {
                state.isLoading = false;
                state.error = action.payload as string;
            })
            // Single quote
            .addCase(fetchQuote.fulfilled, (state, action) => {
                state.quotes[action.payload.symbol] = action.payload.quote;
            })
            // Multiple quotes
            .addCase(fetchMultipleQuotes.fulfilled, (state, action) => {
                state.quotes = { ...state.quotes, ...action.payload };
            })
            // Indices
            .addCase(fetchIndices.fulfilled, (state, action) => {
                state.indices = action.payload || [];
            });
    },
});

export const { setSelectedSymbol, addToWatchlist, removeFromWatchlist, updateQuote, clearError } = marketSlice.actions;
export default marketSlice.reducer;
