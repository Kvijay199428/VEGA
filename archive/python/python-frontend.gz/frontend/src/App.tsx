import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from './store';
import { useAppSelector, useAppDispatch } from './store/hooks';
import { Layout } from './components/layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Market from './pages/Market';
import Trading from './pages/Trading';
import Portfolio from './pages/Portfolio';
import Strategies from './pages/Strategies';
import Indicators from './pages/Indicators';
import Settings from './pages/Settings';
import EquityLiveFeed from './pages/EquityLiveFeed';
import OptionsChain from './pages/OptionsChain';
import OptionChainPopupPage from './pages/OptionChainPopupPage';
import EquityPopupPage from './pages/EquityPopupPage';
import Futures from './pages/Futures';
import { useEffect } from 'react';
import { fetchUserProfile } from './store/slices/authSlice';
import { ThemeProvider } from './theme';
import { TokenExpiryPopup } from './components/TokenExpiryPopup';

// Protected route wrapper
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const dispatch = useAppDispatch();
  const { isAuthenticated, user } = useAppSelector(state => state.auth);

  // Fetch user profile when authenticated and user data is not loaded
  useEffect(() => {
    if (isAuthenticated && !user) {
      dispatch(fetchUserProfile());
    }
  }, [isAuthenticated, user, dispatch]);

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

const AppRoutes = () => {
  const { isAuthenticated } = useAppSelector(state => state.auth);

  return (
    <ThemeProvider>
      <TokenExpiryPopup isAuthenticated={isAuthenticated} />
      <Routes>
        {/* Public routes */}
        <Route path="/login" element={<Login />} />

        {/* Popup pages - no layout wrapper */}
        <Route path="/options-popup" element={
          <ProtectedRoute>
            <OptionChainPopupPage />
          </ProtectedRoute>
        } />
        <Route path="/equity-popup" element={
          <ProtectedRoute>
            <EquityPopupPage />
          </ProtectedRoute>
        } />

        {/* Protected routes */}
        <Route path="/" element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }>
          <Route index element={<Dashboard />} />
          <Route path="market" element={<Market />} />
          <Route path="trading" element={<Trading />} />
          <Route path="portfolio" element={<Portfolio />} />
          <Route path="strategies" element={<Strategies />} />
          <Route path="indicators" element={<Indicators />} />
          <Route path="settings" element={<Settings />} />
          <Route path="equity-feed" element={<EquityLiveFeed />} />
          <Route path="options" element={<OptionsChain />} />
          <Route path="futures" element={<Futures />} />
        </Route>

        {/* Catch all */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </ThemeProvider>
  );
};

function App() {
  return (
    <Provider store={store}>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </Provider>
  );
}

export default App;