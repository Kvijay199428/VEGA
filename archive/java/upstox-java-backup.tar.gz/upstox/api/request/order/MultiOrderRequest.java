package com.vegatrader.upstox.api.request.order;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * Request DTO for placing multiple orders in a single request.
 *
 * @since 2.0.0
 */
public class MultiOrderRequest {

    @SerializedName("orders")
    private List<PlaceOrderRequest> orders;

    public MultiOrderRequest() {
    }

    public MultiOrderRequest(List<PlaceOrderRequest> orders) {
        this.orders = orders;
    }

    public List<PlaceOrderRequest> getOrders() {
        return orders;
    }

    public void setOrders(List<PlaceOrderRequest> orders) {
        this.orders = orders;
    }

    public int getOrderCount() {
        return orders != null ? orders.size() : 0;
    }

    public void validate() {
        if (orders == null || orders.isEmpty()) {
            throw new IllegalArgumentException("Orders list cannot be empty");
        }

        if (orders.size() > 10) {
            throw new IllegalArgumentException("Maximum 10 orders per batch request");
        }

        // Validate each order
        for (PlaceOrderRequest order : orders) {
            order.validate();
        }
    }
}
