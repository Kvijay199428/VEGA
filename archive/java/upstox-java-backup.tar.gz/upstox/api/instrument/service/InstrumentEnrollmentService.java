package com.vegatrader.upstox.api.instrument.service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.vegatrader.upstox.api.instrument.filter.InstrumentFilterCriteria;
import com.vegatrader.upstox.api.instrument.filter.InstrumentFilterService;
import com.vegatrader.upstox.api.response.instrument.InstrumentResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.io.*;
import java.lang.reflect.Type;
import java.net.URL;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.GZIPInputStream;

/**
 * Service for loading and managing instrument master data.
 * 
 * <p>
 * Loads instrument data from Upstox JSON files and provides
 * filtering and enrollment capabilities for MarketDataStreamerV3.
 * 
 * @since 3.0.0
 */
@Service
public class InstrumentEnrollmentService {

    private static final Logger logger = LoggerFactory.getLogger(InstrumentEnrollmentService.class);

    /**
     * Default instrument JSON URL for NSE.
     */
    public static final String DEFAULT_NSE_URL = "https://assets.upstox.com/market-quote/instruments/exchange/NSE.json.gz";

    /**
     * Default instrument JSON URL for BSE.
     */
    public static final String DEFAULT_BSE_URL = "https://assets.upstox.com/market-quote/instruments/exchange/BSE.json.gz";

    private final InstrumentFilterService filterService;
    private final Gson gson;
    private final Map<String, List<InstrumentResponse>> instrumentCache;

    public InstrumentEnrollmentService(InstrumentFilterService filterService) {
        this.filterService = filterService;
        this.gson = new Gson();
        this.instrumentCache = new ConcurrentHashMap<>();
    }

    @PostConstruct
    public void initialize() {
        logger.info("Instrument Enrollment Service initialized");
    }

    /**
     * Loads instruments from default NSE source.
     * 
     * @return list of instruments
     */
    public List<InstrumentResponse> loadNSEInstruments() {
        return loadInstruments(DEFAULT_NSE_URL, "NSE");
    }

    /**
     * Loads instruments from default BSE source.
     * 
     * @return list of instruments
     */
    public List<InstrumentResponse> loadBSEInstruments() {
        return loadInstruments(DEFAULT_BSE_URL, "BSE");
    }

    /**
     * Loads instruments from URL.
     * 
     * @param url      the URL to load from
     * @param exchange exchange name for caching
     * @return list of instruments
     */
    public List<InstrumentResponse> loadInstruments(String url, String exchange) {
        // Check cache first
        if (instrumentCache.containsKey(exchange)) {
            logger.info("Using cached instruments for {}", exchange);
            return instrumentCache.get(exchange);
        }

        logger.info("Loading instruments from: {}", url);

        try {
            List<InstrumentResponse> instruments = downloadAndParseInstruments(url);
            instrumentCache.put(exchange, instruments);
            logger.info("Loaded {} instruments from {}", instruments.size(), exchange);
            return instruments;
        } catch (Exception e) {
            logger.error("Failed to load instruments from {}", url, e);
            return List.of();
        }
    }

    /**
     * Downloads and parses instrument JSON file.
     */
    private List<InstrumentResponse> downloadAndParseInstruments(String urlString) throws IOException {
        URL url = new URL(urlString);

        try (InputStream inputStream = url.openStream();
                GZIPInputStream gzipStream = new GZIPInputStream(inputStream);
                InputStreamReader reader = new InputStreamReader(gzipStream)) {

            Type listType = new TypeToken<List<InstrumentResponse>>() {
            }.getType();
            return gson.fromJson(reader, listType);
        }
    }

    /**
     * Enrolls instruments based on filter criteria.
     * 
     * @param criteria filter criteria
     * @return list of enrolled instrument keys
     */
    public List<String> enrollInstruments(InstrumentFilterCriteria criteria) {
        // Load instruments (uses cache if available)
        List<InstrumentResponse> instruments = loadNSEInstruments();

        // Apply filters
        return filterService.extractInstrumentKeys(instruments, criteria);
    }

    /**
     * Enrolls instruments for a specific segment and type.
     * 
     * @param segment        segment (e.g., "NSE_EQ", "NSE_FO")
     * @param instrumentType instrument type (e.g., "EQ", "OPTION")
     * @return list of instrument keys
     */
    public List<String> enrollBySegmentAndType(String segment, String instrumentType) {
        InstrumentFilterCriteria criteria = InstrumentFilterCriteria.builder()
                .segment(segment)
                .instrumentType(instrumentType)
                .build();

        return enrollInstruments(criteria);
    }

    /**
     * Enrolls instruments by trading symbol pattern.
     * 
     * @param segment        segment
     * @param instrumentType instrument type
     * @param symbolPattern  symbol pattern
     * @param limit          max number of instruments
     * @return list of instrument keys
     */
    public List<String> enrollByPattern(String segment, String instrumentType,
            String symbolPattern, int limit) {
        InstrumentFilterCriteria criteria = InstrumentFilterCriteria.builder()
                .segment(segment)
                .instrumentType(instrumentType)
                .tradingSymbolPattern(symbolPattern)
                .limit(limit)
                .build();

        return enrollInstruments(criteria);
    }

    /**
     * Enrolls Reliance Equity (example).
     * 
     * @return Reliance equity instrument keys
     */
    public List<String> enrollRelianceEquity() {
        return enrollByPattern("NSE_EQ", "EQ", "RELIANCE", 1);
    }

    /**
     * Enrolls Nifty 50 index.
     * 
     * @return Nifty 50 instrument key
     */
    public List<String> enrollNifty50() {
        return enrollByPattern("NSE_INDEX", "INDEX", "NIFTY 50", 1);
    }

    /**
     * Enrolls Bank Nifty index.
     * 
     * @return Bank Nifty instrument key
     */
    public List<String> enrollBankNifty() {
        return enrollByPattern("NSE_INDEX", "INDEX", "NIFTY BANK", 1);
    }

    /**
     * Gets instrument details.
     * 
     * @param instrumentKey the instrument key
     * @return instrument details or null
     */
    public InstrumentResponse getInstrumentDetails(String instrumentKey) {
        List<InstrumentResponse> instruments = loadNSEInstruments();
        return instruments.stream()
                .filter(i -> i.getInstrumentKey().equals(instrumentKey))
                .findFirst()
                .orElse(null);
    }

    /**
     * Clears instrument cache.
     */
    public void clearCache() {
        instrumentCache.clear();
        logger.info("Instrument cache cleared");
    }

    /**
     * Gets cache statistics.
     * 
     * @return cache stats map
     */
    public Map<String, Object> getCacheStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("cached_exchanges", instrumentCache.keySet());
        stats.put("total_cached_instruments",
                instrumentCache.values().stream().mapToInt(List::size).sum());
        return stats;
    }
}
