package com.vegatrader.upstox.api.websocket;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.vegatrader.service.UpstoxTokenProvider;
import com.vegatrader.upstox.api.request.websocket.MarketDataFeedV3Request;
import com.vegatrader.upstox.api.response.websocket.MarketDataFeedV3Response;
import com.vegatrader.upstox.api.websocket.cache.MarketDataCache;
import com.vegatrader.upstox.api.websocket.listener.*;
import com.vegatrader.upstox.api.websocket.logging.MarketDataStreamerV3Logger;
import com.vegatrader.upstox.api.websocket.settings.ConnectionSettings;
import com.vegatrader.upstox.api.websocket.settings.MarketDataStreamerSettings;
import com.vegatrader.upstox.api.websocket.bus.*;
import com.vegatrader.upstox.api.websocket.buffer.*;
import com.vegatrader.upstox.api.websocket.protocol.UpstoxMessageParser;
import com.vegatrader.upstox.api.websocket.event.*;
import okhttp3.*;
import okio.ByteString;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Enhanced WebSocket client for Upstox Market Data Feed V3.
 * 
 * <p>
 * Features:
 * <ul>
 * <li>Database token integration</li>
 * <li>Tier-based subscription limits (Normal/Plus)</li>
 * <li>Structured logging with metrics</li>
 * <li>TTL-based caching</li>
 * <li>Authorization flow support</li>
 * <li>Auto-reconnect with customizable parameters</li>
 * <li>Event-driven architecture</li>
 * </ul>
 * 
 * @since 3.0.0
 */
public class MarketDataStreamerV3 {

    private final UpstoxTokenProvider tokenProvider;
    private final MarketDataStreamerSettings settings;
    private final MarketDataStreamerV3Logger logger;
    private final MarketDataCache cache;
    private final Gson gson;
    private final OkHttpClient httpClient;
    private final Set<String> subscribedInstruments;
    private final Map<String, Mode> instrumentModes;

    // Enterprise upgrade components
    private final EventBus eventBus;
    private final MarketDataBuffer buffer;
    private final UpstoxMessageParser messageParser;
    private final ExecutorService workerPool;

    private WebSocket webSocket;
    private final AtomicBoolean isConnected;
    private final AtomicBoolean isReconnecting;
    private final AtomicInteger reconnectAttempts;
    private ScheduledExecutorService reconnectScheduler;

    // Event listeners
    private OnOpenListener onOpenListener;
    private OnCloseListener onCloseListener;
    private OnMarketUpdateV3Listener onMarketUpdateListener;
    private OnErrorListener onErrorListener;
    private OnReconnectingListener onReconnectingListener;
    private OnAutoReconnectStoppedListener onAutoReconnectStoppedListener;

    // Initial subscription support
    private Set<String> initialInstrumentKeys;
    private Mode initialMode;

    /**
     * Creates streamer with token provider and settings.
     * 
     * @param tokenProvider token provider for database access
     * @param settings      configuration settings
     */
    public MarketDataStreamerV3(
            UpstoxTokenProvider tokenProvider,
            MarketDataStreamerSettings settings) {

        this.tokenProvider = tokenProvider;
        this.settings = settings;

        // Initialize logger
        this.logger = new MarketDataStreamerV3Logger(
                getClass(),
                settings.getLogFilePath(),
                settings.isEnableLogging(),
                settings.isLogMarketUpdates());

        // Initialize cache
        this.cache = new MarketDataCache(
                settings.getCacheTTL(),
                settings.getMaxCacheSize(),
                settings.isEnableCaching());

        this.gson = new Gson();
        this.subscribedInstruments = Collections.synchronizedSet(new HashSet<>());
        this.instrumentModes = new ConcurrentHashMap<>();
        this.isConnected = new AtomicBoolean(false);
        this.isReconnecting = new AtomicBoolean(false);
        this.reconnectAttempts = new AtomicInteger(0);

        // Initialize enterprise components
        this.eventBus = new InMemoryEventBus();
        this.buffer = new MarketDataBuffer(settings.getBufferCapacity());
        this.messageParser = new UpstoxMessageParser();

        // Initialize worker pool
        int workerCount = Runtime.getRuntime().availableProcessors();
        this.workerPool = Executors.newFixedThreadPool(workerCount, r -> {
            Thread t = new Thread(r);
            t.setName("MarketData-Worker-" + t.getId());
            t.setDaemon(true);
            return t;
        });

        // Start buffer consumers
        for (int i = 0; i < workerCount; i++) {
            workerPool.submit(new BufferConsumer(buffer, eventBus, "worker-" + i));
        }

        // Set up event subscribers
        setupEventSubscribers();

        // Build OkHttp client
        this.httpClient = new OkHttpClient.Builder()
                .readTimeout(settings.getReadTimeout(), TimeUnit.MILLISECONDS)
                .writeTimeout(settings.getWriteTimeout(), TimeUnit.MILLISECONDS)
                .connectTimeout(settings.getConnectTimeout(), TimeUnit.MILLISECONDS)
                .pingInterval(settings.getPingInterval(), TimeUnit.SECONDS)
                .build();

        logger.info("MarketDataStreamerV3 initialized with tier: {}", settings.getTier());
    }

    /**
     * Creates streamer with initial subscription.
     * 
     * @param tokenProvider  token provider
     * @param settings       configuration
     * @param instrumentKeys initial keys
     * @param mode           initial mode
     */
    public MarketDataStreamerV3(
            UpstoxTokenProvider tokenProvider,
            MarketDataStreamerSettings settings,
            Set<String> instrumentKeys,
            Mode mode) {
        this(tokenProvider, settings);
        this.initialInstrumentKeys = instrumentKeys;
        this.initialMode = mode;
    }

    /**
     * Establishes the WebSocket connection.
     */
    public synchronized void connect() {
        if (isConnected.get()) {
            logger.warn("Already connected");
            return;
        }

        int attemptNumber = reconnectAttempts.get() + 1;
        logger.logConnectionAttempt(attemptNumber);

        try {
            // Increment connection count
            if (settings.getConnectionSettings().canAddConnection()) {
                settings.getConnectionSettings().incrementConnections();
            }

            String accessToken = tokenProvider.getAccessToken();
            String wsUrl = getWebSocketUrl(accessToken);

            Request request = new Request.Builder()
                    .url(wsUrl)
                    .build();

            webSocket = httpClient.newWebSocket(request, new WebSocketListener() {
                @Override
                public void onOpen(WebSocket webSocket, Response response) {
                    handleOnOpen();
                }

                @Override
                public void onMessage(WebSocket webSocket, String text) {
                    handleMessage(text);
                }

                @Override
                public void onMessage(WebSocket webSocket, ByteString bytes) {
                    handleBinaryMessage(bytes);
                }

                @Override
                public void onClosing(WebSocket webSocket, int code, String reason) {
                    webSocket.close(1000, null);
                }

                @Override
                public void onClosed(WebSocket webSocket, int code, String reason) {
                    handleOnClose(code, reason);
                }

                @Override
                public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                    handleError(new Exception("WebSocket failure", t));
                }
            });

        } catch (Exception e) {
            logger.logConnectionError("Failed to connect", e);
            handleError(e);
        }
    }

    /**
     * Gets WebSocket URL (with authorization if enabled).
     */
    private String getWebSocketUrl(String accessToken) throws Exception {
        if (!settings.isUseAuthorizeEndpoint()) {
            return settings.getWsUrl();
        }

        // Use authorization endpoint to get WebSocket URL
        String authorizedUrl = getAuthorizedUrl(accessToken);
        return authorizedUrl != null ? authorizedUrl : settings.getWsUrl();
    }

    /**
     * Gets authorized WebSocket URL via 302 redirect flow.
     */
    private String getAuthorizedUrl(String token) throws Exception {
        String authUrl = settings.getAuthorizeUrl();
        Request request = new Request.Builder()
                .url(authUrl)
                .header("Authorization", "Bearer " + token)
                .header("Accept", "*/*")
                .build();

        OkHttpClient authClient = new OkHttpClient.Builder()
                .followRedirects(false)
                .build();

        try (Response response = authClient.newCall(request).execute()) {
            if (response.code() == 302) {
                return response.header("Location");
            } else if (response.isSuccessful()) {
                JsonNode node = new ObjectMapper()
                        .readTree(response.body().string());
                if ("success".equals(node.path("status").asText())) {
                    return node.path("data").path("authorizedRedirectUri").asText();
                }
            }
            logger.logConnectionError("Auth failed with status: " + response.code(), null);
            return null;
        }
    }

    /**
     * Disconnects the WebSocket connection.
     */
    public synchronized void disconnect() {
        if (webSocket != null) {
            webSocket.close(1000, "Client disconnect");
            webSocket = null;
        }
        isConnected.set(false);

        if (reconnectScheduler != null) {
            reconnectScheduler.shutdownNow();
            reconnectScheduler = null;
        }

        settings.getConnectionSettings().decrementConnections();
        logger.info("Disconnected");
    }

    /**
     * Subscribes to market data for the specified instruments.
     * 
     * @param instrumentKeys the instrument keys to subscribe
     * @param mode           the subscription mode
     */
    public void subscribe(Set<String> instrumentKeys, Mode mode) {
        if (instrumentKeys == null || instrumentKeys.isEmpty()) {
            throw new IllegalArgumentException("Instrument keys cannot be empty");
        }

        if (mode == null) {
            throw new IllegalArgumentException("Mode cannot be null");
        }

        // Validate subscription limits
        try {
            settings.getConnectionSettings().validateSubscription(mode, instrumentKeys.size());
            logger.logLimitValidation(mode.toString(), instrumentKeys.size(),
                    mode.getIndividualLimit(), true);
        } catch (ConnectionSettings.SubscriptionLimitExceededException e) {
            logger.logLimitValidation(mode.toString(), instrumentKeys.size(),
                    mode.getIndividualLimit(), false);
            logger.logSubscriptionError("subscribe", e.getMessage());
            throw e;
        }

        logger.logSubscription("subscribe", mode.toString(), instrumentKeys.size());

        MarketDataFeedV3Request request = MarketDataFeedV3Request.builder()
                .subscribe()
                .mode(mode.getMarketDataMode())
                .instrumentKeys(new ArrayList<>(instrumentKeys))
                .build();

        sendRequest(request);

        // Track subscriptions
        settings.getConnectionSettings().addSubscriptions(mode, instrumentKeys.size());
        subscribedInstruments.addAll(instrumentKeys);
        for (String key : instrumentKeys) {
            instrumentModes.put(key, mode);
        }

        logger.logSubscriptionSuccess("subscribe", instrumentKeys.size());
    }

    /**
     * Unsubscribes from market data for the specified instruments.
     * 
     * @param instrumentKeys the instrument keys to unsubscribe
     */
    public void unsubscribe(Set<String> instrumentKeys) {
        if (instrumentKeys == null || instrumentKeys.isEmpty()) {
            throw new IllegalArgumentException("Instrument keys cannot be empty");
        }

        // Get the mode from existing subscriptions
        Mode mode = instrumentModes.values().stream().findFirst().orElse(Mode.LTPC);

        logger.logSubscription("unsubscribe", mode.toString(), instrumentKeys.size());

        MarketDataFeedV3Request request = MarketDataFeedV3Request.builder()
                .unsubscribe()
                .mode(mode.getMarketDataMode())
                .instrumentKeys(new ArrayList<>(instrumentKeys))
                .build();

        sendRequest(request);

        // Remove from tracking
        settings.getConnectionSettings().removeSubscriptions(mode, instrumentKeys.size());
        subscribedInstruments.removeAll(instrumentKeys);
        for (String key : instrumentKeys) {
            instrumentModes.remove(key);
        }

        logger.logSubscriptionSuccess("unsubscribe", instrumentKeys.size());
    }

    /**
     * Changes the subscription mode for already subscribed instruments.
     * 
     * @param instrumentKeys the instrument keys to change mode for
     * @param mode           the new subscription mode
     */
    public void changeMode(Set<String> instrumentKeys, Mode mode) {
        if (instrumentKeys == null || instrumentKeys.isEmpty()) {
            throw new IllegalArgumentException("Instrument keys cannot be empty");
        }

        if (mode == null) {
            throw new IllegalArgumentException("Mode cannot be null");
        }

        logger.logSubscription("change_mode", mode.toString(), instrumentKeys.size());

        MarketDataFeedV3Request request = MarketDataFeedV3Request.builder()
                .changeMode()
                .mode(mode.getMarketDataMode())
                .instrumentKeys(new ArrayList<>(instrumentKeys))
                .build();

        sendRequest(request);

        // Update mode tracking
        settings.getConnectionSettings().changeMode(mode, instrumentKeys.size());
        for (String key : instrumentKeys) {
            instrumentModes.put(key, mode);
        }

        logger.logSubscriptionSuccess("change_mode", instrumentKeys.size());
    }

    /**
     * Enables or disables auto-reconnect.
     * 
     * @param enable true to enable, false to disable
     */
    public void autoReconnect(boolean enable) {
        settings.setAutoReconnectEnabled(enable);
        logger.info("Auto-reconnect {}", enable ? "enabled" : "disabled");
    }

    /**
     * Configures auto-reconnect parameters.
     * 
     * @param enable     true to enable auto-reconnect
     * @param interval   reconnect interval in seconds
     * @param retryCount maximum number of retry attempts
     */
    public void autoReconnect(boolean enable, int interval, int retryCount) {
        settings.setAutoReconnectEnabled(enable);
        settings.setReconnectInterval(interval);
        settings.setMaxReconnectAttempts(retryCount);
        logger.info("Auto-reconnect configured: enabled={}, interval={}s, maxAttempts={}",
                enable, interval, retryCount);
    }

    // Event listener setters

    public void setOnOpenListener(OnOpenListener listener) {
        this.onOpenListener = listener;
    }

    public void setOnCloseListener(OnCloseListener listener) {
        this.onCloseListener = listener;
    }

    public void setOnMarketUpdateListener(OnMarketUpdateV3Listener listener) {
        this.onMarketUpdateListener = listener;
    }

    public void setOnErrorListener(OnErrorListener listener) {
        this.onErrorListener = listener;
    }

    public void setOnReconnectingListener(OnReconnectingListener listener) {
        this.onReconnectingListener = listener;
    }

    public void setOnAutoReconnectStoppedListener(OnAutoReconnectStoppedListener listener) {
        this.onAutoReconnectStoppedListener = listener;
    }

    // Private helper methods

    private void handleOnOpen() {
        isConnected.set(true);
        reconnectAttempts.set(0);
        isReconnecting.set(false);
        logger.logConnectionSuccess();

        // Call user listener
        if (onOpenListener != null) {
            try {
                onOpenListener.onOpen();
            } catch (Exception e) {
                logger.error("Error in onOpen listener", e);
            }
        }

        // Auto-subscribe if initial keys were provided
        if (initialInstrumentKeys != null && initialMode != null) {
            subscribe(initialInstrumentKeys, initialMode);
        }
    }

    private void handleOnClose(int code, String reason) {
        boolean wasConnected = isConnected.getAndSet(false);
        logger.logConnectionClosed(code, reason);

        // Call user listener
        if (onCloseListener != null) {
            try {
                onCloseListener.onClose(code, reason);
            } catch (Exception e) {
                logger.error("Error in onClose listener", e);
            }
        }

        // Attempt reconnection if enabled and wasn't a clean disconnect
        if (wasConnected && settings.isAutoReconnectEnabled() && code != 1000) {
            attemptReconnect();
        }
    }

    private void handleMessage(String text) {
        try {
            long startTime = System.currentTimeMillis();

            MarketDataFeedV3Response response = gson.fromJson(text, MarketDataFeedV3Response.class);
            MarketUpdateV3 update = new MarketUpdateV3(response);

            logger.logMessageReceived(update.getType() != null ? update.getType().toString() : "unknown",
                    update.getFeedCount());

            // Cache live feed updates
            if (update.isLiveFeed() && cache.isEnabled()) {
                if (update.getFeeds() != null) {
                    update.getFeeds().forEach((key, data) -> {
                        cache.put(key, update);
                    });
                }
            }

            // Notify listeners
            if (onMarketUpdateListener != null) {
                onMarketUpdateListener.onUpdate(update);
            }

            long processingTime = System.currentTimeMillis() - startTime;
            logger.logMessageProcessed(update.getType() != null ? update.getType().toString() : "unknown",
                    processingTime);

        } catch (Exception e) {
            logger.logParsingError("Failed to parse message", e);
            handleError(e);
        }
    }

    private void handleBinaryMessage(ByteString bytes) {
        try {
            // For now, treat as JSON (Upstox V3 uses JSON encoding)
            String json = bytes.utf8();
            handleMessage(json);
        } catch (Exception e) {
            logger.error("Error handling binary message", e);
            handleError(e);
        }
    }

    private void handleError(Exception error) {
        logger.error("WebSocket error", error);

        if (onErrorListener != null) {
            try {
                onErrorListener.onError(error);
            } catch (Exception e) {
                logger.error("Error in onError listener", e);
            }
        }
    }

    /**
     * Sets up event subscribers for the enterprise event bus.
     * 
     * <p>
     * Subscribers handle:
     * <ul>
     * <li>Market update events (caching, logging)</li>
     * <li>Heartbeat events (connection monitoring)</li>
     * <li>Error events (error handling)</li>
     * <li>Unknown events (schema drift monitoring)</li>
     * </ul>
     */
    private void setupEventSubscribers() {
        // Market update subscriber - cache updates
        eventBus.subscribe(MarketUpdateEvent.class, event -> {
            if (event instanceof MarketUpdateV3 update) {
                if (cache != null && settings.isEnableCaching()) {
                    cache.put(event.getInstrumentKey(), update);
                }

                // Call existing listener if set (listener expects MarketUpdateEvent)
                if (onMarketUpdateListener != null) {
                    onMarketUpdateListener.onUpdate(update);
                }
            }
        });

        // Heartbeat subscriber - connection health monitoring
        eventBus.subscribe(HeartbeatEvent.class, event -> {
            logger.info("Heartbeat received at {}", event.getTimestamp());
        });

        // Error subscriber - error handling
        eventBus.subscribe(UpstoxErrorEvent.class, event -> {
            logger.error("Upstox error: {} - {}", event.getCode(), event.getMessage());
            if (onErrorListener != null) {
                onErrorListener.onError(new Exception(event.getMessage()));
            }
        });

        // Unknown event subscriber - schema drift monitoring
        eventBus.subscribe(UnknownEvent.class, event -> {
            logger.warn("Unknown message type detected: {} - {}",
                    event.getType(), event.getRawJson().substring(0, Math.min(100, event.getRawJson().length())));
        });

        logger.info("Event subscribers configured");
    }

    /**
     * Processes messages using enterprise parser and buffer.
     * 
     * @param json the raw JSON message
     */
    private void processMessageWithEnterpriseComponents(String json) {
        try {
            MarketUpdateEvent event = messageParser.parse(json);

            if (event instanceof MarketUpdateV3 update) {
                // Offer to buffer (non-blocking)
                boolean accepted = buffer.offer(update);
                if (!accepted) {
                    logger.warn("Buffer full - message dropped");
                }
            } else {
                // Heartbeat, errors, unknown events - publish directly
                eventBus.publish(event);
            }
        } catch (Exception e) {
            logger.error("Failed to process message: {}", e.getMessage());
        }
    }

    /**
     * Gets the event bus.
     * 
     * @return the event bus
     */
    public EventBus getEventBus() {
        return eventBus;
    }

    /**
     * Gets buffer statistics.
     * 
     * @return buffer statistics
     */
    public MarketDataBuffer.BufferStatistics getBufferStatistics() {
        return buffer.getStatistics();
    }

    /**
     * Shuts down the worker pool.
     */
    public void shutdown() {
        if (workerPool != null && !workerPool.isShutdown()) {
            logger.info("Shutting down worker pool");
            workerPool.shutdown();
            try {
                if (!workerPool.awaitTermination(5, TimeUnit.SECONDS)) {
                    workerPool.shutdownNow();
                }
            } catch (InterruptedException e) {
                workerPool.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }

    private void attemptReconnect() {
        if (isReconnecting.get()) {
            return;
        }

        isReconnecting.set(true);
        int currentAttempt = reconnectAttempts.incrementAndGet();

        if (currentAttempt > settings.getMaxReconnectAttempts()) {
            String msg = String.format("Max reconnect attempts (%d) reached",
                    settings.getMaxReconnectAttempts());
            logger.logReconnectStopped(msg);

            if (onAutoReconnectStoppedListener != null) {
                onAutoReconnectStoppedListener.onHault(msg);
            }

            isReconnecting.set(false);
            return;
        }

        logger.logReconnectAttempt(currentAttempt, settings.getMaxReconnectAttempts());

        if (onReconnectingListener != null) {
            try {
                onReconnectingListener.onReconnecting(currentAttempt);
            } catch (Exception e) {
                logger.error("Error in onReconnecting listener", e);
            }
        }

        if (reconnectScheduler == null || reconnectScheduler.isShutdown()) {
            reconnectScheduler = Executors.newSingleThreadScheduledExecutor();
        }

        reconnectScheduler.schedule(() -> {
            try {
                connect();

                // Resubscribe to previous subscriptions
                if (!subscribedInstruments.isEmpty()) {
                    Map<Mode, Set<String>> modeGroups = new HashMap<>();
                    for (String key : subscribedInstruments) {
                        Mode mode = instrumentModes.get(key);
                        modeGroups.computeIfAbsent(mode, k -> new HashSet<>()).add(key);
                    }

                    for (Map.Entry<Mode, Set<String>> entry : modeGroups.entrySet()) {
                        subscribe(entry.getValue(), entry.getKey());
                    }
                }
                logger.logReconnectSuccess(currentAttempt);
            } catch (Exception e) {
                logger.error("Reconnection failed", e);
                attemptReconnect();
            }
        }, settings.getReconnectInterval(), TimeUnit.SECONDS);
    }

    private void sendRequest(MarketDataFeedV3Request request) {
        if (webSocket == null || !isConnected.get()) {
            throw new IllegalStateException("WebSocket is not connected");
        }

        try {
            String json = gson.toJson(request);
            boolean sent = webSocket.send(json);

            if (!sent) {
                throw new IllegalStateException("Failed to send message");
            }

            logger.debug("Sent request: {}", request);
        } catch (Exception e) {
            logger.error("Error sending request", e);
            handleError(e);
        }
    }

    // Public getters

    /**
     * Gets the current connection status.
     * 
     * @return true if connected
     */
    public boolean isConnected() {
        return isConnected.get();
    }

    /**
     * Gets the set of currently subscribed instruments.
     * 
     * @return unmodifiable set of subscribed instrument keys
     */
    public Set<String> getSubscribedInstruments() {
        return Collections.unmodifiableSet(new HashSet<>(subscribedInstruments));
    }

    /**
     * Gets the subscription mode for a specific instrument.
     * 
     * @param instrumentKey the instrument key
     * @return the Mode, or null if not subscribed
     */
    public Mode getInstrumentMode(String instrumentKey) {
        return instrumentModes.get(instrumentKey);
    }

    /**
     * Gets the logger.
     * 
     * @return the logger instance
     */
    public MarketDataStreamerV3Logger getLogger() {
        return logger;
    }

    /**
     * Gets the cache.
     * 
     * @return the cache instance
     */
    public MarketDataCache getCache() {
        return cache;
    }

    /**
     * Gets the settings.
     * 
     * @return the settings instance
     */
    public MarketDataStreamerSettings getSettings() {
        return settings;
    }
}
