package com.vegatrader.upstox.api.websocket;

import com.vegatrader.upstox.api.request.websocket.MarketDataMode;

/**
 * Subscription modes for Market Data Feed V3.
 * 
 * <p>
 * This enum provides SDK-style naming that maps to {@link MarketDataMode}.
 * 
 * @since 3.0.0
 */
public enum Mode {

    /**
     * LTPC mode - Last Traded Price and Close Price only.
     * Individual limit: 5000, Combined limit: 2000
     */
    LTPC(MarketDataMode.LTPC),

    /**
     * Full mode - LTPC + 5 market levels + OHLC + Option Greeks.
     * Individual limit: 2000, Combined limit: 1500
     */
    FULL(MarketDataMode.FULL),

    /**
     * Full D30 mode - LTPC + 30 market levels + OHLC + Option Greeks (Plus
     * subscription).
     * Individual limit: 50, Combined limit: 1500
     */
    FULL_D30(MarketDataMode.FULL_D30),

    /**
     * Option Greeks mode - Option sensitivity metrics only.
     * Individual limit: 3000, Combined limit: 2000
     */
    OPTION_GREEKS(MarketDataMode.OPTION_GREEKS);

    private final MarketDataMode marketDataMode;

    Mode(MarketDataMode marketDataMode) {
        this.marketDataMode = marketDataMode;
    }

    /**
     * Gets the corresponding MarketDataMode for this mode.
     * 
     * @return the MarketDataMode enum
     */
    public MarketDataMode getMarketDataMode() {
        return marketDataMode;
    }

    /**
     * Gets the string value for JSON serialization.
     * 
     * @return the mode string value
     */
    public String getValue() {
        return marketDataMode.getValue();
    }

    /**
     * Gets the individual subscription limit.
     * 
     * @return the individual limit
     */
    public int getIndividualLimit() {
        return marketDataMode.getIndividualLimit();
    }

    /**
     * Gets the combined subscription limit.
     * 
     * @return the combined limit
     */
    public int getCombinedLimit() {
        return marketDataMode.getCombinedLimit();
    }

    /**
     * Converts a string value to Mode enum.
     * 
     * @param value the string value
     * @return the Mode enum
     * @throws IllegalArgumentException if value is invalid
     */
    public static Mode fromValue(String value) {
        MarketDataMode mdMode = MarketDataMode.fromValue(value);
        for (Mode mode : values()) {
            if (mode.marketDataMode == mdMode) {
                return mode;
            }
        }
        throw new IllegalArgumentException("Unknown mode: " + value);
    }

    @Override
    public String toString() {
        return marketDataMode.getValue();
    }
}
