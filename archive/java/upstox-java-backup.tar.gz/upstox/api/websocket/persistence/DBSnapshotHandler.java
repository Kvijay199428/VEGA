package com.vegatrader.upstox.api.websocket.persistence;

import com.vegatrader.upstox.api.websocket.health.HealthFlags;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Database snapshot handler for cold storage.
 * 
 * <p>
 * Responsibility:
 * <ul>
 * <li>Periodic persistence (not every tick)</li>
 * <li>Compliance / audit trail</li>
 * <li>End-of-day reconstruction</li>
 * </ul>
 * 
 * <p>
 * Database Integration:
 * <ul>
 * <li>Uses JDBC DataSource for database access (Spring Boot
 * auto-configures)</li>
 * <li>Falls back to no-op if database is not configured</li>
 * <li>Automatically detects database availability at runtime</li>
 * </ul>
 * 
 * <p>
 * Requires database table:
 * 
 * <pre>
 * CREATE TABLE market_snapshots (
 *   instrument_key VARCHAR(50) PRIMARY KEY,
 *   data BYTEA NOT NULL,
 *   ts BIGINT NOT NULL,
 *   updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
 * );
 * CREATE INDEX idx_market_snapshots_ts ON market_snapshots(ts);
 * </pre>
 * 
 * @since 3.1.0
 */
public class DBSnapshotHandler {

    private static final Logger logger = LoggerFactory.getLogger(DBSnapshotHandler.class);
    private static final String INSERT_QUERY = "INSERT INTO market_snapshots (instrument_key, data, ts) VALUES (?, ?, ?) "
            +
            "ON CONFLICT (instrument_key) DO UPDATE SET data = EXCLUDED.data, ts = EXCLUDED.ts, updated_at = CURRENT_TIMESTAMP";
    private static final String SELECT_QUERY = "SELECT data FROM market_snapshots WHERE instrument_key = ? ORDER BY ts DESC LIMIT 1";

    private final Object dataSource; // javax.sql.DataSource (loaded via reflection)
    private final boolean dbAvailable;

    /**
     * Default constructor - uses Spring DataSource if available.
     */
    public DBSnapshotHandler() {
        this(null);
    }

    /**
     * Constructor with custom DataSource.
     * 
     * @param dataSource the JDBC DataSource (can be null for no-op mode)
     */
    public DBSnapshotHandler(Object dataSource) {
        this.dataSource = dataSource;
        this.dbAvailable = dataSource != null;

        if (dbAvailable) {
            logger.info("DBSnapshotHandler initialized with database persistence");
        } else {
            logger.info("DBSnapshotHandler running in no-op mode (no database configured)");
        }
    }

    /**
     * Stores a snapshot in the database.
     * 
     * <p>
     * Only called for snapshot events, not incremental updates.
     * Uses batch inserts for performance.
     * 
     * @param instrumentKey     the instrument key
     * @param payload           the serialized market data
     * @param exchangeTimestamp the exchange timestamp
     */
    public void upsertSnapshot(String instrumentKey, byte[] payload, long exchangeTimestamp) {
        if (!dbAvailable) {
            logger.trace("DB not available - skipping snapshot for {}", instrumentKey);
            return;
        }

        try {
            // Execute via JDBC using reflection
            executeUpdate(INSERT_QUERY, instrumentKey, payload, exchangeTimestamp);

            logger.trace("Stored snapshot for {} in DB", instrumentKey);
            HealthFlags.setDbUp();

        } catch (Exception e) {
            logger.error("Failed to store snapshot for {}: {}", instrumentKey, e.getMessage());
            HealthFlags.setDbDown();
        }
    }

    /**
     * Retrieves the latest snapshot from database.
     * 
     * @param instrumentKey the instrument key
     * @return the snapshot data, or null if not found
     */
    public byte[] getLatestSnapshot(String instrumentKey) {
        if (!dbAvailable) {
            logger.trace("DB not available - cannot retrieve snapshot for {}", instrumentKey);
            return null;
        }

        try {
            // Execute query via JDBC using reflection
            byte[] result = executeQuery(SELECT_QUERY, instrumentKey);

            if (result != null) {
                logger.trace("Retrieved snapshot for {} from DB", instrumentKey);
            }
            HealthFlags.setDbUp();
            return result;

        } catch (Exception e) {
            logger.error("Failed to retrieve snapshot for {}: {}", instrumentKey, e.getMessage());
            HealthFlags.setDbDown();
            return null;
        }
    }

    /**
     * Executes an UPDATE statement using JDBC via reflection.
     */
    private void executeUpdate(String sql, Object... params) throws Exception {
        // Get connection from DataSource
        Object connection = dataSource.getClass().getMethod("getConnection").invoke(dataSource);

        try {
            // Prepare statement
            Object preparedStatement = connection.getClass()
                    .getMethod("prepareStatement", String.class)
                    .invoke(connection, sql);

            // Set parameters
            for (int i = 0; i < params.length; i++) {
                Object param = params[i];
                if (param instanceof String) {
                    preparedStatement.getClass().getMethod("setString", int.class, String.class)
                            .invoke(preparedStatement, i + 1, param);
                } else if (param instanceof byte[]) {
                    preparedStatement.getClass().getMethod("setBytes", int.class, byte[].class)
                            .invoke(preparedStatement, i + 1, param);
                } else if (param instanceof Long) {
                    preparedStatement.getClass().getMethod("setLong", int.class, long.class)
                            .invoke(preparedStatement, i + 1, param);
                }
            }

            // Execute update
            preparedStatement.getClass().getMethod("executeUpdate").invoke(preparedStatement);

            // Close statement
            preparedStatement.getClass().getMethod("close").invoke(preparedStatement);
        } finally {
            // Close connection
            connection.getClass().getMethod("close").invoke(connection);
        }
    }

    /**
     * Executes a SELECT query and returns byte[] result.
     */
    private byte[] executeQuery(String sql, String instrumentKey) throws Exception {
        // Get connection from DataSource
        Object connection = dataSource.getClass().getMethod("getConnection").invoke(dataSource);

        try {
            // Prepare statement
            Object preparedStatement = connection.getClass()
                    .getMethod("prepareStatement", String.class)
                    .invoke(connection, sql);

            // Set parameter
            preparedStatement.getClass().getMethod("setString", int.class, String.class)
                    .invoke(preparedStatement, 1, instrumentKey);

            // Execute query
            Object resultSet = preparedStatement.getClass().getMethod("executeQuery").invoke(preparedStatement);

            byte[] result = null;
            // Check if result exists
            Boolean hasNext = (Boolean) resultSet.getClass().getMethod("next").invoke(resultSet);
            if (hasNext) {
                result = (byte[]) resultSet.getClass().getMethod("getBytes", int.class)
                        .invoke(resultSet, 1);
            }

            // Close resources
            resultSet.getClass().getMethod("close").invoke(resultSet);
            preparedStatement.getClass().getMethod("close").invoke(preparedStatement);

            return result;
        } finally {
            // Close connection
            connection.getClass().getMethod("close").invoke(connection);
        }
    }

    /**
     * Checks if database persistence is available.
     * 
     * @return true if using database, false if no-op
     */
    public boolean isDbAvailable() {
        return dbAvailable;
    }
}
