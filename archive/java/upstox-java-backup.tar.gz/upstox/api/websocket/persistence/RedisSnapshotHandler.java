package com.vegatrader.upstox.api.websocket.persistence;

import com.vegatrader.upstox.api.websocket.health.HealthFlags;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.nio.charset.StandardCharsets;

/**
 * Redis snapshot handler for hot storage.
 * 
 * <p>
 * Responsibility:
 * <ul>
 * <li>Store latest snapshot per instrument</li>
 * <li>Fast recovery after reconnect</li>
 * <li>TTL-based expiry (3:30 AM cutoff)</li>
 * </ul>
 * 
 * <p>
 * Redis Integration:
 * <ul>
 * <li>Uses Lettuce client if available (add io.lettuce:lettuce-core to
 * pom.xml)</li>
 * <li>Falls back to in-memory HashMap if Redis is not configured</li>
 * <li>Automatically detects Redis availability at runtime</li>
 * </ul>
 * 
 * <p>
 * To enable Redis (optional):
 * 
 * <pre>
 * &lt;dependency&gt;
 *   &lt;groupId&gt;io.lettuce&lt;/groupId&gt;
 *   &lt;artifactId&gt;lettuce-core&lt;/artifactId&gt;
 *   &lt;version&gt;6.3.0.RELEASE&lt;/version&gt;
 * &lt;/dependency&gt;
 * </pre>
 * 
 * @since 3.1.0
 */
public class RedisSnapshotHandler {

    private static final Logger logger = LoggerFactory.getLogger(RedisSnapshotHandler.class);
    private static final String REDIS_KEY_PREFIX = "md:";

    // Redis client (loaded via reflection to avoid hard dependency)
    private final Object redisClient; // Type: io.lettuce.core.api.StatefulRedisConnection (if available)
    private final boolean redisAvailable;

    // Fallback in-memory storage when Redis is not available
    private final Map<String, byte[]> fallbackStorage = new HashMap<>();

    /**
     * Default constructor - attempts to connect to Redis on localhost:6379.
     * Falls back to in-memory storage if Redis is unavailable.
     */
    public RedisSnapshotHandler() {
        this("redis://localhost:6379");
    }

    /**
     * Constructor with custom Redis URL.
     * 
     * @param redisUrl Redis connection URL (e.g., "redis://localhost:6379")
     */
    public RedisSnapshotHandler(String redisUrl) {
        Object client = null;
        boolean available = false;

        try {
            // Attempt to load Lettuce RedisClient via reflection (optional dependency)
            Class<?> redisClientClass = Class.forName("io.lettuce.core.RedisClient");
            Class<?> redisURIClass = Class.forName("io.lettuce.core.RedisURI");

            // Parse Redis URI
            Object redisURI = redisURIClass.getMethod("create", String.class).invoke(null, redisUrl);

            // Create Redis client
            Object tempClient = redisClientClass.getMethod("create", redisURIClass).invoke(null, redisURI);

            // Connect (StatefulRedisConnection)
            client = tempClient.getClass().getMethod("connect").invoke(tempClient);

            available = true;
            logger.info("Redis client connected successfully to {}", redisUrl);
        } catch (ClassNotFoundException e) {
            logger.warn("Lettuce Redis client not found - add dependency to pom.xml. Using in-memory fallback.");
        } catch (Exception e) {
            logger.warn("Failed to connect to Redis at {}: {}. Using in-memory fallback.",
                    redisUrl, e.getMessage());
        }

        this.redisClient = client;
        this.redisAvailable = available;

        if (!available) {
            logger.info("RedisSnapshotHandler running in fallback mode (in-memory)");
        }
    }

    /**
     * Stores a market data snapshot in Redis.
     * 
     * @param instrumentKey the instrument key
     * @param payload       the serialized market data
     * @param ttlSeconds    TTL in seconds (until 3:30 AM)
     */
    public void storeSnapshot(String instrumentKey, byte[] payload, long ttlSeconds) {
        try {
            String key = REDIS_KEY_PREFIX + instrumentKey;

            if (redisAvailable && redisClient != null) {
                // Use Redis via reflection
                storeInRedis(key, payload, ttlSeconds);
            } else {
                // Use fallback in-memory storage
                fallbackStorage.put(key, payload);
            }

            logger.trace("Stored snapshot for {} (mode: {})",
                    instrumentKey, redisAvailable ? "Redis" : "in-memory");
            HealthFlags.setRedisUp();

        } catch (Exception e) {
            logger.error("Failed to store snapshot for {}: {}", instrumentKey, e.getMessage());
            HealthFlags.setRedisDown();
        }
    }

    /**
     * Retrieves a snapshot from Redis.
     * 
     * @param instrumentKey the instrument key
     * @return the snapshot data, or null if not found
     */
    public byte[] getSnapshot(String instrumentKey) {
        try {
            String key = REDIS_KEY_PREFIX + instrumentKey;
            byte[] data;

            if (redisAvailable && redisClient != null) {
                // Retrieve from Redis via reflection
                data = getFromRedis(key);
            } else {
                // Retrieve from fallback in-memory storage
                data = fallbackStorage.get(key);
            }

            if (data != null) {
                logger.trace("Retrieved snapshot for {} from {}",
                        instrumentKey, redisAvailable ? "Redis" : "in-memory");
            }
            HealthFlags.setRedisUp();
            return data;

        } catch (Exception e) {
            logger.error("Failed to retrieve snapshot for {}: {}", instrumentKey, e.getMessage());
            HealthFlags.setRedisDown();
            return null;
        }
    }

    /**
     * Stores data in Redis using reflection (to avoid hard dependency).
     */
    private void storeInRedis(String key, byte[] value, long ttlSeconds) throws Exception {
        // Get sync commands: redisClient.sync()
        Object syncCommands = redisClient.getClass().getMethod("sync").invoke(redisClient);

        // Call: syncCommands.setex(key, ttlSeconds, value)
        syncCommands.getClass()
                .getMethod("setex", String.class, long.class, byte[].class)
                .invoke(syncCommands, key, ttlSeconds, value);
    }

    /**
     * Retrieves data from Redis using reflection (to avoid hard dependency).
     */
    private byte[] getFromRedis(String key) throws Exception {
        // Get sync commands: redisClient.sync()
        Object syncCommands = redisClient.getClass().getMethod("sync").invoke(redisClient);

        // Call: syncCommands.get(key)
        Object result = syncCommands.getClass()
                .getMethod("get", Object.class)
                .invoke(syncCommands, key);

        return (byte[]) result;
    }

    /**
     * Checks if Redis is available.
     * 
     * @return true if using Redis, false if using fallback
     */
    public boolean isRedisAvailable() {
        return redisAvailable;
    }

    /**
     * Closes the Redis connection (if open).
     */
    public void close() {
        if (redisClient != null) {
            try {
                redisClient.getClass().getMethod("close").invoke(redisClient);
                logger.info("Redis connection closed");
            } catch (Exception e) {
                logger.error("Failed to close Redis connection: {}", e.getMessage());
            }
        }
    }

    /**
     * Calculates TTL until 3:30 AM next day.
     * 
     * @return seconds until 3:30 AM IST
     */
    private long ttlUntil330AM() {
        java.time.LocalDateTime now = com.vegatrader.upstox.api.utils.DateTimeUtils.now();
        java.time.LocalDateTime target;

        // If current time is before 3:30 AM, target is today 3:30 AM
        // Otherwise, target is tomorrow 3:30 AM
        if (now.getHour() < 3 || (now.getHour() == 3 && now.getMinute() < 30)) {
            target = now.toLocalDate().atTime(3, 30);
        } else {
            target = now.toLocalDate().plusDays(1).atTime(3, 30);
        }

        // Calculate duration in seconds
        long secondsUntilTarget = java.time.Duration.between(now, target).getSeconds();
        logger.trace("TTL calculated: {} seconds until 3:30 AM", secondsUntilTarget);

        return secondsUntilTarget;
    }
}
