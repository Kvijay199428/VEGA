package com.vegatrader.upstox.api.websocket.persistence;

import com.vegatrader.upstox.api.websocket.health.HealthFlags;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.util.zip.GZIPOutputStream;

/**
 * Filesystem archive handler for fallback storage.
 * 
 * <p>
 * Activated when both Redis AND DB are unavailable.
 * Ensures zero data loss by writing to gzipped files.
 * 
 * <p>
 * Directory structure:
 * 
 * <pre>
 * /archive/MarketDataStreamerV3/data/
 * └── 2025-12-27/
 *     ├── NSE_EQ|RELIANCE.gz
 *     ├── NSE_INDEX|Nifty50.gz
 *     └── ...
 * </pre>
 * 
 * @since 3.1.0
 */
public class FileArchiveHandler {

    private static final Logger logger = LoggerFactory.getLogger(FileArchiveHandler.class);

    private final Path baseDir;

    /**
     * Creates a file archive handler with default base directory.
     */
    public FileArchiveHandler() {
        this(Paths.get("/archive/MarketDataStreamerV3/data"));
    }

    /**
     * Creates a file archive handler with custom base directory.
     * 
     * @param baseDir the base directory for archives
     */
    public FileArchiveHandler(Path baseDir) {
        this.baseDir = baseDir;
        initializeDirectory();
    }

    /**
     * Initializes the base directory.
     */
    private void initializeDirectory() {
        try {
            Files.createDirectories(baseDir);
            logger.info("File archive initialized at: {}", baseDir.toAbsolutePath());
        } catch (IOException e) {
            logger.error("Failed to initialize archive directory: {}", e.getMessage(), e);
        }
    }

    /**
     * Archives a market data update.
     * 
     * <p>
     * Only writes if both Redis and DB are down.
     * Appends to gzipped file for the current date.
     * 
     * @param instrumentKey the instrument key
     * @param payload       the serialized market data
     */
    public void archive(String instrumentKey, byte[] payload) {
        // Only write if both primary stores are down
        if (HealthFlags.redisUp() || HealthFlags.dbUp()) {
            return;
        }

        try {
            Path dateDir = baseDir.resolve(LocalDate.now().toString());
            Files.createDirectories(dateDir);

            // Replace colons in instrument key for filesystem safety
            String safeFileName = instrumentKey.replace(":", "|") + ".gz";
            Path file = dateDir.resolve(safeFileName);

            // Append to gzipped file
            try (OutputStream os = new GZIPOutputStream(
                    Files.newOutputStream(file,
                            StandardOpenOption.CREATE,
                            StandardOpenOption.APPEND))) {

                os.write(payload);
                os.write('\n'); // Record delimiter
            }

            logger.trace("Archived {} to filesystem", instrumentKey);

        } catch (IOException e) {
            // Last resort: log and drop
            logger.error("Failed to archive to filesystem: {}", e.getMessage());
        }
    }

    /**
     * Gets the base directory path.
     * 
     * @return the base directory
     */
    public Path getBaseDir() {
        return baseDir;
    }
}
