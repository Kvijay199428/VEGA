package com.vegatrader.upstox.api.response.instrument;

import com.google.gson.annotations.SerializedName;

/**
 * Response DTO for instrument data.
 * Used for parsing instrument master CSV/JSON files.
 *
 * @since 2.0.0
 */
public class InstrumentResponse {

    @SerializedName("instrument_key")
    private String instrumentKey;

    @SerializedName("exchange_token")
    private String exchangeToken;

    @SerializedName("tradingsymbol")
    private String tradingSymbol;

    @SerializedName("name")
    private String name;

    @SerializedName("segment")
    private String segment;

    @SerializedName("exchange")
    private String exchange;

    @SerializedName("isin")
    private String isin;

    @SerializedName("expiry")
    private String expiry;

    @SerializedName("strike")
    private Double strike;

    @SerializedName("lot_size")
    private Integer lotSize;

    @SerializedName("instrument_type")
    private String instrumentType;

    @SerializedName("option_type")
    private String optionType;

    @SerializedName("tick_size")
    private Double tickSize;

    @SerializedName("last_price")
    private Double lastPrice;

    public InstrumentResponse() {
    }

    // Getters/Setters
    public String getInstrumentKey() {
        return instrumentKey;
    }

    public void setInstrumentKey(String instrumentKey) {
        this.instrumentKey = instrumentKey;
    }

    public String getExchangeToken() {
        return exchangeToken;
    }

    public void setExchangeToken(String exchangeToken) {
        this.exchangeToken = exchangeToken;
    }

    public String getTradingSymbol() {
        return tradingSymbol;
    }

    public void setTradingSymbol(String tradingSymbol) {
        this.tradingSymbol = tradingSymbol;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public String getExchange() {
        return exchange;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    public String getIsin() {
        return isin;
    }

    public void setIsin(String isin) {
        this.isin = isin;
    }

    public String getExpiry() {
        return expiry;
    }

    public void setExpiry(String expiry) {
        this.expiry = expiry;
    }

    public Double getStrike() {
        return strike;
    }

    public void setStrike(Double strike) {
        this.strike = strike;
    }

    public Integer getLotSize() {
        return lotSize;
    }

    public void setLotSize(Integer lotSize) {
        this.lotSize = lotSize;
    }

    public String getInstrumentType() {
        return instrumentType;
    }

    public void setInstrumentType(String instrumentType) {
        this.instrumentType = instrumentType;
    }

    public String getOptionType() {
        return optionType;
    }

    public void setOptionType(String optionType) {
        this.optionType = optionType;
    }

    public Double getTickSize() {
        return tickSize;
    }

    public void setTickSize(Double tickSize) {
        this.tickSize = tickSize;
    }

    public Double getLastPrice() {
        return lastPrice;
    }

    public void setLastPrice(Double lastPrice) {
        this.lastPrice = lastPrice;
    }

    public boolean isOption() {
        return "OPTION".equalsIgnoreCase(instrumentType);
    }

    public boolean isFuture() {
        return "FUTURE".equalsIgnoreCase(instrumentType);
    }

    public boolean isEquity() {
        return "EQUITY".equalsIgnoreCase(instrumentType);
    }

    public boolean isExpired() {
        // Logic to check if instrument is expired (requires date comparison)
        return expiry != null && !expiry.isEmpty();
    }

    @Override
    public String toString() {
        return String.format("Instrument{symbol='%s', type='%s', exchange='%s'}",
                tradingSymbol, instrumentType, exchange);
    }
}
