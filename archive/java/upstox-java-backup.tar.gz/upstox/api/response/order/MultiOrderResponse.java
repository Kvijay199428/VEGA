package com.vegatrader.upstox.api.response.order;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * Response DTO for multi-order placement.
 *
 * @since 2.0.0
 */
public class MultiOrderResponse {

    @SerializedName("orders")
    private List<OrderResult> orders;

    public MultiOrderResponse() {
    }

    public List<OrderResult> getOrders() {
        return orders;
    }

    public void setOrders(List<OrderResult> orders) {
        this.orders = orders;
    }

    public int getTotalOrders() {
        return orders != null ? orders.size() : 0;
    }

    public long getSuccessCount() {
        if (orders == null)
            return 0;
        return orders.stream()
                .filter(OrderResult::isSuccess)
                .count();
    }

    public long getFailedCount() {
        if (orders == null)
            return 0;
        return orders.stream()
                .filter(o -> !o.isSuccess())
                .count();
    }

    public boolean allSuccessful() {
        return orders != null && orders.stream().allMatch(OrderResult::isSuccess);
    }

    public boolean anySuccessful() {
        return orders != null && orders.stream().anyMatch(OrderResult::isSuccess);
    }

    public static class OrderResult {
        @SerializedName("order_id")
        private String orderId;

        @SerializedName("status")
        private String status;

        @SerializedName("message")
        private String message;

        @SerializedName("error_code")
        private String errorCode;

        @SerializedName("order_index")
        private Integer orderIndex;

        public OrderResult() {
        }

        public String getOrderId() {
            return orderId;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getErrorCode() {
            return errorCode;
        }

        public void setErrorCode(String errorCode) {
            this.errorCode = errorCode;
        }

        public Integer getOrderIndex() {
            return orderIndex;
        }

        public void setOrderIndex(Integer orderIndex) {
            this.orderIndex = orderIndex;
        }

        public boolean isSuccess() {
            return "SUCCESS".equalsIgnoreCase(status) ||
                    "PENDING".equalsIgnoreCase(status);
        }

        public boolean isFailed() {
            return "FAILED".equalsIgnoreCase(status) ||
                    "REJECTED".equalsIgnoreCase(status);
        }

        @Override
        public String toString() {
            if (isSuccess()) {
                return String.format("OrderResult{index=%d, orderId='%s', status='%s'}",
                        orderIndex, orderId, status);
            } else {
                return String.format("OrderResult{index=%d, status='%s', error='%s'}",
                        orderIndex, status, errorCode);
            }
        }
    }

    @Override
    public String toString() {
        return String.format("MultiOrderResponse{total=%d, success=%d, failed=%d}",
                getTotalOrders(), getSuccessCount(), getFailedCount());
    }
}
