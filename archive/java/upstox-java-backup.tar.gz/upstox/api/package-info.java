package com.vegatrader.upstox.api;

/**
 * Main entry point and README for Upstox API Integration.
 * <p>
 * This package provides a comprehensive, production-ready Java implementation
 * for integrating with Upstox API v2 and v3.
 * </p>
 *
 * <h2>Quick Start</h2>
 * <pre>{@code
 * // 1. Place an order
 * PlaceOrderRequest order = PlaceOrderRequest.builder()
 *     .instrumentKey("NSE_EQ|INE528G01035")
 *     .quantity(1)
 *     .product("D")
 *     .validity("DAY")
 *     .transactionType("BUY")
 *     .asMarketOrder()
 *     .build();
 *
 * // 2. Check rate limits
 * RateLimitManager manager = RateLimitManager.getInstance();
 * if (manager.checkLimit(OrderEndpoints.PLACE_ORDER).isAllowed()) {
 *     // Make API call
 *     manager.recordRequest(OrderEndpoints.PLACE_ORDER);
 * }
 *
 * // 3. Get sectoral data
 * SectorDataFetcher fetcher = new SectorDataFetcher();
 * List<SectorConstituent> niftyBank = fetcher.getTopConstituents(
 *     SectoralIndex.BANK, 10
 * );
 * }</pre>
 *
 * <h2>Package Structure</h2>
 * <ul>
 *   <li>{@code com.vegatrader.upstox.api.request} - Request DTOs</li>
 *   <li>{@code com.vegatrader.upstox.api.response} - Response DTOs</li>
 *   <li>{@code com.vegatrader.upstox.api.ratelimit} - Rate limiting system</li>
 *   <li>{@code com.vegatrader.upstox.api.sectoral} - NSE sectoral indices</li>
 *   <li>{@code com.vegatrader.upstox.api.errors} - Error handling</li>
 *   <li>{@code com.vegatrader.upstox.api.utils} - Utility classes</li>
 * </ul>
 *
 * <h2>Features</h2>
 * <ul>
 *   <li>✅ Complete order management (place, modify, cancel, GTT, multi-order)</li>
 *   <li>✅ Portfolio tracking (holdings, positions, P&L)</li>
 *   <li>✅ Market data (quotes, OHLC, candles, Greeks, option chains)</li>
 *   <li>✅ All 21 NSE sectoral indices</li>
 *   <li>✅ Production-ready rate limiting (auto-categorizing)</li>
 *   <li>✅ Comprehensive error handling</li>
 *   <li>✅ WebSocket market data feeds</li>
 *   <li>✅ Utility calculators (price, P&L, option strategies)</li>
 * </ul>
 *
 * <h2>Thread Safety</h2>
 * <p>
 * All rate limiters and caches are thread-safe. DTOs are immutable or designed
 * for single-threaded use in request contexts.
 * </p>
 *
 * <h2>Documentation</h2>
 * <ul>
 *   <li>{@link ImplementedEndpointsSummary} - Complete DTO catalog</li>
 *   <li>{@link com.vegatrader.upstox.api.examples.Phase2Examples} - Usage examples</li>
 *   <li>{@link com.vegatrader.upstox.api.utils.UpstoxConstants} - API constants</li>
 * </ul>
 *
 * @see com.vegatrader.upstox.api.request.order.PlaceOrderRequest
 * @see com.vegatrader.upstox.api.ratelimit.RateLimitManager
 * @see com.vegatrader.upstox.api.sectoral.SectoralIndex
 * @since 2.0.0
 * @version 2.0.0
 */
package com.vegatrader.upstox.api;
