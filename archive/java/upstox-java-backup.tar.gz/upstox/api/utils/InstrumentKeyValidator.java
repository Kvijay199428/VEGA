package com.vegatrader.upstox.api.utils;

/**
 * Utility class for validating instrument keys.
 *
 * @since 2.0.0
 */
public final class InstrumentKeyValidator {

    private InstrumentKeyValidator() {
        // Utility class - no instantiation
    }

    /**
     * Validates instrument key format.
     * Expected format: EXCHANGE|IDENTIFIER (e.g., NSE_EQ|INE528G01035)
     *
     * @param instrumentKey the instrument key to validate
     * @return true if valid, false otherwise
     */
    public static boolean isValid(String instrumentKey) {
        if (instrumentKey == null || instrumentKey.isEmpty()) {
            return false;
        }

        // Must contain pipe separator
        if (!instrumentKey.contains("|")) {
            return false;
        }

        String[] parts = instrumentKey.split("\\|");
        if (parts.length != 2) {
            return false;
        }

        // Exchange part should not be empty
        if (parts[0].isEmpty() || parts[1].isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Validates and throws exception if invalid.
     *
     * @param instrumentKey the instrument key to validate
     * @throws IllegalArgumentException if invalid
     */
    public static void validate(String instrumentKey) {
        if (!isValid(instrumentKey)) {
            throw new IllegalArgumentException(
                    "Invalid instrument key format. Expected: EXCHANGE|IDENTIFIER (e.g., NSE_EQ|INE528G01035)");
        }
    }

    /**
     * Extracts exchange from instrument key.
     *
     * @param instrumentKey the instrument key
     * @return exchange part
     */
    public static String getExchange(String instrumentKey) {
        validate(instrumentKey);
        return instrumentKey.split("\\|")[0];
    }

    /**
     * Extracts identifier from instrument key.
     *
     * @param instrumentKey the instrument key
     * @return identifier part
     */
    public static String getIdentifier(String instrumentKey) {
        validate(instrumentKey);
        return instrumentKey.split("\\|")[1];
    }

    /**
     * Checks if instrument is from NSE Equity.
     *
     * @param instrumentKey the instrument key
     * @return true if NSE_EQ
     */
    public static boolean isNSEEquity(String instrumentKey) {
        return instrumentKey != null && instrumentKey.startsWith("NSE_EQ|");
    }

    /**
     * Checks if instrument is from NSE F&O.
     *
     * @param instrumentKey the instrument key
     * @return true if NSE_FO
     */
    public static boolean isNSEFO(String instrumentKey) {
        return instrumentKey != null && instrumentKey.startsWith("NSE_FO|");
    }

    /**
     * Checks if instrument is an index.
     *
     * @param instrumentKey the instrument key
     * @return true if NSE_INDEX
     */
    public static boolean isIndex(String instrumentKey) {
        return instrumentKey != null && instrumentKey.startsWith("NSE_INDEX|");
    }

    /**
     * Builds an instrument key.
     *
     * @param exchange   the exchange
     * @param identifier the identifier
     * @return formatted instrument key
     */
    public static String build(String exchange, String identifier) {
        if (exchange == null || exchange.isEmpty()) {
            throw new IllegalArgumentException("Exchange is required");
        }
        if (identifier == null || identifier.isEmpty()) {
            throw new IllegalArgumentException("Identifier is required");
        }
        return exchange + "|" + identifier;
    }
}
