package com.vegatrader.upstox.auth.controller;

import com.vegatrader.upstox.auth.selenium.config.LoginCredentials;
import com.vegatrader.upstox.auth.selenium.config.SeleniumConfig;
import com.vegatrader.upstox.auth.selenium.integration.ApiConfig;
import com.vegatrader.upstox.auth.selenium.integration.AuthenticationOrchestrator;
import com.vegatrader.upstox.auth.selenium.workflow.MultiLoginOrchestrator;
import com.vegatrader.upstox.auth.response.TokenResponse;
import com.vegatrader.upstox.auth.service.TokenStorageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST controller for login automation endpoints.
 * 
 * Base URL: http://localhost:28021/api/v1/auth/selenium
 *
 * @since 2.0.0
 */
@RestController
@RequestMapping("/api/v1/auth/selenium")
public class LoginAutomationController {

    private static final Logger logger = LoggerFactory.getLogger(LoginAutomationController.class);

    @Autowired
    private TokenStorageService tokenStorageService;

    /**
     * Initiate single API login.
     *
     * POST http://localhost:28021/api/v1/auth/selenium/login
     */
    @PostMapping("/login")
    public ResponseEntity<?> loginSingleApi(@RequestBody LoginRequest request) {
        logger.info("Initiating login for API: {}", request.getApiName());

        try {
            // Validate request
            request.validate();

            // Create credentials
            LoginCredentials credentials = new LoginCredentials(
                    request.getUsername(),
                    request.getPassword(),
                    request.getTotpSecret());

            // Create Selenium config
            SeleniumConfig seleniumConfig = new SeleniumConfig(
                    request.getBrowser() != null ? request.getBrowser() : "chrome",
                    request.isHeadless());

            // Create orchestrator
            AuthenticationOrchestrator orchestrator = new AuthenticationOrchestrator(
                    seleniumConfig, tokenStorageService);

            // Perform authentication
            TokenResponse token = orchestrator.authenticate(
                    request.getApiName(),
                    request.getClientId(),
                    request.getClientSecret(),
                    request.getRedirectUri(),
                    credentials,
                    request.isPrimary());

            // Build response
            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("message", "Login successful");
            response.put("apiName", request.getApiName());
            response.put("tokenType", token.getTokenType());
            response.put("expiresIn", token.getExpiresIn());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Login failed", e);

            Map<String, Object> error = new HashMap<>();
            error.put("status", "error");
            error.put("message", "Login failed: " + e.getMessage());

            return ResponseEntity.status(500).body(error);
        }
    }

    /**
     * Initiate multi-login for multiple APIs.
     *
     * POST http://localhost:28021/api/v1/auth/selenium/multi-login
     */
    @PostMapping("/multi-login")
    public ResponseEntity<?> loginMultipleApis(@RequestBody MultiLoginRequest request) {
        logger.info("Initiating multi-login for {} APIs", request.getApiConfigs().size());

        try {
            // Create credentials
            LoginCredentials credentials = new LoginCredentials(
                    request.getUsername(),
                    request.getPassword(),
                    request.getTotpSecret());

            // Create Selenium config
            SeleniumConfig seleniumConfig = new SeleniumConfig("chrome", true);

            // Create orchestrator
            AuthenticationOrchestrator authOrchestrator = new AuthenticationOrchestrator(
                    seleniumConfig, tokenStorageService);

            // Create multi-login orchestrator
            MultiLoginOrchestrator multiLogin = new MultiLoginOrchestrator(
                    request.getApiConfigs(),
                    credentials,
                    seleniumConfig,
                    authOrchestrator);

            // Perform all logins
            MultiLoginOrchestrator.MultiLoginResult result = multiLogin.loginAll();

            // Build response
            Map<String, Object> response = new HashMap<>();
            response.put("status", result.isAllSuccessful() ? "success" : "partial");
            response.put("total", result.getTotalCount());
            response.put("successful", result.getSuccessCount());
            response.put("failed", result.getFailedCount());
            response.put("successfulApis", result.getSuccessful());
            response.put("failedApis", result.getFailed());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Multi-login failed", e);

            Map<String, Object> error = new HashMap<>();
            error.put("status", "error");
            error.put("message", "Multi-login failed: " + e.getMessage());

            return ResponseEntity.status(500).body(error);
        }
    }

    /**
     * Login request DTO.
     */
    public static class LoginRequest {
        private String apiName;
        private String clientId;
        private String clientSecret;
        private String redirectUri;
        private String username;
        private String password;
        private String totpSecret;
        private boolean isPrimary;
        private String browser;
        private boolean headless = true;

        public void validate() {
            if (apiName == null || apiName.isEmpty()) {
                throw new IllegalArgumentException("apiName is required");
            }
            if (clientId == null || clientId.isEmpty()) {
                throw new IllegalArgumentException("clientId is required");
            }
            if (username == null || username.isEmpty()) {
                throw new IllegalArgumentException("username is required");
            }
            if (password == null || password.isEmpty()) {
                throw new IllegalArgumentException("password is required");
            }
        }

        // Getters/Setters
        public String getApiName() {
            return apiName;
        }

        public void setApiName(String apiName) {
            this.apiName = apiName;
        }

        public String getClientId() {
            return clientId;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String getClientSecret() {
            return clientSecret;
        }

        public void setClientSecret(String clientSecret) {
            this.clientSecret = clientSecret;
        }

        public String getRedirectUri() {
            return redirectUri;
        }

        public void setRedirectUri(String redirectUri) {
            this.redirectUri = redirectUri;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getTotpSecret() {
            return totpSecret;
        }

        public void setTotpSecret(String totpSecret) {
            this.totpSecret = totpSecret;
        }

        public boolean isPrimary() {
            return isPrimary;
        }

        public void setPrimary(boolean primary) {
            isPrimary = primary;
        }

        public String getBrowser() {
            return browser;
        }

        public void setBrowser(String browser) {
            this.browser = browser;
        }

        public boolean isHeadless() {
            return headless;
        }

        public void setHeadless(boolean headless) {
            this.headless = headless;
        }
    }

    /**
     * Multi-login request DTO.
     */
    public static class MultiLoginRequest {
        private List<ApiConfig> apiConfigs;
        private String username;
        private String password;
        private String totpSecret;

        // Getters/Setters
        public List<ApiConfig> getApiConfigs() {
            return apiConfigs;
        }

        public void setApiConfigs(List<ApiConfig> apiConfigs) {
            this.apiConfigs = apiConfigs;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getTotpSecret() {
            return totpSecret;
        }

        public void setTotpSecret(String totpSecret) {
            this.totpSecret = totpSecret;
        }
    }
}
