package com.vegatrader.upstox.auth.service;

import com.vegatrader.upstox.auth.entity.UpstoxTokenEntity;
import com.vegatrader.upstox.auth.repository.TokenRepository;
import com.vegatrader.upstox.auth.response.TokenResponse;
import com.vegatrader.upstox.auth.utils.TokenExpiryCalculator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Service for token storage and retrieval operations.
 *
 * @since 2.0.0
 */
public class TokenStorageService {

    private static final Logger logger = LoggerFactory.getLogger(TokenStorageService.class);

    private final TokenRepository tokenRepository;

    public TokenStorageService() {
        this.tokenRepository = new TokenRepository();
    }

    public TokenStorageService(TokenRepository tokenRepository) {
        this.tokenRepository = tokenRepository;
    }

    /**
     * Store new token in database.
     *
     * @param tokenResponse token response from API
     * @param apiName       API name category (PRIMARY, WEBSOCKET1, etc.)
     * @param clientId      client ID
     * @param clientSecret  client secret
     * @param redirectUri   redirect URI
     * @param isPrimary     whether this is the primary token
     */
    public void storeToken(TokenResponse tokenResponse, String apiName,
            String clientId, String clientSecret,
            String redirectUri, boolean isPrimary) {

        UpstoxTokenEntity entity = new UpstoxTokenEntity();
        entity.setAccessToken(tokenResponse.getAccessToken());
        entity.setRefreshToken(tokenResponse.getRefreshToken());
        entity.setTokenType(tokenResponse.getTokenType());
        entity.setExpiresIn(tokenResponse.getExpiresIn());
        entity.setApiName(apiName);
        entity.setClientId(clientId);
        entity.setClientSecret(clientSecret);
        entity.setRedirectUri(redirectUri);
        entity.setIsPrimary(isPrimary);
        entity.setIsActive(1);
        entity.setCreatedAt(LocalDateTime.now());
        entity.setGeneratedAt(LocalDateTime.now().toString());
        entity.setValidityAt(TokenExpiryCalculator.calculateValidityAtString());

        tokenRepository.save(entity);

        logger.info("✓ Stored token for apiName: {}, isPrimary: {}", apiName, isPrimary);
    }

    /**
     * Update existing token with new access token.
     *
     * @param apiName       API name
     * @param tokenResponse new token response
     */
    public void updateToken(String apiName, TokenResponse tokenResponse) {
        Optional<UpstoxTokenEntity> existing = tokenRepository.findByApiName(apiName);

        if (existing.isPresent()) {
            UpstoxTokenEntity entity = existing.get();
            entity.setAccessToken(tokenResponse.getAccessToken());
            entity.setRefreshToken(tokenResponse.getRefreshToken());
            entity.setLastRefreshed(LocalDateTime.now());
            entity.setValidityAt(TokenExpiryCalculator.calculateValidityAtString());
            entity.setUpdatedAt(System.currentTimeMillis());

            tokenRepository.save(entity);

            logger.info("✓ Updated token for apiName: {}", apiName);
        } else {
            logger.warn("⚠ Token not found for update: {}", apiName);
        }
    }

    /**
     * Get token by API name.
     *
     * @param apiName API name
     * @return token entity or empty
     */
    public Optional<UpstoxTokenEntity> getToken(String apiName) {
        return tokenRepository.findByApiName(apiName);
    }

    /**
     * Get all active tokens.
     *
     * @return list of active tokens
     */
    public List<UpstoxTokenEntity> getAllActiveTokens() {
        return tokenRepository.findAllActive();
    }

    /**
     * Deactivate token by API name.
     *
     * @param apiName API name
     */
    public void deactivateToken(String apiName) {
        tokenRepository.deactivateByApiName(apiName);
        logger.info("✓ Deactivated token: {}", apiName);
    }

    /**
     * Check if token exists and is active.
     *
     * @param apiName API name
     * @return true if token exists and active
     */
    public boolean hasActiveToken(String apiName) {
        Optional<UpstoxTokenEntity> token = tokenRepository.findByApiName(apiName);
        return token.isPresent() && token.get().isActive();
    }

    /**
     * Get total count of active tokens.
     *
     * @return count
     */
    public int getActiveTokenCount() {
        return tokenRepository.countActive();
    }
}
