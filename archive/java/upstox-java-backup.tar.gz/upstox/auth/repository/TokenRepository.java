package com.vegatrader.upstox.auth.repository;

import com.vegatrader.upstox.auth.entity.UpstoxTokenEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Repository for accessing upstox_tokens table.
 * Provides CRUD operations for token management.
 *
 * @since 2.0.0
 */
public class TokenRepository {

    private static final Logger logger = LoggerFactory.getLogger(TokenRepository.class);

    private static final String DB_URL = "jdbc:sqlite:backend/java/database/vega_trader.db";

    static {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("SQLite JDBC driver not found", e);
        }
    }

    /**
     * Find token by API name (with primary preference).
     */
    public Optional<UpstoxTokenEntity> findByApiName(String apiName) {
        String sql = "SELECT * FROM upstox_tokens WHERE api_name = ? AND is_active = 1 " +
                "ORDER BY is_primary DESC LIMIT 1";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, apiName);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return Optional.of(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            logger.error("Error finding token by apiName: {}", apiName, e);
        }

        return Optional.empty();
    }

    /**
     * Find all active tokens.
     */
    public List<UpstoxTokenEntity> findAllActive() {
        String sql = "SELECT * FROM upstox_tokens WHERE is_active = 1 " +
                "ORDER BY api_name, is_primary DESC";

        List<UpstoxTokenEntity> tokens = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                tokens.add(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            logger.error("Error finding all active tokens", e);
        }

        return tokens;
    }

    /**
     * Find all active tokens by category prefix.
     */
    public List<UpstoxTokenEntity> findByApiNamePrefix(String prefix) {
        String sql = "SELECT * FROM upstox_tokens WHERE api_name LIKE ? AND is_active = 1 " +
                "ORDER BY api_name";

        List<UpstoxTokenEntity> tokens = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, prefix + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                tokens.add(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            logger.error("Error finding tokens by prefix: {}", prefix, e);
        }

        return tokens;
    }

    /**
     * Save or update token.
     */
    public void save(UpstoxTokenEntity token) {
        if (token.getId() == null) {
            insert(token);
        } else {
            update(token);
        }
    }

    /**
     * Insert new token.
     */
    private void insert(UpstoxTokenEntity token) {
        String sql = "INSERT INTO upstox_tokens (access_token, api_name, client_id, client_secret, " +
                "created_at, expires_in, is_primary, refresh_token, token_type, api_index, " +
                "generated_at, is_active, purpose, updated_at, user_id, validity_at, redirect_uri) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            setStatementParameters(stmt, token);
            stmt.executeUpdate();

            logger.info("Inserted new token for apiName: {}", token.getApiName());
        } catch (SQLException e) {
            logger.error("Error inserting token", e);
        }
    }

    /**
     * Update existing token.
     */
    private void update(UpstoxTokenEntity token) {
        String sql = "UPDATE upstox_tokens SET access_token = ?, refresh_token = ?, " +
                "last_refreshed = ?, is_active = ?, updated_at = ?, validity_at = ? " +
                "WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, token.getAccessToken());
            stmt.setString(2, token.getRefreshToken());
            stmt.setTimestamp(3, token.getLastRefreshed() != null ? Timestamp.valueOf(token.getLastRefreshed()) : null);
            stmt.setInt(4, token.getIsActive());
            stmt.setLong(5, System.currentTimeMillis());
            stmt.setString(6, token.getValidityAt());
            stmt.setInt(7, token.getId());

            stmt.executeUpdate();

            logger.info("Updated token id: {}, apiName: {}", token.getId(), token.getApiName());
        } catch (SQLException e) {
            logger.error("Error updating token", e);
        }
    }

    /**
     * Deactivate token by API name.
     */
    public void deactivateByApiName(String apiName) {
        String sql = "UPDATE upstox_tokens SET is_active = 0, updated_at = ? WHERE api_name = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, System.currentTimeMillis());
            stmt.setString(2, apiName);
            stmt.executeUpdate();

            logger.info("Deactivated tokens for apiName: {}", apiName);
        } catch (SQLException e) {
            logger.error("Error deactivating token", e);
        }
    }

    /**
     * Count active tokens.
     */
    public int countActive() {
        String sql = "SELECT COUNT(*) as count FROM upstox_tokens WHERE is_active = 1";

        try (Connection conn = DriverManager.getConnection(DB_URL);
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (SQLException e) {
            logger.error("Error counting active tokens", e);
        }

        return 0;
    }

    /**
     * Map ResultSet to UpstoxTokenEntity.
     */
    private UpstoxTokenEntity mapResultSetToEntity(ResultSet rs) throws SQLException {
        UpstoxTokenEntity entity = new UpstoxTokenEntity();
        entity.setId(rs.getInt("id"));
        entity.setAccessToken(rs.getString("access_token"));
        entity.setApiName(rs.getString("api_name"));
        entity.setClientId(rs.getString("client_id"));
        entity.setClientSecret(rs.getString("client_secret"));

        Timestamp createdTimestamp = rs.getTimestamp("created_at");
        if (createdTimestamp != null) {
            entity.setCreatedAt(createdTimestamp.toLocalDateTime());
        }

        entity.setExpiresIn(rs.getLong("expires_in"));
        entity.setIsPrimary(rs.getBoolean("is_primary"));

        Timestamp refreshedTimestamp = rs.getTimestamp("last_refreshed");
        if (refreshedTimestamp != null) {
            entity.setLastRefreshed(refreshedTimestamp.toLocalDateTime());
        }

        entity.setRedirectUri(rs.getString("redirect_uri"));
        entity.setRefreshToken(rs.getString("refresh_token"));
        entity.setTokenType(rs.getString("token_type"));
        entity.setApiIndex(rs.getInt("api_index"));
        entity.setGeneratedAt(rs.getString("generated_at"));
        entity.setIsActive(rs.getInt("is_active"));
        entity.setPurpose(rs.getString("purpose"));
        entity.setUpdatedAt(rs.getLong("updated_at"));
        entity.setUserId(rs.getInt("user_id"));
        entity.setValidityAt(rs.getString("validity_at"));

        return entity;
    }

    /**
     * Set prepared statement parameters for insert.
     */
    private void setStatementParameters(PreparedStatement stmt, UpstoxTokenEntity token)
            throws SQLException {
        stmt.setString(1, token.getAccessToken());
        stmt.setString(2, token.getApiName());
        stmt.setString(3, token.getClientId());
        stmt.setString(4, token.getClientSecret());
        stmt.setTimestamp(5, token.getCreatedAt() != null ? Timestamp.valueOf(token.getCreatedAt())
                : Timestamp.valueOf(LocalDateTime.now()));
        stmt.setLong(6, token.getExpiresIn() != null ? token.getExpiresIn() : 86400);
        stmt.setBoolean(7, token.getIsPrimary() != null ? token.getIsPrimary() : false);
        stmt.setString(8, token.getRefreshToken());
        stmt.setString(9, token.getTokenType());
        stmt.setInt(10, token.getApiIndex() != null ? token.getApiIndex() : 0);
        stmt.setString(11, token.getGeneratedAt());
        stmt.setInt(12, token.getIsActive() != null ? token.getIsActive() : 1);
        stmt.setString(13, token.getPurpose());
        stmt.setLong(14, System.currentTimeMillis());
        stmt.setInt(15, token.getUserId() != null ? token.getUserId() : 0);
        stmt.setString(16, token.getValidityAt());
        stmt.setString(17, token.getRedirectUri());
    }
}
