package com.vegatrader.upstox.auth.selenium.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;

/**
 * Page Object for Upstox login page.
 * Handles username/password entry and login button click.
 *
 * @since 2.0.0
 */
public class LoginPage {

    private static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

    private final WebDriver driver;
    private final WebDriverWait wait;

    // Locators (update these based on actual Upstox login page)
    private static final By USERNAME_FIELD = By.id("mobileNum");
    private static final By PASSWORD_FIELD = By.id("password");
    private static final By LOGIN_BUTTON = By
            .xpath("//button[contains(text(), 'Continue') or contains(text(), 'Login')]");
    private static final By ERROR_MESSAGE = By.className("error-message");
    private static final By TOTP_FIELD = By.id("totpCode"); // If TOTP is required

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    /**
     * Navigate to Upstox OAuth authorization URL.
     *
     * @param authorizationUrl complete authorization URL
     */
    public void navigateToAuthUrl(String authorizationUrl) {
        logger.info("Navigating to: {}", authorizationUrl);
        driver.get(authorizationUrl);

        // Wait for page to load
        wait.until(ExpectedConditions.or(
                ExpectedConditions.presenceOfElementLocated(USERNAME_FIELD),
                ExpectedConditions.presenceOfElementLocated(PASSWORD_FIELD)));
    }

    /**
     * Enter username (mobile number).
     *
     * @param username username or mobile number
     */
    public void enterUsername(String username) {
        logger.info("Entering username: {}", username);

        WebElement usernameField = wait.until(
                ExpectedConditions.elementToBeClickable(USERNAME_FIELD));
        usernameField.clear();
        usernameField.sendKeys(username);
    }

    /**
     * Enter password.
     *
     * @param password password
     */
    public void enterPassword(String password) {
        logger.info("Entering password");

        WebElement passwordField = wait.until(
                ExpectedConditions.elementToBeClickable(PASSWORD_FIELD));
        passwordField.clear();
        passwordField.sendKeys(password);
    }

    /**
     * Click login/continue button.
     */
    public void clickLoginButton() {
        logger.info("Clicking login button");

        WebElement loginButton = wait.until(
                ExpectedConditions.elementToBeClickable(LOGIN_BUTTON));
        loginButton.click();

        // Wait a moment for page transition
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Enter TOTP code if required.
     *
     * @param totpCode TOTP code
     */
    public void enterTOTP(String totpCode) {
        logger.info("Entering TOTP code");

        try {
            WebElement totpField = wait.until(
                    ExpectedConditions.presenceOfElementLocated(TOTP_FIELD));
            totpField.clear();
            totpField.sendKeys(totpCode);
        } catch (Exception e) {
            logger.warn("TOTP field not found or not required");
        }
    }

    /**
     * Check if error message is displayed.
     *
     * @return true if error exists
     */
    public boolean hasError() {
        try {
            return driver.findElements(ERROR_MESSAGE).size() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Get error message text.
     *
     * @return error message or empty string
     */
    public String getErrorMessage() {
        try {
            WebElement error = driver.findElement(ERROR_MESSAGE);
            return error.getText();
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Perform complete login sequence.
     *
     * @param username username
     * @param password password
     */
    public void login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();

        if (hasError()) {
            String errorMsg = getErrorMessage();
            logger.error("Login error: {}", errorMsg);
            throw new RuntimeException("Login failed: " + errorMsg);
        }
    }
}
