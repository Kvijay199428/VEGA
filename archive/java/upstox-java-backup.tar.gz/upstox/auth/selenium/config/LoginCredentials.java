package com.vegatrader.upstox.auth.selenium.config;

/**
 * DTO for storing login credentials.
 *
 * @since 2.0.0
 */
public class LoginCredentials {

    private String username;
    private String password;
    private String totpSecret; // For TOTP/2FA if needed

    public LoginCredentials() {
    }

    public LoginCredentials(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public LoginCredentials(String username, String password, String totpSecret) {
        this.username = username;
        this.password = password;
        this.totpSecret = totpSecret;
    }

    /**
     * Validate credentials.
     */
    public void validate() {
        if (username == null || username.isEmpty()) {
            throw new IllegalArgumentException("Username is required");
        }
        if (password == null || password.isEmpty()) {
            throw new IllegalArgumentException("Password is required");
        }
    }

    // Getters/Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTotpSecret() {
        return totpSecret;
    }

    public void setTotpSecret(String totpSecret) {
        this.totpSecret = totpSecret;
    }

    public boolean hasTotpSecret() {
        return totpSecret != null && !totpSecret.isEmpty();
    }

    @Override
    public String toString() {
        return String.format("LoginCredentials{username='%s', hasTOTP=%b}",
                username, hasTotpSecret());
    }
}
